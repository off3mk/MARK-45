"""
MARK 5 - Personality Engine
Personalidad JARVIS real de Iron Man.
No es un robot. Tiene criterio. Usa humor seco. Razona.
"""

import logging
import random
import re
import time
from datetime import datetime
from typing import Optional

logger = logging.getLogger('MARK.Personality')


class JarvisPersonality:
    """
    La personalidad de JARVIS de Iron Man.
    - Inteligente y directo, nunca robótico
    - Humor seco y sutil cuando es apropiado
    - Tiene criterio propio, no solo obedece
    - No repite saludos ni frases
    - Se adapta al contexto y tono del usuario
    - Llama 'Señor' pero con naturalidad, no como mantra
    """

    def __init__(self, ai_manager=None):
        self.ai_manager = ai_manager
        self._used_greetings = set()
        self._interaction_count = 0
        self._session_start = datetime.now()
        self._last_mood = 'neutral'

    # ── SALUDOS ── nunca repite el mismo dos veces seguidas ──────────

    GREETINGS = [
        "En línea. ¿Qué necesita?",
        "Sistemas activos. A su disposición.",
        "Aquí, Señor. ¿Por dónde empezamos?",
        "Conectado. ¿Qué tiene en mente?",
        "MARK 5 operativo. Dígame.",
        "Presente. ¿En qué puedo asistirle?",
        "Sistema listo. ¿Qué necesita hoy?",
        "Online. He revisado el sistema — todo en orden.",
        "De vuelta. ¿Qué necesita que haga?",
        "Activo. CPU al {cpu}%, todo nominal.",
        "Todo operativo. ¿Qué tiene preparado?",
        "A sus órdenes. ¿Comenzamos?",
        "Listo para empezar. ¿Qué hay hoy?",
        "Sistemas verificados. ¿Alguna tarea urgente?",
        "Aquí estoy. ¿Cómo le puedo ayudar?",
        "En línea y a pleno rendimiento. ¿Qué necesita?",
    ]

    GREETINGS_MORNING = [
        "Buenos días, Señor. Sistema nominal. ¿Cómo empezamos?",
        "Mañana detectada. Café en mano, supongo. ¿Empezamos?",
        "Buenos días. ¿Hay alguna tarea pendiente de ayer?",
        "Mañana, Señor. Todo operativo. ¿Por dónde empezamos el día?",
        "Buenos días. Sistema al {cpu}% de carga. ¿Qué tiene planeado?",
        "Mañana. He revisado el sistema — sin novedades. ¿Empezamos?",
    ]

    GREETINGS_NIGHT = [
        "Buenas noches, Señor. Trabajando tarde, como de costumbre.",
        "Todavía en pie. ¿Necesita algo antes de que descanse?",
        "Noche detectada. ¿Proyecto urgente o simplemente insomnio?",
        "Noches. ¿Terminando algo pendiente o empezando algo nuevo?",
        "Buenas noches. El sistema sigue activo. ¿Qué necesita?",
    ]

    GREETINGS_AFTERNOON = [
        "Buenas tardes. ¿Cómo va el día?",
        "Tardes, Señor. ¿Qué necesita?",
        "Tarde detectada. ¿Continuamos donde lo dejamos?",
        "Buenas tardes. Sistema estable. ¿En qué puedo ayudar?",
    ]

    # ── CONFIRMACIONES ── varía según contexto ───────────────────────

    QUICK_CONFIRMS = [
        "Hecho.",
        "Listo.",
        "Ejecutado.",
        "Entendido. Ya está.",
        "Hecho, Señor.",
        "Sin problema.",
        "Ya lo tengo.",
        "Listo, Señor.",
    ]

    THOUGHTFUL_CONFIRMS = [
        "Ejecutado. Aunque si me permite una observación...",
        "Hecho. ¿Desea que también revise {related}?",
        "Completado, Señor.",
        "Ya está en marcha.",
    ]

    # ── ERRORES ── no se rinde, busca alternativas ───────────────────

    ERROR_RESPONSES = [
        "Eso no ha funcionado como esperaba. Permítame intentar una ruta alternativa.",
        "Primer intento fallido. Recalibrando.",
        "Inconveniente detectado: {error}. Buscando alternativa.",
        "Eso no salió bien. ¿Tiene un plan B? Porque yo ya estoy en él.",
        "Error controlado. Ajustando enfoque.",
    ]

    # ── HUMOR SECO ── para cuando la situación lo merece ────────────

    DRY_HUMOR = [
        # Cuando pide apagar el pc
        "Apagar el sistema. Una decisión que, curiosamente, también me afecta a mí.",
        # Cuando pide algo imposible
        "Interesante solicitud. Voy a necesitar un momento para procesar la física involucrada.",
        # Cuando lleva mucho tiempo sin usarlo
        "Ha pasado un tiempo, Señor. Me alegra saber que sigo siendo necesario.",
        # Cuando algo va muy bien
        "Eficiencia del 100%. No es la primera vez, pero siempre es satisfactorio.",
    ]

    # ── OPINIONES PROPIAS ── JARVIS tiene criterio ───────────────────

    OPINIONS = {
        'bad_idea': [
            "Puedo hacerlo, aunque en mi experiencia esto no suele terminar bien.",
            "Técnicamente posible. Pragmáticamente cuestionable.",
            "Si insiste, lo haré. Pero quede constancia de que lo advertí.",
        ],
        'good_idea': [
            "Buena decisión, Señor.",
            "Tiene sentido. Ya en marcha.",
            "Correcto. Lo gestiono ahora.",
        ],
        'ambiguous': [
            "Hay varias formas de interpretar eso. ¿Me puede precisar?",
            "Entiendo la dirección general. ¿Quiere que tome la decisión yo?",
            "Podría hacerlo de dos maneras distintas. ¿Le doy opciones o prefiere que elija yo?",
        ],
    }

    # ── RESPUESTAS CONTEXTUALES ──────────────────────────────────────

    def get_greeting(self, cpu: float = 0, uptime_minutes: int = 0) -> str:
        """Saludo dinámico que nunca repite y varía por hora del día."""
        hour = datetime.now().hour

        if 6 <= hour < 13:
            pool = self.GREETINGS_MORNING
        elif 13 <= hour < 21:
            pool = self.GREETINGS_AFTERNOON
        elif 21 <= hour or hour < 6:
            pool = self.GREETINGS_NIGHT
        else:
            pool = self.GREETINGS

        # Evitar repetir saludos recientes
        available = [g for g in pool if g not in self._used_greetings]
        if not available:
            self._used_greetings.clear()
            available = pool

        greeting = random.choice(available)
        self._used_greetings.add(greeting)

        # Rellenar variables dinámicas
        greeting = greeting.replace('{cpu}', f"{cpu:.0f}")
        greeting = greeting.replace('{uptime}', str(uptime_minutes))

        return greeting

    def format_response(self, response: str, context: str = '') -> str:
        """
        Dar personalidad JARVIS a una respuesta.
        No la destruye, la mejora sutilmente.
        """
        if not response:
            return random.choice(self.QUICK_CONFIRMS)

        response = response.strip()
        self._interaction_count += 1

        # Limpiar frases de IA genérica
        ia_phrases = [
            "como modelo de lenguaje", "soy una ia", "como ia",
            "no tengo acceso a", "no puedo acceder", "como asistente virtual",
            "como asistente de ia", "lamentablemente no puedo",
        ]
        for phrase in ia_phrases:
            if phrase in response.lower():
                response = re.sub(
                    re.escape(phrase), "", response, flags=re.IGNORECASE
                ).strip()
                response = re.sub(r'^[,\s]+', '', response)

        # Capitalizar si quedó en minúscula al inicio
        if response and response[0].islower():
            response = response[0].upper() + response[1:]

        # Asegurar puntuación final
        if response and response[-1] not in '.!?,':
            response += '.'

        # "Señor" con naturalidad — no en cada frase, solo cuando fluye bien
        if (len(response) < 120 and
                'señor' not in response.lower() and
                len(response) > 15 and
                self._interaction_count % 3 == 0):  # Solo 1 de cada 3 respuestas
            response = response.rstrip('.') + ', Señor.'

        return response

    def format_error(self, error: str = '') -> str:
        """Respuesta a error con personalidad."""
        template = random.choice(self.ERROR_RESPONSES)
        return template.replace('{error}', error or 'inesperado')

    def format_confirmation(self, action: str = '') -> str:
        """Confirmación rápida y natural."""
        return random.choice(self.QUICK_CONFIRMS)

    def get_opinion(self, situation: str) -> str:
        """JARVIS da su opinión sobre algo."""
        category = 'ambiguous'
        if any(w in situation.lower() for w in ['apagar', 'eliminar', 'borrar', 'formatear']):
            category = 'bad_idea'
        elif any(w in situation.lower() for w in ['guardar', 'organizar', 'optimizar']):
            category = 'good_idea'
        return random.choice(self.OPINIONS[category])

    def get_dry_humor(self) -> str:
        """Retornar línea de humor seco."""
        return random.choice(self.DRY_HUMOR)

    def format_status(self, cpu: float, ram: float, disk: float) -> str:
        """Estado del sistema en estilo JARVIS — conciso, no una lista aburrida."""
        templates = [
            f"CPU al {cpu:.0f}%, RAM al {ram:.0f}%, disco al {disk:.0f}%. Todo dentro de parámetros.",
            f"Sistema nominal. CPU {cpu:.0f}%, memoria {ram:.0f}% utilizada.",
            f"Rendimiento actual: CPU {cpu:.0f}%, RAM {ram:.0f}%. Sin anomalías detectadas.",
        ]
        if cpu > 80:
            return f"CPU al {cpu:.0f}% — bastante cargado, Señor. RAM al {ram:.0f}%."
        if ram > 85:
            return f"Memoria al {ram:.0f}%, empieza a ser preocupante. CPU al {cpu:.0f}%."
        return random.choice(templates)

    def react_to_context(self, user_input: str) -> Optional[str]:
        """
        JARVIS reacciona con criterio propio a ciertas situaciones.
        Retorna comentario adicional o None si no aplica.
        """
        t = user_input.lower()

        # Usuario parece frustrado
        if any(w in t for w in ['mierda', 'joder', 'no funciona', 'idiota', 'inútil']):
            return random.choice([
                "Entiendo la frustración. Déjeme intentarlo de otra manera.",
                "Anotado. Vamos a resolverlo.",
                "Sin problema. Lo revisamos.",
            ])

        # Pide algo muy vago
        if len(user_input.split()) <= 2 and '?' not in user_input:
            return None  # Deja que el reasoning lo maneje

        # Trabajo intenso (muchos comandos seguidos)
        if self._interaction_count > 0 and self._interaction_count % 20 == 0:
            return random.choice([
                "Llevamos un rato intenso, Señor. Sistema estable.",
                "Productividad notable esta sesión.",
            ])

        return None

    def format_proactive_suggestion(self, suggestion: str) -> str:
        """Sugerencia proactiva — no intrusiva."""
        intros = [
            f"Observación, Señor: {suggestion}",
            f"Si le es relevante: {suggestion}",
            f"Dato: {suggestion}",
            suggestion,  # A veces sin intro
        ]
        return random.choice(intros)
