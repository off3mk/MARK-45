"""
JARVIS v4.0 - Memoria Cognitiva Avanzada
Aprende hábitos, detecta patrones temporales, infiere rutinas automáticamente.
"""

import logging
import sqlite3
import json
import os
import time
import threading
import math
from datetime import datetime, timedelta
from typing import Optional, List, Dict, Any, Tuple
from collections import defaultdict, Counter

logger = logging.getLogger('JARVIS.CognitiveMemory')

DB_PATH = os.path.join(os.path.dirname(os.path.dirname(__file__)), 'memory', 'cognitive.db')


class PatternAnalyzer:
    """Analiza patrones temporales en acciones del usuario."""

    def analyze_temporal_patterns(self, actions: List[Dict]) -> List[Dict]:
        """Detectar patrones de hora/día en una lista de acciones."""
        if not actions:
            return []

        patterns = []
        by_hour: Dict[int, List] = defaultdict(list)
        by_weekday: Dict[int, List] = defaultdict(list)

        for a in actions:
            ts = a.get('timestamp', '')
            if ts:
                try:
                    dt = datetime.fromisoformat(ts)
                    by_hour[dt.hour].append(a)
                    by_weekday[dt.weekday()].append(a)
                except Exception:
                    pass

        # Horas con más actividad
        for hour, acts in by_hour.items():
            if len(acts) >= 3:
                patterns.append({
                    'type': 'hourly',
                    'hour': hour,
                    'frequency': len(acts),
                    'action': Counter(a.get('action', '') for a in acts).most_common(1)[0][0],
                    'confidence': min(len(acts) / 10.0, 1.0),
                })

        # Días con más actividad
        days = ['Lunes', 'Martes', 'Miércoles', 'Jueves', 'Viernes', 'Sábado', 'Domingo']
        for dow, acts in by_weekday.items():
            if len(acts) >= 2:
                patterns.append({
                    'type': 'weekly',
                    'day': days[dow],
                    'day_index': dow,
                    'frequency': len(acts),
                    'action': Counter(a.get('action', '') for a in acts).most_common(1)[0][0],
                    'confidence': min(len(acts) / 7.0, 1.0),
                })

        return sorted(patterns, key=lambda x: x['confidence'], reverse=True)

    def detect_sequences(self, actions: List[Dict], window: int = 3) -> List[Dict]:
        """Detectar secuencias de acciones que ocurren juntas."""
        if len(actions) < window:
            return []

        # Agrupar por sesiones (acciones dentro de 5 min)
        sessions = []
        current_session = [actions[0]]
        for i in range(1, len(actions)):
            try:
                t1 = datetime.fromisoformat(actions[i-1].get('timestamp', ''))
                t2 = datetime.fromisoformat(actions[i].get('timestamp', ''))
                if (t2 - t1).total_seconds() < 300:
                    current_session.append(actions[i])
                else:
                    if len(current_session) >= 2:
                        sessions.append(current_session)
                    current_session = [actions[i]]
            except Exception:
                current_session.append(actions[i])
        if len(current_session) >= 2:
            sessions.append(current_session)

        # Encontrar secuencias frecuentes
        seq_counter: Counter = Counter()
        for session in sessions:
            action_seq = tuple(a.get('action', '') for a in session[:window])
            if len(action_seq) >= 2:
                seq_counter[action_seq] += 1

        sequences = []
        for seq, count in seq_counter.most_common(5):
            if count >= 2:
                sequences.append({
                    'sequence': list(seq),
                    'frequency': count,
                    'confidence': min(count / 5.0, 1.0),
                })

        return sequences


class HabitLearner:
    """Aprende hábitos del usuario y genera sugerencias proactivas."""

    def __init__(self):
        self.analyzer = PatternAnalyzer()

    def should_suggest(self, action: str, hour: int, weekday: int,
                       patterns: List[Dict]) -> Tuple[bool, str]:
        """Determinar si se debe hacer una sugerencia basada en patrones."""
        for p in patterns:
            if p.get('action') == action:
                if p['type'] == 'hourly' and abs(p['hour'] - hour) <= 1:
                    if p['confidence'] > 0.5:
                        return True, (f"Señor, basándome en sus hábitos, suelo "
                                      f"asistirle con '{action}' a esta hora.")
                if p['type'] == 'weekly' and p.get('day_index') == weekday:
                    if p['confidence'] > 0.4:
                        return True, (f"Señor, los {p['day']} frecuentemente "
                                      f"ejecuta '{action}'.")
        return False, ""

    def get_predictive_actions(self, hour: int, weekday: int,
                                patterns: List[Dict]) -> List[str]:
        """Obtener acciones que probablemente querrá el usuario ahora."""
        predictions = []
        for p in patterns:
            if p['confidence'] < 0.3:
                continue
            if p['type'] == 'hourly' and abs(p.get('hour', -99) - hour) <= 1:
                predictions.append(p['action'])
            elif p['type'] == 'weekly' and p.get('day_index') == weekday:
                predictions.append(p['action'])
        return list(set(predictions))[:3]


class CognitiveMemory:
    """
    Sistema de memoria cognitiva avanzada.
    Aprende patrones, hábitos y rutinas del usuario automáticamente.
    """

    def __init__(self):
        self.db_path = DB_PATH
        self.conn: Optional[sqlite3.Connection] = None
        self._lock = threading.Lock()
        self._pattern_cache: Optional[List[Dict]] = None
        self._cache_time: float = 0
        self._cache_ttl = 300  # 5 minutos
        self.pattern_analyzer = PatternAnalyzer()
        self.habit_learner = HabitLearner()

    def initialize(self):
        """Inicializar base de datos cognitiva."""
        os.makedirs(os.path.dirname(self.db_path), exist_ok=True)
        self.conn = sqlite3.connect(self.db_path, check_same_thread=False)
        self.conn.row_factory = sqlite3.Row
        self._create_tables()
        logger.info("Memoria cognitiva inicializada")

    def _create_tables(self):
        with self._lock:
            self.conn.executescript("""
                CREATE TABLE IF NOT EXISTS action_log (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    timestamp TEXT NOT NULL,
                    action TEXT NOT NULL,
                    skill TEXT,
                    params TEXT,
                    context TEXT,
                    success INTEGER DEFAULT 1,
                    hour_of_day INTEGER,
                    day_of_week INTEGER,
                    session_id TEXT
                );

                CREATE TABLE IF NOT EXISTS habit_patterns (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    pattern_type TEXT NOT NULL,
                    action TEXT NOT NULL,
                    time_hour INTEGER DEFAULT -1,
                    day_of_week INTEGER DEFAULT -1,
                    frequency INTEGER DEFAULT 1,
                    confidence REAL DEFAULT 0.0,
                    last_updated TEXT,
                    metadata TEXT
                );

                CREATE TABLE IF NOT EXISTS app_usage (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    app_name TEXT NOT NULL,
                    open_time TEXT NOT NULL,
                    duration_seconds INTEGER DEFAULT 0,
                    day_of_week INTEGER,
                    hour_of_day INTEGER
                );

                CREATE TABLE IF NOT EXISTS user_profile (
                    key TEXT PRIMARY KEY,
                    value TEXT NOT NULL,
                    confidence REAL DEFAULT 1.0,
                    updated_at TEXT
                );

                CREATE TABLE IF NOT EXISTS interaction_sessions (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    session_id TEXT UNIQUE,
                    start_time TEXT,
                    end_time TEXT,
                    command_count INTEGER DEFAULT 0,
                    dominant_skill TEXT
                );

                CREATE INDEX IF NOT EXISTS idx_action_ts ON action_log(timestamp);
                CREATE INDEX IF NOT EXISTS idx_action_name ON action_log(action);
                CREATE INDEX IF NOT EXISTS idx_habit_action ON habit_patterns(action);
            """)
            self.conn.commit()

    def log_action(self, action: str, skill: str = '', params: Dict = None,
                   success: bool = True, context: str = ''):
        """Registrar una acción del usuario para aprendizaje."""
        now = datetime.now()
        try:
            with self._lock:
                self.conn.execute(
                    """INSERT INTO action_log
                       (timestamp, action, skill, params, context, success, hour_of_day, day_of_week)
                       VALUES (?, ?, ?, ?, ?, ?, ?, ?)""",
                    (now.isoformat(), action, skill,
                     json.dumps(params or {}), context,
                     1 if success else 0, now.hour, now.weekday())
                )
                self.conn.commit()

            # Actualizar patrones cada 10 acciones
            self._maybe_update_patterns()
            self._invalidate_cache()

        except Exception as e:
            logger.debug(f"Error registrando acción: {e}")

    def _maybe_update_patterns(self):
        """Actualizar patrones de hábitos periódicamente."""
        try:
            with self._lock:
                count = self.conn.execute(
                    "SELECT COUNT(*) FROM action_log"
                ).fetchone()[0]
            if count % 10 == 0:
                threading.Thread(target=self._update_patterns, daemon=True).start()
        except Exception:
            pass

    def _update_patterns(self):
        """Recalcular patrones de hábitos desde el log."""
        try:
            with self._lock:
                rows = self.conn.execute(
                    """SELECT action, skill, hour_of_day, day_of_week, timestamp
                       FROM action_log
                       WHERE success = 1
                       ORDER BY timestamp DESC
                       LIMIT 500"""
                ).fetchall()

            if not rows:
                return

            actions = [dict(r) for r in rows]

            # Frecuencia por acción y hora
            hourly: Dict[Tuple, int] = defaultdict(int)
            daily: Dict[Tuple, int] = defaultdict(int)

            for a in actions:
                h = a.get('hour_of_day', -1)
                d = a.get('day_of_week', -1)
                action = a.get('action', '')
                if h >= 0:
                    hourly[(action, h)] += 1
                if d >= 0:
                    daily[(action, d)] += 1

            # Guardar patrones significativos
            patterns_to_save = []
            for (action, hour), freq in hourly.items():
                if freq >= 2:
                    conf = min(freq / 8.0, 1.0)
                    patterns_to_save.append(
                        ('hourly', action, hour, -1, freq, conf)
                    )

            for (action, dow), freq in daily.items():
                if freq >= 2:
                    conf = min(freq / 4.0, 1.0)
                    patterns_to_save.append(
                        ('weekly', action, -1, dow, freq, conf)
                    )

            now = datetime.now().isoformat()
            with self._lock:
                self.conn.execute("DELETE FROM habit_patterns")
                self.conn.executemany(
                    """INSERT INTO habit_patterns
                       (pattern_type, action, time_hour, day_of_week, frequency, confidence, last_updated)
                       VALUES (?, ?, ?, ?, ?, ?, ?)""",
                    [(p[0], p[1], p[2], p[3], p[4], p[5], now) for p in patterns_to_save]
                )
                self.conn.commit()

            logger.debug(f"Patrones actualizados: {len(patterns_to_save)} patrones")
            self._invalidate_cache()

        except Exception as e:
            logger.debug(f"Error actualizando patrones: {e}")

    def get_patterns(self, min_confidence: float = 0.2) -> List[Dict]:
        """Obtener patrones de hábitos detectados."""
        now = time.time()
        if self._pattern_cache and (now - self._cache_time) < self._cache_ttl:
            return self._pattern_cache

        try:
            with self._lock:
                rows = self.conn.execute(
                    """SELECT pattern_type, action, time_hour, day_of_week,
                              frequency, confidence, last_updated
                       FROM habit_patterns
                       WHERE confidence >= ?
                       ORDER BY confidence DESC""",
                    (min_confidence,)
                ).fetchall()
            patterns = [dict(r) for r in rows]
            self._pattern_cache = patterns
            self._cache_time = now
            return patterns
        except Exception as e:
            logger.debug(f"Error obteniendo patrones: {e}")
            return []

    def _invalidate_cache(self):
        self._pattern_cache = None

    def get_predictions_for_now(self) -> List[str]:
        """Obtener acciones predichas para el momento actual."""
        now = datetime.now()
        patterns = self.get_patterns(min_confidence=0.3)
        return self.habit_learner.get_predictive_actions(
            now.hour, now.weekday(), patterns
        )

    def record_app_open(self, app_name: str):
        """Registrar apertura de aplicación."""
        now = datetime.now()
        try:
            with self._lock:
                self.conn.execute(
                    """INSERT INTO app_usage (app_name, open_time, day_of_week, hour_of_day)
                       VALUES (?, ?, ?, ?)""",
                    (app_name, now.isoformat(), now.weekday(), now.hour)
                )
                self.conn.commit()
        except Exception as e:
            logger.debug(f"Error registrando app: {e}")

    def get_most_used_apps(self, limit: int = 5) -> List[Dict]:
        """Obtener las apps más usadas."""
        try:
            with self._lock:
                rows = self.conn.execute(
                    """SELECT app_name, COUNT(*) as uses,
                              AVG(hour_of_day) as avg_hour
                       FROM app_usage
                       GROUP BY app_name
                       ORDER BY uses DESC
                       LIMIT ?""",
                    (limit,)
                ).fetchall()
            return [dict(r) for r in rows]
        except Exception:
            return []

    def get_action_frequency(self, action: str, days: int = 7) -> int:
        """Obtener frecuencia de una acción en los últimos N días."""
        cutoff = (datetime.now() - timedelta(days=days)).isoformat()
        try:
            with self._lock:
                row = self.conn.execute(
                    "SELECT COUNT(*) FROM action_log WHERE action = ? AND timestamp > ?",
                    (action, cutoff)
                ).fetchone()
            return row[0] if row else 0
        except Exception:
            return 0

    def save_profile(self, key: str, value: Any, confidence: float = 1.0):
        """Guardar dato del perfil del usuario."""
        try:
            val = json.dumps(value) if not isinstance(value, str) else value
            now = datetime.now().isoformat()
            with self._lock:
                self.conn.execute(
                    """INSERT OR REPLACE INTO user_profile (key, value, confidence, updated_at)
                       VALUES (?, ?, ?, ?)""",
                    (key, val, confidence, now)
                )
                self.conn.commit()
        except Exception as e:
            logger.debug(f"Error guardando perfil: {e}")

    def get_profile(self, key: str) -> Optional[Any]:
        """Obtener dato del perfil del usuario."""
        try:
            with self._lock:
                row = self.conn.execute(
                    "SELECT value FROM user_profile WHERE key = ?", (key,)
                ).fetchone()
            if row:
                try:
                    return json.loads(row['value'])
                except Exception:
                    return row['value']
        except Exception:
            pass
        return None

    def get_habit_summary(self) -> str:
        """Generar resumen de hábitos para JARVIS."""
        patterns = self.get_patterns(min_confidence=0.3)
        if not patterns:
            return "Aún no tengo suficientes datos para detectar patrones, Señor."

        lines = [f"He detectado {len(patterns)} patrones de comportamiento, Señor:"]
        days = ['lunes', 'martes', 'miércoles', 'jueves', 'viernes', 'sábado', 'domingo']

        for p in patterns[:5]:
            action = p['action']
            conf = p['confidence']
            if p['pattern_type'] == 'hourly':
                h = p['time_hour']
                lines.append(f"  • '{action}' frecuentemente a las {h:02d}:xx ({conf:.0%} confianza)")
            elif p['pattern_type'] == 'weekly':
                d = days[p['day_of_week']] if 0 <= p.get('day_of_week', -1) < 7 else '?'
                lines.append(f"  • '{action}' frecuentemente los {d} ({conf:.0%} confianza)")

        apps = self.get_most_used_apps(3)
        if apps:
            app_list = ', '.join(f"'{a['app_name']}' ({a['uses']}x)" for a in apps)
            lines.append(f"\nAplicaciones más usadas: {app_list}")

        return '\n'.join(lines)

    def get_recent_actions(self, limit: int = 20) -> List[Dict]:
        """Obtener acciones recientes."""
        try:
            with self._lock:
                rows = self.conn.execute(
                    """SELECT action, skill, timestamp, success
                       FROM action_log
                       ORDER BY timestamp DESC
                       LIMIT ?""",
                    (limit,)
                ).fetchall()
            return [dict(r) for r in rows]
        except Exception:
            return []

    def close(self):
        if self.conn:
            try:
                self.conn.close()
            except Exception:
                pass
