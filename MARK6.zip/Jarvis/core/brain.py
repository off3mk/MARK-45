"""
J.A.R.V.I.S MARK 6 - Núcleo Central (Brain)
Coordinador principal de todos los subsistemas.
"""

import logging
import threading
import time
import queue
from typing import Optional, Callable, Dict, Any

logger = logging.getLogger('JARVIS.Brain')


class JarvisBrain:
    """Núcleo central de JARVIS - coordina todos los subsistemas."""

    def __init__(self):
        self.initialized = False
        self.running = False
        self.command_queue = queue.PriorityQueue()
        self._ui_callback: Optional[Callable] = None
        self._modules: Dict[str, Any] = {}
        self.lock = threading.Lock()

        # Estado del sistema
        self.state = None
        self.memory = None
        self.cognitive_memory = None
        self.intent_engine = None
        self.ai_manager = None
        self.personality = None
        self.executor = None
        self.voice = None
        self.autonomous = None
        self.reasoning = None
        self.planner = None
        self.security = None
        self.skill_manager = None

    def initialize(self):
        """Inicializar todos los módulos del sistema."""
        logger.info("Inicializando módulos de J.A.R.V.I.S MARK 6...")

        try:
            # Importar y cargar módulos en orden
            self._load_state()
            self._load_memory()
            self._load_cognitive_memory()
            self._load_ai_manager()
            self._load_personality()
            self._load_security()
            self._load_intent_engine()
            self._load_reasoning()
            self._load_planner()
            self._load_executor()
            self._load_voice()
            self._load_skills()
            self._load_autonomous()

            self.initialized = True
            self.running = True

            # Iniciar procesador de comandos
            self._start_command_processor()

            logger.info("J.A.R.V.I.S MARK 6 inicializado correctamente.")

        except Exception as e:
            logger.error(f"Error durante inicialización: {e}")
            # Continuar con módulos disponibles
            self.initialized = True
            self.running = True

    def _load_state(self):
        try:
            from core.state import JarvisState
            self.state = JarvisState()
            self.state.start()
            logger.info("✓ State Engine cargado")
        except Exception as e:
            logger.warning(f"State Engine no disponible: {e}")

    def _load_cognitive_memory(self):
        try:
            from core.cognitive_memory import CognitiveMemory
            self.cognitive_memory = CognitiveMemory()
            self.cognitive_memory.initialize()
            logger.info("✓ Cognitive Memory cargado")
        except Exception as e:
            logger.warning(f"Cognitive Memory no disponible: {e}")
            self.cognitive_memory = None

    def _load_memory(self):
        try:
            from core.memory import MemorySystem
            self.memory = MemorySystem()
            self.memory.initialize()
            logger.info("✓ Memory System cargado")
        except Exception as e:
            logger.warning(f"Memory System no disponible: {e}")
            self.memory = None

    def _load_ai_manager(self):
        try:
            from core.ai_manager import AIManager
            self.ai_manager = AIManager()
            logger.info("✓ AI Manager cargado")
        except Exception as e:
            logger.warning(f"AI Manager no disponible: {e}")
            self.ai_manager = None

    def _load_personality(self):
        try:
            from core.personality import JarvisPersonality
            self.personality = JarvisPersonality(self.ai_manager)
            logger.info("✓ Personality Engine cargado")
        except Exception as e:
            logger.warning(f"Personality Engine no disponible: {e}")
            self.personality = None

    def _load_security(self):
        try:
            from core.security import SecuritySystem
            self.security = SecuritySystem()
            logger.info("✓ Security System cargado")
        except Exception as e:
            logger.warning(f"Security System no disponible: {e}")
            self.security = None

    def _load_intent_engine(self):
        try:
            from core.intent_engine import SemanticIntentEngine
            self.intent_engine = SemanticIntentEngine()
            logger.info("✓ Intent Engine cargado")
        except Exception as e:
            logger.warning(f"Intent Engine no disponible: {e}")
            self.intent_engine = None

    def _load_reasoning(self):
        try:
            from core.reasoning import ReasoningEngine
            self.reasoning = ReasoningEngine(self)
            logger.info("✓ Reasoning Engine cargado")
        except Exception as e:
            logger.warning(f"Reasoning Engine no disponible: {e}")
            self.reasoning = None

    def _load_planner(self):
        try:
            from core.planner import TaskPlanner
            self.planner = TaskPlanner(self)
            logger.info("✓ Task Planner cargado")
        except Exception as e:
            logger.warning(f"Task Planner no disponible: {e}")
            self.planner = None

    def _load_executor(self):
        try:
            from core.executor import CommandExecutor
            self.executor = CommandExecutor(self)
            logger.info("✓ Command Executor cargado")
        except Exception as e:
            logger.warning(f"Command Executor no disponible: {e}")
            self.executor = None

    def _load_voice(self):
        try:
            from core.voice import VoiceSystem
            self.voice = VoiceSystem()
            logger.info("✓ Voice System cargado")
        except Exception as e:
            logger.warning(f"Voice System no disponible: {e}")
            self.voice = None

    def _load_skills(self):
        try:
            from core.skills import SkillManager
            self.skill_manager = SkillManager(self)
            self.skill_manager.load_all_skills()
            logger.info("✓ Skill Manager cargado")
        except Exception as e:
            logger.warning(f"Skill Manager no disponible: {e}")
            self.skill_manager = None

    def _load_autonomous(self):
        try:
            from core.autonomous import AutonomousEngine
            self.autonomous = AutonomousEngine(self)
            self.autonomous.start()
            logger.info("✓ Autonomous Engine cargado")
        except Exception as e:
            logger.warning(f"Autonomous Engine no disponible: {e}")
            self.autonomous = None

    def _start_command_processor(self):
        """Iniciar hilo procesador de comandos."""
        def processor():
            while self.running:
                try:
                    if not self.command_queue.empty():
                        priority, cmd_data = self.command_queue.get(timeout=0.1)
                        self._execute_queued_command(cmd_data)
                except queue.Empty:
                    pass
                except Exception as e:
                    logger.error(f"Error en procesador de comandos: {e}")
                time.sleep(0.05)

        t = threading.Thread(target=processor, daemon=True)
        t.start()

    def _execute_queued_command(self, cmd_data: dict):
        """Ejecutar un comando de la cola."""
        try:
            command = cmd_data.get('command', '')
            callback = cmd_data.get('callback')
            result = self.process_command(command)
            if callback:
                callback(result)
        except Exception as e:
            logger.error(f"Error ejecutando comando en cola: {e}")

    def process_command(self, user_input: str) -> str:
        """
        Procesa CUALQUIER input con el nuevo NLU + Reasoning Engine.
        Entiende lenguaje natural, typos, frases vagas, idioma mezclado.
        """
        if not user_input or not user_input.strip():
            return ""

        user_input = user_input.strip()
        logger.info(f"MARK input: '{user_input}'")

        try:
            # Guardar en memoria
            if self.memory:
                try: self.memory.save_message('user', user_input)
                except Exception: pass
            if self.state:
                try: self.state.update_interaction()
                except Exception: pass

            # ── NLU: comprender la solicitud ──────────────────────
            try:
                from core.nlu import get_nlu
                nlu = get_nlu()
                nlu_result = nlu.understand(user_input)
            except Exception as e:
                logger.warning(f"NLU fallo: {e}")
                nlu_result = {'intent': 'ai_chat', 'confidence': 0.5,
                               'entities': {}, 'context': {},
                               'emotional_tone': 'neutral', 'needs_ai': True,
                               'needs_local': False}

            intent_name = nlu_result.get('intent', 'ai_chat')
            confidence  = nlu_result.get('confidence', 0.5)

            # ── Razonamiento + acción ─────────────────────────────
            response = ""
            if self.reasoning:
                try:
                    response = self.reasoning.reason(user_input, nlu_result)
                except Exception as e:
                    logger.error(f"Reasoning error: {e}", exc_info=True)

            if not response or len(response.strip()) < 3:
                # Fallback directo a IA
                response = self._ask_ai(user_input)

            # ── Personalidad sutil ────────────────────────────────
            if self.personality and response:
                try:
                    response = self.personality.format_response(response)
                except Exception:
                    pass

            # Guardar respuesta
            if self.memory:
                try: self.memory.save_message('mark', response)
                except Exception: pass

            # Actualizar NLU con respuesta del bot
            try:
                from core.nlu import get_nlu
                get_nlu().add_bot_response(response)
            except Exception:
                pass

            # TTS
            self.speak(response)
            return response

        except Exception as e:
            logger.error(f"process_command error: {e}", exc_info=True)
            err = f"Error interno: {str(e)[:80]}"
            return err

    def speak(self, text: str):
        """Convertir texto a voz."""
        if self.voice and text:
            try:
                self.voice.speak(text)
            except Exception as e:
                logger.debug(f"Error en TTS: {e}")

    def set_ui_callback(self, callback: Callable):
        """Establecer callback para actualizar UI."""
        self._ui_callback = callback

    def update_ui(self, event_type: str, data: Any = None):
        """Enviar actualización a la UI."""
        if self._ui_callback:
            try:
                self._ui_callback(event_type, data)
            except Exception as e:
                logger.debug(f"Error actualizando UI: {e}")

    def queue_command(self, command: str, priority: int = 5, callback: Optional[Callable] = None):
        """Añadir comando a la cola de procesamiento."""
        self.command_queue.put((priority, {
            'command': command,
            'callback': callback,
            'timestamp': time.time()
        }))

    def shutdown(self):
        """Apagar el sistema ordenadamente."""
        logger.info("Iniciando secuencia de apagado...")
        self.running = False

        if self.autonomous:
            try:
                self.autonomous.stop()
            except Exception:
                pass

        if self.state:
            try:
                self.state.stop()
            except Exception:
                pass

        if self.memory:
            try:
                self.memory.close()
            except Exception:
                pass

        logger.info("Sistema MARK apagado.")

    def get_status(self) -> dict:
        """Obtener estado actual del sistema."""
        status = {
            'initialized': self.initialized,
            'running': self.running,
            'modules': {
                'state': self.state is not None,
                'memory': self.memory is not None,
                'ai_manager': self.ai_manager is not None,
                'intent_engine': self.intent_engine is not None,
                'reasoning': self.reasoning is not None,
                'planner': self.planner is not None,
                'voice': self.voice is not None,
                'skill_manager': self.skill_manager is not None,
                'autonomous': self.autonomous is not None,
            }
        }
        if self.state:
            status['system'] = self.state.get_state()
        return status
