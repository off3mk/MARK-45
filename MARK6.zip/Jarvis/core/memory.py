"""
JARVIS v4.0 - Sistema de Memoria Persistente
SQLite + cache LRU + memoria cognitiva.
"""

import logging
import sqlite3
import json
import os
import time
import threading
from datetime import datetime
from typing import Optional, List, Dict, Any
from collections import OrderedDict

logger = logging.getLogger('JARVIS.Memory')

DB_PATH = os.path.join(os.path.dirname(os.path.dirname(__file__)), 'memory', 'jarvis.db')


class LRUCache:
    """Caché LRU en memoria."""
    def __init__(self, capacity: int = 100):
        self.cache = OrderedDict()
        self.capacity = capacity
        self.lock = threading.Lock()

    def get(self, key: str):
        with self.lock:
            if key not in self.cache:
                return None
            self.cache.move_to_end(key)
            return self.cache[key]

    def put(self, key: str, value: Any):
        with self.lock:
            if key in self.cache:
                self.cache.move_to_end(key)
            self.cache[key] = value
            if len(self.cache) > self.capacity:
                self.cache.popitem(last=False)


class MemorySystem:
    """Sistema de memoria completo con SQLite y cache."""

    def __init__(self):
        self.db_path = DB_PATH
        self.conn: Optional[sqlite3.Connection] = None
        self.cache = LRUCache(200)
        self.lock = threading.Lock()

    def initialize(self):
        """Inicializar base de datos."""
        os.makedirs(os.path.dirname(self.db_path), exist_ok=True)
        self.conn = sqlite3.connect(self.db_path, check_same_thread=False)
        self.conn.row_factory = sqlite3.Row
        self._create_tables()
        logger.info(f"Base de datos inicializada: {self.db_path}")

    def _create_tables(self):
        """Crear tablas si no existen."""
        with self.lock:
            cursor = self.conn.cursor()
            cursor.executescript("""
                CREATE TABLE IF NOT EXISTS conversations (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    timestamp TEXT NOT NULL,
                    role TEXT NOT NULL,
                    content TEXT NOT NULL,
                    session_id TEXT DEFAULT 'default'
                );

                CREATE TABLE IF NOT EXISTS knowledge (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    key TEXT UNIQUE NOT NULL,
                    value TEXT NOT NULL,
                    category TEXT DEFAULT 'general',
                    created_at TEXT NOT NULL,
                    updated_at TEXT NOT NULL
                );

                CREATE TABLE IF NOT EXISTS habits (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    action TEXT NOT NULL,
                    frequency INTEGER DEFAULT 1,
                    last_seen TEXT,
                    hour_of_day INTEGER DEFAULT -1,
                    day_of_week INTEGER DEFAULT -1
                );

                CREATE TABLE IF NOT EXISTS preferences (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    key TEXT UNIQUE NOT NULL,
                    value TEXT NOT NULL,
                    updated_at TEXT NOT NULL
                );

                CREATE TABLE IF NOT EXISTS events (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    timestamp TEXT NOT NULL,
                    event_type TEXT NOT NULL,
                    data TEXT,
                    processed INTEGER DEFAULT 0
                );

                CREATE INDEX IF NOT EXISTS idx_conv_timestamp ON conversations(timestamp);
                CREATE INDEX IF NOT EXISTS idx_knowledge_key ON knowledge(key);
                CREATE INDEX IF NOT EXISTS idx_habits_action ON habits(action);
            """)
            self.conn.commit()

    def save_message(self, role: str, content: str, session_id: str = 'default'):
        """Guardar mensaje en historial de conversación."""
        try:
            with self.lock:
                cursor = self.conn.cursor()
                now = datetime.now().isoformat()
                cursor.execute(
                    "INSERT INTO conversations (timestamp, role, content, session_id) VALUES (?, ?, ?, ?)",
                    (now, role, content, session_id)
                )
                self.conn.commit()
        except Exception as e:
            logger.error(f"Error guardando mensaje: {e}")

    def get_recent_messages(self, limit: int = 10, session_id: str = 'default') -> List[Dict]:
        """Obtener mensajes recientes."""
        try:
            with self.lock:
                cursor = self.conn.cursor()
                cursor.execute(
                    "SELECT role, content, timestamp FROM conversations WHERE session_id = ? "
                    "ORDER BY timestamp DESC LIMIT ?",
                    (session_id, limit)
                )
                rows = cursor.fetchall()
                return [{'role': r['role'], 'content': r['content'], 'timestamp': r['timestamp']}
                        for r in reversed(rows)]
        except Exception as e:
            logger.error(f"Error obteniendo mensajes: {e}")
            return []

    def remember(self, key: str, value: Any, category: str = 'general'):
        """Guardar información importante."""
        try:
            value_str = json.dumps(value) if not isinstance(value, str) else value
            now = datetime.now().isoformat()
            with self.lock:
                cursor = self.conn.cursor()
                cursor.execute(
                    "INSERT OR REPLACE INTO knowledge (key, value, category, created_at, updated_at) "
                    "VALUES (?, ?, ?, COALESCE((SELECT created_at FROM knowledge WHERE key = ?), ?), ?)",
                    (key, value_str, category, key, now, now)
                )
                self.conn.commit()
            self.cache.put(f"know:{key}", value_str)
            logger.debug(f"Recordado: {key} = {value_str[:50]}")
        except Exception as e:
            logger.error(f"Error recordando {key}: {e}")

    def recall(self, key: str) -> Optional[Any]:
        """Recuperar información guardada."""
        # Verificar cache primero
        cached = self.cache.get(f"know:{key}")
        if cached is not None:
            try:
                return json.loads(cached)
            except Exception:
                return cached

        try:
            with self.lock:
                cursor = self.conn.cursor()
                cursor.execute("SELECT value FROM knowledge WHERE key = ?", (key,))
                row = cursor.fetchone()
                if row:
                    value = row['value']
                    self.cache.put(f"know:{key}", value)
                    try:
                        return json.loads(value)
                    except Exception:
                        return value
        except Exception as e:
            logger.error(f"Error recuperando {key}: {e}")
        return None

    def search_knowledge(self, query: str) -> List[Dict]:
        """Buscar en la base de conocimiento."""
        try:
            with self.lock:
                cursor = self.conn.cursor()
                cursor.execute(
                    "SELECT key, value, category FROM knowledge WHERE key LIKE ? OR value LIKE ? LIMIT 10",
                    (f"%{query}%", f"%{query}%")
                )
                return [{'key': r['key'], 'value': r['value'], 'category': r['category']}
                        for r in cursor.fetchall()]
        except Exception as e:
            logger.error(f"Error buscando: {e}")
            return []

    def set_preference(self, key: str, value: Any):
        """Guardar preferencia del usuario."""
        try:
            value_str = json.dumps(value) if not isinstance(value, str) else value
            now = datetime.now().isoformat()
            with self.lock:
                cursor = self.conn.cursor()
                cursor.execute(
                    "INSERT OR REPLACE INTO preferences (key, value, updated_at) VALUES (?, ?, ?)",
                    (key, value_str, now)
                )
                self.conn.commit()
            self.cache.put(f"pref:{key}", value_str)
        except Exception as e:
            logger.error(f"Error guardando preferencia {key}: {e}")

    def get_preference(self, key: str, default=None):
        """Obtener preferencia del usuario."""
        cached = self.cache.get(f"pref:{key}")
        if cached is not None:
            try:
                return json.loads(cached)
            except Exception:
                return cached

        try:
            with self.lock:
                cursor = self.conn.cursor()
                cursor.execute("SELECT value FROM preferences WHERE key = ?", (key,))
                row = cursor.fetchone()
                if row:
                    value = row['value']
                    self.cache.put(f"pref:{key}", value)
                    try:
                        return json.loads(value)
                    except Exception:
                        return value
        except Exception as e:
            logger.error(f"Error obteniendo preferencia {key}: {e}")
        return default

    def track_habit(self, action: str):
        """Registrar hábito del usuario."""
        try:
            now = datetime.now()
            with self.lock:
                cursor = self.conn.cursor()
                cursor.execute("SELECT id, frequency FROM habits WHERE action = ?", (action,))
                row = cursor.fetchone()
                if row:
                    cursor.execute(
                        "UPDATE habits SET frequency = frequency + 1, last_seen = ?, "
                        "hour_of_day = ?, day_of_week = ? WHERE id = ?",
                        (now.isoformat(), now.hour, now.weekday(), row['id'])
                    )
                else:
                    cursor.execute(
                        "INSERT INTO habits (action, frequency, last_seen, hour_of_day, day_of_week) "
                        "VALUES (?, 1, ?, ?, ?)",
                        (action, now.isoformat(), now.hour, now.weekday())
                    )
                self.conn.commit()
        except Exception as e:
            logger.error(f"Error registrando hábito {action}: {e}")

    def get_frequent_habits(self, min_frequency: int = 3) -> List[Dict]:
        """Obtener hábitos frecuentes del usuario."""
        try:
            with self.lock:
                cursor = self.conn.cursor()
                cursor.execute(
                    "SELECT action, frequency, hour_of_day, day_of_week, last_seen "
                    "FROM habits WHERE frequency >= ? ORDER BY frequency DESC LIMIT 20",
                    (min_frequency,)
                )
                return [dict(r) for r in cursor.fetchall()]
        except Exception as e:
            logger.error(f"Error obteniendo hábitos: {e}")
            return []

    def log_event(self, event_type: str, data: Any = None):
        """Registrar evento del sistema."""
        try:
            data_str = json.dumps(data) if data else None
            now = datetime.now().isoformat()
            with self.lock:
                cursor = self.conn.cursor()
                cursor.execute(
                    "INSERT INTO events (timestamp, event_type, data) VALUES (?, ?, ?)",
                    (now, event_type, data_str)
                )
                self.conn.commit()
        except Exception as e:
            logger.debug(f"Error registrando evento: {e}")

    def get_conversation_summary(self, session_id: str = 'default') -> str:
        """Obtener resumen de conversación."""
        messages = self.get_recent_messages(20, session_id)
        if not messages:
            return "Sin conversación previa."
        lines = [f"{m['role'].upper()}: {m['content']}" for m in messages]
        return "\n".join(lines)

    def clear_old_messages(self, days: int = 30):
        """Limpiar mensajes antiguos."""
        try:
            cutoff = datetime.fromtimestamp(time.time() - days * 86400).isoformat()
            with self.lock:
                cursor = self.conn.cursor()
                cursor.execute("DELETE FROM conversations WHERE timestamp < ?", (cutoff,))
                deleted = cursor.rowcount
                self.conn.commit()
            logger.info(f"Eliminados {deleted} mensajes antiguos.")
        except Exception as e:
            logger.error(f"Error limpiando mensajes: {e}")

    def close(self):
        """Cerrar conexión a base de datos."""
        if self.conn:
            try:
                self.conn.close()
            except Exception:
                pass
