"""
JARVIS v4.0 - Browser Skill
Automatización de navegador con Selenium/Playwright.
"""

import logging
import webbrowser
import urllib.parse
import time
from typing import Optional

logger = logging.getLogger('JARVIS.Skills.Browser')


class BrowserSkill:
    """Skill de automatización de navegador web."""

    def __init__(self, brain):
        self.brain = brain
        self._driver = None
        self._selenium_available = False
        self._playwright_available = False
        self._browser_type = None

        self._detect_available()

    def _detect_available(self):
        """Detectar qué librerías de automatización están disponibles."""
        try:
            from selenium import webdriver
            self._selenium_available = True
            logger.info("Selenium disponible")
        except ImportError:
            pass

        try:
            from playwright.sync_api import sync_playwright
            self._playwright_available = True
            logger.info("Playwright disponible")
        except ImportError:
            pass

    def _get_selenium_driver(self):
        """Obtener driver de Selenium."""
        if self._driver:
            return self._driver

        if not self._selenium_available:
            return None

        try:
            from selenium import webdriver
            from selenium.webdriver.chrome.options import Options
            from selenium.webdriver.chrome.service import Service

            options = Options()
            options.add_argument('--no-sandbox')
            options.add_argument('--disable-dev-shm-usage')
            # No usar headless para que el usuario vea el navegador
            # options.add_argument('--headless')

            try:
                from webdriver_manager.chrome import ChromeDriverManager
                service = Service(ChromeDriverManager().install())
                self._driver = webdriver.Chrome(service=service, options=options)
            except Exception:
                self._driver = webdriver.Chrome(options=options)

            self._browser_type = 'selenium_chrome'
            logger.info("Driver Chrome iniciado")
            return self._driver

        except Exception as e:
            logger.debug(f"Error iniciando Chrome: {e}")

        try:
            from selenium import webdriver
            self._driver = webdriver.Firefox()
            self._browser_type = 'selenium_firefox'
            return self._driver
        except Exception as e:
            logger.debug(f"Error iniciando Firefox: {e}")

        return None

    def open(self, url: str = '') -> str:
        """Abrir URL en navegador."""
        if not url:
            return "Especifique la URL, Señor."

        if not url.startswith(('http://', 'https://')):
            url = 'https://' + url

        driver = self._get_selenium_driver()
        if driver:
            try:
                driver.get(url)
                return f"Navegador abierto en: {url}, Señor."
            except Exception as e:
                logger.debug(f"Error Selenium: {e}")

        # Fallback a webbrowser
        webbrowser.open(url)
        return f"Abriendo '{url}' en navegador, Señor."

    def search(self, query: str = '') -> str:
        """Buscar en Google."""
        if not query:
            return "Especifique qué desea buscar, Señor."

        query_encoded = urllib.parse.quote(query)
        url = f"https://www.google.com/search?q={query_encoded}"

        driver = self._get_selenium_driver()
        if driver:
            try:
                driver.get(url)
                time.sleep(2)
                return f"Búsqueda de '{query}' completada en navegador, Señor."
            except Exception as e:
                logger.debug(f"Error Selenium: {e}")

        webbrowser.open(url)
        return f"Buscando '{query}' en el navegador, Señor."

    def fill_form(self, selector: str, value: str) -> str:
        """Rellenar campo de formulario."""
        driver = self._get_selenium_driver()
        if not driver:
            return "Automatización de navegador no disponible, Señor."

        try:
            from selenium.webdriver.common.by import By
            element = driver.find_element(By.CSS_SELECTOR, selector)
            element.clear()
            element.send_keys(value)
            return f"Campo rellenado con '{value}', Señor."
        except Exception as e:
            return f"Error rellenando formulario: {str(e)}, Señor."

    def click_element(self, selector: str) -> str:
        """Hacer clic en elemento."""
        driver = self._get_selenium_driver()
        if not driver:
            return "Automatización de navegador no disponible, Señor."

        try:
            from selenium.webdriver.common.by import By
            element = driver.find_element(By.CSS_SELECTOR, selector)
            element.click()
            return f"Clic en elemento '{selector}' realizado, Señor."
        except Exception as e:
            return f"Error en clic: {str(e)}, Señor."

    def get_page_text(self) -> str:
        """Obtener texto de la página actual."""
        driver = self._get_selenium_driver()
        if not driver:
            return "Navegador no activo, Señor."

        try:
            text = driver.find_element('tag name', 'body').text
            if len(text) > 500:
                text = text[:500] + "..."
            return f"Contenido de la página:\n{text}"
        except Exception as e:
            return f"Error obteniendo contenido: {str(e)}, Señor."

    def take_screenshot(self, filename: Optional[str] = None) -> str:
        """Capturar screenshot del navegador."""
        driver = self._get_selenium_driver()
        if not driver:
            return "Navegador no activo, Señor."

        try:
            import os
            from datetime import datetime
            workspace = os.path.join(
                os.path.dirname(os.path.dirname(__file__)), 'workspace'
            )
            os.makedirs(workspace, exist_ok=True)

            if not filename:
                timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
                filename = os.path.join(workspace, f"browser_{timestamp}.png")

            driver.save_screenshot(filename)
            return f"Screenshot del navegador guardado en: {filename}, Señor."
        except Exception as e:
            return f"Error en screenshot: {str(e)}, Señor."

    def get_current_url(self) -> str:
        """Obtener URL actual."""
        driver = self._get_selenium_driver()
        if driver:
            try:
                return f"URL actual: {driver.current_url}, Señor."
            except Exception:
                pass
        return "No hay navegador activo, Señor."

    def close(self) -> str:
        """Cerrar navegador automatizado."""
        if self._driver:
            try:
                self._driver.quit()
                self._driver = None
                return "Navegador automatizado cerrado, Señor."
            except Exception as e:
                return f"Error cerrando navegador: {str(e)}, Señor."
        return "No hay navegador activo para cerrar, Señor."

    def navigate_back(self) -> str:
        """Navegar atrás."""
        driver = self._get_selenium_driver()
        if driver:
            try:
                driver.back()
                return "Navegando atrás, Señor."
            except Exception as e:
                return f"Error: {str(e)}, Señor."
        return "No hay navegador activo, Señor."

    def navigate_forward(self) -> str:
        """Navegar adelante."""
        driver = self._get_selenium_driver()
        if driver:
            try:
                driver.forward()
                return "Navegando adelante, Señor."
            except Exception as e:
                return f"Error: {str(e)}, Señor."
        return "No hay navegador activo, Señor."

    def refresh(self) -> str:
        """Recargar página."""
        driver = self._get_selenium_driver()
        if driver:
            try:
                driver.refresh()
                return "Página recargada, Señor."
            except Exception as e:
                return f"Error: {str(e)}, Señor."
        return "No hay navegador activo, Señor."
