# J.A.R.V.I.S. v4.0
## Just A Rather Very Intelligent System

Sistema de asistencia personal avanzado estilo Iron Man, construido en Python para Windows.

---

## 🚀 Inicio Rápido

```bash
# 1. Instalar dependencias
install.bat          # Windows (automático)
# O manualmente:
pip install psutil pyautogui pygetwindow pynput edge-tts pyttsx3

# 2. Iniciar JARVIS
python main.py           # Con interfaz gráfica
python main.py --cli     # Modo consola
python main.py --debug   # Modo debug
```

---

## 🏗️ Arquitectura

```
Jarvis/
├── core/                    # NÚCLEO DEL SISTEMA
│   ├── brain.py            # Coordinador central
│   ├── state.py            # Conciencia operativa
│   ├── memory.py           # Memoria persistente SQLite
│   ├── ai_manager.py       # IA Híbrida (Ollama → Pollinations → Fallback)
│   ├── intent_engine.py    # Detección de intenciones
│   ├── personality.py      # Personalidad JARVIS
│   ├── security.py         # Sistema de seguridad
│   ├── reasoning.py        # Motor de razonamiento
│   ├── planner.py          # Planificador multi-paso
│   ├── executor.py         # Ejecutor de comandos
│   ├── voice.py            # Sistema de voz (TTS/STT)
│   ├── autonomous.py       # Motor autónomo
│   ├── vision.py           # Visión computacional
│   └── skills.py           # Gestor de skills
│
├── skills/                  # SKILLS/PLUGINS
│   ├── system.py           # Control total del PC
│   ├── internet.py         # Búsquedas y web
│   ├── media.py            # Multimedia
│   ├── coding.py           # Generación de código
│   ├── memory_skill.py     # Gestión de memoria
│   ├── browser.py          # Automatización de navegador
│   └── generated/          # Skills generados dinámicamente
│
├── ui/
│   └── interface.py        # Interfaz gráfica futurista
│
├── perception/
│   └── system_monitor.py   # Monitor continuo del sistema
│
├── workspace/              # Scripts generados
├── memory/                 # Base de datos SQLite
├── cache/                  # Caché temporal
└── logs/                   # Logs del sistema
```

---

## 💡 Comandos de Ejemplo

### Control del Sistema
```
"abre chrome"
"abre spotify"
"abre vscode"
"cierra notepad"
"minimiza la ventana"
"maximiza"
"screenshot"
"información del sistema"
"ejecuta dir"
"escribe 'Hola mundo'"
```

### Internet
```
"busca inteligencia artificial"
"clima Madrid"
"wikipedia python"
"noticias de tecnología"
"abre https://github.com"
```

### Multimedia
```
"pon un temazo"
"reproduce música relajante"
"pausa"
"siguiente"
"volumen 50"
"sube el volumen"
"silenciar"
"spotify"
"youtube lofi music"
```

### Memoria
```
"recuerda que mi email es usuario@ejemplo.com"
"recuérdame mi email"
"guarda mi número 123456789"
```

### Código
```
"crea un script de calculadora"
"código web scraper"
"genera un programa de información del sistema"
```

### Automatización
```
"modo trabajo"
"modo relajación"
"modo estudio"
"prepara entorno de trabajo"
```

---

## 🤖 IA Híbrida

JARVIS usa un sistema de IA con tres niveles de prioridad:

1. **Ollama Local** (si está instalado) — Más rápido, privado
2. **Pollinations AI** — Online, sin costo
3. **Motor Fallback** — Local, sin internet

Para usar Ollama: instalar desde [ollama.ai](https://ollama.ai) y ejecutar:
```bash
ollama pull llama3
```

---

## 🎭 Personalidad JARVIS

JARVIS habla siempre con:
- Formalidad y precisión
- "Señor" al dirigirse al usuario
- Respuestas concisas pero informativas
- Nunca menciona ser una IA

---

## 🔒 Seguridad

El sistema solicita confirmación antes de:
- Apagar el sistema
- Reiniciar el sistema  
- Ejecutar código generado
- Eliminar archivos

---

## 🔧 Dependencias Opcionales

| Funcionalidad | Paquete |
|---|---|
| Control volumen | `pycaw comtypes` |
| Automatización navegador | `selenium webdriver-manager` |
| Visión computacional | `opencv-python pytesseract` |
| Audio TTS | `pygame` o `playsound` |
| STT (reconocimiento de voz) | `SpeechRecognition` |

---

## 📄 Licencia

Sistema de uso personal. Desarrollado con Python.
