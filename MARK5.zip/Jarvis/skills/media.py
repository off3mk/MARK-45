"""
JARVIS v4.0 - Media Skill
Control multimedia: Spotify, YouTube, volumen del sistema.
"""

import logging
import subprocess
import webbrowser
import platform
import urllib.parse
import time
from typing import Optional

logger = logging.getLogger('JARVIS.Skills.Media')

# URLs de música predefinidas
MUSIC_URLS = {
    'temazo': 'https://www.youtube.com/watch?v=dQw4w9WgXcQ',
    'rock': 'https://www.youtube.com/results?search_query=rock+classics',
    'jazz': 'https://www.youtube.com/results?search_query=jazz+music',
    'clasica': 'https://www.youtube.com/results?search_query=classical+music',
    'electronica': 'https://www.youtube.com/results?search_query=electronic+music',
    'relajante': 'https://www.youtube.com/results?search_query=musica+relajante',
    'estudio': 'https://www.youtube.com/results?search_query=music+for+studying',
    'lofi': 'https://www.youtube.com/results?search_query=lofi+hip+hop',
}


class MediaSkill:
    """Skill de control multimedia."""

    def __init__(self, brain):
        self.brain = brain
        self._is_windows = platform.system() == 'Windows'
        self._current_volume = 50
        self._init_volume_control()

    def _init_volume_control(self):
        """Inicializar control de volumen."""
        self._volume_available = False
        if self._is_windows:
            try:
                from ctypes import cast, POINTER
                from comtypes import CLSCTX_ALL
                from pycaw.pycaw import AudioUtilities, IAudioEndpointVolume
                devices = AudioUtilities.GetSpeakers()
                interface = devices.Activate(
                    IAudioEndpointVolume._iid_, CLSCTX_ALL, None)
                self._volume_ctrl = cast(interface, POINTER(IAudioEndpointVolume))
                self._volume_available = True
                logger.info("Control de volumen (pycaw) disponible")
            except Exception:
                logger.debug("pycaw no disponible, usando fallback")

    def play(self, query: str = '') -> str:
        """Reproducir música o contenido."""
        query_lower = query.lower().strip()

        # Detectar tipo de contenido
        if 'spotify' in query_lower:
            return self.open_spotify()

        if not query or 'temazo' in query_lower or 'música' in query_lower:
            query = 'temazo'

        # Buscar en URLs predefinidas
        for keyword, url in MUSIC_URLS.items():
            if keyword in query_lower:
                webbrowser.open(url)
                return f"Reproduciendo {keyword} en YouTube, Señor."

        # Buscar en YouTube
        return self.youtube(query)

    def pause(self) -> str:
        """Pausar/reanudar reproducción."""
        if self._is_windows:
            try:
                import pyautogui
                pyautogui.press('playpause')
                return "Reproducción pausada/reanudada, Señor."
            except Exception:
                pass

        # Intentar con pynput
        try:
            from pynput.keyboard import Key, Controller
            keyboard = Controller()
            keyboard.press(Key.media_play_pause)
            keyboard.release(Key.media_play_pause)
            return "Reproducción pausada/reanudada, Señor."
        except Exception as e:
            logger.debug(f"Error pausa: {e}")

        return "No pude controlar la reproducción, Señor."

    def next(self) -> str:
        """Saltar a siguiente pista."""
        if self._is_windows:
            try:
                import pyautogui
                pyautogui.press('nexttrack')
                return "Siguiente pista, Señor."
            except Exception:
                pass

        try:
            from pynput.keyboard import Key, Controller
            keyboard = Controller()
            keyboard.press(Key.media_next)
            keyboard.release(Key.media_next)
            return "Siguiente pista, Señor."
        except Exception as e:
            logger.debug(f"Error next track: {e}")

        return "No pude cambiar la pista, Señor."

    def previous(self) -> str:
        """Ir a pista anterior."""
        if self._is_windows:
            try:
                import pyautogui
                pyautogui.press('prevtrack')
                return "Pista anterior, Señor."
            except Exception:
                pass

        try:
            from pynput.keyboard import Key, Controller
            keyboard = Controller()
            keyboard.press(Key.media_previous)
            keyboard.release(Key.media_previous)
            return "Pista anterior, Señor."
        except Exception as e:
            logger.debug(f"Error previous track: {e}")

        return "No pude cambiar la pista, Señor."

    def volume(self, level: Optional[int] = None, direction: Optional[str] = None) -> str:
        """Controlar volumen del sistema."""
        if level is not None:
            return self._set_volume(max(0, min(100, level)))
        elif direction == 'up':
            return self._adjust_volume(10)
        elif direction == 'down':
            return self._adjust_volume(-10)
        else:
            return f"Volumen actual: {self._get_current_volume()}%, Señor."

    def _set_volume(self, level: int) -> str:
        """Establecer volumen a nivel específico."""
        if self._volume_available:
            try:
                import numpy as np
                volume_scalar = level / 100.0
                self._volume_ctrl.SetMasterVolumeLevelScalar(volume_scalar, None)
                self._current_volume = level
                return f"Volumen establecido al {level}%, Señor."
            except Exception as e:
                logger.debug(f"Error pycaw volume: {e}")

        # Fallback: nircmd en Windows
        if self._is_windows:
            try:
                # Usando PowerShell
                cmd = f'(Get-WmiObject -Class Win32_Volume).SetVolume({level})'
                subprocess.run(['powershell', '-Command', cmd],
                               capture_output=True, timeout=5)
                self._current_volume = level
                return f"Volumen al {level}%, Señor."
            except Exception:
                pass

        # Fallback: pyautogui
        try:
            import pyautogui
            # Ajustar con teclas multimedia
            current = self._current_volume
            diff = level - current
            key = 'volumeup' if diff > 0 else 'volumedown'
            presses = abs(diff) // 5  # Cada tecla = ~5%
            for _ in range(min(presses, 20)):
                pyautogui.press(key)
                time.sleep(0.1)
            self._current_volume = level
            return f"Volumen ajustado a aproximadamente {level}%, Señor."
        except Exception as e:
            return f"No pude ajustar el volumen: {str(e)}, Señor."

    def _adjust_volume(self, delta: int) -> str:
        """Ajustar volumen relativamente."""
        new_level = max(0, min(100, self._current_volume + delta))
        return self._set_volume(new_level)

    def _get_current_volume(self) -> int:
        """Obtener volumen actual."""
        if self._volume_available:
            try:
                volume = self._volume_ctrl.GetMasterVolumeLevelScalar()
                self._current_volume = int(volume * 100)
            except Exception:
                pass
        return self._current_volume

    def mute(self) -> str:
        """Silenciar/activar sonido."""
        if self._volume_available:
            try:
                is_muted = self._volume_ctrl.GetMute()
                self._volume_ctrl.SetMute(not is_muted, None)
                status = "silenciado" if not is_muted else "activado"
                return f"Sonido {status}, Señor."
            except Exception:
                pass

        try:
            import pyautogui
            pyautogui.press('volumemute')
            return "Silencio activado/desactivado, Señor."
        except Exception as e:
            return f"No pude silenciar: {str(e)}, Señor."

    def open_spotify(self) -> str:
        """Abrir Spotify."""
        # Intentar abrir ejecutable
        try:
            if self._is_windows:
                subprocess.Popen(['spotify.exe'], shell=True)
            else:
                subprocess.Popen(['spotify'])
            time.sleep(2)
            return "Spotify iniciado, Señor."
        except Exception:
            pass

        # Fallback: abrir web
        webbrowser.open('https://open.spotify.com')
        return "Abriendo Spotify Web, Señor."

    def youtube(self, query: str = '') -> str:
        """Buscar y abrir en YouTube."""
        if not query:
            webbrowser.open('https://www.youtube.com')
            return "YouTube abierto, Señor."

        query_encoded = urllib.parse.quote(query)
        url = f"https://www.youtube.com/results?search_query={query_encoded}"
        webbrowser.open(url)
        return f"Buscando '{query}' en YouTube, Señor."

    def open_youtube_url(self, url: str) -> str:
        """Abrir URL específica de YouTube."""
        webbrowser.open(url)
        return f"Reproduciendo en YouTube, Señor."
