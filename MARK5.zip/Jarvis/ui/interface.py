"""
MARK 5 - Interfaz Gráfica Futurista
Diseño oscuro estilo Iron Man con panel de chat y estado del sistema.
"""

import logging
import threading
import time
import queue
from typing import Optional, Callable
from datetime import datetime

logger = logging.getLogger('MARK.UI')

# Intentar importar tkinter
try:
    import tkinter as tk
    from tkinter import ttk, scrolledtext, font
    TK_AVAILABLE = True
except ImportError:
    TK_AVAILABLE = False
    logger.warning("tkinter no disponible")

# =====================
# PALETA DE COLORES JARVIS
# =====================
COLORS = {
    'bg_dark': '#0a0e1a',
    'bg_medium': '#0f1530',
    'bg_panel': '#141c3a',
    'bg_input': '#0d1428',
    'accent_blue': '#00a8ff',
    'accent_cyan': '#00e5ff',
    'accent_glow': '#1a6fff',
    'text_primary': '#e0f0ff',
    'text_secondary': '#7090c0',
    'text_jarvis': '#00e5ff',
    'text_user': '#80d0ff',
    'text_system': '#40a0d0',
    'success': '#00ff88',
    'warning': '#ffb020',
    'danger': '#ff4060',
    'border': '#1a3060',
    'separator': '#0d2040',
}


class AnimatedLabel(tk.Label):
    """Label con efecto de parpadeo."""
    def __init__(self, parent, **kwargs):
        super().__init__(parent, **kwargs)
        self._blink_state = True
        self._blink_job = None

    def start_blink(self, interval: int = 800):
        """Iniciar efecto de parpadeo."""
        orig_fg = self.cget('fg')
        self._blink_orig = orig_fg

        def blink():
            if not self.winfo_exists():
                return
            if self._blink_state:
                self.config(fg=self._blink_orig)
            else:
                self.config(fg=COLORS['bg_dark'])
            self._blink_state = not self._blink_state
            self._blink_job = self.after(interval, blink)

        blink()

    def stop_blink(self):
        """Detener parpadeo."""
        if self._blink_job:
            self.after_cancel(self._blink_job)
        self.config(fg=self._blink_orig if hasattr(self, '_blink_orig') else COLORS['text_primary'])


class JarvisInterface:
    """Interfaz gráfica principal de JARVIS."""

    def __init__(self, brain):
        if not TK_AVAILABLE:
            raise ImportError("tkinter no disponible")

        self.brain = brain
        self.root = tk.Tk()
        self._setup_window()
        self._build_ui()
        self._bind_events()

        # Cola de mensajes para thread-safety
        self._msg_queue = queue.Queue()

        # Registrar callback en brain
        brain.set_ui_callback(self._on_brain_event)

        # Estado de voz
        self._voice_listening = False

        # Iniciar actualizador de UI
        self._schedule_ui_updates()

    def _setup_window(self):
        """Configurar ventana principal."""
        self.root.title("J.A.R.V.I.S. MARK 5 — Just A Rather Very Intelligent System")
        self.root.configure(bg=COLORS['bg_dark'])
        self.root.geometry("1200x800")
        self.root.minsize(900, 600)

        # Icono (si existe)
        try:
            self.root.iconbitmap('assets/jarvis.ico')
        except Exception:
            pass

        # Protocolo de cierre
        self.root.protocol("WM_DELETE_WINDOW", self._on_close)

    def _build_ui(self):
        """Construir toda la interfaz."""
        self._build_header()
        self._build_main_content()
        self._build_status_bar()

    def _build_header(self):
        """Construir encabezado."""
        header = tk.Frame(self.root, bg=COLORS['bg_panel'],
                          height=70, bd=0)
        header.pack(fill='x', side='top')
        header.pack_propagate(False)

        # Borde inferior del header
        border = tk.Frame(self.root, bg=COLORS['accent_blue'], height=2)
        border.pack(fill='x', side='top')

        # Logo/Título
        title_frame = tk.Frame(header, bg=COLORS['bg_panel'])
        title_frame.pack(side='left', padx=20, pady=10)

        title_lbl = tk.Label(
            title_frame, text="J.A.R.V.I.S.",
            font=('Courier New', 22, 'bold'),
            fg=COLORS['accent_cyan'], bg=COLORS['bg_panel']
        )
        title_lbl.pack(side='top', anchor='w')

        subtitle_lbl = tk.Label(
            title_frame, text="MARK 5 — Just A Rather Very Intelligent System",
            font=('Courier New', 8),
            fg=COLORS['text_secondary'], bg=COLORS['bg_panel']
        )
        subtitle_lbl.pack(side='top', anchor='w')

        # Indicadores de estado
        indicators = tk.Frame(header, bg=COLORS['bg_panel'])
        indicators.pack(side='right', padx=20)

        # Indicador AI
        self._ai_indicator = self._create_indicator(indicators, "AI", COLORS['accent_cyan'])

        # Indicador de voz
        self._voice_indicator = self._create_indicator(indicators, "VOZ", COLORS['text_secondary'])

        # Reloj
        self._clock_lbl = tk.Label(
            header,
            font=('Courier New', 12, 'bold'),
            fg=COLORS['text_primary'], bg=COLORS['bg_panel']
        )
        self._clock_lbl.pack(side='right', padx=20)
        self._update_clock()

    def _create_indicator(self, parent, text: str, color: str) -> dict:
        """Crear indicador de estado."""
        frame = tk.Frame(parent, bg=COLORS['bg_panel'])
        frame.pack(side='right', padx=8)

        dot = tk.Label(frame, text="●", font=('Arial', 12),
                       fg=color, bg=COLORS['bg_panel'])
        dot.pack(side='left')

        lbl = tk.Label(frame, text=text, font=('Courier New', 8),
                       fg=COLORS['text_secondary'], bg=COLORS['bg_panel'])
        lbl.pack(side='left')

        return {'frame': frame, 'dot': dot, 'label': lbl, 'active': False}

    def _build_main_content(self):
        """Construir contenido principal."""
        main = tk.Frame(self.root, bg=COLORS['bg_dark'])
        main.pack(fill='both', expand=True, padx=5, pady=5)

        # Panel izquierdo: Chat
        left_panel = tk.Frame(main, bg=COLORS['bg_dark'])
        left_panel.pack(side='left', fill='both', expand=True, padx=(0, 3))

        self._build_chat_panel(left_panel)
        self._build_input_panel(left_panel)

        # Panel derecho: Estado + Logs
        right_panel = tk.Frame(main, bg=COLORS['bg_dark'], width=300)
        right_panel.pack(side='right', fill='y', padx=(3, 0))
        right_panel.pack_propagate(False)

        self._build_system_panel(right_panel)
        self._build_log_panel(right_panel)

    def _build_chat_panel(self, parent):
        """Construir panel de chat."""
        chat_header = tk.Frame(parent, bg=COLORS['bg_panel'], height=30)
        chat_header.pack(fill='x')

        tk.Label(
            chat_header, text="◈ INTERFAZ DE COMUNICACIÓN",
            font=('Courier New', 9, 'bold'),
            fg=COLORS['accent_blue'], bg=COLORS['bg_panel']
        ).pack(side='left', padx=10, pady=5)

        # Área de chat
        self.chat_area = scrolledtext.ScrolledText(
            parent,
            font=('Courier New', 10),
            bg=COLORS['bg_panel'],
            fg=COLORS['text_primary'],
            insertbackground=COLORS['accent_cyan'],
            wrap=tk.WORD,
            state='disabled',
            relief='flat',
            bd=0,
            selectbackground=COLORS['accent_glow'],
        )
        self.chat_area.pack(fill='both', expand=True, pady=(2, 0))

        # Tags de colores
        self.chat_area.tag_configure('user',
                                     foreground=COLORS['text_user'],
                                     font=('Courier New', 10))
        self.chat_area.tag_configure('jarvis',
                                     foreground=COLORS['text_jarvis'],
                                     font=('Courier New', 10, 'bold'))
        self.chat_area.tag_configure('system',
                                     foreground=COLORS['text_system'],
                                     font=('Courier New', 9, 'italic'))
        self.chat_area.tag_configure('timestamp',
                                     foreground=COLORS['text_secondary'],
                                     font=('Courier New', 8))
        self.chat_area.tag_configure('success',
                                     foreground=COLORS['success'])
        self.chat_area.tag_configure('warning',
                                     foreground=COLORS['warning'])
        self.chat_area.tag_configure('error',
                                     foreground=COLORS['danger'])

        # Mensaje de bienvenida — sin el startup fijo que duplica el greeting
        import datetime
        hora = datetime.datetime.now().hour
        if 6 <= hora < 13:
            turno = "matinal"
        elif 13 <= hora < 20:
            turno = "vespertino"
        else:
            turno = "nocturno"
        # Sesión iniciada — sin mensaje de sistema redundante

    def _build_input_panel(self, parent):
        """Construir panel de entrada de texto."""
        # Borde superior
        tk.Frame(parent, bg=COLORS['accent_blue'], height=1).pack(fill='x')

        input_frame = tk.Frame(parent, bg=COLORS['bg_panel'], height=60)
        input_frame.pack(fill='x', pady=(0, 0))
        input_frame.pack_propagate(False)

        # Prompt label
        prompt_lbl = tk.Label(
            input_frame, text="  SEÑOR > ",
            font=('Courier New', 11, 'bold'),
            fg=COLORS['accent_cyan'], bg=COLORS['bg_panel']
        )
        prompt_lbl.pack(side='left', pady=15)

        # Campo de entrada
        self._input_var = tk.StringVar()
        self.input_field = tk.Entry(
            input_frame,
            textvariable=self._input_var,
            font=('Courier New', 11),
            bg=COLORS['bg_input'],
            fg=COLORS['text_primary'],
            insertbackground=COLORS['accent_cyan'],
            relief='flat',
            bd=5,
        )
        self.input_field.pack(side='left', fill='both', expand=True, pady=12, padx=(0, 5))

        # Botones
        btn_frame = tk.Frame(input_frame, bg=COLORS['bg_panel'])
        btn_frame.pack(side='right', padx=5)

        self._send_btn = tk.Button(
            btn_frame, text="ENVIAR",
            font=('Courier New', 9, 'bold'),
            fg=COLORS['bg_dark'], bg=COLORS['accent_cyan'],
            relief='flat', padx=10, pady=8,
            cursor='hand2',
            command=self._send_message
        )
        self._send_btn.pack(side='left', padx=3, pady=12)

        self._voice_btn = tk.Button(
            btn_frame, text="🎤",
            font=('Arial', 12),
            fg=COLORS['text_primary'], bg=COLORS['bg_medium'],
            relief='flat', padx=8, pady=8,
            cursor='hand2',
            command=self._toggle_voice
        )
        self._voice_btn.pack(side='left', padx=3, pady=12)

    def _build_system_panel(self, parent):
        """Construir panel de estado del sistema."""
        # Header
        sys_header = tk.Frame(parent, bg=COLORS['bg_panel'], height=30)
        sys_header.pack(fill='x')

        tk.Label(
            sys_header, text="◈ ESTADO DEL SISTEMA",
            font=('Courier New', 9, 'bold'),
            fg=COLORS['accent_blue'], bg=COLORS['bg_panel']
        ).pack(side='left', padx=10, pady=5)

        # Panel de métricas
        metrics_frame = tk.Frame(parent, bg=COLORS['bg_panel'], padx=10, pady=10)
        metrics_frame.pack(fill='x')

        # CPU
        self._cpu_var = tk.StringVar(value="CPU: ---%")
        self._cpu_bar_var = tk.DoubleVar(value=0)

        cpu_frame = tk.Frame(metrics_frame, bg=COLORS['bg_panel'])
        cpu_frame.pack(fill='x', pady=4)
        tk.Label(cpu_frame, textvariable=self._cpu_var,
                 font=('Courier New', 9), fg=COLORS['text_primary'],
                 bg=COLORS['bg_panel'], anchor='w').pack(side='top', fill='x')
        cpu_prog = ttk.Progressbar(cpu_frame, variable=self._cpu_bar_var,
                                   maximum=100, length=260)
        cpu_prog.pack(side='top', fill='x')

        # RAM
        self._ram_var = tk.StringVar(value="RAM: ---%")
        self._ram_bar_var = tk.DoubleVar(value=0)

        ram_frame = tk.Frame(metrics_frame, bg=COLORS['bg_panel'])
        ram_frame.pack(fill='x', pady=4)
        tk.Label(ram_frame, textvariable=self._ram_var,
                 font=('Courier New', 9), fg=COLORS['text_primary'],
                 bg=COLORS['bg_panel'], anchor='w').pack(side='top', fill='x')
        ram_prog = ttk.Progressbar(ram_frame, variable=self._ram_bar_var,
                                   maximum=100, length=260)
        ram_prog.pack(side='top', fill='x')

        # Disco
        self._disk_var = tk.StringVar(value="Disco: ---%")
        self._disk_bar_var = tk.DoubleVar(value=0)

        disk_frame = tk.Frame(metrics_frame, bg=COLORS['bg_panel'])
        disk_frame.pack(fill='x', pady=4)
        tk.Label(disk_frame, textvariable=self._disk_var,
                 font=('Courier New', 9), fg=COLORS['text_primary'],
                 bg=COLORS['bg_panel'], anchor='w').pack(side='top', fill='x')
        disk_prog = ttk.Progressbar(disk_frame, variable=self._disk_bar_var,
                                    maximum=100, length=260)
        disk_prog.pack(side='top', fill='x')

        # Estado IA
        ai_frame = tk.Frame(metrics_frame, bg=COLORS['bg_panel'])
        ai_frame.pack(fill='x', pady=8)
        tk.Label(ai_frame, text="FUENTE IA:",
                 font=('Courier New', 8), fg=COLORS['text_secondary'],
                 bg=COLORS['bg_panel']).pack(side='left')
        self._ai_source_var = tk.StringVar(value="Inicializando...")
        tk.Label(ai_frame, textvariable=self._ai_source_var,
                 font=('Courier New', 8, 'bold'),
                 fg=COLORS['accent_cyan'], bg=COLORS['bg_panel']).pack(side='left', padx=5)

        # Estado actual
        tk.Label(metrics_frame, text="ESTADO:", font=('Courier New', 8),
                 fg=COLORS['text_secondary'], bg=COLORS['bg_panel']).pack(anchor='w')
        self._mood_var = tk.StringVar(value="INICIANDO...")
        tk.Label(metrics_frame, textvariable=self._mood_var,
                 font=('Courier New', 10, 'bold'),
                 fg=COLORS['success'], bg=COLORS['bg_panel']).pack(anchor='w')

        # Módulos activos
        mods_lbl = tk.Label(metrics_frame, text="MÓDULOS:", font=('Courier New', 8),
                             fg=COLORS['text_secondary'], bg=COLORS['bg_panel'])
        mods_lbl.pack(anchor='w', pady=(8, 0))
        self._modules_var = tk.StringVar(value="Cargando...")
        tk.Label(metrics_frame, textvariable=self._modules_var,
                 font=('Courier New', 8), fg=COLORS['text_system'],
                 bg=COLORS['bg_panel'], justify='left').pack(anchor='w')

    def _build_log_panel(self, parent):
        """Construir panel de logs."""
        # Borde
        tk.Frame(parent, bg=COLORS['separator'], height=2).pack(fill='x', pady=5)

        log_header = tk.Frame(parent, bg=COLORS['bg_panel'], height=25)
        log_header.pack(fill='x')

        tk.Label(
            log_header, text="◈ LOGS DEL SISTEMA",
            font=('Courier New', 8, 'bold'),
            fg=COLORS['accent_blue'], bg=COLORS['bg_panel']
        ).pack(side='left', padx=10, pady=3)

        self.log_area = scrolledtext.ScrolledText(
            parent,
            font=('Courier New', 8),
            bg=COLORS['bg_dark'],
            fg=COLORS['text_secondary'],
            state='disabled',
            relief='flat',
            bd=0,
            height=12,
            wrap=tk.WORD
        )
        self.log_area.pack(fill='both', expand=True)

    def _build_status_bar(self):
        """Construir barra de estado inferior."""
        tk.Frame(self.root, bg=COLORS['accent_blue'], height=1).pack(fill='x')

        status_bar = tk.Frame(self.root, bg=COLORS['bg_panel'], height=25)
        status_bar.pack(fill='x', side='bottom')
        status_bar.pack_propagate(False)

        self._status_var = tk.StringVar(value="Sistema inicializado — A sus órdenes, Señor.")
        tk.Label(
            status_bar,
            textvariable=self._status_var,
            font=('Courier New', 8),
            fg=COLORS['text_secondary'],
            bg=COLORS['bg_panel']
        ).pack(side='left', padx=10, pady=3)

        # Versión
        tk.Label(
            status_bar, text="MARK 5 | Anthropic Claude Engine",
            font=('Courier New', 8),
            fg=COLORS['text_secondary'], bg=COLORS['bg_panel']
        ).pack(side='right', padx=10)

    def _bind_events(self):
        """Vincular eventos de teclado."""
        self.root.bind('<Return>', lambda e: self._send_message())
        self.root.bind('<Control-l>', lambda e: self._clear_chat())
        self.input_field.focus_set()

    def _send_message(self):
        """Enviar mensaje al brain — con protección anti-duplicado."""
        if getattr(self, '_processing', False):
            return  # Ya procesando, ignorar
        text = self._input_var.get().strip()
        if not text:
            return

        self._processing = True
        self._input_var.set('')
        self._add_chat_message("Señor", text, 'user')
        self._set_status("Procesando solicitud...")
        self._set_ai_indicator(True)

        def process():
            try:
                response = self.brain.process_command(text)
                self._msg_queue.put(('response', response))
            except Exception as e:
                self._msg_queue.put(('error', str(e)))
            finally:
                self._msg_queue.put(('done', None))
                self._processing = False

        threading.Thread(target=process, daemon=True).start()

    def _on_brain_event(self, event_type: str, data=None):
        """Manejar eventos del brain."""
        self._msg_queue.put((event_type, data))

    def _process_msg_queue(self):
        """Procesar mensajes de la cola."""
        while not self._msg_queue.empty():
            try:
                event_type, data = self._msg_queue.get_nowait()
                self._handle_event(event_type, data)
            except queue.Empty:
                break
            except Exception as e:
                logger.debug(f"Error procesando queue: {e}")

    def _handle_event(self, event_type: str, data):
        """Manejar evento específico."""
        if event_type == 'response':
            if data:
                self._add_chat_message("MARK", data, 'jarvis')
                self._set_status("Listo — A sus órdenes, Señor.")
        elif event_type == 'error':
            self._add_chat_message("Sistema", f"Error: {data}", 'error')
        elif event_type == 'done':
            self._set_ai_indicator(False)
        elif event_type == 'autonomous_notification':
            self._add_chat_message("MARK [Autónomo]", data, 'system')
            self._add_log(f"[AUTÓNOMO] {data}")
        elif event_type == 'log':
            self._add_log(str(data))
        elif event_type == 'alert':
            self._add_chat_message("Sistema", str(data), 'warning')

    def _add_chat_message(self, sender: str, message: str, msg_type: str = 'system'):
        """Añadir mensaje al chat."""
        timestamp = datetime.now().strftime("%H:%M:%S")

        self.chat_area.config(state='normal')

        # Timestamp
        self.chat_area.insert('end', f"[{timestamp}] ", 'timestamp')

        # Sender
        prefix = {
            'user': f"[ {sender} ]: ",
            'jarvis': f"[ {sender} ]: ",
            'system': f"[ {sender} ]: ",
            'error': f"[ ERROR ]: ",
            'warning': f"[ ALERTA ]: ",
            'success': f"[ ✓ ]: ",
        }.get(msg_type, f"[ {sender} ]: ")

        self.chat_area.insert('end', prefix, msg_type)
        self.chat_area.insert('end', f"{message}\n\n", msg_type)

        self.chat_area.config(state='disabled')
        self.chat_area.see('end')

    def _add_log(self, message: str):
        """Añadir entrada al log."""
        timestamp = datetime.now().strftime("%H:%M:%S")
        self.log_area.config(state='normal')
        self.log_area.insert('end', f"[{timestamp}] {message}\n")
        self.log_area.config(state='disabled')
        self.log_area.see('end')

    def _set_status(self, text: str):
        """Actualizar barra de estado."""
        self._status_var.set(text)

    def _set_ai_indicator(self, active: bool):
        """Actualizar indicador de IA."""
        if active:
            self._ai_indicator['dot'].config(fg=COLORS['warning'])
        else:
            self._ai_indicator['dot'].config(fg=COLORS['accent_cyan'])

    def _update_clock(self):
        """Actualizar reloj."""
        now = datetime.now().strftime("%Y-%m-%d  %H:%M:%S")
        self._clock_lbl.config(text=now)
        self.root.after(1000, self._update_clock)

    def _update_system_metrics(self):
        """Actualizar métricas del sistema en UI."""
        if not self.brain:
            return

        try:
            status = self.brain.get_status()
            system_state = status.get('system', {})

            cpu = system_state.get('cpu_usage', 0)
            ram = system_state.get('memory_usage', 0)
            disk = system_state.get('disk_usage', 0)
            mood = system_state.get('mood', 'unknown')

            self._cpu_var.set(f"CPU: {cpu:.1f}%")
            self._cpu_bar_var.set(cpu)
            self._ram_var.set(f"RAM: {ram:.1f}%")
            self._ram_bar_var.set(ram)
            self._disk_var.set(f"Disco: {disk:.1f}%")
            self._disk_bar_var.set(disk)

            mood_display = {
                'neutral': '●  NOMINAL',
                'focused': '◉  PROCESANDO',
                'alert': '⚠  ALERTA',
                'idle': '○  REPOSO',
                'processing': '◈  ACTIVO',
                'warning': '⚠  ADVERTENCIA',
            }.get(mood, f'●  {mood.upper()}')

            self._mood_var.set(mood_display)

            # Color del mood
            mood_color = {
                'neutral': COLORS['success'],
                'focused': COLORS['accent_cyan'],
                'alert': COLORS['warning'],
                'idle': COLORS['text_secondary'],
                'processing': COLORS['accent_blue'],
                'warning': COLORS['danger'],
            }.get(mood, COLORS['text_primary'])

            # Actualizar source de IA
            if self.brain.ai_manager:
                ai_status = self.brain.ai_manager.get_status()
                source_map = {
                    'local': 'Ollama Local',
                    'online': 'Pollinations',
                    'fallback': 'Motor Local'
                }
                self._ai_source_var.set(source_map.get(ai_status.get('active_source', ''), 'Desconocido'))

            # Módulos activos
            modules = status.get('modules', {})
            active = [k.upper() for k, v in modules.items() if v]
            self._modules_var.set("\n".join(f"  ✓ {m}" for m in active[:6]))

        except Exception as e:
            logger.debug(f"Error actualizando métricas UI: {e}")

    def _schedule_ui_updates(self):
        """Programar actualizaciones periódicas de UI."""
        def update():
            self._process_msg_queue()
            self._update_system_metrics()
            self.root.after(1000, update)

        self.root.after(1000, update)

    def _toggle_voice(self):
        """Activar/desactivar escucha de voz."""
        if not self.brain.voice or not self.brain.voice.stt_enabled:
            self._add_chat_message("Sistema", "Sistema de voz STT no disponible. Instale speech_recognition, Señor.", 'system')
            return

        if self._voice_listening:
            self._voice_listening = False
            self._voice_btn.config(text="🎤", bg=COLORS['bg_medium'])
            self._voice_indicator['dot'].config(fg=COLORS['text_secondary'])
        else:
            self._voice_listening = True
            self._voice_btn.config(text="⏹", bg=COLORS['danger'])
            self._voice_indicator['dot'].config(fg=COLORS['success'])
            threading.Thread(target=self._listen_voice, daemon=True).start()

    def _listen_voice(self):
        """Escuchar entrada de voz."""
        self._add_log("Escuchando voz...")
        try:
            text = self.brain.voice.listen(timeout=8)
            if text:
                self._input_var.set(text)
                self._send_message()
            else:
                self._add_log("No se detectó voz")
        except Exception as e:
            self._add_log(f"Error voz: {e}")
        finally:
            self._voice_listening = False
            self._voice_btn.config(text="🎤", bg=COLORS['bg_medium'])
            self._voice_indicator['dot'].config(fg=COLORS['text_secondary'])

    def _clear_chat(self):
        """Limpiar área de chat."""
        self.chat_area.config(state='normal')
        self.chat_area.delete('1.0', 'end')
        self.chat_area.config(state='disabled')
        self._add_chat_message("Sistema", "Historial de chat limpiado, Señor.", 'system')

    def _on_close(self):
        """Manejar cierre de ventana."""
        if self.brain:
            try:
                self.brain.speak("Hasta luego, Señor. Sistema desconectándose.")
                self.brain.shutdown()
            except Exception:
                pass
        self.root.destroy()

    def run(self):
        """Iniciar loop principal de UI."""
        import time
        try:
            cpu = 0
            uptime = 0
            if self.brain and self.brain.state:
                m = self.brain.state.get_metrics()
                cpu = m.get('cpu', 0)
            greeting = "MARK en línea."
            if self.brain and self.brain.personality:
                greeting = self.brain.personality.get_greeting(cpu=cpu, uptime_minutes=uptime)
            self._add_chat_message("MARK", greeting, 'jarvis')
            if self.brain:
                threading.Thread(target=lambda: self.brain.speak(greeting), daemon=True).start()
        except Exception as e:
            self._add_chat_message("MARK", "En línea. ¿Qué necesita?", 'jarvis')

        self.root.mainloop()
