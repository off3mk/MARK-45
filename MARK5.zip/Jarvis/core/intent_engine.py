"""
JARVIS v4.0 - Intent Engine Semántico Avanzado
TF-IDF vectorization + cosine similarity + regex + contexto conversacional.
Entiende CUALQUIER frase, no solo patrones exactos.
"""

import logging
import re
import math
import json
from typing import Optional, Dict, Any, List, Tuple
from collections import defaultdict
from difflib import SequenceMatcher

logger = logging.getLogger('JARVIS.IntentEngine')


INTENT_KNOWLEDGE = [
    {
        'name': 'system_open', 'skill': 'system', 'action': 'open_app',
        'examples': [
            "abre chrome", "abre el navegador", "inicia spotify", "lanza vscode",
            "pon en marcha el bloc de notas", "ejecuta el explorador", "arranca discord",
            "quiero usar firefox", "necesito abrir word", "abre una ventana de chrome",
            "pon spotify", "dame chrome", "navegar por internet", "carga el editor",
            "abre visual studio", "inicia la aplicación", "lanza el programa",
        ],
        'extract': '_extract_app', 'requires_planning': False,
    },
    {
        'name': 'system_close', 'skill': 'system', 'action': 'close_app',
        'examples': [
            "cierra chrome", "mata el proceso", "termina spotify", "cierra esa ventana",
            "quita discord", "finaliza notepad", "apaga chrome", "sal de vscode",
            "cierra todo", "elimina el proceso de firefox", "mata discord",
        ],
        'extract': '_extract_app', 'requires_planning': False,
    },
    {
        'name': 'system_screenshot', 'skill': 'system', 'action': 'screenshot',
        'examples': [
            "toma una captura", "screenshot", "foto de la pantalla",
            "captura de pantalla", "guarda lo que se ve", "registra la pantalla",
            "quiero una imagen de la pantalla", "saca foto de la pantalla",
        ],
        'extract': '_empty', 'requires_planning': False,
    },
    {
        'name': 'system_info', 'skill': 'system', 'action': 'system_info',
        'examples': [
            "cómo está el sistema", "información del pc", "estado del sistema",
            "cuánta ram estoy usando", "qué uso de cpu tengo", "dime el estado del equipo",
            "cómo va el ordenador", "informe del sistema", "monitor de rendimiento",
            "cpu y ram", "uso de recursos", "rendimiento del sistema",
            "cuántos procesos hay", "memoria disponible",
        ],
        'extract': '_empty', 'requires_planning': False,
    },
    {
        'name': 'system_run_command', 'skill': 'system', 'action': 'run_command',
        'examples': [
            "ejecuta dir", "corre ipconfig", "lanza el comando ping",
            "ejecuta en terminal", "cmd ipconfig", "shell ls", "run dir",
            "ejecuta este comando", "desde la consola", "terminal con",
        ],
        'extract': '_extract_command', 'requires_planning': False,
    },
    {
        'name': 'system_type', 'skill': 'system', 'action': 'type_text',
        'examples': [
            "escribe hola mundo", "teclea mi nombre", "escribe esto",
            "ingresa el texto", "escríbelo ahí", "introduce el texto",
        ],
        'extract': '_extract_text', 'requires_planning': False,
    },
    {
        'name': 'system_shutdown', 'skill': 'system', 'action': 'shutdown',
        'examples': [
            "apaga el pc", "apaga el ordenador", "shutdown el sistema",
            "apaga el equipo ahora", "quiero apagar el ordenador",
            "cierra todo y apaga el pc", "power off el sistema",
        ],
        'extract': '_empty', 'requires_planning': False,
    },
    {
        'name': 'system_restart', 'skill': 'system', 'action': 'restart',
        'examples': [
            "reinicia el pc", "restart", "reiniciar el sistema", "reboot",
            "que se reinicie", "vuelve a arrancar", "reinicio del equipo",
        ],
        'extract': '_empty', 'requires_planning': False,
    },
    {
        'name': 'system_minimize', 'skill': 'system', 'action': 'minimize_window',
        'examples': [
            "minimiza la ventana", "minimiza chrome", "oculta la ventana",
            "manda abajo la ventana", "esconde la ventana",
        ],
        'extract': '_extract_app_optional', 'requires_planning': False,
    },
    {
        'name': 'system_maximize', 'skill': 'system', 'action': 'maximize_window',
        'examples': [
            "maximiza la ventana", "pon en pantalla completa",
            "maximiza chrome", "expande la ventana", "full screen",
        ],
        'extract': '_extract_app_optional', 'requires_planning': False,
    },
    {
        'name': 'internet_search', 'skill': 'internet', 'action': 'search',
        'examples': [
            "busca python en google", "googlea inteligencia artificial",
            "investiga sobre machine learning", "qué es una api rest",
            "quién inventó internet", "busca noticias de tesla",
            "encuéntrame información de react", "dame datos sobre el universo",
            "cómo funciona blockchain", "qué es docker",
            "dime qué es", "explícame cómo funciona", "buscar en internet",
            "información sobre", "qué sabes de", "cuéntame sobre",
        ],
        'extract': '_extract_query', 'requires_planning': False,
    },
    {
        'name': 'internet_open_url', 'skill': 'internet', 'action': 'open_url',
        'examples': [
            "abre github.com", "ve a youtube.com", "navega a google.com",
            "abre https://", "entra a la web", "visita la web de",
            "abre la página de", "ir a la url",
        ],
        'extract': '_extract_url', 'requires_planning': False,
    },
    {
        'name': 'internet_weather', 'skill': 'internet', 'action': 'weather',
        'examples': [
            "clima en madrid", "tiempo en barcelona", "qué temperatura hace en sevilla",
            "va a llover hoy", "cómo está el tiempo", "pronóstico del tiempo",
            "weather in london", "temperatura actual", "llueve en valencia",
            "hace frío en", "está lloviendo en", "qué tiempo hace",
        ],
        'extract': '_extract_city', 'requires_planning': False,
    },
    {
        'name': 'internet_news', 'skill': 'internet', 'action': 'news',
        'examples': [
            "noticias de hoy", "qué hay de nuevo", "últimas noticias",
            "noticias sobre ia", "novedades tecnología", "qué pasó hoy",
            "news", "titulares", "qué noticias hay", "novedades de hoy",
        ],
        'extract': '_extract_news_topic', 'requires_planning': False,
    },
    {
        'name': 'internet_wikipedia', 'skill': 'internet', 'action': 'wikipedia',
        'examples': [
            "wikipedia sobre python", "qué dice la wiki de einstein",
            "busca en wikipedia", "enciclopedia sobre la luna",
            "artículo de wikipedia sobre", "info enciclopédica de",
        ],
        'extract': '_extract_wiki_topic', 'requires_planning': False,
    },
    {
        'name': 'media_play', 'skill': 'media', 'action': 'play',
        'examples': [
            "pon un temazo", "quiero escuchar música", "reproduce algo",
            "pon música", "escuchar rock", "quiero oír jazz",
            "reproduce lo que sea", "música electrónica", "pon algo de fondo",
            "una canción", "música para estudiar", "pon lofi",
            "quiero relajarme con música", "algo de trap", "música latina",
            "play music", "ponme algo", "canciones", "pon algo bueno",
            "quiero música", "dame música", "activa la música",
        ],
        'extract': '_extract_music_query', 'requires_planning': False,
    },
    {
        'name': 'media_spotify', 'skill': 'media', 'action': 'open_spotify',
        'examples': [
            "abre spotify", "inicia spotify", "quiero spotify",
            "usa spotify", "pon spotify", "entra a spotify",
        ],
        'extract': '_empty', 'requires_planning': False,
    },
    {
        'name': 'media_pause', 'skill': 'media', 'action': 'pause',
        'examples': [
            "para la música", "pausa", "silencia la reproducción",
            "detén lo que suena", "para eso", "stop música",
            "parar la canción", "deja de reproducir",
        ],
        'extract': '_empty', 'requires_planning': False,
    },
    {
        'name': 'media_next', 'skill': 'media', 'action': 'next',
        'examples': [
            "siguiente canción", "skip", "pasa a la siguiente",
            "otra canción", "cambia la canción", "no me gusta esta",
            "pasa", "salta esta", "siguiente pista",
        ],
        'extract': '_empty', 'requires_planning': False,
    },
    {
        'name': 'media_previous', 'skill': 'media', 'action': 'previous',
        'examples': [
            "anterior", "canción anterior", "vuelve atrás", "la anterior",
            "pon la de antes", "previous",
        ],
        'extract': '_empty', 'requires_planning': False,
    },
    {
        'name': 'media_volume_set', 'skill': 'media', 'action': 'volume',
        'examples': [
            "volumen al 50", "sube el volumen", "baja el sonido",
            "ponlo más alto", "más bajito", "volumen máximo", "volumen mínimo",
            "que suene más fuerte", "muy alto el volumen", "casi no se oye",
            "súbelo", "bájalo", "más volumen", "menos volumen",
        ],
        'extract': '_extract_volume', 'requires_planning': False,
    },
    {
        'name': 'media_mute', 'skill': 'media', 'action': 'mute',
        'examples': [
            "silencia", "mute", "quita el sonido", "sin audio",
            "desactiva el sonido", "silencio", "apaga el sonido",
        ],
        'extract': '_empty', 'requires_planning': False,
    },
    {
        'name': 'memory_save', 'skill': 'memory_skill', 'action': 'remember',
        'examples': [
            "recuerda que mi email es", "guarda mi contraseña",
            "anota esto", "no olvides que", "guárdate que",
            "toma nota", "apunta", "memoriza esto",
            "mi nombre es", "mi número es", "vivo en",
            "quiero que sepas que", "guarda esta información",
        ],
        'extract': '_extract_memory_text', 'requires_planning': False,
    },
    {
        'name': 'memory_recall', 'skill': 'memory_skill', 'action': 'recall',
        'examples': [
            "cuál es mi email", "recuérdame mi contraseña",
            "qué guardaste sobre", "dime lo que sé de",
            "qué recuerdas de", "dime mi número", "cuál era",
            "qué tienes guardado de", "busca en tu memoria",
        ],
        'extract': '_extract_recall_key', 'requires_planning': False,
    },
    {
        'name': 'coding_read_doc', 'skill': 'coding', 'action': 'read_document',
        'examples': [
            "lee este documento", "lee el word", "lee el archivo",
            "analiza este documento", "qué dice el documento",
            "abre el word y léelo", "revisa el documento word",
            "lee mi práctica", "lee mi trabajo", "lee mi tarea",
            "abre el docx", "lee el archivo de texto",
        ],
        'extract': '_extract_doc_path', 'requires_planning': False,
    },
    {
        'name': 'coding_analyze_doc', 'skill': 'coding', 'action': 'analyze_document',
        'examples': [
            "ayúdame con mi práctica", "mejora mi trabajo",
            "corrige mi tarea", "revisa lo que he escrito",
            "analiza mi documento", "qué puedo mejorar",
            "edita mi trabajo para que parezca que lo escribí yo",
            "reescribe esto como si fuera yo", "mejóralo pero que suene a mí",
            "hazlo más natural", "corrige sin que se note",
        ],
        'extract': '_extract_doc_path', 'requires_planning': False,
    },
    {
        'name': 'coding_learn_style', 'skill': 'coding', 'action': 'learn_style_from_text',
        'examples': [
            "aprende cómo escribo", "aprende mi estilo",
            "así es como escribo yo", "memoriza mi forma de escribir",
            "este es mi estilo de escritura", "adapta tu escritura a la mía",
        ],
        'extract': '_extract_doc_path', 'requires_planning': False,
    },
    {
        'name': 'coding_create', 'skill': 'coding', 'action': 'create_script',
        'examples': [
            "crea un script de python", "escribe código para una calculadora",
            "genera un programa", "hazme un script", "programa una función",
            "código para automatizar", "escríbeme un bot", "quiero un script que",
            "crea un archivo python", "genera código", "hazme un programa",
            "crea un script", "escribe un programa en python",
        ],
        'extract': '_extract_code_description', 'requires_planning': False,
    },
    {
        'name': 'automation_work_mode', 'skill': 'system', 'action': 'automation_mode',
        'examples': [
            "modo trabajo", "prepara el entorno de trabajo", "empieza la jornada",
            "quiero trabajar", "configura para trabajar", "setup de trabajo",
            "activa modo oficina", "entorno laboral",
            "voy a programar", "voy a trabajar", "a trabajar",
            "modo programación", "voy a picar código", "a programar",
        ],
        'extract': '_extract_mode_work', 'requires_planning': True,
    },
    {
        'name': 'automation_relax_mode', 'skill': 'system', 'action': 'automation_mode',
        'examples': [
            "modo relajación", "quiero descansar", "tiempo de relax",
            "prepara ambiente relajado", "modo descanso", "relajarme",
        ],
        'extract': '_extract_mode_relax', 'requires_planning': True,
    },
    {
        'name': 'automation_study_mode', 'skill': 'system', 'action': 'automation_mode',
        'examples': [
            "modo estudio", "quiero estudiar", "prepara para estudiar",
            "voy a estudiar", "modo concentración", "entorno de estudio",
        ],
        'extract': '_extract_mode_study', 'requires_planning': True,
    },
    {
        'name': 'system_check_performance', 'skill': 'system', 'action': 'system_info',
        'examples': [
            "algo va lento", "el pc va lento", "está todo lento",
            "va muy lento", "está colgado", "no responde",
            "el sistema va fatal", "va como el culo", "tarda mucho",
            "se ha quedado pillado", "se congela", "lag",
        ],
        'extract': '_empty', 'requires_planning': False,
    },
    {
        'name': 'greeting', 'skill': 'system', 'action': 'greeting',
        'examples': [
            "hola", "buenas", "buenos días", "buenas tardes", "buenas noches",
            "hey", "qué tal", "cómo estás", "qué pasa", "ey mark",
            "ey jarvis", "estás ahí", "sigues ahí",
        ],
        'extract': '_empty', 'requires_planning': False,
    },
    {
        'name': 'system_status', 'skill': 'system', 'action': 'system_info',
        'examples': [
            "cómo va todo", "informe de estado", "dame un reporte",
            "qué tal estás", "estás funcionando bien",
        ],
        'extract': '_empty', 'requires_planning': False,
    },
    {
        'name': 'cancel', 'skill': 'system', 'action': 'cancel',
        'examples': [
            "cancela eso", "cancela la operación", "cancela todo",
            "abortar", "abort", "olvídalo", "déjalo", "no hagas nada",
            "para la operación", "cancela lo que ibas a hacer",
        ],
        'extract': '_empty', 'requires_planning': False,
    },
]

APP_ALIASES = {
    'chrome': ['chrome', 'google chrome', 'chromium', 'navegador', 'browser'],
    'firefox': ['firefox', 'mozilla'],
    'edge': ['edge', 'microsoft edge'],
    'spotify': ['spotify', 'spoti'],
    'vscode': ['vscode', 'visual studio code', 'code', 'vs code'],
    'discord': ['discord'],
    'notepad': ['notepad', 'bloc de notas', 'notas'],
    'explorer': ['explorador', 'archivos', 'explorer', 'carpetas'],
    'word': ['word', 'microsoft word'],
    'excel': ['excel', 'hoja de cálculo'],
    'obs': ['obs', 'obs studio'],
    'terminal': ['terminal', 'consola', 'cmd', 'powershell'],
    'steam': ['steam'],
    'vlc': ['vlc', 'reproductor'],
}


class TFIDFVectorizer:
    """Vectorizador TF-IDF sin dependencias externas."""

    def __init__(self):
        self.idf: Dict[str, float] = {}
        self._fitted = False

    def _tokenize(self, text: str) -> List[str]:
        text = text.lower()
        text = re.sub(r'[^\w\s]', ' ', text)
        words = [w for w in text.split() if len(w) > 1]
        bigrams = [f"{words[i]}_{words[i+1]}" for i in range(len(words)-1)]
        return words + bigrams

    def fit(self, corpus: List[str]):
        n = len(corpus)
        doc_freq: Dict[str, int] = defaultdict(int)
        for doc in corpus:
            for term in set(self._tokenize(doc)):
                doc_freq[term] += 1
        for term, df in doc_freq.items():
            self.idf[term] = math.log((n + 1) / (df + 1)) + 1
        self._fitted = True

    def transform(self, text: str) -> Dict[str, float]:
        tokens = self._tokenize(text)
        if not tokens:
            return {}
        tf: Dict[str, float] = {}
        total = len(tokens)
        for t in tokens:
            tf[t] = tf.get(t, 0) + 1 / total
        return {t: tf_val * self.idf.get(t, math.log(2) + 1)
                for t, tf_val in tf.items()}

    def cosine_similarity(self, v1: Dict[str, float], v2: Dict[str, float]) -> float:
        if not v1 or not v2:
            return 0.0
        common = set(v1) & set(v2)
        if not common:
            return 0.0
        dot = sum(v1[k] * v2[k] for k in common)
        n1 = math.sqrt(sum(x**2 for x in v1.values()))
        n2 = math.sqrt(sum(x**2 for x in v2.values()))
        return dot / (n1 * n2) if n1 and n2 else 0.0


class SemanticIntentEngine:
    """Motor de intención semántico completo."""

    THRESHOLD = 0.22
    HIGH_CONF = 0.60

    def __init__(self):
        self.vectorizer = TFIDFVectorizer()
        self._example_vectors: List[Tuple[str, Dict[str, float]]] = []
        self._intent_map: Dict[str, Dict] = {}
        self._context_history: List[Dict] = []
        self._max_context = 8
        self._build_index()

    def _build_index(self):
        corpus, ids = [], []
        for intent in INTENT_KNOWLEDGE:
            self._intent_map[intent['name']] = intent
            for ex in intent['examples']:
                corpus.append(ex)
                ids.append(intent['name'])
        self.vectorizer.fit(corpus)
        self._example_vectors = [
            (ids[i], self.vectorizer.transform(corpus[i]))
            for i in range(len(corpus))
        ]
        logger.info(f"Índice semántico: {len(corpus)} ejemplos | {len(INTENT_KNOWLEDGE)} intenciones")

    def detect_intent(self, text: str) -> Optional[Dict[str, Any]]:
        text = text.strip()
        if not text:
            return None

        # 1. Regex rápido
        r1 = self._regex_fast(text)
        if r1 and r1['confidence'] > 0.88:
            self._push_context(r1)
            return r1

        # 2. Semántico TF-IDF
        r2 = self._semantic(text)

        # 3. Fuzzy fallback
        r3 = self._fuzzy(text)

        # 4. Merge
        best = self._merge(r1, r2, r3)

        if best and best['confidence'] >= self.THRESHOLD:
            self._push_context(best)
            logger.debug(f"→ {best['name']} [{best['confidence']:.2f}]")
            return best

        # 5. Contexto
        ctx = self._from_context(text)
        if ctx:
            return ctx

        return None

    def _regex_fast(self, text: str) -> Optional[Dict]:
        t = text.lower()
        rules = [
            (r'https?://\S+|www\.\w+\.\w+', 'internet_open_url', '_extract_url'),
            (r'\bvolumen?\s+(?:al?\s+)?(\d+)', 'media_volume_set', '_extract_volume'),
            (r'\bapaga[r]?\s+(?:el\s+)?(?:pc|ordenador|sistema|equipo)\b', 'system_shutdown', '_empty'),
            (r'\breinicia[r]?\b', 'system_restart', '_empty'),
            (r'\bscreenshot\b|\bcaptura\s+de\s+pantalla\b', 'system_screenshot', '_empty'),
            (r'\bmute\b|\bsilenci[ao][r]?\b', 'media_mute', '_empty'),
            (r'\bskip\b|\bsiguiente\s+(?:canción|pista)\b', 'media_next', '_empty'),
            (r'^(?:abre?|inicia?|lanza?)\s+([\w\s]+?)\s*$', 'system_open', '_extract_app'),
            (r'^(?:cierra?|mata?|termina?)\s+([\w\s]+?)\s*$', 'system_close', '_extract_app'),
            (r'^(?:modo|mode)\s+(trabajo|trabajo|relax|relajación|estudio|concentración)', 'automation_work_mode', '_extract_mode_auto'),
        ]
        for pattern, intent_name, extractor in rules:
            m = re.search(pattern, t)
            if m:
                idef = self._intent_map.get(intent_name)
                if idef:
                    params = self._extract(extractor, text, m)
                    return self._make(idef, params, 0.92, text)
        return None

    def _semantic(self, text: str) -> Optional[Dict]:
        qv = self.vectorizer.transform(text)
        if not qv:
            return None
        scores: Dict[str, float] = {}
        for intent_name, ev in self._example_vectors:
            s = self.vectorizer.cosine_similarity(qv, ev)
            scores[intent_name] = max(scores.get(intent_name, 0), s)
        if not scores:
            return None
        best_name = max(scores, key=lambda k: scores[k])
        best_score = scores[best_name]
        if best_score < self.THRESHOLD:
            return None
        idef = self._intent_map.get(best_name)
        if not idef:
            return None
        return self._make(idef, self._extract(idef['extract'], text), best_score, text)

    def _fuzzy(self, text: str) -> Optional[Dict]:
        tl = text.lower()
        best_s, best_intent = 0.0, None
        for intent in INTENT_KNOWLEDGE:
            for ex in intent['examples']:
                ratio = SequenceMatcher(None, tl, ex.lower()).ratio()
                tw = set(tl.split())
                ew = set(ex.lower().split())
                overlap = len(tw & ew) / max(len(ew), 1)
                score = ratio * 0.35 + overlap * 0.65
                if score > best_s:
                    best_s, best_intent = score, intent
        if best_s < 0.30 or not best_intent:
            return None
        return self._make(best_intent,
                          self._extract(best_intent['extract'], text),
                          best_s * 0.78, text)

    def _merge(self, *results) -> Optional[Dict]:
        candidates = [r for r in results if r]
        if not candidates:
            return None
        names = [c['name'] for c in candidates]
        if len(set(names)) == 1:
            best = max(candidates, key=lambda x: x['confidence'])
            best['confidence'] = min(best['confidence'] * 1.15, 1.0)
            return best
        return max(candidates, key=lambda x: x['confidence'])

    def _from_context(self, text: str) -> Optional[Dict]:
        if not self._context_history:
            return None
        last = self._context_history[-1]
        tl = text.lower()
        yes = {'sí', 'si', 'yes', 'ok', 'claro', 'dale', 'adelante', 'confirmar', 'hazlo'}
        no  = {'no', 'nope', 'cancela', 'cancel', 'para', 'olvídalo', 'déjalo'}
        if any(w in tl for w in yes):
            if last.get('action') == 'create_script':
                return self._make({'name': 'coding_confirm', 'skill': 'coding',
                                   'action': 'confirm_run', 'requires_planning': False},
                                  {}, 0.80, text)
        if any(w in tl for w in no):
            return self._make(self._intent_map.get('cancel', {}), {}, 0.80, text)
        # Seguimiento de volumen
        if last.get('action') == 'volume':
            if any(w in tl for w in ['más', 'sube', 'alto', 'fuerte']):
                return self._make(self._intent_map['media_volume_set'],
                                  {'level': None, 'direction': 'up'}, 0.72, text)
            if any(w in tl for w in ['baja', 'menos', 'bajo']):
                return self._make(self._intent_map['media_volume_set'],
                                  {'level': None, 'direction': 'down'}, 0.72, text)
        return None

    def _make(self, idef: Dict, params: Dict, conf: float, text: str,
              name_override=None, action_override=None) -> Optional[Dict]:
        if not idef:
            return None
        return {
            'name': name_override or idef.get('name', 'unknown'),
            'skill': idef.get('skill', ''),
            'action': action_override or idef.get('action', ''),
            'requires_planning': idef.get('requires_planning', False),
            'multi_step': idef.get('requires_planning', False),
            'params': params or {},
            'confidence': round(min(conf, 1.0), 3),
            'original_text': text,
        }

    def _push_context(self, intent: Dict):
        self._context_history.append(intent)
        if len(self._context_history) > self._max_context:
            self._context_history.pop(0)

    # ── EXTRACTORES ──────────────────────────────────────────────────

    def _extract(self, name: str, text: str, match=None) -> Dict:
        fn = {
            '_extract_app': self._ext_app,
            '_extract_app_optional': self._ext_app_opt,
            '_extract_query': self._ext_query,
            '_extract_city': self._ext_city,
            '_extract_news_topic': self._ext_news,
            '_extract_wiki_topic': self._ext_wiki,
            '_extract_music_query': self._ext_music,
            '_extract_volume': self._ext_volume,
            '_extract_text': self._ext_text,
            '_extract_command': self._ext_command,
            '_extract_url': self._ext_url,
            '_extract_memory_text': self._ext_mem,
            '_extract_recall_key': self._ext_recall,
            '_extract_code_description': self._ext_code,
            '_extract_doc_path': self._ext_doc_path,
            '_extract_mode_work': lambda t, m=None: {'mode': 'trabajo'},
            '_extract_mode_relax': lambda t, m=None: {'mode': 'relajacion'},
            '_extract_mode_study': lambda t, m=None: {'mode': 'estudio'},
            '_extract_mode_auto': self._ext_mode_auto,
            '_empty': lambda t, m=None: {},
        }.get(name, lambda t, m=None: {})
        try:
            return fn(text, match)
        except Exception:
            return {}

    def _normalize_app(self, text: str, match=None) -> str:
        tl = text.lower()
        for canonical, aliases in APP_ALIASES.items():
            for alias in aliases:
                if alias in tl:
                    return canonical
        if match and match.lastindex:
            raw = match.group(match.lastindex).strip()
            for canonical, aliases in APP_ALIASES.items():
                if raw in aliases or raw == canonical:
                    return canonical
            return raw.split()[0] if raw else ''
        m = re.search(r'\b(?:abre?|inicia?|lanza?|cierra?|mata?|pon)\s+(.+)', tl)
        if m:
            raw = m.group(1).strip()
            for c, als in APP_ALIASES.items():
                if raw in als:
                    return c
            return raw.split()[0]
        return ''

    def _ext_app(self, t: str, m=None) -> Dict:
        return {'app': self._normalize_app(t, m)}

    def _ext_app_opt(self, t: str, m=None) -> Dict:
        return {'app': self._normalize_app(t, m) or 'active'}

    def _ext_query(self, t: str, m=None) -> Dict:
        tl = t.lower()
        for r in sorted(['busca', 'buscar', 'googlea', 'investiga', 'dime', 'qué es',
                          'quién es', 'cómo funciona', 'encuéntrame', 'explícame',
                          'dame datos sobre', 'cuéntame sobre', 'qué sabes de',
                          'información sobre'], key=len, reverse=True):
            tl = tl.replace(r, '').strip()
        tl = re.sub(r'^\s*(un|una|el|la|sobre|de|en)\s+', '', tl)
        return {'query': tl.strip() or t}

    def _ext_city(self, t: str, m=None) -> Dict:
        tl = t.lower()
        for r in sorted(['clima', 'tiempo', 'temperatura', 'weather', 'pronóstico',
                          'hace', 'cuántos grados', 'qué tiempo', 'está lloviendo',
                          'va a llover', 'cómo está'], key=len, reverse=True):
            tl = tl.replace(r, '').strip()
        tl = re.sub(r'^\s*(en|de|a|hoy)\s+', '', tl).strip()
        return {'city': tl or 'Madrid'}

    def _ext_news(self, t: str, m=None) -> Dict:
        tl = t.lower()
        for r in ['noticias', 'news', 'titulares', 'qué hay de nuevo',
                  'últimas', 'novedades', 'qué pasó', 'sobre', 'de']:
            tl = tl.replace(r, '').strip()
        return {'topic': tl.strip() or 'general'}

    def _ext_wiki(self, t: str, m=None) -> Dict:
        tl = t.lower()
        for r in ['wikipedia', 'wiki', 'busca en', 'artículo', 'enciclopedia', 'sobre', 'de']:
            tl = tl.replace(r, '').strip()
        return {'topic': tl.strip() or t}

    def _ext_music(self, t: str, m=None) -> Dict:
        tl = t.lower()
        for r in sorted(['reproduce', 'pon', 'ponme', 'quiero', 'escuchar', 'oír',
                          'música', 'canción', 'play', 'una', 'un', 'algo de',
                          'temazo', 'dame', 'activa'], key=len, reverse=True):
            tl = re.sub(r'\b' + re.escape(r) + r'\b', '', tl)
        q = tl.strip()
        return {'query': q if len(q) > 2 else 'música'}

    def _ext_volume(self, t: str, m=None) -> Dict:
        tl = t.lower()
        n = re.search(r'(\d+)', tl)
        if n:
            return {'level': int(n.group(1)), 'direction': None}
        if any(w in tl for w in ['sube', 'más alto', 'fuerte', 'más', 'aumenta', 'súbelo']):
            return {'level': None, 'direction': 'up'}
        if any(w in tl for w in ['baja', 'menos', 'bajo', 'reduce', 'bájalo']):
            return {'level': None, 'direction': 'down'}
        if 'máximo' in tl or 'max' in tl:
            return {'level': 100, 'direction': None}
        if 'mínimo' in tl or 'min' in tl:
            return {'level': 10, 'direction': None}
        return {'level': None, 'direction': None}

    def _ext_text(self, t: str, m=None) -> Dict:
        q = re.search(r'["\'](.+?)["\']', t)
        if q:
            return {'text': q.group(1)}
        m2 = re.search(r'\b(?:escribe?|teclea?|ingresa?)\s+(.+)', t.lower())
        return {'text': m2.group(1).strip() if m2 else t}

    def _ext_command(self, t: str, m=None) -> Dict:
        bt = re.search(r'`(.+?)`', t)
        if bt:
            return {'command': bt.group(1)}
        m2 = re.search(r'\b(?:ejecuta?|corre?|run|cmd|shell|comando)\s+(.+)', t.lower())
        return {'command': m2.group(1).strip() if m2 else t}

    def _ext_url(self, t: str, m=None) -> Dict:
        um = re.search(r'https?://\S+|www\.\S+|[\w-]+\.\w{2,}(?:/\S*)?', t.lower())
        if um:
            url = um.group(0)
            if not url.startswith('http'):
                url = 'https://' + url
            return {'url': url}
        return {'url': ''}

    def _ext_mem(self, t: str, m=None) -> Dict:
        for prefix in sorted(['recuerda que', 'guarda que', 'anota que', 'no olvides que',
                               'recuerda', 'guarda', 'anota', 'toma nota', 'apunta',
                               'memoriza', 'quiero que sepas que'], key=len, reverse=True):
            if t.lower().startswith(prefix):
                t = t[len(prefix):].strip()
                break
        return {'text': t}

    def _ext_recall(self, t: str, m=None) -> Dict:
        tl = t.lower()
        for r in sorted(['cuál es', 'cuál era', 'recuérdame', 'dime', 'qué es',
                          'qué recuerdas de', 'qué tienes guardado de',
                          'busca en tu memoria', 'mi', 'el', 'la'],
                         key=len, reverse=True):
            tl = tl.replace(r, '').strip()
        return {'key': tl.strip()}

    def _ext_code(self, t: str, m=None) -> Dict:
        tl = t.lower()
        for r in sorted(['crea', 'escribe', 'genera', 'hazme', 'programa', 'código',
                          'script', 'función', 'un', 'una', 'de python', 'en python',
                          'archivo', 'para'], key=len, reverse=True):
            tl = re.sub(r'\b' + re.escape(r) + r'\b', '', tl)
        desc = tl.strip()
        return {'description': desc if len(desc) > 3 else t}

    def _ext_doc_path(self, t: str, m=None) -> Dict:
        """Extraer ruta de documento."""
        path_m = re.search(r'[\w/\\:\- ]+\.(?:docx?|txt|pdf|odt)', t, re.IGNORECASE)
        if path_m:
            return {'path': path_m.group(0).strip()}
        path_m2 = re.search(r'[A-Za-z]:\\[\w\\ ]+|/[\w/ ]+\.[\w]+', t)
        if path_m2:
            return {'path': path_m2.group(0).strip()}
        return {'path': None}

    def _ext_mode_auto(self, t: str, m=None) -> Dict:
        tl = t.lower()
        if any(w in tl for w in ['trabajo', 'work', 'oficina']):
            return {'mode': 'trabajo'}
        if any(w in tl for w in ['relax', 'relajación', 'descanso']):
            return {'mode': 'relajacion'}
        if any(w in tl for w in ['estudio', 'study', 'concentración']):
            return {'mode': 'estudio'}
        return {'mode': tl.split()[-1] if tl.split() else 'trabajo'}

    def get_context(self) -> List[Dict]:
        return list(self._context_history)

    def get_stats(self) -> Dict:
        return {
            'examples': len(self._example_vectors),
            'intents': len(INTENT_KNOWLEDGE),
            'vocab': len(self.vectorizer.idf),
            'context': len(self._context_history),
        }


# Alias de compatibilidad
IntentEngine = SemanticIntentEngine
