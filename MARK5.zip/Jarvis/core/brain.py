"""
J.A.R.V.I.S MARK 5 - Núcleo Central (Brain)
Coordinador principal de todos los subsistemas.
"""

import logging
import threading
import time
import queue
from typing import Optional, Callable, Dict, Any

logger = logging.getLogger('JARVIS.Brain')


class JarvisBrain:
    """Núcleo central de JARVIS - coordina todos los subsistemas."""

    def __init__(self):
        self.initialized = False
        self.running = False
        self.command_queue = queue.PriorityQueue()
        self._ui_callback: Optional[Callable] = None
        self._modules: Dict[str, Any] = {}
        self.lock = threading.Lock()

        # Estado del sistema
        self.state = None
        self.memory = None
        self.cognitive_memory = None
        self.intent_engine = None
        self.ai_manager = None
        self.personality = None
        self.executor = None
        self.voice = None
        self.autonomous = None
        self.reasoning = None
        self.planner = None
        self.security = None
        self.skill_manager = None

    def initialize(self):
        """Inicializar todos los módulos del sistema."""
        logger.info("Inicializando módulos de J.A.R.V.I.S MARK 5...")

        try:
            # Importar y cargar módulos en orden
            self._load_state()
            self._load_memory()
            self._load_cognitive_memory()
            self._load_ai_manager()
            self._load_personality()
            self._load_security()
            self._load_intent_engine()
            self._load_reasoning()
            self._load_planner()
            self._load_executor()
            self._load_voice()
            self._load_skills()
            self._load_autonomous()

            self.initialized = True
            self.running = True

            # Iniciar procesador de comandos
            self._start_command_processor()

            logger.info("J.A.R.V.I.S MARK 5 inicializado correctamente.")

        except Exception as e:
            logger.error(f"Error durante inicialización: {e}")
            # Continuar con módulos disponibles
            self.initialized = True
            self.running = True

    def _load_state(self):
        try:
            from core.state import JarvisState
            self.state = JarvisState()
            self.state.start()
            logger.info("✓ State Engine cargado")
        except Exception as e:
            logger.warning(f"State Engine no disponible: {e}")

    def _load_cognitive_memory(self):
        try:
            from core.cognitive_memory import CognitiveMemory
            self.cognitive_memory = CognitiveMemory()
            self.cognitive_memory.initialize()
            logger.info("✓ Cognitive Memory cargado")
        except Exception as e:
            logger.warning(f"Cognitive Memory no disponible: {e}")
            self.cognitive_memory = None

    def _load_memory(self):
        try:
            from core.memory import MemorySystem
            self.memory = MemorySystem()
            self.memory.initialize()
            logger.info("✓ Memory System cargado")
        except Exception as e:
            logger.warning(f"Memory System no disponible: {e}")
            self.memory = None

    def _load_ai_manager(self):
        try:
            from core.ai_manager import AIManager
            self.ai_manager = AIManager()
            logger.info("✓ AI Manager cargado")
        except Exception as e:
            logger.warning(f"AI Manager no disponible: {e}")
            self.ai_manager = None

    def _load_personality(self):
        try:
            from core.personality import JarvisPersonality
            self.personality = JarvisPersonality(self.ai_manager)
            logger.info("✓ Personality Engine cargado")
        except Exception as e:
            logger.warning(f"Personality Engine no disponible: {e}")
            self.personality = None

    def _load_security(self):
        try:
            from core.security import SecuritySystem
            self.security = SecuritySystem()
            logger.info("✓ Security System cargado")
        except Exception as e:
            logger.warning(f"Security System no disponible: {e}")
            self.security = None

    def _load_intent_engine(self):
        try:
            from core.intent_engine import IntentEngine
            self.intent_engine = IntentEngine()
            logger.info("✓ Intent Engine cargado")
        except Exception as e:
            logger.warning(f"Intent Engine no disponible: {e}")
            self.intent_engine = None

    def _load_reasoning(self):
        try:
            from core.reasoning import ReasoningEngine
            self.reasoning = ReasoningEngine(self)
            logger.info("✓ Reasoning Engine cargado")
        except Exception as e:
            logger.warning(f"Reasoning Engine no disponible: {e}")
            self.reasoning = None

    def _load_planner(self):
        try:
            from core.planner import TaskPlanner
            self.planner = TaskPlanner(self)
            logger.info("✓ Task Planner cargado")
        except Exception as e:
            logger.warning(f"Task Planner no disponible: {e}")
            self.planner = None

    def _load_executor(self):
        try:
            from core.executor import CommandExecutor
            self.executor = CommandExecutor(self)
            logger.info("✓ Command Executor cargado")
        except Exception as e:
            logger.warning(f"Command Executor no disponible: {e}")
            self.executor = None

    def _load_voice(self):
        try:
            from core.voice import VoiceSystem
            self.voice = VoiceSystem()
            logger.info("✓ Voice System cargado")
        except Exception as e:
            logger.warning(f"Voice System no disponible: {e}")
            self.voice = None

    def _load_skills(self):
        try:
            from core.skills import SkillManager
            self.skill_manager = SkillManager(self)
            self.skill_manager.load_all_skills()
            logger.info("✓ Skill Manager cargado")
        except Exception as e:
            logger.warning(f"Skill Manager no disponible: {e}")
            self.skill_manager = None

    def _load_autonomous(self):
        try:
            from core.autonomous import AutonomousEngine
            self.autonomous = AutonomousEngine(self)
            self.autonomous.start()
            logger.info("✓ Autonomous Engine cargado")
        except Exception as e:
            logger.warning(f"Autonomous Engine no disponible: {e}")
            self.autonomous = None

    def _start_command_processor(self):
        """Iniciar hilo procesador de comandos."""
        def processor():
            while self.running:
                try:
                    if not self.command_queue.empty():
                        priority, cmd_data = self.command_queue.get(timeout=0.1)
                        self._execute_queued_command(cmd_data)
                except queue.Empty:
                    pass
                except Exception as e:
                    logger.error(f"Error en procesador de comandos: {e}")
                time.sleep(0.05)

        t = threading.Thread(target=processor, daemon=True)
        t.start()

    def _execute_queued_command(self, cmd_data: dict):
        """Ejecutar un comando de la cola."""
        try:
            command = cmd_data.get('command', '')
            callback = cmd_data.get('callback')
            result = self.process_command(command)
            if callback:
                callback(result)
        except Exception as e:
            logger.error(f"Error ejecutando comando en cola: {e}")

    def process_command(self, user_input: str) -> str:
        """Procesar cualquier input con razonamiento MARK real."""
        if not user_input or not user_input.strip():
            return ""
        user_input = user_input.strip()
        logger.info(f"MARK: '{user_input}'")
        try:
            if self.memory:
                self.memory.save_message('user', user_input)
            if self.state:
                self.state.update_interaction()

            # Detectar intención semántica
            intent = None
            if self.intent_engine:
                intent = self.intent_engine.detect_intent(user_input)

            # Seguridad solo en acciones críticas con alta confianza
            if self.security and intent and intent.get('confidence', 0) > 0.7:
                if not self.security.check_command(user_input, intent):
                    response = "Esa acción necesita confirmación explícita. ¿Confirma?"
                    if self.personality:
                        response = self.personality.format_response(response)
                    return response

            # PIPELINE MARK: razona primero, actúa después
            # Intents que necesitan confianza MUY alta para no dar falsos positivos
            HIGH_RISK_ACTIONS = {'cancel', 'shutdown', 'restart', 'automation_mode'}
            HIGH_CONF = 0.50
            VERY_HIGH_CONF = 0.80
            LOW_CONF_OK = {'internet_news', 'internet_search', 'internet_weather',
                           'greeting', 'media_play', 'media_mute', 'media_pause'}

            # Intents de alto riesgo necesitan más confianza
            if intent and intent['name'] in HIGH_RISK_ACTIONS:
                effective_threshold = VERY_HIGH_CONF
            elif intent and intent['name'] in LOW_CONF_OK:
                effective_threshold = 0.40  # Más permisivos con búsquedas y medios
            else:
                effective_threshold = HIGH_CONF

            # Interceptar búsquedas que son en realidad preguntas conversacionales
            CONVERSATIONAL_PATTERNS = ['quién eres', 'qué eres', 'cómo te llamas',
                'opinas', 'piensas', 'qué crees', 'tu opinión',
                'mejor lenguaje', 'recomiendas', 'ventajas', 'desventajas']
            is_conversational = (intent and intent.get('name') == 'internet_search' and
                any(p in user_input.lower() for p in CONVERSATIONAL_PATTERNS))

            if intent and intent.get('confidence', 0) >= effective_threshold and not is_conversational:
                if intent.get('requires_planning') or intent.get('multi_step'):
                    response = self._run_plan(user_input, intent)
                else:
                    response = self._execute_intent(user_input, intent)
                if not response or len(response) < 5:
                    response = self.reasoning.reason(user_input, intent) if self.reasoning else "Ejecutado."
            elif self.reasoning:
                response = self.reasoning.reason(user_input, intent)
            else:
                response = self._ask_ai(user_input)

            # Personalidad MARK — sutil
            if self.personality and response:
                response = self.personality.format_response(response)
                extra = self.personality.react_to_context(user_input)
                if extra and len(extra) < len(response):
                    pass  # Mantener respuesta original si es más completa

            # Memoria + tracking
            if self.memory:
                self.memory.save_message('mark', response)
            if self.cognitive_memory and intent:
                try:
                    self.cognitive_memory.log_action(
                        action=intent.get('action', ''),
                        skill=intent.get('skill', ''),
                        params=intent.get('params', {}),
                        context=user_input[:100]
                    )
                except Exception:
                    pass
            if self.autonomous and intent:
                try:
                    self.autonomous.observe_action(intent.get('action', ''))
                except Exception:
                    pass

            self.speak(response)
            # NOTE: No enviar 'response' via ui_callback — la UI ya lo recibe
            # del return value de process_command. Evita duplicados.
            # ui_callback solo para eventos autónomos/proactivos.
            return response

        except Exception as e:
            logger.error(f"Error en process_command: {e}", exc_info=True)
            return f"Algo falló: {str(e)[:80]}"

    def _run_plan(self, user_input: str, intent: dict) -> str:
        """Ejecutar plan multi-paso."""
        if self.planner:
            try:
                plan = self.planner.create_plan(user_input, intent)
                if plan:
                    return self.planner.execute_plan(plan)
            except Exception as e:
                logger.debug(f"Error en planner: {e}")
        return self._execute_intent(user_input, intent)

    def _execute_intent(self, user_input: str, intent: dict) -> str:
        """Ejecutar una intención detectada usando los skills."""
        if not intent:
            return self._ask_ai(user_input)

        skill_name = intent.get('skill')
        action = intent.get('action')
        params = intent.get('params', {})

        # Acciones especiales manejadas directamente por el brain
        if action == 'greeting':
            if self.personality:
                cpu = 0
                try:
                    if self.state:
                        s = self.state.get_state()
                        cpu = s.get('cpu_usage', 0)
                except Exception:
                    pass
                return self.personality.get_greeting(cpu=cpu)
            return "Presente. ¿Qué necesita?"
        if action == 'cancel':
            return "Entendido. Cancelado."

        if self.skill_manager and skill_name:
            try:
                result = self.skill_manager.execute(skill_name, action, params, user_input)
                if result:
                    return result
            except Exception as e:
                logger.error(f"Error ejecutando skill {skill_name}.{action}: {e}")

        # Fallback a IA
        return self._ask_ai(user_input)

    def _ask_ai(self, user_input: str) -> str:
        """Consultar al AI Manager."""
        if self.ai_manager:
            try:
                context = ""
                if self.memory:
                    history = self.memory.get_recent_messages(5)
                    context = "\n".join([f"{m['role']}: {m['content']}" for m in history])
                return self.ai_manager.generate(user_input, context)
            except Exception as e:
                logger.error(f"Error consultando IA: {e}")

        return "Procesando su solicitud, Señor."

    def speak(self, text: str):
        """Convertir texto a voz."""
        if self.voice and text:
            try:
                self.voice.speak(text)
            except Exception as e:
                logger.debug(f"Error en TTS: {e}")

    def set_ui_callback(self, callback: Callable):
        """Establecer callback para actualizar UI."""
        self._ui_callback = callback

    def update_ui(self, event_type: str, data: Any = None):
        """Enviar actualización a la UI."""
        if self._ui_callback:
            try:
                self._ui_callback(event_type, data)
            except Exception as e:
                logger.debug(f"Error actualizando UI: {e}")

    def queue_command(self, command: str, priority: int = 5, callback: Optional[Callable] = None):
        """Añadir comando a la cola de procesamiento."""
        self.command_queue.put((priority, {
            'command': command,
            'callback': callback,
            'timestamp': time.time()
        }))

    def shutdown(self):
        """Apagar el sistema ordenadamente."""
        logger.info("Iniciando secuencia de apagado...")
        self.running = False

        if self.autonomous:
            try:
                self.autonomous.stop()
            except Exception:
                pass

        if self.state:
            try:
                self.state.stop()
            except Exception:
                pass

        if self.memory:
            try:
                self.memory.close()
            except Exception:
                pass

        logger.info("Sistema MARK apagado.")

    def get_status(self) -> dict:
        """Obtener estado actual del sistema."""
        status = {
            'initialized': self.initialized,
            'running': self.running,
            'modules': {
                'state': self.state is not None,
                'memory': self.memory is not None,
                'ai_manager': self.ai_manager is not None,
                'intent_engine': self.intent_engine is not None,
                'reasoning': self.reasoning is not None,
                'planner': self.planner is not None,
                'voice': self.voice is not None,
                'skill_manager': self.skill_manager is not None,
                'autonomous': self.autonomous is not None,
            }
        }
        if self.state:
            status['system'] = self.state.get_state()
        return status
