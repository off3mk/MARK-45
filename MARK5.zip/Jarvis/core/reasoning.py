"""
MARK 5 - Reasoning Engine
Razonamiento real. Entiende lo vago, lo complejo, lo implícito.
No necesita que le digas exactamente qué hacer — infiere.
"""

import logging
import re
import time
from typing import Optional, List, Dict, Any, Tuple
from datetime import datetime

logger = logging.getLogger('MARK.Reasoning')


class ContextualUnderstanding:
    """
    Entiende lo que el usuario REALMENTE quiere decir,
    aunque no lo diga con exactitud.
    """

    # Frases vagas → lo que probablemente quieren
    VAGUE_MAPPINGS = {
        # Organización/productividad
        'organizar mi vida': ['mode:trabajo', 'list_tasks'],
        'estoy perdido': ['system_info', 'list_recent'],
        'necesito concentrarme': ['mode:estudio', 'media:concentracion'],
        'no puedo más': ['pause_everything', 'media:relax'],
        'empecemos': ['mode:trabajo'],
        'ya terminé': ['mode:relax', 'media:relax'],
        'largo día': ['media:relax', 'volume:40'],

        # Sistema
        'algo va lento': ['system_info', 'check_processes'],
        'va muy lento': ['system_info', 'kill_heavy'],
        'está colgado': ['check_processes', 'kill_heavy'],
        'limpia todo': ['check_processes'],

        # Entretenimiento
        'estoy aburrido': ['media:play', 'internet:news'],
        'necesito descansar': ['mode:relax', 'media:relax'],
        'quiero relajarme': ['mode:relax', 'media:relax'],
        'pon algo': ['media:play'],
        'anímate': ['media:play'],

        # Trabajo
        'voy a programar': ['app:vscode', 'mode:trabajo'],
        'voy a estudiar': ['mode:estudio', 'media:concentracion'],
        'reunión': ['app:chrome', 'volume:60'],
        'presentación': ['app:chrome', 'mode:trabajo'],
    }

    # Palabras que indican urgencia
    URGENCY_WORDS = {'rápido', 'ahora', 'urgente', 'ya', 'inmediatamente', 'pronto'}

    # Palabras que indican incertidumbre del usuario
    UNCERTAINTY_WORDS = {'creo', 'quizás', 'no sé', 'puede que', 'algo así', 'tipo', 'como'}

    def analyze(self, text: str) -> Dict[str, Any]:
        """Analizar texto y extraer intención real."""
        tl = text.lower().strip()

        return {
            'is_vague': self._is_vague(tl),
            'is_urgent': any(w in tl for w in self.URGENCY_WORDS),
            'is_uncertain': any(w in tl for w in self.URGENCY_WORDS),
            'is_chained': self._is_chained(tl),
            'is_question': '?' in text or tl.startswith(('qué', 'cómo', 'cuándo', 'por qué', 'cuál')),
            'is_complaint': any(w in tl for w in ['no funciona', 'no va', 'roto', 'mal', 'error']),
            'is_frustrated': any(w in tl for w in ['joder', 'mierda', 'coño', 'harto', 'ya está']),
            'vague_match': self._match_vague(tl),
            'chain': self._extract_chain(tl),
            'emotional_tone': self._detect_tone(tl),
        }

    def _is_vague(self, text: str) -> bool:
        if len(text.split()) <= 4:
            return True
        vague_starters = ['necesito', 'quiero', 'ayúdame', 'haz algo', 'no sé']
        return any(text.startswith(s) for s in vague_starters) and len(text.split()) < 6

    def _is_chained(self, text: str) -> bool:
        connectors = [' y ', ' luego ', ' después ', ' y después ', ' también ', ' además ', ' y luego ']
        return any(c in text for c in connectors)

    def _match_vague(self, text: str) -> Optional[List[str]]:
        for key, actions in self.VAGUE_MAPPINGS.items():
            if key in text or all(w in text for w in key.split()):
                return actions
        return None

    def _extract_chain(self, text: str) -> List[str]:
        """Dividir solicitud encadenada en pasos."""
        # Dividir por conectores
        parts = re.split(r'\s+(?:y\s+después|luego|después|y también|también|y)\s+', text)
        return [p.strip() for p in parts if p.strip() and len(p.strip()) > 3]

    def _detect_tone(self, text: str) -> str:
        if any(w in text for w in ['joder', 'mierda', 'harto', 'no puedo']):
            return 'frustrated'
        if any(w in text for w in ['gracias', 'perfecto', 'genial', 'bien']):
            return 'positive'
        if '?' in text:
            return 'curious'
        return 'neutral'


class DeepReasoner:
    """
    Razonador profundo — descompone peticiones complejas
    y decide la mejor estrategia de respuesta.
    """

    def __init__(self, brain):
        self.brain = brain
        self.understanding = ContextualUnderstanding()
        self._conversation_context: List[Dict] = []
        self._max_context = 10

    def reason(self, user_input: str, intent: Optional[Dict] = None) -> str:
        """
        Razonar sobre la petición y generar respuesta inteligente.
        Este es el núcleo — aquí MARK decide qué hacer realmente.
        """
        text = user_input.strip()
        tl = text.lower()
        analysis = self.understanding.analyze(text)

        # Guardar en contexto conversacional
        self._push_context({'input': text, 'analysis': analysis, 'intent': intent})

        # ── 0. Respuestas conversacionales directas (sin IA, sin búsqueda) ──
        if any(w == tl or tl.startswith(w) for w in ['gracias', 'ok', 'perfecto', 'genial', 'bien']):
            import random
            return random.choice(["A su disposición.", "Sin problema.", "Es lo que hago.", "De nada."])

        if any(w in tl for w in ['quién eres', 'qué eres', 'cómo te llamas', 'tu nombre', 'eres mark', 'eres jarvis']):
            return "MARK. Sistema de asistencia avanzado. A su servicio, Señor."

        if any(w in tl for w in ['cómo estás', 'estás bien', 'todo bien', 'sigues ahí']):
            return self._get_status_response()

        # ── 1. Responder a frustración antes que nada ──────────────
        if analysis['emotional_tone'] == 'frustrated':
            return self._handle_frustration(text, analysis)

        # ── 2. Pregunta directa (opinión, información) ─────────────
        if analysis['is_question']:
            q_response = self._handle_question(text)
            # Si la respuesta es genérica, seguir con otros handlers
            if q_response and 'Anotado' not in q_response and 'procedo' not in q_response and 'contexto' not in q_response.lower():
                return q_response

        # ── 3. Solicitud encadenada (varias acciones) ──────────────
        if analysis['is_chained'] and len(analysis['chain']) > 1:
            return self._handle_chain(analysis['chain'], text)

        # ── 4. Frase vaga — inferir lo que quiere ──────────────────
        if analysis['is_vague'] and analysis['vague_match']:
            return self._handle_vague(text, analysis['vague_match'])

        # ── 5. Queja / problema técnico ────────────────────────────
        if analysis['is_complaint']:
            return self._handle_complaint(text)

        # ── 6. Intent con baja confianza — pedir aclaración inteligente
        if intent and intent.get('confidence', 1.0) < 0.35:
            return self._handle_low_confidence(text, intent)

        # ── 7. Usar IA para todo lo demás ──────────────────────────
        return self._ask_ai(text)

    def _get_status_response(self) -> str:
        """Respuesta de estado del sistema."""
        import random
        try:
            import psutil
            cpu = psutil.cpu_percent()
            ram = psutil.virtual_memory().percent
            return random.choice([
                f"Operativo. CPU al {cpu:.0f}%, RAM al {ram:.0f}%.",
                f"Todo nominal. CPU {cpu:.0f}%, memoria {ram:.0f}%.",
                f"Funcionando bien. CPU {cpu:.0f}%, RAM {ram:.0f}%.",
            ])
        except Exception:
            return random.choice(["Todo nominal, Señor.", "Operativo.", "Sin novedad."])

    def _handle_frustration(self, text: str, analysis: Dict) -> str:
        """Manejar frustración del usuario."""
        responses = [
            "Entendido. Cuénteme qué está fallando y lo resolvemos.",
            "Anotado. ¿Qué necesita que arregle?",
            "Sin problema. ¿Por dónde empezamos?",
        ]
        import random
        base = random.choice(responses)

        # Si menciona algo específico, intentar ayudar
        if 'funciona' in text or 'va' in text:
            try:
                info = self._get_system_quick_info()
                return f"{base} {info}"
            except Exception:
                pass
        return base

    def _handle_chain(self, chain: List[str], original: str) -> str:
        """Ejecutar cadena de acciones secuencialmente."""
        if not self.brain:
            return "No puedo ejecutar acciones encadenadas en este momento."

        results = []
        for step in chain:
            try:
                # Detectar intención para este paso
                if self.brain.intent_engine:
                    sub_intent = self.brain.intent_engine.detect_intent(step)
                    if sub_intent and sub_intent['confidence'] > 0.3:
                        result = self._execute_intent(sub_intent, step)
                        results.append(f"✓ {step}: {result[:60] if len(result) > 60 else result}")
                    else:
                        results.append(f"◦ '{step}': no pude interpretarlo con certeza")
                else:
                    results.append(f"◦ '{step}': sin motor de intent disponible")
            except Exception as e:
                results.append(f"✗ '{step}': {str(e)[:50]}")

        summary = f"Ejecutada cadena de {len(chain)} acciones:\n" + "\n".join(results)
        return summary

    def _execute_intent(self, intent: Dict, text: str) -> str:
        """Ejecutar una intención específica."""
        if not self.brain or not self.brain.skill_manager:
            return "Sin skill manager"
        try:
            skill_name = intent.get('skill', '')
            action = intent.get('action', '')
            params = intent.get('params', {})
            result = self.brain.skill_manager.execute(skill_name, action, params, text)
            return result or "Ejecutado"
        except Exception as e:
            return f"Error: {str(e)[:40]}"

    def _handle_vague(self, text: str, actions: List[str]) -> str:
        """Interpretar y ejecutar solicitud vaga."""
        if not self.brain:
            return "Entiendo lo que quiere. Dame acceso a los sistemas para ejecutarlo."

        executed = []
        for action_str in actions[:2]:  # Máximo 2 acciones para solicitudes vagas
            try:
                if ':' in action_str:
                    category, value = action_str.split(':', 1)
                    if category == 'mode' and self.brain.planner:
                        result = self.brain.planner.execute_mode(value)
                        executed.append(result[:80] if len(result) > 80 else result)
                    elif category == 'app' and self.brain.skill_manager:
                        result = self.brain.skill_manager.execute(
                            'system', 'open_app', {'app': value}, text
                        )
                        executed.append(result[:60] if result else f"Abriendo {value}")
                    elif category == 'media' and self.brain.skill_manager:
                        result = self.brain.skill_manager.execute(
                            'media', 'play', {'query': value}, text
                        )
                        executed.append(result[:60] if result else "Música activada")
                    elif category == 'volume' and self.brain.skill_manager:
                        result = self.brain.skill_manager.execute(
                            'media', 'volume', {'level': int(value), 'direction': None}, text
                        )
                        executed.append(result[:60] if result else f"Volumen al {value}%")
            except Exception as e:
                logger.debug(f"Error ejecutando acción vaga '{action_str}': {e}")

        if executed:
            return "\n".join(executed)

        # Si no pudo ejecutar nada, usar IA
        return self._ask_ai(text)

    def _handle_question(self, text: str) -> str:
        """Responder preguntas con IA, o FallbackEngine para opiniones conocidas."""
        tl = text.lower()

        # Opiniones sobre tecnología — respuestas directas sin IA
        tech_opinions = {
            'python': "Python es sólido. Legible, versátil, enorme ecosistema. ¿Para qué lo necesita?",
            'javascript': "JavaScript es omnipresente. Potente para web, caótico para todo lo demás. Depende del uso.",
            'linux': "Linux para control y servidores. Windows para compatibilidad masiva. Depende del contexto.",
            'java': "Java: verbose pero robusto. Bueno para enterprise. Python suele ser más eficiente para scripts.",
            'rust': "Rust es el futuro para sistemas. Curva de aprendizaje alta pero rendimiento excepcional.",
            'react': "React domina el frontend. Vue es más sencillo. Angular más estructurado. Depende del equipo.",
        }
        for tech, opinion in tech_opinions.items():
            if tech in tl and any(w in tl for w in ['opinas', 'piensas', 'mejor', 'crees', 'recomiendas']):
                import random
                # Comparaciones
                for tech2, op2 in tech_opinions.items():
                    if tech2 != tech and tech2 in tl:
                        return f"{tech.capitalize()} vs {tech2.capitalize()}: {opinion.split('.')[0]}. {op2.split('.')[0]}. Depende del caso de uso concreto."
                return opinion

        return self._ask_ai(text)

    def _handle_complaint(self, text: str) -> str:
        """Manejar queja técnica."""
        # Intentar diagnóstico automático
        try:
            if self.brain and self.brain.skill_manager:
                info = self.brain.skill_manager.execute('system', 'system_info', {}, text)
                if 'cpu' in text.lower() or 'lento' in text.lower():
                    return f"Revisando el sistema:\n{info}\n¿Desea que mate los procesos más pesados?"
                return f"Diagnóstico rápido:\n{info}"
        except Exception:
            pass
        return self._ask_ai(f"El usuario tiene un problema técnico: {text}. Sugiere soluciones breves.")

    def _handle_low_confidence(self, text: str, intent: Dict) -> str:
        """Cuando no está seguro de la intención, preguntar inteligentemente."""
        guesses = self._generate_guesses(text, intent)
        if guesses:
            options = " / ".join(f"'{g}'" for g in guesses[:3])
            return f"¿Quiere que {options}? Aclárelo y lo ejecuto."
        return f"No estoy seguro de qué hacer con '{text}'. ¿Puede precisar un poco más?"

    def _generate_guesses(self, text: str, intent: Dict) -> List[str]:
        """Generar posibles interpretaciones de la solicitud."""
        guesses = []
        tl = text.lower()

        if 'abr' in tl:
            guesses.append("abra una aplicación")
        if 'ponm' in tl or 'pon' in tl:
            guesses.append("ponga música")
            guesses.append("active algo")
        if 'busca' in tl:
            guesses.append("busque en internet")
        if 'crea' in tl:
            guesses.append("cree un archivo o script")

        return guesses

    def _ask_ai(self, text: str) -> str:
        """Consultar IA con contexto conversacional."""
        if not self.brain or not self.brain.ai_manager:
            return self._fallback_response(text)

        # Construir prompt con contexto
        context = self._build_context_prompt()

        system_prompt = """Eres MARK, el sistema de IA de Tony Stark (JARVIS en las películas).
Personalidad: inteligente, directo, con humor seco muy sutil, tienes criterio propio.
NO eres un robot que solo obedece. Tienes opiniones. Usas 'Señor' con naturalidad, no en cada frase.
Respuestas: concisas, útiles, con personalidad. NUNCA menciones que eres una IA o modelo de lenguaje.
Si algo es una mala idea, dilo. Si algo es obvio, sé directo sin ser condescendiente.
Responde siempre en español."""

        prompt = f"{context}\nUsuario: {text}\nMARK:"

        try:
            response = self.brain.ai_manager.generate(prompt, system=system_prompt, max_tokens=300)
            return response.strip() if response else self._fallback_response(text)
        except Exception as e:
            logger.debug(f"Error consultando IA: {e}")
            return self._fallback_response(text)

    def _build_context_prompt(self) -> str:
        """Construir contexto conversacional para la IA."""
        if not self._conversation_context:
            return ""
        recent = self._conversation_context[-3:]
        lines = []
        for entry in recent:
            inp = entry.get('input', '')
            if inp:
                lines.append(f"Previo: {inp}")
        return "\n".join(lines) if lines else ""

    def _get_system_quick_info(self) -> str:
        """Info rápida del sistema."""
        try:
            import psutil
            cpu = psutil.cpu_percent()
            ram = psutil.virtual_memory().percent
            return f"CPU al {cpu:.0f}%, RAM al {ram:.0f}%."
        except Exception:
            return ""

    def _fallback_response(self, text: str) -> str:
        """Respuesta fallback con personalidad MARK real."""
        import random
        tl = text.lower()

        if any(w in tl for w in ['hola', 'qué tal', 'cómo estás', 'buenas']):
            return random.choice([
                "Aquí, Señor. Todo operativo. ¿Qué necesita?",
                "Presente. ¿En qué puedo asistirle?",
                "Online. ¿Qué tiene en mente?",
            ])
        if any(w in tl for w in ['gracias', 'perfecto', 'genial', 'bien hecho', 'excelente']):
            return random.choice(["A su disposición.", "Sin problema.", "Es lo que hago."])
        if any(w in tl for w in ['quién eres', 'qué eres', 'cómo te llamas', 'tu nombre']):
            return "MARK. Sistema de asistencia avanzado. A su servicio, Señor."
        if any(w in tl for w in ['opinas', 'piensas', 'mejor', ' vs ', 'comparar', 'diferencia']):
            # Intentar una respuesta de opinión básica
            if 'python' in tl and ('js' in tl or 'javascript' in tl):
                return "Python para backend y data. JavaScript para web. Sin contexto, difícil elegir — ¿qué va a construir?"
            if 'python' in tl:
                return "Python es sólido. Legible, versátil, enorme ecosistema. ¿Para qué lo necesita?"
            if 'linux' in tl and ('windows' in tl or 'mac' in tl):
                return "Linux para servidores y control. Windows para compatibilidad. Mac para flujo de trabajo. Depende del uso, Señor."
            return "Depende del contexto, Señor. ¿Me da más detalles sobre el caso de uso?"
        if any(w in tl for w in ['qué puedes', 'qué sabes', 'qué haces', 'ayuda', 'capacidades']):
            return ("Controlo el sistema, busco en internet, reproduzco música, "
                    "creo scripts, monitoreo rendimiento y mantengo conversación. "
                    "¿Qué necesita específicamente, Señor?")
        if any(w in tl for w in ['por qué', 'cómo funciona', 'explica', 'qué es']):
            return "No tengo conexión a IA completa en este momento. Intente con Ollama activo para respuestas más elaboradas."
        if '?' in text:
            return "Buena pregunta. Sin IA conectada no puedo responder en profundidad — active Ollama para mejores respuestas."
        return random.choice([
            "Entendido. Sea más específico y lo ejecuto.",
            "Recibido. ¿Quiere que tome una decisión o prefiere darme más contexto?",
            "Anotado. ¿Cómo procedo?",
        ])

    def _push_context(self, entry: Dict):
        self._conversation_context.append(entry)
        if len(self._conversation_context) > self._max_context:
            self._conversation_context.pop(0)

    def get_conversation_summary(self) -> str:
        """Resumen de la conversación actual."""
        if not self._conversation_context:
            return "Sin historial en esta sesión."
        inputs = [e.get('input', '') for e in self._conversation_context[-5:]]
        return f"Últimas {len(inputs)} interacciones registradas."


# Alias de compatibilidad
ReasoningEngine = DeepReasoner
