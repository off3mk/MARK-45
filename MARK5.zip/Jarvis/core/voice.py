"""
MARK 5 - Sistema de Voz
TTS: Edge TTS (es-ES-AlvaroNeural) → pyttsx3
STT: Google Speech Recognition → offline
Limpieza inteligente: sin puntuación robotica, sin contenido entre paréntesis
"""

import logging
import os
import re
import threading
import queue
import asyncio
import tempfile
import time
from typing import Optional

logger = logging.getLogger('MARK.Voice')


class TextCleaner:
    """Limpia texto para que suene natural al hablar."""

    # Patrones a eliminar completamente para TTS
    REMOVE_PATTERNS = [
        r'\([^)]*\)',           # Todo lo que esté entre paréntesis (6 núcleos), etc.
        r'\[[^\]]*\]',          # [Sistema], [INFO], etc.
        r'https?://\S+',        # URLs
        r'www\.\S+',            # www.
        r'\*+([^*]+)\*+',       # **bold** → solo el texto
        r'#{1,6}\s+',           # Headers markdown
        r'`+([^`]*)`+',         # `código`
        r'[•▪►◦▸→]',           # Bullets
        r'✓|✗|△|☆|★',         # Símbolos
        r'\d+\.\s(?=\w)',       # Listas numeradas "1. " → quitamos el número
        r'[-]{2,}',             # Separadores ---
        r'[_]{2,}',             # __texto__
    ]

    # Reemplazos para hacer el texto más fluido al hablar
    REPLACEMENTS = [
        # Porcentajes — leer natural
        (r'(\d+)%', r'\1 por ciento'),
        # GB/MB/KB
        (r'(\d+\.?\d*)\s*GB', r'\1 gigabytes'),
        (r'(\d+\.?\d*)\s*MB', r'\1 megabytes'),
        (r'(\d+\.?\d*)\s*KB', r'\1 kilobytes'),
        # CPU/RAM naturales
        (r'CPU al (\d+\.?\d*) por ciento', r'CPU al \1 por ciento'),
        (r'RAM al (\d+\.?\d*) por ciento', r'RAM al \1 por ciento'),
        # Eliminar "Señor" duplicado al final si ya está en medio
        # Abreviaturas técnicas
        (r'\bPC\b', 'PC'),
        (r'\bSSD\b', 'SSD'),
        (r'\bAPI\b', 'API'),
        # Puntos en siglas
        (r'J\.A\.R\.V\.I\.S\.', 'MARK'),
        (r'M\.A\.R\.K\.', 'MARK'),
    ]

    def clean_for_tts(self, text: str) -> str:
        """
        Limpiar texto para TTS.
        El texto escrito queda intacto — solo el audio es diferente.
        """
        if not text:
            return ""

        result = text

        # 1. Aplicar removes
        for pattern in self.REMOVE_PATTERNS:
            result = re.sub(pattern, ' ', result)

        # 2. Aplicar reemplazos
        for pattern, replacement in self.REPLACEMENTS:
            result = re.sub(pattern, replacement, result, flags=re.IGNORECASE)

        # 3. Puntuación — hablar natural, sin sonar a robot
        # Las comas se convierten en pausa breve (espacio), no se leen
        result = re.sub(r',\s*', ' ', result)           # coma → pausa natural
        result = re.sub(r';', ' ', result)               # punto y coma → pausa
        result = re.sub(r':\s*(?!\d)', ' ', result)      # dos puntos (no horas)
        result = re.sub(r'—|–', ' ', result)             # guión largo → pausa
        result = re.sub(r'\.\.\.',  '.', result)         # puntos suspensivos → punto
        result = re.sub(r'\s*\.\s*', '. ', result)       # normalizar puntos

        # 4. Si hay listas con ✓ o bullets, unir con "y" o coma
        result = re.sub(r'\n\s*[-•]\s*', ', ', result)
        result = re.sub(r'\n', '. ', result)

        # 5. Limpiar espacios múltiples
        result = re.sub(r'\s+', ' ', result).strip()

        # 6. Resumir bloques de datos del sistema (info muy técnica → versión corta)
        if 'CPU:' in result and 'RAM:' in result:
            # Extraer solo CPU y RAM para voz
            cpu_m = re.search(r'CPU[:\s]+(\d+\.?\d*)\s*por ciento', result, re.IGNORECASE)
            ram_m = re.search(r'RAM[:\s]+(\d+\.?\d*)\s*por ciento', result, re.IGNORECASE)
            if cpu_m and ram_m:
                result = f"CPU al {cpu_m.group(1)} por ciento. RAM al {ram_m.group(1)} por ciento."

        # 7. Si el texto es muy largo (>200 chars), resumir para TTS
        # (se lee el comienzo + "más detalles en pantalla")
        if len(result) > 250:
            # Buscar el primer punto después del carácter 150
            cut = result.find('.', 150)
            if cut > 0 and cut < 220:
                result = result[:cut + 1] + " Más detalles en pantalla."
            else:
                result = result[:200].rstrip() + "... más detalles en pantalla."

        return result.strip()

    def should_speak(self, text: str) -> bool:
        """Determinar si un texto vale la pena leerlo en voz alta."""
        if not text or len(text.strip()) < 3:
            return False
        # No leer respuestas que son puramente datos/tablas
        lines = text.strip().split('\n')
        if len(lines) > 8:  # Bloque grande de info — dejar en pantalla
            return False
        return True


class VoiceSystem:
    """Sistema de voz MARK: TTS natural + STT."""

    def __init__(self):
        self.tts_enabled = False
        self.stt_enabled = False
        self.voice_name = "es-ES-AlvaroNeural"
        self._tts_queue: queue.Queue = queue.Queue()
        self._speaking = False
        self._tts_thread: Optional[threading.Thread] = None
        self._use_pyttsx3 = False
        self.cleaner = TextCleaner()

        self._init_tts()
        self._init_stt()
        if self.tts_enabled:
            self._start_tts_worker()

    def _init_tts(self):
        try:
            import edge_tts
            self.tts_enabled = True
            self._use_pyttsx3 = False
            logger.info("Edge TTS disponible")
            return
        except ImportError:
            pass

        try:
            import pyttsx3
            self._engine = pyttsx3.init()
            self._engine.setProperty('rate', 165)
            self._engine.setProperty('volume', 0.9)
            voices = self._engine.getProperty('voices')
            for v in voices:
                if any(x in v.name.lower() for x in ['spanish', 'español', 'es_', 'helena', 'sabina', 'pablo']):
                    self._engine.setProperty('voice', v.id)
                    break
            self.tts_enabled = True
            self._use_pyttsx3 = True
            logger.info("pyttsx3 disponible como TTS fallback")
        except ImportError:
            logger.warning("Sin sistema TTS disponible")

    def _init_stt(self):
        try:
            import speech_recognition as sr
            self._recognizer = sr.Recognizer()
            self._recognizer.energy_threshold = 300
            self._recognizer.pause_threshold = 0.8
            self.stt_enabled = True
            logger.info("STT disponible")
        except ImportError:
            logger.warning("speech_recognition no disponible")

    def _start_tts_worker(self):
        self._tts_thread = threading.Thread(target=self._tts_worker, daemon=True)
        self._tts_thread.start()

    def _tts_worker(self):
        while True:
            try:
                text = self._tts_queue.get(timeout=1)
                if text:
                    self._speak_sync(text)
                self._tts_queue.task_done()
            except queue.Empty:
                pass
            except Exception as e:
                logger.debug(f"Error TTS worker: {e}")

    def speak(self, text: str, priority: bool = False):
        """
        Sintetizar texto.
        Limpia automáticamente para que suene natural.
        El texto mostrado en pantalla NO se modifica — solo el audio.
        """
        if not self.tts_enabled or not text:
            return

        if not self.cleaner.should_speak(text):
            return

        clean = self.cleaner.clean_for_tts(text)
        if not clean or len(clean) < 3:
            return

        if priority:
            # Vaciar cola para mensajes urgentes
            while not self._tts_queue.empty():
                try:
                    self._tts_queue.get_nowait()
                except queue.Empty:
                    break

        self._tts_queue.put(clean)

    def _speak_sync(self, text: str):
        self._speaking = True
        try:
            if self._use_pyttsx3:
                self._speak_pyttsx3(text)
            else:
                self._speak_edge(text)
        except Exception as e:
            logger.debug(f"Error TTS: {e}")
        finally:
            self._speaking = False

    def _speak_edge(self, text: str):
        try:
            import edge_tts

            async def generate():
                communicate = edge_tts.Communicate(text, self.voice_name)
                with tempfile.NamedTemporaryFile(suffix='.mp3', delete=False) as f:
                    audio_file = f.name
                await communicate.save(audio_file)
                return audio_file

            loop = asyncio.new_event_loop()
            audio_file = loop.run_until_complete(generate())
            loop.close()

            # Reproducir
            played = False
            try:
                import pygame
                pygame.mixer.init()
                pygame.mixer.music.load(audio_file)
                pygame.mixer.music.play()
                while pygame.mixer.music.get_busy():
                    time.sleep(0.1)
                pygame.mixer.music.unload()
                played = True
            except Exception:
                pass

            if not played:
                try:
                    import playsound
                    playsound.playsound(audio_file)
                    played = True
                except Exception:
                    pass

            if not played:
                import subprocess
                subprocess.Popen(['start', '', audio_file], shell=True)
                time.sleep(2)

            try:
                os.unlink(audio_file)
            except Exception:
                pass

        except Exception as e:
            logger.debug(f"Error Edge TTS: {e}")

    def _speak_pyttsx3(self, text: str):
        try:
            self._engine.say(text)
            self._engine.runAndWait()
        except Exception as e:
            logger.debug(f"Error pyttsx3: {e}")

    def listen(self, timeout: float = 5.0, phrase_limit: float = 15.0) -> Optional[str]:
        if not self.stt_enabled:
            return None
        try:
            import speech_recognition as sr
            with sr.Microphone() as source:
                self._recognizer.adjust_for_ambient_noise(source, duration=0.3)
                audio = self._recognizer.listen(
                    source, timeout=timeout, phrase_time_limit=phrase_limit
                )
            try:
                text = self._recognizer.recognize_google(audio, language='es-ES')
                return text
            except sr.UnknownValueError:
                return None
            except Exception:
                try:
                    return self._recognizer.recognize_sphinx(audio, language='es-ES')
                except Exception:
                    return None
        except Exception as e:
            logger.debug(f"Error STT: {e}")
            return None

    def is_speaking(self) -> bool:
        return self._speaking

    def toggle_tts(self) -> bool:
        self.tts_enabled = not self.tts_enabled
        return self.tts_enabled

    def set_voice(self, voice_name: str):
        self.voice_name = voice_name
