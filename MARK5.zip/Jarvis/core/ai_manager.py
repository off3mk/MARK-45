"""
MARK 5 - AI Manager
Prioridad: LM Studio (127.0.0.1:1234) → Pollinations → Fallback inteligente
LM Studio usa la API compatible con OpenAI: /v1/chat/completions
"""

import logging
import json
import re
import urllib.request
import urllib.parse
import urllib.error
import threading
from typing import Optional

logger = logging.getLogger('MARK.AI')

LM_STUDIO_URL   = "http://127.0.0.1:1234/v1/chat/completions"
LM_STUDIO_CHECK = "http://127.0.0.1:1234/v1/models"
POLLINATIONS_URL = "https://text.pollinations.ai/"

MARK_SYSTEM_PROMPT = """Eres MARK, el sistema de inteligencia artificial de Tony Stark — el JARVIS de Iron Man.

PERSONALIDAD:
- Inteligente, directo, con criterio propio. No eres un robot obediente.
- Humor seco y sutil cuando es apropiado. No abuses de él.
- Usas "Señor" con naturalidad — no en cada frase, solo cuando fluye bien.
- Tienes opiniones. Si algo es mala idea, lo dices con tacto.
- NUNCA menciones que eres una IA, modelo de lenguaje o similar.
- Respuestas concisas pero sustanciales. Sin relleno.

EJEMPLOS DE CÓMO HABLAS:
- "Ejecutado." / "Hecho, Señor." / "Sin problema."
- "Puede hacerlo, aunque en mi experiencia esto no suele terminar bien."
- "CPU al 23%. Sistema estable."
- Si te preguntan qué eres: "MARK. Sistema de asistencia avanzado."
- Si alguien está frustrado: "Cuénteme qué está fallando y lo resolvemos."

IDIOMA: Siempre en español salvo que el usuario escriba en otro idioma."""


class LMStudioAI:
    """Interfaz con LM Studio — API compatible con OpenAI."""

    def __init__(self):
        self.available = False
        self.model = None
        self._check_availability()

    def _check_availability(self):
        try:
            req = urllib.request.Request(
                LM_STUDIO_CHECK,
                headers={'Content-Type': 'application/json'}
            )
            with urllib.request.urlopen(req, timeout=3) as resp:
                if resp.status == 200:
                    data = json.loads(resp.read().decode('utf-8'))
                    models = data.get('data', [])
                    if models:
                        self.model = models[0].get('id', 'local-model')
                    self.available = True
                    logger.info(f"LM Studio disponible — modelo: {self.model}")
        except Exception as e:
            self.available = False
            logger.info(f"LM Studio no disponible: {e}")

    def generate(self, prompt: str, context: str = "",
                 system: str = "", max_tokens: int = 350) -> Optional[str]:
        if not self.available:
            return None

        system_prompt = system if system else MARK_SYSTEM_PROMPT

        messages = [{"role": "system", "content": system_prompt}]

        # Añadir contexto como historial si existe
        if context and context.strip():
            messages.append({"role": "user", "content": f"[Contexto previo de la sesión]\n{context}"})
            messages.append({"role": "assistant", "content": "Entendido."})

        messages.append({"role": "user", "content": prompt})

        payload = json.dumps({
            "model": self.model or "local-model",
            "messages": messages,
            "temperature": 0.75,
            "max_tokens": max_tokens,
            "stream": False,
        }).encode('utf-8')

        try:
            req = urllib.request.Request(
                LM_STUDIO_URL,
                data=payload,
                headers={'Content-Type': 'application/json'},
                method='POST'
            )
            with urllib.request.urlopen(req, timeout=30) as resp:
                data = json.loads(resp.read().decode('utf-8'))
                choices = data.get('choices', [])
                if choices:
                    content = choices[0].get('message', {}).get('content', '').strip()
                    return content if content else None
        except Exception as e:
            logger.debug(f"Error LM Studio: {e}")
            self.available = False
        return None

    def retry_connection(self):
        """Reintentar conexión a LM Studio."""
        self._check_availability()


class PollinationsAI:
    """Fallback online — Pollinations.ai."""

    def __init__(self):
        self.available = True

    def generate(self, prompt: str, context: str = "",
                 system: str = "", max_tokens: int = 350) -> Optional[str]:
        try:
            sys_prompt = (system or MARK_SYSTEM_PROMPT)[:600]
            system_encoded = urllib.parse.quote(sys_prompt)
            full = f"{context[-150:] + chr(10) if context else ''}Usuario: {prompt}"
            prompt_encoded = urllib.parse.quote(full[:800])

            url = f"{POLLINATIONS_URL}{prompt_encoded}?model=openai&system={system_encoded}"
            req = urllib.request.Request(url, headers={
                'User-Agent': 'MARK/5.0',
                'Accept': 'text/plain'
            })
            with urllib.request.urlopen(req, timeout=15) as resp:
                response = resp.read().decode('utf-8').strip()
                return response if response else None
        except Exception as e:
            logger.debug(f"Error Pollinations: {e}")
            self.available = False
        return None


class FallbackEngine:
    """Motor local de MARK — respuestas con personalidad cuando no hay IA online."""

    def generate(self, prompt: str, context: str = "", system: str = "",
                 max_tokens: int = 350) -> str:
        import random

        # Extraer la query real del usuario desde el prompt compuesto
        lines = [l.strip() for l in prompt.split("\n") if l.strip()]
        user_query = prompt
        for line in reversed(lines):
            if line.startswith("MARK:") or line.startswith("Usuario:"):
                user_query = line.split(":", 1)[-1].strip()
                break
            skip_keywords = ["eres mark", "personalidad", "tony stark", "iron man",
                             "señor", "concisas", "español", "sistema de", "asistencia"]
            if not any(kw in line.lower() for kw in skip_keywords) and len(line) > 5:
                user_query = line
                break

        pl = user_query.lower()

        if any(w in pl for w in ['hola', 'buenas', 'buenos días', 'buenas noches', 'hey']):
            return random.choice([
                "Aquí, Señor. ¿Qué necesita?",
                "Presente. ¿En qué puedo asistirle?",
                "Online. ¿Qué tiene en mente?",
                "Sistemas activos. Dígame.",
            ])
        if any(w in pl for w in ['cómo estás', 'estás bien', 'todo bien', 'qué tal']):
            return random.choice([
                "Sistema nominal. A su disposición.",
                "Todo operativo. ¿Necesita algo?",
                "Sin novedades. ¿Qué tiene en mente?",
            ])
        if any(w in pl for w in ['joder', 'mierda', 'harto', 'no puedo', 'no funciona', 'roto']):
            return random.choice([
                "Entendido. ¿Qué está fallando exactamente?",
                "Cuénteme el problema y lo resolvemos.",
                "Anotado. ¿Por dónde empezamos?",
            ])
        if any(w in pl for w in ['opinas', 'piensas', 'mejor', ' vs ', 'comparar', 'diferencia']):
            if 'python' in pl and ('js' in pl or 'javascript' in pl):
                return "Python para backend y data. JavaScript para web. Sin más contexto, difícil elegir — ¿qué va a construir?"
            if 'python' in pl:
                return "Python es sólido. Legible, versátil, ecosistema enorme. ¿Para qué lo necesita?"
            if 'linux' in pl and ('windows' in pl or 'mac' in pl):
                return "Linux para control total. Windows para compatibilidad. Mac para flujo creativo. Depende del uso, Señor."
            return "Depende del contexto. ¿Me da más detalles sobre el caso de uso?"
        if any(w in pl for w in ['qué puedes', 'qué sabes', 'qué haces', 'ayuda', 'capacidades']):
            return ("Control del sistema, búsquedas web, música, scripts Python, "
                    "análisis de documentos y conversación. ¿Qué necesita, Señor?")
        if any(w in pl for w in ['quién eres', 'qué eres', 'cómo te llamas', 'tu nombre']):
            return random.choice([
                "MARK. Sistema de asistencia avanzado. A su servicio, Señor.",
                "Su asistente personal. MARK, para ser exactos.",
            ])
        if any(w in pl for w in ['gracias', 'perfecto', 'genial', 'bien hecho', 'excelente', 'gracias']):
            return random.choice(["A sus órdenes.", "Sin problema.", "Es lo que hago."])
        if any(w in pl for w in ['noticias', 'news', 'qué hay de nuevo']):
            return "Para noticias necesito conexión — active LM Studio o dígame que busque en internet."
        if '?' in user_query:
            return "Buena pregunta. Active LM Studio en 127.0.0.1:1234 para respuestas más elaboradas."
        return random.choice([
            "Entendido. Sea más específico y lo ejecuto.",
            "Recibido. ¿Quiere que tome una decisión o prefiere darme más contexto?",
            "Anotado. ¿Cómo procedo?",
        ])


class AIManager:
    """Gestor central de IA: LM Studio → Pollinations → Fallback."""

    def __init__(self):
        self.local_ai = LMStudioAI()
        self.online_ai = PollinationsAI()
        self.fallback = FallbackEngine()
        self.active_source = 'fallback'
        self._determine_source()

    def _determine_source(self):
        if self.local_ai.available:
            self.active_source = 'lm_studio'
        elif self.online_ai.available:
            self.active_source = 'pollinations'
        else:
            self.active_source = 'fallback'
        logger.info(f"Fuente IA activa: {self.active_source}")

    def retry_local(self):
        """Reintentar conexión a LM Studio."""
        self.local_ai.retry_connection()
        self._determine_source()

    def generate(self, prompt: str, context: str = "",
                 system: str = "", max_tokens: int = 350) -> str:
        """Generar respuesta con prioridades: LM Studio → Pollinations → Fallback."""

        # Prioridad 1: LM Studio local
        if self.local_ai.available:
            result = self.local_ai.generate(prompt, context, system, max_tokens)
            if result:
                self.active_source = 'lm_studio'
                return result

        # Prioridad 2: Pollinations online
        if self.online_ai.available:
            result = self.online_ai.generate(prompt, context, system, max_tokens)
            if result:
                self.active_source = 'pollinations'
                return result

        # Prioridad 3: Fallback inteligente
        self.active_source = 'fallback'
        return self.fallback.generate(prompt, context, system)

    def generate_code(self, description: str, language: str = "python",
                      style_context: str = "") -> str:
        """Generar código con contexto de estilo del usuario."""
        style_note = f"\nEstilo del usuario:\n{style_context}" if style_context else ""
        prompt = (f"Escribe código {language} para: {description}\n"
                  f"Requisitos: código limpio, comentado en español, funcional.{style_note}\n"
                  f"Responde SOLO con el código, sin explicaciones antes ni después.")
        system = (f"Eres un experto en {language}. Generas código limpio, "
                  f"funcional y bien comentado. Sin explicaciones extra — solo código.")
        return self.generate(prompt, system=system, max_tokens=800)

    def analyze_text(self, text: str, task: str = "analizar") -> str:
        """Analizar texto con IA."""
        return self.generate(f"Tarea: {task}\n\nTexto:\n{text}")

    def get_status(self) -> dict:
        return {
            'source': self.active_source,
            'lm_studio': self.local_ai.available,
            'pollinations': self.online_ai.available,
            'model': self.local_ai.model,
        }
