@echo off
echo ============================================
echo    JARVIS v4.0 - Instalador Windows
echo ============================================
echo.
echo Instalando dependencias base...
pip install psutil pyautogui pygetwindow pynput

echo.
echo Instalando sistema de voz...
pip install edge-tts pyttsx3 SpeechRecognition

echo.
echo Instalando dependencias adicionales...
pip install pygame

echo.
echo Instalando automatizacion de navegador...
pip install selenium webdriver-manager

echo.
echo Instalando vision computacional (opcional)...
pip install opencv-python Pillow mss
pip install pytesseract

echo.
echo Instalando control de volumen Windows...
pip install pycaw comtypes

echo.
echo ============================================
echo   INSTALACION COMPLETADA
echo ============================================
echo.
echo Para iniciar JARVIS ejecute: python main.py
echo Para modo consola: python main.py --cli
echo.
pause
