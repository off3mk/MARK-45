@echo off
echo Iniciando JARVIS v4.0...
cd /d "%~dp0"
python main.py
pause
