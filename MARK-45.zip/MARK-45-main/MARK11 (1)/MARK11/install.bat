@echo off
title MARK 11 -- Instalacion -- Ali (Sidi3Ali)
color 0A
echo.
echo  ============================================================
echo   M A R K  1 1  --  Instalando dependencias
echo   Motor IA: LM Studio + Qwen2.5-7B-Instruct-1M
echo   Hardware: i5-9600K + RX 5700 XT + 16GB RAM
echo   Creator: Ali (Sidi3Ali)
echo  ============================================================
echo.
echo  [1/5] Core...
pip install psutil requests
echo.
echo  [2/5] UI y control...
pip install pyautogui pygetwindow pynput pyperclip pywin32 uiautomation
echo.
echo  [3/5] Voz...
pip install edge-tts pyttsx3 SpeechRecognition pygame
echo.
echo  [4/5] Vision...
pip install Pillow mss
echo.
echo  [5/5] Extras...
pip install spotipy comtypes
echo.
echo  ============================================================
echo  MOTOR IA: LM Studio (requerido)
echo    1. Descarga: https://lmstudio.ai/download
echo    2. Busca y descarga: Qwen2.5-7B-Instruct-1M-GGUF (Q4_K_M)
echo    3. Carga el modelo
echo    4. Server tab -> Start Server (puerto 1234)
echo.
echo  CONFIG LM Studio:
echo    Temperature: 0.3
echo    Top-P: 0.9
echo    Context Length: 8192
echo    GPU Layers: 20-35
echo  ============================================================
echo.
echo  OPCIONAL OCR: pip install pytesseract opencv-python
echo  OPCIONAL audio: pip install pipwin ^& pipwin install pyaudio
echo  OPCIONAL volumen: pip install pycaw
echo.
echo  Instalacion completada. Ejecuta start.bat
pause
