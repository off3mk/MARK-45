@echo off
title MARK 11 CLI — Ali (Sidi3Ali)
color 0E
cd /d "%~dp0"
python main.py --cli %*
pause
