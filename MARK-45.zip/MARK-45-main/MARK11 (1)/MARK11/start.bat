@echo off
title MARK 11 — Autonomous Cognitive System — Ali (Sidi3Ali)
color 0B
cd /d "%~dp0"
echo  Iniciando MARK 11...
python main.py %*
pause
