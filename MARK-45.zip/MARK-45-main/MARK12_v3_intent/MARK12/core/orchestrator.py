"""
MARK 12 — Orchestrator v2 (Full Integration)
=============================================
Cerebro central con TODOS los módulos integrados:
  • Computer Use Agent  (ve + actúa sobre la pantalla)
  • File Manager        (acceso directo al sistema de archivos)
  • Hotkey Daemon       (invocación global desde cualquier app)
  • OODA Cognitive Loop (bucle cognitivo autónomo)
  • LLM Engine          (cascada LM Studio → Ollama → Mistral → Pollinations)
  • Modo Gaming         (libera VRAM automáticamente)
  • SSML Voice          (TTS natural con Edge TTS)

Arquitectura: asyncio puro. Nunca se bloquea.
Hardware objetivo: i5-9600K + RX 5700 XT + 16GB RAM

Creado por Ali (Sidi3Ali) — MARK 12
"""

import asyncio
import logging
import os
import platform
import re
import sys
import threading
import time
import webbrowser
import urllib.parse
from datetime import datetime
from typing import Any, Callable, Dict, List, Optional

logger = logging.getLogger("MARK12")

SYSTEM = platform.system()

# ── IDENTIDAD PERMANENTE ──────────────────────────────────────────────────────
_CREATOR = {
    "name":    "Ali",
    "alias":   "Sidi3Ali",
    "system":  "MARK 12",
    "version": "12.0",
    "built":   "2024",
}


class Orchestrator:
    """Director central de MARK 12."""

    def __init__(self):
        self.running      = False
        self.gaming_mode  = False
        self._ui_callback: Optional[Callable] = None
        self._chat_history: List[Dict] = []

        logger.info("=" * 60)
        logger.info("  M A R K  12  — Inicializando subsistemas")
        logger.info(f"  Creado por Ali (Sidi3Ali)")
        logger.info("=" * 60)

        # ── LLM Engine ────────────────────────────────────────────────────────
        self.llm = self._init_llm()

        # ── Identidad de usuario ──────────────────────────────────────────────
        self._user_name  = "Señor"
        self._is_creator = False
        self._load_identity()

        # ── Computer Use (visión + control) ───────────────────────────────────
        self.cua = self._init_cua()

        # ── File Manager ──────────────────────────────────────────────────────
        from core.file_manager import FileManager
        self.files = FileManager(self.llm)
        logger.info("✓ File Manager listo")

        # ── Perception (monitor de sistema) ───────────────────────────────────
        self.monitor = self._init_monitor()

        # ── OODA Loop ─────────────────────────────────────────────────────────
        self.ooda = self._init_ooda()

        # ── Voz ───────────────────────────────────────────────────────────────
        self._voice = self._init_voice()

        # ── Hotkey Daemon ─────────────────────────────────────────────────────
        self.hotkey = self._init_hotkey()

        # ── Skills modulares ──────────────────────────────────────────────────
        self._skills: Dict[str, Any] = {}
        self._load_skills()

        # ── IntentEngine + Dispatcher (núcleo de comprensión) ─────────────
        from core.intent_engine import IntentEngine
        from core.dispatcher    import ActionDispatcher
        self.intent_engine = IntentEngine(self.llm)
        self.dispatcher    = ActionDispatcher(self)
        logger.info("✓ IntentEngine + Dispatcher listos (comprensión universal)")

        # Cola de eventos asyncio (se inicializa en start())
        self.event_queue: Optional[asyncio.Queue] = None

        logger.info("=" * 60)
        logger.info(f"  Usuario: {self._user_name} ({'Creador' if self._is_creator else 'Estándar'})")
        logger.info(f"  LLM: {getattr(self.llm, 'active_provider', 'N/A')}")
        logger.info(f"  CUA: {'✓ Activo' if self.cua else '✗ No disponible'}")
        logger.info(f"  Hotkeys: {self.hotkey.get_registered().split(chr(10))[0]}")
        logger.info("=" * 60)

    # ── INICIALIZACIÓN DE SUBSISTEMAS ─────────────────────────────────────────

    def _init_llm(self):
        try:
            from core.llm_engine import LLMEngine
            llm = LLMEngine()
            logger.info("✓ LLM Engine listo")
            return llm
        except Exception as e:
            logger.warning(f"LLM Engine: {e}")
            return None

    def _init_cua(self):
        try:
            from core.computer_use.agent import ComputerUseAgent
            cua = ComputerUseAgent(self.llm)
            logger.info("✓ Computer Use Agent listo")
            return cua
        except Exception as e:
            logger.warning(f"CUA: {e}")
            return None

    def _init_monitor(self):
        try:
            from perception.perception_loop import SystemMonitor
            m = SystemMonitor()
            logger.info("✓ System Monitor listo")
            return m
        except Exception as e:
            logger.warning(f"Monitor: {e}")
            return None

    def _init_ooda(self):
        try:
            from core.cognitive_loop import OODALoop
            o = OODALoop()
            o.state.user_name  = self._user_name
            o.state.is_creator = self._is_creator
            logger.info("✓ OODA Loop listo")
            return o
        except Exception as e:
            logger.warning(f"OODA: {e}")
            return None

    def _init_voice(self):
        try:
            # Intentar importar VoiceSystem del JARVIS anterior
            jarvis_path = os.path.join(os.path.dirname(__file__), '..', '..', 'Jarvis')
            if os.path.exists(jarvis_path) and jarvis_path not in sys.path:
                sys.path.insert(0, os.path.abspath(jarvis_path))
            from core.voice import VoiceSystem
            v = VoiceSystem()
            logger.info(f"✓ Voice TTS listo")
            return v
        except Exception as e:
            logger.debug(f"Voice no disponible: {e}")
            return None

    def _init_hotkey(self):
        from core.hotkey_daemon import HotkeyDaemon
        hk = HotkeyDaemon()
        return hk

    def _load_identity(self):
        try:
            import getpass
            uname = getpass.getuser().lower()
            self._is_creator = any(x in uname for x in ['ali', 'sidi'])
            self._user_name  = 'Señor' if self._is_creator else uname.capitalize()
        except Exception:
            pass

    def _load_skills(self):
        skill_map = {
            'system':  'skills.system',
            'media':   'skills.media',
            'browser': 'skills.browser',
            'coding':  'skills.coding',
            'files':   'skills.file_skill',
            'spotify': 'skills.spotify_skill',
        }
        for name, mod_path in skill_map.items():
            try:
                import importlib
                self._skills[name] = importlib.import_module(mod_path)
            except Exception:
                pass

    # ── ARRANQUE ──────────────────────────────────────────────────────────────

    async def start(self):
        """Arrancar todos los bucles asíncronos en paralelo."""
        self.running     = True
        self.event_queue = asyncio.Queue()

        # Registrar hotkeys
        self._setup_hotkeys()

        # Saludo de inicio
        await self._speak(self._greeting(), 'greeting')

        logger.info("🚀 MARK 12 — Todos los bucles activos")

        await asyncio.gather(
            self._perception_loop(),
            self._gaming_monitor(),
            self._cognitive_cycle(),
            self._vision_loop(),
            self._voice_loop(),
            self._execution_loop(),
        )

    def _setup_hotkeys(self):
        """Registrar hotkeys globales para invocar MARK desde cualquier app."""
        callbacks = {
            'screenshot':    lambda: asyncio.run_coroutine_threadsafe(
                self._quick_screenshot(), asyncio.get_event_loop()
            ),
            'analyze_screen': lambda: asyncio.run_coroutine_threadsafe(
                self._quick_screen_analysis(), asyncio.get_event_loop()
            ),
        }
        self.hotkey.setup_defaults(callbacks)
        self.hotkey.start(block=False)

    async def _quick_screenshot(self):
        if self.cua:
            path = await self.cua.take_screenshot()
            if path:
                await self.event_queue.put({'type': 'speak', 'text': f"Captura guardada en el escritorio."})

    async def _quick_screen_analysis(self):
        if self.cua:
            analysis = await self.cua.read_screen()
            await self.event_queue.put({'type': 'speak', 'text': analysis[:200], 'speech_type': 'info'})

    # ── BUCLES ASÍNCRONOS ─────────────────────────────────────────────────────

    async def _perception_loop(self):
        """Sensores del sistema — cada 1s."""
        while self.running:
            try:
                if self.monitor:
                    stats = await asyncio.to_thread(self.monitor.get_stats)
                    self.gaming_mode = stats.get('gaming_mode', False)
                    if self.ooda:
                        self.ooda.observe(stats)
            except Exception as e:
                logger.debug(f"perception: {e}")
            await asyncio.sleep(1)

    async def _gaming_monitor(self):
        """Detecta transiciones de modo gaming — cada 5s."""
        was_gaming = False
        while self.running:
            try:
                if self.gaming_mode and not was_gaming:
                    logger.warning("🎮 MODO GAMING ACTIVADO — Liberando VRAM")
                    await self._speak(
                        f"Modo Gaming activado, {self._user_name}. VRAM liberada.", 'info'
                    )
                    if self.llm:
                        await asyncio.to_thread(self.llm.unload_model)
                    was_gaming = True
                elif not self.gaming_mode and was_gaming:
                    logger.info("✅ Modo Gaming OFF — Sistemas reactivados")
                    await self._speak("Modo Gaming desactivado. Sistemas al máximo.", 'info')
                    if self.llm:
                        await asyncio.to_thread(self.llm.reload_model)
                    was_gaming = False
            except Exception as e:
                logger.debug(f"gaming_monitor: {e}")
            await asyncio.sleep(5)

    async def _cognitive_cycle(self):
        """OODA Loop — cada 5s (30s en gaming)."""
        while self.running:
            interval = 30 if self.gaming_mode else 5
            try:
                if self.ooda and not self.gaming_mode:
                    analysis = self.ooda.orient()
                    action   = self.ooda.decide(analysis)
                    if action:
                        t = action.get('type')
                        if t == 'alert':
                            await self.event_queue.put({
                                'type': 'speak',
                                'text': action.get('msg', ''),
                                'speech_type': 'alert'
                            })
            except Exception as e:
                logger.debug(f"cognitive: {e}")
            await asyncio.sleep(interval)

    async def _vision_loop(self):
        """Análisis visual — cada 2s, pausado en gaming."""
        if not self.cua:
            return
        while self.running:
            if self.gaming_mode:
                await asyncio.sleep(10)
                continue
            try:
                analysis = await asyncio.to_thread(
                    self.cua.screen.analyze
                )
                if analysis:
                    logger.debug(f"Visión: {analysis[:80]}")
                    # Solo alertar si detecta algo urgente
                    if any(w in analysis.lower() for w in
                            ['error', 'crítico', 'fallo', 'warning', 'advertencia']):
                        await self.event_queue.put({
                            'type': 'speak',
                            'text': f"Detectado en pantalla: {analysis[:120]}",
                            'speech_type': 'alert'
                        })
            except Exception as e:
                logger.debug(f"vision: {e}")
            await asyncio.sleep(2)

    async def _voice_loop(self):
        """STT continuo — siempre activo."""
        if not self._voice or not getattr(self._voice, 'stt_enabled', False):
            return
        while self.running:
            try:
                text = await asyncio.to_thread(self._voice.listen, 3.0, 15.0)
                if text and len(text.strip()) > 1:
                    await self.event_queue.put({'type': 'voice_command', 'text': text.strip()})
            except Exception:
                await asyncio.sleep(0.5)

    async def _execution_loop(self):
        """Ejecutor de eventos — siempre activo."""
        while self.running:
            try:
                event = await asyncio.wait_for(self.event_queue.get(), timeout=1.0)
                await self._process_event(event)
                self.event_queue.task_done()
            except asyncio.TimeoutError:
                pass
            except Exception as e:
                logger.error(f"execution: {e}")

    async def _process_event(self, event: Dict):
        t = event.get('type', '')
        if t == 'speak':
            await self._speak(event.get('text', ''), event.get('speech_type', 'info'))
        elif t in ('voice_command', 'text_command'):
            text = event.get('text', '')
            response = await self.handle_command(text)
            if response:
                await self._speak(response)
                if self._ui_callback:
                    self._ui_callback('response', {'user': text, 'mark': response})
        elif t == 'cua_task':
            goal = event.get('goal', '')
            if goal and self.cua:
                result = await self.cua.execute(goal)
                summary = result.get('summary', '')
                if summary:
                    await self._speak(summary[:200])

    # ── PROCESAMIENTO DE COMANDOS ─────────────────────────────────────────────

    async def handle_command(self, user_input: str) -> str:
        """
        Procesar CUALQUIER comando de texto o voz.
        El LLM interpreta la intención — sin comandos hardcodeados.
        """
        if not user_input or not user_input.strip():
            return ""

        user_input = user_input.strip()
        logger.info(f"CMD: '{user_input}'")

        if self.ooda:
            self.ooda.process_user_command(user_input)

        self._chat_history.append({
            'role': 'user', 'text': user_input,
            'time': datetime.now().strftime('%H:%M:%S')
        })

        # Contexto de pantalla
        screen_ctx = ""
        if self.cua and not self.gaming_mode:
            try:
                screen_ctx = self.cua.screen.last_analysis or ""
            except Exception:
                pass

        # Contexto conversación reciente
        conv_ctx = ""
        if len(self._chat_history) > 1:
            recent = self._chat_history[-4:]
            conv_ctx = " | ".join(
                f"{'tú' if h['role']=='user' else 'MARK'}: {h['text'][:60]}"
                for h in recent
            )

        # 1. Clasificar intención con LLM
        intent = await asyncio.to_thread(
            self.intent_engine.classify,
            user_input, screen_ctx, conv_ctx
        )

        logger.info(f"Intent: '{intent.intent}' → {intent.action} ({intent.confidence:.0%})")

        # 2. Ejecutar via dispatcher
        response = await self.dispatcher.dispatch(intent)
        return self._save(response)

        # ── VOZ ───────────────────────────────────────────────────────────────────

    async def _speak(self, text: str, speech_type: str = 'info'):
        if not text or not self._voice:
            return
        try:
            if speech_type == 'greeting':
                await asyncio.to_thread(self._voice.speak_greeting, text)
            elif speech_type == 'alert':
                await asyncio.to_thread(self._voice.speak_alert, text)
            else:
                await asyncio.to_thread(self._voice.speak, text)
        except Exception:
            pass

    def speak_sync(self, text: str):
        if self._voice:
            try: self._voice.speak(text)
            except Exception: pass

    def _greeting(self) -> str:
        h = datetime.now().hour
        prefix = "Buenos días" if 5 <= h < 12 else "Bienvenido" if h < 20 else "Buenas noches"
        return f"{prefix}, {self._user_name}. MARK 12 en línea. Todos los sistemas activos."

    # ── UTILIDADES ────────────────────────────────────────────────────────────

    def _save(self, response: str) -> str:
        self._chat_history.append({
            'role': 'mark', 'text': response,
            'time': datetime.now().strftime('%H:%M:%S')
        })
        return response

    def set_ui_callback(self, cb: Callable):
        self._ui_callback = cb

    def get_stats(self) -> Dict:
        return self.monitor.get_stats() if self.monitor else {}

    def send_text_command(self, text: str) -> str:
        """Interfaz síncrona para llamar desde UI sin asyncio activo."""
        loop = asyncio.new_event_loop()
        try:
            return loop.run_until_complete(self.handle_command(text))
        finally:
            loop.close()

    async def shutdown(self):
        logger.info("Apagando MARK 12...")
        self.running = False
        self.hotkey.stop()
        if self.cua: self.cua.screen.close()
        logger.info("MARK 12 apagado.")
