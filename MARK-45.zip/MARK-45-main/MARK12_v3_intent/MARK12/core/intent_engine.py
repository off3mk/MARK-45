"""
MARK 12 — Intent Engine (Motor de Intención Universal)
========================================================
El cerebro interpretador de MARK 12.

NO usa listas de palabras clave. NO tiene comandos predefinidos.
USA el LLM para entender CUALQUIER forma de pedir algo.

El usuario puede decir:
  "oye abre el spotify"
  "pon algo de música"  
  "quiero escuchar música"
  "ponme una canción"
  "dale al spotify"
  → Todos se interpretan como: MUSIC_PLAY

Proceso:
  1. El usuario escribe/dice CUALQUIER cosa
  2. El LLM lee el mensaje + contexto actual
  3. Devuelve un JSON estructurado con:
     - intent: qué quiere hacer
     - action: qué módulo ejecutar
     - params: parámetros extraídos
     - confidence: 0.0 - 1.0
  4. El dispatcher ejecuta la acción apropiada

Creado por Ali (Sidi3Ali) — MARK 12
"""

import json
import logging
import re
from dataclasses import dataclass, field
from typing import Any, Dict, List, Optional

logger = logging.getLogger("MARK12.Intent")


# ── CATÁLOGO DE ACCIONES DISPONIBLES ─────────────────────────────────────────
# Esto no son comandos — es el "menú" que el LLM puede elegir.
# El LLM decide cuál usar basándose en el mensaje del usuario.

ACTIONS_CATALOG = """
Eres el clasificador de intenciones de MARK 12. Tu trabajo es entender
qué quiere el usuario, sin importar cómo lo diga.

ACCIONES DISPONIBLES:
──────────────────────────────────────────────────────────────────
SISTEMA
  system.status         → Ver estado del sistema (CPU, RAM, disco, procesos)
  system.open_app       → Abrir cualquier aplicación o programa
  system.close_app      → Cerrar una aplicación
  system.shutdown       → Apagar/reiniciar el PC
  system.volume         → Subir/bajar/silenciar el volumen
  system.brightness     → Ajustar brillo de pantalla
  system.processes      → Ver/matar procesos
  system.gaming_mode    → Activar/desactivar modo gaming

PANTALLA Y VISIÓN
  screen.analyze        → Describir/analizar lo que hay en pantalla ahora
  screen.screenshot     → Tomar captura de pantalla
  screen.read_text      → Leer/extraer el texto visible en pantalla (OCR)
  screen.find_click     → Buscar algo en pantalla y hacer clic
  screen.record         → Grabar la pantalla

CONTROL DEL PC (Computer Use)
  pc.click              → Hacer clic en coordenadas o en texto
  pc.type               → Escribir texto en el campo activo
  pc.hotkey             → Ejecutar atajo de teclado
  pc.task               → Tarea autónoma compleja (multi-paso)
  pc.scroll             → Hacer scroll
  pc.drag               → Arrastrar elemento

ARCHIVOS Y DOCUMENTOS
  files.read            → Leer/analizar un archivo del disco
  files.write           → Crear o modificar un archivo
  files.organize        → Organizar carpeta (por tipo, fecha, etc.)
  files.search          → Buscar archivos en el disco
  files.move            → Mover/copiar archivos
  files.delete          → Eliminar archivos
  files.rename          → Renombrar archivos (masivo o individual)
  files.compress        → Comprimir/descomprimir archivos
  files.report          → Generar reporte (gastos, análisis, etc.)
  files.disk_info       → Ver espacio en disco

WEB Y BÚSQUEDA
  web.search            → Buscar en internet (Google u otro buscador)
  web.open_url          → Abrir una URL específica
  web.youtube           → Buscar/abrir YouTube
  web.news              → Ver noticias actuales
  web.download          → Descargar algo de internet

MÚSICA Y SPOTIFY
  music.play            → Reproducir música/canción/artista/playlist
  music.pause           → Pausar música
  music.next            → Siguiente canción
  music.previous        → Canción anterior
  music.volume          → Cambiar volumen de música
  music.info            → Qué está sonando / info de la canción
  music.playlist        → Ver/gestionar playlists
  music.shuffle         → Activar/desactivar shuffle

CÓDIGO Y DESARROLLO
  code.generate         → Generar script/programa/función
  code.analyze          → Analizar/revisar código existente
  code.fix              → Corregir errores en código
  code.run              → Ejecutar un script
  code.explain          → Explicar qué hace un código
  code.terminal         → Ejecutar comando en terminal

IA Y RAZONAMIENTO
  ai.chat               → Conversación general, preguntas, respuestas
  ai.summarize          → Resumir texto/documento/conversación
  ai.translate          → Traducir texto
  ai.write              → Redactar texto, emails, documentos
  ai.analyze_data       → Analizar datos, crear gráficos, estadísticas
  ai.explain            → Explicar conceptos técnicos o complejos
  ai.math               → Resolver problemas matemáticos

MARK 12 (autogestión)
  mark.status           → Estado general de MARK 12
  mark.history          → Ver historial de conversación
  mark.clear_history    → Limpiar historial
  mark.hotkeys          → Ver atajos de teclado disponibles
  mark.identity         → Quién creó MARK 12, versión, etc.
  mark.stop             → Apagar MARK 12
──────────────────────────────────────────────────────────────────

INSTRUCCIONES:
1. Lee el mensaje del usuario (puede estar mal escrito, en spanglish, abreviado, informal)
2. Determina la intención real
3. Devuelve SOLO un JSON válido con esta estructura exacta:

{
  "intent": "descripción breve de lo que quiere",
  "action": "categoria.accion",
  "params": {
    "key": "value"
  },
  "confidence": 0.95,
  "response_hint": "cómo debería responder MARK si no puede ejecutar la acción"
}

EJEMPLOS:
Usuario: "oye ponme spotify que quiero escuchar algo"
→ {"intent": "reproducir spotify", "action": "music.play", "params": {}, "confidence": 0.97, "response_hint": ""}

Usuario: "mi carpeta de descargas está fatal ordénamela"
→ {"intent": "organizar carpeta descargas", "action": "files.organize", "params": {"folder": "downloads", "method": "type"}, "confidence": 0.95, "response_hint": ""}

Usuario: "che sabes qué está pasando en la panta"
→ {"intent": "analizar pantalla", "action": "screen.analyze", "params": {}, "confidence": 0.90, "response_hint": ""}

Usuario: "oye cuánta ram me queda"
→ {"intent": "ver estado RAM del sistema", "action": "system.status", "params": {"focus": "ram"}, "confidence": 0.98, "response_hint": ""}

Usuario: "bro hazme un script que mueva los pdfs a una carpeta"
→ {"intent": "generar script mover PDFs", "action": "code.generate", "params": {"description": "script que mueve archivos PDF a una carpeta específica", "language": "python"}, "confidence": 0.96, "response_hint": ""}

Si la intención no corresponde a ninguna acción disponible, usa "ai.chat".
NUNCA devuelvas texto fuera del JSON.
"""


@dataclass
class Intent:
    """Resultado del análisis de intención."""
    intent:        str
    action:        str          # "categoria.accion"
    category:      str          # "sistema", "archivos", etc.
    subcategory:   str          # "status", "open_app", etc.
    params:        Dict = field(default_factory=dict)
    confidence:    float = 0.0
    response_hint: str = ""
    raw_input:     str = ""

    @classmethod
    def from_dict(cls, d: Dict, raw: str = "") -> 'Intent':
        action = d.get('action', 'ai.chat')
        parts  = action.split('.', 1)
        return cls(
            intent      = d.get('intent', ''),
            action      = action,
            category    = parts[0] if len(parts) > 0 else 'ai',
            subcategory = parts[1] if len(parts) > 1 else 'chat',
            params      = d.get('params', {}),
            confidence  = float(d.get('confidence', 0.5)),
            response_hint = d.get('response_hint', ''),
            raw_input   = raw,
        )

    @classmethod
    def chat_fallback(cls, raw: str = "") -> 'Intent':
        return cls(
            intent='conversación general', action='ai.chat',
            category='ai', subcategory='chat',
            params={}, confidence=0.5, raw_input=raw
        )


class IntentEngine:
    """
    Motor de intención universal.
    Usa el LLM para entender CUALQUIER mensaje, sin comandos predefinidos.
    """

    def __init__(self, llm_engine):
        self.llm = llm_engine
        self._cache: Dict[str, Intent] = {}   # Cache simple para frases repetidas
        self._stats = {'total': 0, 'cache_hits': 0, 'failures': 0}

    def classify(self, user_input: str,
                  screen_context: str = "",
                  conversation_context: str = "") -> Intent:
        """
        Clasificar la intención del usuario.

        user_input          → Lo que dijo el usuario (cualquier forma)
        screen_context      → Qué hay en pantalla ahora (opcional)
        conversation_context → Últimos mensajes (opcional)
        """
        self._stats['total'] += 1

        if not user_input or not user_input.strip():
            return Intent.chat_fallback()

        # Normalizar input
        text = user_input.strip()

        # Cache para frases repetidas (insensible a mayúsculas/puntuación)
        cache_key = re.sub(r'[^\w\s]', '', text.lower()).strip()
        if cache_key in self._cache:
            self._stats['cache_hits'] += 1
            cached = self._cache[cache_key]
            cached.raw_input = text
            logger.debug(f"Intent [cache]: {cached.action} ({cached.confidence:.0%})")
            return cached

        # Construir prompt con contexto
        context_parts = []
        if screen_context:
            context_parts.append(f"Pantalla actual: {screen_context[:200]}")
        if conversation_context:
            context_parts.append(f"Contexto conversación: {conversation_context[:300]}")

        context_str = '\n'.join(context_parts)

        prompt = (
            f"{ACTIONS_CATALOG}\n\n"
            f"{'CONTEXTO:\n' + context_str + chr(10) if context_str else ''}"
            f"MENSAJE DEL USUARIO: \"{text}\"\n\n"
            f"JSON:"
        )

        try:
            if not self.llm:
                return self._heuristic_fallback(text)

            response = self.llm.generate(
                prompt,
                with_history=False,
                max_tokens=300,
                temperature=0.1,   # Temperatura baja = más determinista
            )

            # Extraer JSON de la respuesta
            intent = self._parse_response(response, text)

            # Guardar en cache
            if intent.confidence >= 0.7:
                self._cache[cache_key] = intent

            logger.info(
                f"Intent: '{intent.intent}' → {intent.action} "
                f"({intent.confidence:.0%}) | params: {intent.params}"
            )
            return intent

        except Exception as e:
            logger.warning(f"IntentEngine.classify: {e}")
            self._stats['failures'] += 1
            return self._heuristic_fallback(text)

    def _parse_response(self, response: str, raw: str) -> Intent:
        """Parsear respuesta JSON del LLM."""
        # Extraer JSON de la respuesta (puede tener texto adicional)
        patterns = [
            r'\{[^{}]*"action"[^{}]*\}',      # JSON de una línea
            r'\{.*?"action".*?\}',              # JSON multilínea
            r'\{.*\}',                          # Cualquier JSON
        ]
        for pattern in patterns:
            match = re.search(pattern, response, re.DOTALL)
            if match:
                try:
                    d = json.loads(match.group())
                    intent = Intent.from_dict(d, raw)
                    # Validar que la acción existe en el catálogo
                    if '.' in intent.action:
                        return intent
                except json.JSONDecodeError:
                    continue

        # Si no se pudo parsear, usar heurística
        logger.debug(f"JSON no parseable: {response[:100]}")
        return self._heuristic_fallback(raw)

    def _heuristic_fallback(self, text: str) -> Intent:
        """
        Fallback heurístico LIGERO cuando el LLM no está disponible.
        Cubre los casos más comunes con patrones simples.
        NO es el sistema principal — solo backup de emergencia.
        """
        t = text.lower()

        # Identidad
        if any(w in t for w in ['quién eres', 'quien eres', 'tu nombre', 'qué eres',
                                   'creador', 'te creó', 'te creo']):
            return Intent('identidad de MARK', 'mark.identity', 'mark', 'identity',
                           {}, 0.9, '', text)

        # Estado sistema
        if any(w in t for w in ['cpu', 'ram', 'memoria', 'disco', 'temperatura',
                                   'estado', 'status', 'cómo está', 'cargando',
                                   'procesos', 'consumo']):
            return Intent('estado del sistema', 'system.status', 'system', 'status',
                           {}, 0.85, '', text)

        # Música
        if any(w in t for w in ['spotify', 'música', 'musica', 'canción', 'cancion',
                                   'escuchar', 'pon algo', 'reproduce', 'song', 'playlist']):
            if any(w in t for w in ['para', 'pausa', 'stop', 'detén', 'deten']):
                return Intent('pausar música', 'music.pause', 'music', 'pause', {}, 0.9, '', text)
            if any(w in t for w in ['siguiente', 'next', 'salta', 'skip']):
                return Intent('siguiente canción', 'music.next', 'music', 'next', {}, 0.9, '', text)
            if any(w in t for w in ['anterior', 'atrás', 'atras', 'back', 'prev']):
                return Intent('canción anterior', 'music.previous', 'music', 'previous', {}, 0.9, '', text)
            # Extraer query
            query = re.sub(r'(spotify|música|musica|reproduce|pon|escuchar|ponme)\s*', '', t).strip()
            return Intent('reproducir música', 'music.play', 'music', 'play',
                           {'query': query} if query else {}, 0.85, '', text)

        # Pantalla
        if any(w in t for w in ['pantalla', 'screen', 'captura', 'screenshot',
                                   'qué hay', 'que hay', 'ves', 'está pasando']):
            if any(w in t for w in ['captura', 'screenshot', 'foto']):
                return Intent('captura de pantalla', 'screen.screenshot', 'screen', 'screenshot',
                               {}, 0.9, '', text)
            if any(w in t for w in ['texto', 'leer', 'lee', 'ocr']):
                return Intent('leer texto pantalla', 'screen.read_text', 'screen', 'read_text',
                               {}, 0.9, '', text)
            return Intent('analizar pantalla', 'screen.analyze', 'screen', 'analyze',
                           {}, 0.85, '', text)

        # Archivos
        if any(w in t for w in ['archivo', 'fichero', 'carpeta', 'descargas', 'folder',
                                   'organiza', 'ordena', 'mueve', 'copia', 'borra', 'elimina']):
            if any(w in t for w in ['organiza', 'ordena', 'limpia', 'arregla']):
                return Intent('organizar archivos', 'files.organize', 'files', 'organize',
                               {'folder': 'downloads'}, 0.85, '', text)
            if any(w in t for w in ['lee', 'abre', 'muéstrame', 'mostrame', 'ver']):
                return Intent('leer archivo', 'files.read', 'files', 'read', {}, 0.8, '', text)
            if any(w in t for w in ['busca', 'encuentra', 'dónde', 'donde']):
                return Intent('buscar archivos', 'files.search', 'files', 'search',
                               {'query': t}, 0.8, '', text)
            if any(w in t for w in ['espacio', 'disco', 'libre', 'lleno']):
                return Intent('espacio en disco', 'files.disk_info', 'files', 'disk_info',
                               {}, 0.85, '', text)

        # Web
        if any(w in t for w in ['busca', 'googlea', 'google', 'internet', 'web', 'online']):
            query = re.sub(r'(busca(r)?|googlea(r)?|google|en internet|en la web)\s*', '', t).strip()
            return Intent('búsqueda web', 'web.search', 'web', 'search',
                           {'query': query}, 0.85, '', text)

        if any(w in t for w in ['youtube', 'yt', 'video', 'vídeo']):
            query = re.sub(r'(youtube|yt|pon|busca|buscar)\s*', '', t).strip()
            return Intent('youtube', 'web.youtube', 'web', 'youtube',
                           {'query': query}, 0.85, '', text)

        # Código
        if any(w in t for w in ['script', 'programa', 'código', 'codigo', 'función',
                                   'funcion', 'hazme', 'crea', 'genera']):
            return Intent('generar código', 'code.generate', 'code', 'generate',
                           {'description': text}, 0.8, '', text)

        # Abre app
        if any(w in t for w in ['abre', 'lanza', 'inicia', 'ejecuta', 'pon', 'arranca']):
            app = re.sub(r'(abre|lanza|inicia|ejecuta|pon|arranca)\s*(el|la|los|las)?\s*', '', t).strip()
            if app and len(app) > 1:
                return Intent(f'abrir {app}', 'system.open_app', 'system', 'open_app',
                               {'name': app}, 0.8, '', text)

        # Hora / fecha
        if any(w in t for w in ['hora', 'fecha', 'día', 'dia', 'tiempo']):
            return Intent('hora y fecha', 'ai.chat', 'ai', 'chat', {}, 0.9, '', text)

        # Saludo
        if t.strip() in {'hola', 'hey', 'buenas', 'ey', 'hello', 'hi'}:
            return Intent('saludo', 'ai.chat', 'ai', 'chat',
                           {'type': 'greeting'}, 0.95, '', text)

        # Apagar MARK
        if any(w in t for w in ['apágate', 'apagate', 'ciérrate', 'cerrate',
                                   'bye', 'adiós', 'adios', 'hasta luego', 'salir']):
            return Intent('apagar MARK', 'mark.stop', 'mark', 'stop', {}, 0.9, '', text)

        # Fallback → chat general
        return Intent.chat_fallback(text)

    def get_stats(self) -> str:
        total = self._stats['total']
        if total == 0:
            return "IntentEngine: sin consultas todavía."
        hits = self._stats['cache_hits']
        fails = self._stats['failures']
        return (
            f"IntentEngine: {total} consultas | "
            f"cache {hits} ({hits/total:.0%}) | "
            f"fallos {fails} ({fails/total:.0%}) | "
            f"cache size: {len(self._cache)}"
        )

    def clear_cache(self):
        self._cache.clear()
