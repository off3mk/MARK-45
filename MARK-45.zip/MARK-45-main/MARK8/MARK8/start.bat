@echo off
title MARK 8 — Autonomous Cognitive System — Ali (Sidi3Ali)
color 0B
echo.
echo  ============================================================
echo   M A R K  8  --  Fully Autonomous Cognitive System
echo   Creado por Ali (Sidi3Ali)
echo  ============================================================
echo.
cd /d "%~dp0"
python main.py %*
pause
