@echo off
title MARK 8 — Instalacion
color 0A
echo.
echo  ============================================================
echo   M A R K  8  --  Instalando dependencias
echo   Creado por Ali (Sidi3Ali)
echo  ============================================================
echo.
pip install --upgrade pip
pip install psutil pyautogui pygetwindow pynput
pip install edge-tts pyttsx3 SpeechRecognition
pip install spotipy
pip install uiautomation pywin32 pyperclip
pip install Pillow mss requests pygame
echo.
echo [OPCIONAL - Solo si necesitas OCR/Vision avanzada]:
echo   pip install opencv-python pytesseract
echo.
echo [OPCIONAL - Detectar cancion actual del sistema]:
echo   pip install winsdk
echo.
echo [NOTA - PyAudio puede requerir instalacion especial]:
echo   pip install pipwin
echo   pipwin install pyaudio
echo.
echo  Instalacion completada. Ejecuta start.bat para iniciar MARK 8.
pause
