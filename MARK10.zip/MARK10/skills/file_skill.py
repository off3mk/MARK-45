"""
J.A.R.V.I.S MARK 6 - File Analysis System
Analiza cualquier tipo de archivo como lo haría ChatGPT/Claude:
- Word (.docx, .doc)
- PDF
- Imágenes (jpg, png, gif, bmp, webp)
- CSV / Excel
- Código (cualquier lenguaje)
- Texto plano
- JSON / XML
"""

import os, re, json, logging, base64, io
from typing import Optional, Dict, List, Any, Tuple
from pathlib import Path

logger = logging.getLogger('MARK.Files')

# Directorios de uploads
UPLOAD_DIRS = [
    '/mnt/user-data/uploads',
    os.path.join(os.path.dirname(os.path.dirname(__file__)), 'uploads'),
    os.path.join(os.path.expanduser('~'), 'uploads'),
    os.path.join(os.path.dirname(os.path.dirname(__file__)), 'workspace', 'uploads'),
]

WORKSPACE = os.path.join(os.path.dirname(os.path.dirname(__file__)), 'workspace')


class FileReader:
    """Lee cualquier tipo de archivo y extrae su contenido."""

    def read(self, path: str) -> Tuple[str, str]:
        """
        Lee un archivo.
        Retorna: (contenido_texto, tipo_archivo)
        """
        if not os.path.exists(path):
            return "", "unknown"

        ext = Path(path).suffix.lower()

        readers = {
            '.docx': self._read_docx,
            '.doc':  self._read_doc,
            '.pdf':  self._read_pdf,
            '.csv':  self._read_csv,
            '.xlsx': self._read_excel,
            '.xls':  self._read_excel,
            '.txt':  self._read_text,
            '.md':   self._read_text,
            '.json': self._read_json,
            '.xml':  self._read_xml,
            '.html': self._read_text,
            '.py':   self._read_code,
            '.js':   self._read_code,
            '.ts':   self._read_code,
            '.java': self._read_code,
            '.cpp':  self._read_code,
            '.c':    self._read_code,
            '.cs':   self._read_code,
            '.go':   self._read_code,
            '.rs':   self._read_code,
            '.php':  self._read_code,
            '.rb':   self._read_code,
            '.sh':   self._read_code,
            '.bat':  self._read_code,
            '.sql':  self._read_code,
        }

        # Imágenes
        if ext in ('.jpg', '.jpeg', '.png', '.gif', '.bmp', '.webp', '.tiff'):
            return self._read_image(path), 'image'

        reader = readers.get(ext, self._read_text)
        file_type = ext.lstrip('.') or 'texto'

        try:
            content = reader(path)
            return content, file_type
        except Exception as e:
            logger.debug(f"Error leyendo {path}: {e}")
            # Intentar leer como texto plano
            try:
                return self._read_text(path), 'texto'
            except Exception:
                return "", "unknown"

    def _read_docx(self, path: str) -> str:
        try:
            import docx
            doc = docx.Document(path)
            parts = []
            for para in doc.paragraphs:
                if para.text.strip():
                    style = para.style.name if para.style else ''
                    if 'Heading' in style:
                        parts.append(f"\n## {para.text}\n")
                    else:
                        parts.append(para.text)
            # También extraer tablas
            for table in doc.tables:
                for row in table.rows:
                    row_text = ' | '.join(cell.text.strip() for cell in row.cells)
                    if row_text.strip():
                        parts.append(row_text)
            return '\n'.join(parts)
        except Exception as e:
            logger.debug(f"docx error: {e}")
            return ""

    def _read_doc(self, path: str) -> str:
        # Intentar con antiword si está disponible
        try:
            import subprocess
            result = subprocess.run(['antiword', path], capture_output=True, text=True, timeout=10)
            if result.returncode == 0:
                return result.stdout
        except Exception:
            pass
        # Leer bytes directamente (extracción básica)
        try:
            with open(path, 'rb') as f:
                data = f.read()
            text = data.decode('latin-1', errors='ignore')
            # Extraer texto legible
            words = re.findall(r'[a-záéíóúñüA-ZÁÉÍÓÚÑÜ][a-záéíóúñüA-ZÁÉÍÓÚÑÜ\s]{3,}', text)
            return ' '.join(words[:500])
        except Exception:
            return ""

    def _read_pdf(self, path: str) -> str:
        try:
            from pypdf import PdfReader
            reader = PdfReader(path)
            pages = []
            for i, page in enumerate(reader.pages):
                text = page.extract_text()
                if text and text.strip():
                    pages.append(f"[Página {i+1}]\n{text}")
            return '\n\n'.join(pages)
        except Exception as e:
            logger.debug(f"PDF error: {e}")
            return ""

    def _read_csv(self, path: str) -> str:
        try:
            import pandas as pd
            df = pd.read_csv(path, nrows=100)
            info = (f"CSV: {len(df)} filas × {len(df.columns)} columnas\n"
                    f"Columnas: {', '.join(df.columns.tolist())}\n\n"
                    f"Primeras 10 filas:\n{df.head(10).to_string()}\n\n"
                    f"Estadísticas:\n{df.describe().to_string()}")
            return info
        except Exception as e:
            logger.debug(f"CSV error: {e}")
            # Fallback: leer como texto
            return self._read_text(path)

    def _read_excel(self, path: str) -> str:
        try:
            import pandas as pd
            xls = pd.ExcelFile(path)
            parts = [f"Excel con {len(xls.sheet_names)} hojas: {', '.join(xls.sheet_names)}\n"]
            for sheet in xls.sheet_names[:3]:
                df = pd.read_excel(path, sheet_name=sheet, nrows=50)
                parts.append(f"\n[Hoja: {sheet}] {len(df)} filas × {len(df.columns)} columnas")
                parts.append(df.head(5).to_string())
            return '\n'.join(parts)
        except Exception as e:
            logger.debug(f"Excel error: {e}")
            return ""

    def _read_text(self, path: str) -> str:
        encodings = ['utf-8', 'latin-1', 'cp1252', 'iso-8859-1']
        for enc in encodings:
            try:
                with open(path, 'r', encoding=enc) as f:
                    return f.read()
            except (UnicodeDecodeError, LookupError):
                continue
        return ""

    def _read_json(self, path: str) -> str:
        try:
            with open(path, 'r', encoding='utf-8') as f:
                data = json.load(f)
            return f"JSON:\n{json.dumps(data, indent=2, ensure_ascii=False)[:3000]}"
        except Exception:
            return self._read_text(path)

    def _read_xml(self, path: str) -> str:
        try:
            import xml.etree.ElementTree as ET
            tree = ET.parse(path)
            root = tree.getroot()
            # Extraer texto de todos los nodos
            texts = []
            for elem in root.iter():
                if elem.text and elem.text.strip():
                    texts.append(f"{elem.tag}: {elem.text.strip()}")
            return '\n'.join(texts[:200])
        except Exception:
            return self._read_text(path)

    def _read_code(self, path: str) -> str:
        content = self._read_text(path)
        if content:
            ext = Path(path).suffix.lstrip('.')
            return f"```{ext}\n{content}\n```"
        return ""

    def _read_image(self, path: str) -> str:
        """Para imágenes, retornar descripción y metadata."""
        try:
            from PIL import Image
            img = Image.open(path)
            info = (f"Imagen: {img.format} | {img.size[0]}×{img.size[1]}px | "
                    f"Modo: {img.mode} | "
                    f"Tamaño: {os.path.getsize(path) // 1024}KB")
            return info
        except Exception:
            return f"Imagen: {os.path.basename(path)} ({os.path.getsize(path) // 1024}KB)"


class StyleLearner:
    """Aprende el estilo de escritura del usuario."""

    STYLE_FILE = os.path.join(os.path.dirname(os.path.dirname(__file__)),
                              'memory', 'user_style.json')

    def __init__(self):
        self.data = self._load()

    def _load(self) -> Dict:
        try:
            if os.path.exists(self.STYLE_FILE):
                with open(self.STYLE_FILE, 'r', encoding='utf-8') as f:
                    return json.load(f)
        except Exception:
            pass
        return {'samples': [], 'profile': {}}

    def _save(self):
        try:
            os.makedirs(os.path.dirname(self.STYLE_FILE), exist_ok=True)
            with open(self.STYLE_FILE, 'w', encoding='utf-8') as f:
                json.dump(self.data, f, ensure_ascii=False, indent=2)
        except Exception as e:
            logger.debug(f"Style save error: {e}")

    def learn(self, text: str, source: str = ""):
        """Analizar texto y aprender estilo."""
        if len(text) < 50:
            return

        sentences = re.split(r'[.!?]+', text)
        sentences = [s.strip() for s in sentences if len(s.strip()) > 5]

        if not sentences:
            return

        # Analizar características
        avg_len = sum(len(s.split()) for s in sentences) / len(sentences)
        formal_words = ['además', 'sin embargo', 'no obstante', 'asimismo', 'por ende',
                        'en consecuencia', 'cabe destacar', 'es importante', 'se puede observar']
        informal_words = ['bueno', 'o sea', 'es que', 'la verdad', 'tipo', 'vamos',
                          'digamos', 'básicamente', 'al final']

        formal_count = sum(1 for s in sentences for w in formal_words if w in s.lower())
        informal_count = sum(1 for s in sentences for w in informal_words if w in s.lower())

        total = formal_count + informal_count or 1
        formality = formal_count / total

        # Palabras más usadas (vocabulario propio)
        words = re.findall(r'\b[a-záéíóúñü]{4,}\b', text.lower())
        from collections import Counter
        common = [w for w, _ in Counter(words).most_common(20)
                  if w not in {'para', 'como', 'que', 'con', 'por', 'una', 'pero'}]

        # Guardar sample
        self.data['samples'].append({
            'source': source,
            'preview': text[:200],
            'length': len(text)
        })
        if len(self.data['samples']) > 10:
            self.data['samples'] = self.data['samples'][-10:]

        # Actualizar perfil
        self.data['profile'] = {
            'avg_sentence_len': round(avg_len, 1),
            'formality': round(formality, 2),
            'style': 'formal' if formality > 0.5 else 'informal' if formality < 0.2 else 'neutro',
            'common_words': common[:10],
            'sample_count': len(self.data['samples'])
        }
        self._save()

    def get_prompt(self) -> str:
        """Generar prompt de estilo para la IA."""
        p = self.data.get('profile', {})
        if not p:
            return ""

        style = p.get('style', 'neutro')
        avg_len = p.get('avg_sentence_len', 15)
        common = p.get('common_words', [])[:5]

        prompt = (f"Escribe imitando EXACTAMENTE el estilo del usuario:\n"
                  f"- Tono: {style}\n"
                  f"- Frases de ~{avg_len:.0f} palabras de media\n"
                  f"- Vocabulario frecuente: {', '.join(common) if common else 'variado'}\n"
                  f"- Debe parecer escrito por la misma persona, NO por una IA\n"
                  f"- No uses estructuras ni vocabulario que no aparezcan en las muestras\n")

        if self.data['samples']:
            last_sample = self.data['samples'][-1]['preview']
            prompt += f"\nMuestra de su escritura:\n\"{last_sample[:300]}\"\n"

        return prompt


class FileSkill:
    """Skill completo de análisis y gestión de archivos."""

    def __init__(self, brain=None):
        self.brain = brain
        self.reader = FileReader()
        self.style  = StyleLearner()

    def execute(self, action: str, params: Dict, text: str = "") -> str:
        actions = {
            'read':           self.read_file,
            'analyze_upload': self.analyze_upload,
            'improve':        self.improve_document,
            'learn_style':    self.learn_style,
            'write_like_me':  self.write_like_user,
            'list':           self.list_files,
        }
        fn = actions.get(action)
        if fn:
            return fn(params=params, text=text)
        return f"Acción de archivos no reconocida: {action}"

    def read_file(self, params: Dict = None, text: str = "") -> str:
        """Leer y mostrar contenido de un archivo."""
        params = params or {}
        path = params.get('path') or params.get('filepath')

        # Si no se especificó ruta, buscar archivo más reciente en uploads
        if not path:
            path = self._find_latest_upload()

        if not path:
            return ("No encontré ningún archivo. Opciones:\n"
                    "• Arrastre el archivo a la carpeta 'uploads' del sistema\n"
                    "• Diga: 'lee C:\\ruta\\al\\archivo.docx'\n"
                    "• Comparta el archivo y diga 'analiza esto'")

        if not os.path.exists(path):
            return f"No encontré el archivo: {path}"

        content, file_type = self.reader.read(path)
        if not content:
            return f"No pude leer '{os.path.basename(path)}'. ¿Está corrupto o protegido?"

        # Aprender estilo si es un documento de texto
        if file_type in ('docx', 'doc', 'txt', 'md', 'pdf'):
            self.style.learn(content, os.path.basename(path))

        name = os.path.basename(path)
        size = os.path.getsize(path) // 1024

        # Preview
        preview = content[:1000] + ("..." if len(content) > 1000 else "")

        response = (f"📄 **{name}** ({file_type.upper()}, {size}KB)\n\n"
                    f"{preview}")

        # Si hay IA disponible, añadir resumen automático
        if self.brain and self.brain.ai_manager and len(content) > 200:
            try:
                summary = self.brain.ai_manager.generate_with_file(
                    "Resume en 2-3 líneas de qué trata este documento.",
                    content, file_type)
                response += f"\n\n💡 **Resumen:** {summary}"
            except Exception:
                pass

        return response

    def analyze_upload(self, params: Dict = None, text: str = "") -> str:
        """Analizar archivo con IA."""
        params = params or {}
        path = params.get('path') or self._find_latest_upload()

        if not path or not os.path.exists(path):
            return "No encontré archivo para analizar. Suba un archivo primero."

        content, file_type = self.reader.read(path)
        if not content:
            return f"No pude leer el archivo."

        # Aprender estilo
        if file_type in ('docx', 'doc', 'txt', 'md'):
            self.style.learn(content, os.path.basename(path))

        if not self.brain or not self.brain.ai_manager:
            return (f"Archivo leído: {os.path.basename(path)} ({file_type})\n"
                    f"Contenido ({len(content)} chars): {content[:500]}...\n"
                    f"Para análisis profundo, active LM Studio.")

        task = text or "Analiza este archivo en detalle: puntos principales, estructura, calidad y sugerencias de mejora."
        result = self.brain.ai_manager.generate_with_file(task, content, file_type)
        return f"📊 **Análisis de {os.path.basename(path)}:**\n\n{result}"

    def improve_document(self, params: Dict = None, text: str = "") -> str:
        """Mejorar documento manteniendo el estilo del usuario."""
        params = params or {}
        path = params.get('path') or self._find_latest_upload()

        if not path or not os.path.exists(path):
            return "No encontré documento para mejorar. Suba el archivo primero."

        content, file_type = self.reader.read(path)
        if not content:
            return "No pude leer el documento."

        # Aprender estilo del documento original
        self.style.learn(content, os.path.basename(path))
        style_prompt = self.style.get_prompt()

        if not self.brain or not self.brain.ai_manager:
            return "Necesito IA conectada (LM Studio/Ollama/Mistral) para mejorar documentos."

        task = text or "Mejora la redacción y claridad"
        prompt = (f"Tarea: {task}\n\n"
                  f"{style_prompt}\n\n"
                  f"TEXTO ORIGINAL:\n{content[:3000]}\n\n"
                  f"TEXTO MEJORADO (debe parecer escrito por la misma persona, no IA):")

        improved = self.brain.ai_manager.generate(
            prompt, with_history=False, max_tokens=1000)

        # Guardar versión mejorada
        base = Path(path).stem
        out_path = os.path.join(WORKSPACE, f"{base}_mejorado.txt")
        os.makedirs(WORKSPACE, exist_ok=True)
        try:
            with open(out_path, 'w', encoding='utf-8') as f:
                f.write(improved)
        except Exception:
            pass

        preview = improved[:600]
        return (f"✅ Documento mejorado.\n\n"
                f"**Preview:**\n{preview}\n\n"
                f"Guardado en: {out_path}")

    def learn_style(self, params: Dict = None, text: str = "") -> str:
        """Aprender estilo de escritura del usuario."""
        params = params or {}
        path = params.get('path')
        sample = params.get('text', '') or text

        if path and os.path.exists(path):
            content, _ = self.reader.read(path)
            if content:
                sample = content

        if len(sample) < 30:
            return ("Dame un texto de muestra para analizar tu estilo. "
                    "Puedes decir: 'aprende mi estilo: [tu texto aquí]' "
                    "o compartir un documento.")

        self.style.learn(sample)
        p = self.style.data.get('profile', {})
        style = p.get('style', 'neutro')
        avg = p.get('avg_sentence_len', 0)
        common = p.get('common_words', [])[:5]

        return (f"✅ Estilo aprendido:\n"
                f"• Tono: {style}\n"
                f"• Frases: ~{avg:.0f} palabras de media\n"
                f"• Vocabulario frecuente: {', '.join(common) if common else 'variado'}\n"
                f"Cuando escriba por usted, imitará este estilo.")

    def write_like_user(self, params: Dict = None, text: str = "") -> str:
        """Escribir contenido imitando el estilo del usuario."""
        topic = (params or {}).get('topic', text) if params else text
        if not topic:
            return "¿Sobre qué quiere que escriba?"

        style_prompt = self.style.get_prompt()
        if not style_prompt:
            return ("No tengo muestras de su estilo. "
                    "Diga primero 'aprende mi estilo: [texto]' o comparta un documento.")

        if not self.brain or not self.brain.ai_manager:
            return "Necesito IA conectada para escribir contenido personalizado."

        prompt = f"{style_prompt}\n\nEscribe sobre: {topic}"
        result = self.brain.ai_manager.generate(prompt, with_history=False, max_tokens=800)
        return f"✍️ **Texto en tu estilo:**\n\n{result}"

    def list_files(self, params: Dict = None, text: str = "") -> str:
        """Listar archivos disponibles para análisis."""
        all_files = []
        for d in UPLOAD_DIRS:
            if os.path.exists(d):
                for f in os.listdir(d):
                    if not f.startswith('.'):
                        full = os.path.join(d, f)
                        size = os.path.getsize(full) // 1024
                        all_files.append(f"• {f} ({size}KB)")

        if all_files:
            return f"Archivos disponibles:\n" + '\n'.join(all_files)
        return ("No hay archivos en la carpeta de uploads. "
                f"Copie archivos a: {UPLOAD_DIRS[0]}")

    def _find_latest_upload(self) -> Optional[str]:
        """Encontrar el archivo más reciente en uploads."""
        supported = {'.docx', '.doc', '.pdf', '.txt', '.csv', '.xlsx', '.xls',
                     '.py', '.js', '.ts', '.json', '.xml', '.html', '.md',
                     '.jpg', '.jpeg', '.png', '.gif', '.bmp'}
        candidates = []
        for d in UPLOAD_DIRS:
            if os.path.exists(d):
                for f in os.listdir(d):
                    ext = Path(f).suffix.lower()
                    if ext in supported:
                        full = os.path.join(d, f)
                        candidates.append((os.path.getmtime(full), full))

        if candidates:
            candidates.sort(reverse=True)
            return candidates[0][1]
        return None
