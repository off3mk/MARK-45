# MARK 10 — Fully Autonomous Cognitive System
**Creator: Ali (Sidi3Ali)**
*Optimized for: i5-9600K + 16GB RAM + RX 5700 XT*

---

## Architecture

```
MARK 10
│
├── main.py                     Entry point (GUI or CLI)
│
├── core/                       Core cognitive modules
│   ├── brain.py                Central orchestrator (Mark10Brain)
│   ├── ai_manager.py           LM Studio AI (primary engine)
│   ├── memory.py               SQLite persistence
│   ├── user_identity.py        Creator detection + user profile
│   ├── context_awareness.py    Real-time context (app/activity)
│   ├── decision_engine.py      Rule-based autonomous decisions
│   ├── cognitive_loop.py       Main pipeline (2.5s cycle)
│   └── performance_manager.py  CPU/RAM optimization
│
├── perception/                 What MARK sees
│   ├── system_monitor.py       CPU/RAM/battery monitoring
│   ├── activity_monitor.py     User activity detection
│   └── screen_monitor.py       Screenshots + OCR (on-demand)
│
├── action/                     What MARK can do
│   ├── system_control.py       Open/close apps, set volume
│   ├── ui_control.py           Click, type, windows
│   ├── browser_control.py      Browser automation
│   └── code_executor.py        Python/PowerShell execution
│
├── voice/
│   ├── tts.py                  Natural Spanish TTS (edge-tts)
│   └── stt.py                  Voice input (optional)
│
├── skills/                     Extended capabilities
│   ├── spotify_skill.py
│   ├── system.py
│   └── generated/
│
├── memory/
│   └── mark10.db               SQLite database
│
└── config/
    └── config.json             System configuration
```

---

## AI Engine: LM Studio

MARK 10 uses **LM Studio** as its primary AI engine.

**Setup:**
1. Download: https://lmstudio.ai/download
2. Load any GGUF model — recommended for 16GB RAM:
   - `mistral-7b-instruct` (fast, efficient)
   - `llama-3.1-8b-instruct` (smarter, slightly slower)
   - `deepseek-coder-6.7b` (for coding tasks)
3. Go to **Server** tab → click **Start Server** (port 1234)

**MARK 10 connects to:** `http://127.0.0.1:1234/v1/chat/completions`

**Fallback chain:** LM Studio → Pollinations.ai (online) → Local rules

---

## Startup

```batch
install.bat        # First time — install all dependencies
start.bat          # Normal start (tries GUI, falls back to CLI)
start_cli.bat      # Force console mode
start.bat --debug  # Debug logging
```

---

## Commands

### System
```
"abre chrome"                   → Open Chrome
"cierra spotify"                → Close Spotify
"apps activas"                  → List running apps
"volumen 50"                    → Set volume 50%
"silencia"                      → Mute audio
"estado del sistema"            → CPU/RAM/disk info
```

### Browser
```
"navega a github.com"           → Browser navigation
"busca Python tutorial"         → Google search
"abre https://..."              → Open URL
```

### Screen
```
"captura pantalla"              → Save screenshot
"lee pantalla"                  → OCR current screen
"qué ves"                       → Describe screen
```

### Code
```
"ejecuta código print('hola')"  → Run Python
"cmd: dir"                      → CMD command
"powershell: Get-Process"       → PowerShell
```

### UI
```
"enfocar ventana VSCode"        → Focus window
"ventanas abiertas"             → List windows
"escribe Hola mundo"            → Type text
```

### Memory & Context
```
"contexto actual"               → Current activity
"limpia historial"              → Clear conversation
"estadísticas de memoria"       → Memory stats
```

### Status
```
"mark 10 status"                → Full system status
"estado lm studio"              → AI status
"cognitive loop"                → Cognitive pipeline status
"cómo estás"                    → Quick self-check
```

---

## Performance

| Metric        | Target     | Actual        |
|---------------|-----------|---------------|
| CPU idle      | < 5%       | ~2-3%        |
| RAM usage     | < 2GB      | ~400-800MB   |
| Loop interval | 2.5s       | 2.5s         |
| LM Studio     | Port 1234  | OpenAI API   |

---

## Creator Identity

```python
CREATOR_NAME  = "Ali"
CREATOR_ALIAS = "Sidi3Ali"
```

MARK 10 automatically detects Ali via Windows username.
Permanent watermark embedded in: `core/brain.py`, `core/user_identity.py`.

---

*MARK 10 — Fully Autonomous Cognitive System — Created by Ali (Sidi3Ali)*
