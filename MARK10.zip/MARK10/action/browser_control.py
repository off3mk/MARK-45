"""
MARK 10 — Browser Control
Open URLs, navigate, read page URL, browser automation.

Creator: Ali (Sidi3Ali)
System: MARK 10
"""

import logging
import subprocess
import time
from typing import Optional

logger = logging.getLogger('MARK10.BrowserControl')

BROWSERS = {
    'chrome': 'chrome',
    'firefox': 'firefox',
    'edge': 'msedge',
    'brave': 'brave',
    'default': 'start',
}


class BrowserControl:
    """Control web browsers: open URLs, navigate, read URL."""

    def __init__(self, ui_control=None):
        self._ui = ui_control
        self._uia_ok = False
        try:
            import uiautomation
            self._uia_ok = True
        except ImportError:
            pass

    def open_url(self, url: str, browser: str = 'default') -> str:
        """Open URL in specified or default browser."""
        if not url.startswith(('http://', 'https://')):
            url = 'https://' + url
        exe = BROWSERS.get(browser.lower(), 'start')
        try:
            if exe == 'start':
                subprocess.Popen(['start', url], shell=True)
            else:
                subprocess.Popen([exe, url], shell=True)
            return f"Abriendo: {url}"
        except Exception as e:
            return f"Error abriendo URL: {e}"

    def navigate(self, url: str) -> str:
        """Navigate active browser to URL using Ctrl+L."""
        if not url.startswith(('http://', 'https://')):
            url = 'https://' + url
        if not self._ui:
            return self.open_url(url)
        for browser_title in ('Chrome', 'Firefox', 'Edge', 'Opera', 'Brave'):
            result = self._ui.focus_window(browser_title)
            if 'no encontrada' not in result:
                time.sleep(0.2)
                self._ui.hotkey('ctrl', 'l')
                time.sleep(0.15)
                self._ui.type_text(url, use_clipboard=True)
                self._ui.key_press('enter')
                return f"Navegando a: {url}"
        return self.open_url(url)

    def get_current_url(self) -> str:
        """Get URL from active browser using UIA."""
        if not self._uia_ok:
            return ''
        try:
            import uiautomation as auto
            for browser in ('Chrome', 'Firefox', 'Microsoft Edge', 'Opera'):
                win = auto.WindowControl(searchDepth=1, SubName=browser)
                if win.Exists(1, 0):
                    edit = win.EditControl(searchDepth=10)
                    if edit.Exists(1, 0):
                        pattern = edit.GetValuePattern()
                        if pattern:
                            return pattern.Value or ''
        except Exception as e:
            logger.debug(f"get_current_url error: {e}")
        return ''

    def search(self, query: str, engine: str = 'google') -> str:
        """Open browser with search query."""
        engines = {
            'google': f'https://www.google.com/search?q={query.replace(" ", "+")}',
            'bing': f'https://www.bing.com/search?q={query.replace(" ", "+")}',
            'ddg': f'https://duckduckgo.com/?q={query.replace(" ", "+")}',
        }
        url = engines.get(engine.lower(), engines['google'])
        return self.open_url(url)

    def new_tab(self) -> str:
        if self._ui:
            return self._ui.new_tab()
        return "UI control no disponible."

    def close_tab(self) -> str:
        if self._ui:
            return self._ui.close_tab()
        return "UI control no disponible."

    def back(self) -> str:
        if self._ui:
            return self._ui.hotkey('alt', 'left')
        return "UI control no disponible."

    def forward(self) -> str:
        if self._ui:
            return self._ui.hotkey('alt', 'right')
        return "UI control no disponible."

    def refresh(self) -> str:
        if self._ui:
            return self._ui.key_press('f5')
        return "UI control no disponible."
