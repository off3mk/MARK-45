"""
MARK 10 — System Control
Open apps, set volume, manage processes, system commands.

Creator: Ali (Sidi3Ali)
System: MARK 10
"""

import logging
import subprocess
import os
import time
from typing import Optional, List, Dict

logger = logging.getLogger('MARK10.SystemControl')


class SystemControl:
    """Control Windows system: launch apps, set volume, manage processes."""

    # Common app aliases → executable
    APP_ALIASES = {
        'chrome': 'chrome', 'google chrome': 'chrome',
        'firefox': 'firefox',
        'edge': 'msedge', 'microsoft edge': 'msedge',
        'code': 'code', 'vscode': 'code', 'visual studio code': 'code',
        'notepad': 'notepad',
        'notepad++': r'C:\Program Files\Notepad++\notepad++.exe',
        'explorer': 'explorer', 'archivos': 'explorer', 'files': 'explorer',
        'word': r'C:\Program Files\Microsoft Office\root\Office16\WINWORD.EXE',
        'excel': r'C:\Program Files\Microsoft Office\root\Office16\EXCEL.EXE',
        'powerpoint': r'C:\Program Files\Microsoft Office\root\Office16\POWERPNT.EXE',
        'spotify': 'spotify',
        'steam': 'steam',
        'discord': 'discord',
        'terminal': 'wt', 'windows terminal': 'wt',
        'cmd': 'cmd', 'powershell': 'powershell',
        'calculadora': 'calc', 'calculator': 'calc',
        'paint': 'mspaint',
        'vlc': 'vlc',
        'obs': 'obs64', 'obs studio': 'obs64',
        'task manager': 'taskmgr', 'taskmgr': 'taskmgr',
    }

    def open_app(self, app_name: str) -> str:
        """Open an application by name."""
        name = app_name.strip().lower()
        executable = self.APP_ALIASES.get(name, name)
        try:
            subprocess.Popen([executable], shell=True,
                             stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
            time.sleep(0.5)
            return f"'{app_name}' abierto."
        except Exception as e:
            return f"Error abriendo '{app_name}': {e}"

    def close_app(self, app_name: str) -> str:
        """Close application by name using taskkill."""
        name = app_name.strip().lower().replace(' ', '_')
        # Try direct process name
        exe_map = {
            'chrome': 'chrome.exe', 'firefox': 'firefox.exe',
            'spotify': 'spotify.exe', 'discord': 'discord.exe',
            'edge': 'msedge.exe', 'code': 'code.exe', 'vscode': 'code.exe',
            'word': 'WINWORD.EXE', 'excel': 'EXCEL.EXE',
            'steam': 'steam.exe', 'vlc': 'vlc.exe',
        }
        exe = exe_map.get(name, f"{name}.exe")
        try:
            result = subprocess.run(
                ['taskkill', '/F', '/IM', exe],
                capture_output=True, text=True
            )
            if result.returncode == 0:
                return f"'{app_name}' cerrado."
            return f"No se encontró proceso '{exe}'."
        except Exception as e:
            return f"Error cerrando '{app_name}': {e}"

    def set_volume(self, level: int) -> str:
        """Set system volume 0-100."""
        level = max(0, min(100, level))
        try:
            from ctypes import cast, POINTER
            from comtypes import CLSCTX_ALL
            from pycaw.pycaw import AudioUtilities, IAudioEndpointVolume
            devices = AudioUtilities.GetSpeakers()
            interface = devices.Activate(IAudioEndpointVolume._iid_, CLSCTX_ALL, None)
            volume = cast(interface, POINTER(IAudioEndpointVolume))
            volume.SetMasterVolumeLevelScalar(level / 100.0, None)
            return f"Volumen al {level}%."
        except ImportError:
            # Fallback via nircmd
            try:
                subprocess.run(['nircmd', 'setsysvolume', str(int(level * 655.35))],
                               capture_output=True)
                return f"Volumen al {level}%."
            except Exception:
                return f"Volumen: no se pudo ajustar (instala pycaw o nircmd)."
        except Exception as e:
            return f"Error ajustando volumen: {e}"

    def mute(self) -> str:
        """Mute system audio."""
        try:
            from ctypes import cast, POINTER
            from comtypes import CLSCTX_ALL
            from pycaw.pycaw import AudioUtilities, IAudioEndpointVolume
            devices = AudioUtilities.GetSpeakers()
            interface = devices.Activate(IAudioEndpointVolume._iid_, CLSCTX_ALL, None)
            volume = cast(interface, POINTER(IAudioEndpointVolume))
            volume.SetMute(1, None)
            return "Audio silenciado."
        except Exception:
            return "No se pudo silenciar (pycaw no disponible)."

    def unmute(self) -> str:
        """Unmute system audio."""
        try:
            from ctypes import cast, POINTER
            from comtypes import CLSCTX_ALL
            from pycaw.pycaw import AudioUtilities, IAudioEndpointVolume
            devices = AudioUtilities.GetSpeakers()
            interface = devices.Activate(IAudioEndpointVolume._iid_, CLSCTX_ALL, None)
            volume = cast(interface, POINTER(IAudioEndpointVolume))
            volume.SetMute(0, None)
            return "Audio activado."
        except Exception:
            return "No se pudo activar audio (pycaw no disponible)."

    def get_running_apps(self) -> List[str]:
        """Get list of running user applications."""
        try:
            import psutil
            ignore = {'system','idle','svchost','dwm','winlogon','csrss',
                      'lsass','smss','wininit','services','spoolsv',
                      'taskhostw','sihost','explorer','ctfmon','runtimebroker'}
            apps = set()
            for p in psutil.process_iter(['name']):
                name = p.info['name'].lower().replace('.exe','').strip()
                if name not in ignore and len(name) > 2:
                    apps.add(name)
            return sorted(apps)[:20]
        except Exception:
            return []

    def list_apps(self) -> str:
        apps = self.get_running_apps()
        if not apps:
            return "No se pudieron listar apps."
        return "Apps activas: " + ", ".join(apps[:12])

    def kill_process(self, process_name: str) -> str:
        """Force kill process by name."""
        try:
            import psutil
            killed = []
            for p in psutil.process_iter(['name']):
                if process_name.lower() in p.info['name'].lower():
                    p.kill()
                    killed.append(p.info['name'])
            return (f"Procesos eliminados: {', '.join(killed)}" if killed
                    else f"Proceso '{process_name}' no encontrado.")
        except Exception as e:
            return f"Error: {e}"

    def run_command(self, command: str, shell: bool = True) -> Dict:
        """Run system command and return output."""
        try:
            result = subprocess.run(
                command,
                shell=shell,
                capture_output=True,
                text=True,
                timeout=30,
            )
            return {
                'success': result.returncode == 0,
                'stdout': result.stdout.strip()[:1000],
                'stderr': result.stderr.strip()[:500],
                'returncode': result.returncode,
            }
        except subprocess.TimeoutExpired:
            return {'success': False, 'stdout': '', 'stderr': 'Timeout', 'returncode': -1}
        except Exception as e:
            return {'success': False, 'stdout': '', 'stderr': str(e), 'returncode': -1}

    def get_system_info(self) -> str:
        """Get formatted system info summary."""
        try:
            import psutil
            cpu = psutil.cpu_percent(0.2)
            ram = psutil.virtual_memory()
            disk = psutil.disk_usage('/')
            bat_str = ''
            try:
                bat = psutil.sensors_battery()
                if bat:
                    charge = 'cargando' if bat.power_plugged else f'{bat.percent:.0f}%'
                    bat_str = f" | Bateria: {charge}"
            except Exception:
                pass
            return (f"CPU: {cpu:.0f}% | "
                    f"RAM: {ram.used // (1024**3):.1f}/{ram.total // (1024**3):.0f}GB "
                    f"({ram.percent:.0f}%) | "
                    f"Disco: {disk.free // (1024**3):.0f}GB libre{bat_str}")
        except Exception as e:
            return f"Error obteniendo info: {e}"
