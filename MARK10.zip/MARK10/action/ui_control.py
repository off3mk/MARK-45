"""
MARK 10 — UI Control
Click, type, scroll, hotkeys, window management.

Creator: Ali (Sidi3Ali)
System: MARK 10
"""

import logging
import time
from typing import Optional, Tuple, List

logger = logging.getLogger('MARK10.UIControl')


class UIControl:
    """Full Windows UI control using pyautogui + win32api."""

    def __init__(self):
        self._pag_ok = False
        self._win32_ok = False
        try:
            import pyautogui
            pyautogui.FAILSAFE = False
            pyautogui.PAUSE = 0.05
            self._pag_ok = True
        except ImportError:
            pass
        try:
            import win32gui
            self._win32_ok = True
        except ImportError:
            pass

    # ── Mouse ─────────────────────────────────────────────────────────────────
    def click(self, x: int, y: int, double: bool = False, button: str = 'left') -> str:
        if not self._pag_ok:
            return "pyautogui no disponible."
        try:
            import pyautogui
            pyautogui.moveTo(x, y, duration=0.12)
            if double:
                pyautogui.doubleClick(x, y, button=button)
            else:
                pyautogui.click(x, y, button=button)
            return f"Click en ({x}, {y})."
        except Exception as e:
            return f"Error click: {e}"

    def right_click(self, x: int, y: int) -> str:
        return self.click(x, y, button='right')

    def drag(self, x1: int, y1: int, x2: int, y2: int) -> str:
        if not self._pag_ok:
            return "pyautogui no disponible."
        try:
            import pyautogui
            pyautogui.drag(x2 - x1, y2 - y1, duration=0.3, button='left')
            return f"Arrastre ({x1},{y1}) → ({x2},{y2})."
        except Exception as e:
            return f"Error arrastre: {e}"

    def scroll(self, amount: int = 3, direction: str = 'down') -> str:
        if not self._pag_ok:
            return "pyautogui no disponible."
        try:
            import pyautogui
            clicks = -amount if direction == 'down' else amount
            pyautogui.scroll(clicks)
            return f"Scroll {direction} {amount}."
        except Exception as e:
            return f"Error scroll: {e}"

    def get_position(self) -> Tuple[int, int]:
        try:
            import pyautogui
            return pyautogui.position()
        except Exception:
            return (0, 0)

    # ── Keyboard ──────────────────────────────────────────────────────────────
    def type_text(self, text: str, use_clipboard: bool = True) -> str:
        """Type text. Uses clipboard for non-ASCII characters."""
        if not self._pag_ok:
            return "pyautogui no disponible."
        try:
            if use_clipboard:
                import pyperclip
                pyperclip.copy(text)
                time.sleep(0.1)
                self.hotkey('ctrl', 'v')
            else:
                import pyautogui
                pyautogui.typewrite(text, interval=0.03)
            return f"Texto escrito: '{text[:50]}'"
        except Exception as e:
            return f"Error escribiendo: {e}"

    def hotkey(self, *keys: str) -> str:
        if not self._pag_ok:
            return "pyautogui no disponible."
        try:
            import pyautogui
            pyautogui.hotkey(*keys)
            return f"Atajo: {'+'.join(keys)}"
        except Exception as e:
            return f"Error atajo: {e}"

    def key_press(self, key: str) -> str:
        if not self._pag_ok:
            return "pyautogui no disponible."
        try:
            import pyautogui
            pyautogui.press(key)
            return f"Tecla: {key}"
        except Exception as e:
            return f"Error tecla: {e}"

    def key_down(self, key: str):
        try:
            import pyautogui
            pyautogui.keyDown(key)
        except Exception: pass

    def key_up(self, key: str):
        try:
            import pyautogui
            pyautogui.keyUp(key)
        except Exception: pass

    # ── Window management ─────────────────────────────────────────────────────
    def find_window(self, title_contains: str) -> Optional[int]:
        if not self._win32_ok:
            return None
        try:
            import win32gui
            result = []
            def cb(hwnd, _):
                if title_contains.lower() in win32gui.GetWindowText(hwnd).lower():
                    result.append(hwnd)
            win32gui.EnumWindows(cb, None)
            return result[0] if result else None
        except Exception:
            return None

    def focus_window(self, title: str) -> str:
        hwnd = self.find_window(title)
        if not hwnd:
            return f"Ventana '{title}' no encontrada."
        try:
            import win32gui, win32con
            if win32gui.IsIconic(hwnd):
                win32gui.ShowWindow(hwnd, win32con.SW_RESTORE)
            win32gui.SetForegroundWindow(hwnd)
            time.sleep(0.25)
            return f"Ventana '{title}' activada."
        except Exception as e:
            return f"Error activando ventana: {e}"

    def close_window(self, title: str) -> str:
        hwnd = self.find_window(title)
        if not hwnd:
            return f"Ventana '{title}' no encontrada."
        try:
            import win32gui, win32con
            win32gui.PostMessage(hwnd, win32con.WM_CLOSE, 0, 0)
            return f"Ventana '{title}' cerrada."
        except Exception as e:
            return f"Error cerrando: {e}"

    def maximize_window(self, title: str) -> str:
        hwnd = self.find_window(title)
        if not hwnd:
            return f"Ventana '{title}' no encontrada."
        try:
            import win32gui, win32con
            win32gui.ShowWindow(hwnd, win32con.SW_MAXIMIZE)
            return f"'{title}' maximizada."
        except Exception as e:
            return f"Error: {e}"

    def minimize_window(self, title: str) -> str:
        hwnd = self.find_window(title)
        if not hwnd:
            return f"Ventana '{title}' no encontrada."
        try:
            import win32gui, win32con
            win32gui.ShowWindow(hwnd, win32con.SW_MINIMIZE)
            return f"'{title}' minimizada."
        except Exception as e:
            return f"Error: {e}"

    def move_window(self, title: str, x: int, y: int, w: int, h: int) -> str:
        hwnd = self.find_window(title)
        if not hwnd:
            return f"Ventana '{title}' no encontrada."
        try:
            import win32gui, win32con
            win32gui.SetWindowPos(hwnd, win32con.HWND_TOP, x, y, w, h, 0)
            return f"Ventana '{title}' movida a ({x},{y}) tamaño {w}x{h}."
        except Exception as e:
            return f"Error: {e}"

    def list_windows(self) -> List[str]:
        if not self._win32_ok:
            return []
        try:
            import win32gui
            windows = []
            def cb(hwnd, _):
                if win32gui.IsWindowVisible(hwnd):
                    title = win32gui.GetWindowText(hwnd)
                    if title and len(title) > 2:
                        windows.append(title)
            win32gui.EnumWindows(cb, None)
            return windows[:20]
        except Exception:
            return []

    # ── Clipboard ─────────────────────────────────────────────────────────────
    def get_clipboard(self) -> str:
        try:
            import pyperclip
            return pyperclip.paste() or ''
        except Exception:
            return ''

    def set_clipboard(self, text: str):
        try:
            import pyperclip
            pyperclip.copy(text)
        except Exception:
            pass

    # ── Common shortcuts ──────────────────────────────────────────────────────
    def select_all(self) -> str:  return self.hotkey('ctrl', 'a')
    def copy(self) -> str:        return self.hotkey('ctrl', 'c')
    def paste(self) -> str:       return self.hotkey('ctrl', 'v')
    def undo(self) -> str:        return self.hotkey('ctrl', 'z')
    def save(self) -> str:        return self.hotkey('ctrl', 's')
    def find(self) -> str:        return self.hotkey('ctrl', 'f')
    def new_tab(self) -> str:     return self.hotkey('ctrl', 't')
    def close_tab(self) -> str:   return self.hotkey('ctrl', 'w')

    def get_status(self) -> dict:
        return {
            'pyautogui': self._pag_ok,
            'win32': self._win32_ok,
        }
