"""
JARVIS v4.0 - Command Executor
Ejecución robusta de comandos con timeouts y retry.
"""

import logging
import threading
import time
import functools
from typing import Any, Callable, Optional, Dict

logger = logging.getLogger('JARVIS.Executor')


class ExecutionResult:
    """Resultado de ejecución de comando."""
    def __init__(self, success: bool, result: Any = None, error: str = None, elapsed: float = 0):
        self.success = success
        self.result = result
        self.error = error
        self.elapsed = elapsed


def timeout_exec(timeout_sec: float):
    """Decorador para ejecutar función con timeout."""
    def decorator(func):
        @functools.wraps(func)
        def wrapper(*args, **kwargs):
            result = [None]
            error = [None]

            def target():
                try:
                    result[0] = func(*args, **kwargs)
                except Exception as e:
                    error[0] = str(e)

            t = threading.Thread(target=target, daemon=True)
            t.start()
            t.join(timeout_sec)

            if t.is_alive():
                return None, f"Timeout después de {timeout_sec}s"
            return result[0], error[0]
        return wrapper
    return decorator


class CommandExecutor:
    """Ejecutor de comandos con manejo robusto de errores."""

    def __init__(self, brain):
        self.brain = brain
        self._pre_hooks: list = []
        self._post_hooks: list = []
        self._history: list = []
        self._max_history = 50

    def execute(self, func: Callable, *args, timeout: float = 30.0,
                max_retries: int = 1, **kwargs) -> ExecutionResult:
        """Ejecutar función con timeout y retry automático."""
        start_time = time.time()
        last_error = None

        for attempt in range(max_retries + 1):
            try:
                # Pre-hooks
                for hook in self._pre_hooks:
                    try:
                        hook(func, args, kwargs)
                    except Exception:
                        pass

                # Ejecutar con timeout
                result = [None]
                error = [None]
                done = threading.Event()

                def target():
                    try:
                        result[0] = func(*args, **kwargs)
                    except Exception as e:
                        error[0] = str(e)
                    finally:
                        done.set()

                t = threading.Thread(target=target, daemon=True)
                t.start()
                completed = done.wait(timeout)

                elapsed = time.time() - start_time

                if not completed:
                    last_error = f"Timeout ({timeout}s)"
                    logger.warning(f"Timeout ejecutando {func.__name__}")
                    continue

                if error[0]:
                    last_error = error[0]
                    if attempt < max_retries:
                        logger.warning(f"Error en intento {attempt+1}: {error[0]}. Reintentando...")
                        time.sleep(0.5 * (attempt + 1))
                        continue
                    break

                exec_result = ExecutionResult(
                    success=True, result=result[0], elapsed=elapsed
                )

                # Post-hooks
                for hook in self._post_hooks:
                    try:
                        hook(exec_result)
                    except Exception:
                        pass

                self._log_execution(func.__name__, exec_result)
                return exec_result

            except Exception as e:
                last_error = str(e)
                logger.error(f"Error inesperado en executor: {e}")
                break

        elapsed = time.time() - start_time
        result = ExecutionResult(success=False, error=last_error, elapsed=elapsed)
        self._log_execution(func.__name__, result)
        return result

    def execute_shell(self, command: str, timeout: float = 30.0) -> ExecutionResult:
        """Ejecutar comando de shell."""
        import subprocess
        start = time.time()
        try:
            proc = subprocess.run(
                command,
                shell=True,
                capture_output=True,
                text=True,
                timeout=timeout
            )
            elapsed = time.time() - start
            output = proc.stdout.strip() or proc.stderr.strip()
            success = proc.returncode == 0
            return ExecutionResult(
                success=success,
                result=output if success else None,
                error=proc.stderr.strip() if not success else None,
                elapsed=elapsed
            )
        except subprocess.TimeoutExpired:
            return ExecutionResult(success=False, error=f"Timeout ({timeout}s)", elapsed=timeout)
        except Exception as e:
            return ExecutionResult(success=False, error=str(e), elapsed=time.time() - start)

    def _log_execution(self, name: str, result: ExecutionResult):
        """Guardar historial de ejecución."""
        entry = {
            'name': name,
            'success': result.success,
            'elapsed': result.elapsed,
            'timestamp': time.time()
        }
        self._history.append(entry)
        if len(self._history) > self._max_history:
            self._history.pop(0)

    def add_pre_hook(self, hook: Callable):
        """Añadir hook previo a ejecución."""
        self._pre_hooks.append(hook)

    def add_post_hook(self, hook: Callable):
        """Añadir hook posterior a ejecución."""
        self._post_hooks.append(hook)

    def get_history(self) -> list:
        """Obtener historial de ejecuciones."""
        return list(self._history)
