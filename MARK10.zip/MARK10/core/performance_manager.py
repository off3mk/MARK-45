"""
MARK 10 — Performance Manager
CPU/RAM optimization for i5-9600K + 16GB.
Target: < 5% CPU idle, < 2GB RAM.

Creator: Ali (Sidi3Ali)
System: MARK 10
"""

import logging
import threading
import time
import os
from typing import Dict, Optional

logger = logging.getLogger('MARK10.Performance')

CPU_IDLE_MAX = 5.0     # Max % CPU when idle
RAM_MAX_GB   = 2.0     # Max RAM usage in GB
POLL_INTERVAL = 10.0   # Check every 10 seconds


class PerformanceManager:
    """
    Monitors and manages MARK 10 resource usage.
    Suspends non-critical modules when system is under load.
    """

    def __init__(self, config: Dict = None):
        cfg = config or {}
        perf = cfg.get('performance', cfg)
        self._cpu_max = perf.get('cpu_idle_max_percent', CPU_IDLE_MAX)
        self._ram_max_gb = perf.get('ram_max_gb', RAM_MAX_GB)
        self._running = False
        self._thread: Optional[threading.Thread] = None
        self._throttled = False
        self._lock = threading.Lock()
        self._warnings = 0

    def start(self):
        self._running = True
        self._thread = threading.Thread(
            target=self._loop,
            name='MARK10-PerfManager',
            daemon=True
        )
        self._thread.start()

    def stop(self):
        self._running = False

    def _loop(self):
        while self._running:
            try:
                self._check()
            except Exception as e:
                logger.debug(f"Perf check error: {e}")
            time.sleep(POLL_INTERVAL)

    def _check(self):
        try:
            import psutil
            cpu = psutil.cpu_percent(interval=None)
            ram_gb = psutil.virtual_memory().used / 1024**3

            was_throttled = self._throttled

            if cpu > 85 or ram_gb > self._ram_max_gb * 1.5:
                with self._lock:
                    self._throttled = True
                if not was_throttled:
                    logger.warning(f"MARK10 en throttle: CPU {cpu:.0f}% RAM {ram_gb:.1f}GB")
                    self._warnings += 1
            elif cpu < 60 and ram_gb < self._ram_max_gb:
                with self._lock:
                    self._throttled = False
        except ImportError:
            pass

    def is_throttled(self) -> bool:
        with self._lock:
            return self._throttled

    def get_recommended_sleep(self, base_sleep: float) -> float:
        """Return adjusted sleep time based on load."""
        if self.is_throttled():
            return base_sleep * 2.0  # Double intervals when throttled
        return base_sleep

    def get_status(self) -> Dict:
        try:
            import psutil
            cpu = psutil.cpu_percent(interval=None)
            ram = psutil.virtual_memory()
            return {
                'cpu': cpu,
                'ram_gb': round(ram.used / 1024**3, 2),
                'ram_total_gb': round(ram.total / 1024**3, 1),
                'throttled': self._throttled,
                'warnings': self._warnings,
            }
        except Exception:
            return {'throttled': self._throttled, 'warnings': self._warnings}

    def optimize_threads(self):
        """Suggest thread pool size based on CPU cores."""
        try:
            import psutil
            cores = psutil.cpu_count(logical=False) or 4
            return max(2, min(cores - 1, 6))
        except Exception:
            return 4
