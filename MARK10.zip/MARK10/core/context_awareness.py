"""
MARK 10 — Context Awareness
Real-time context: active window, app, activity, writing/coding/browsing detection.
Updates every 3 seconds. CPU overhead: minimal.

Creator: Ali (Sidi3Ali)
System: MARK 10
"""

import logging
import threading
import time
from typing import Optional, Dict, List, Callable
from dataclasses import dataclass, field
from datetime import datetime

logger = logging.getLogger('MARK10.Context')

UPDATE_INTERVAL = 3.0  # seconds


@dataclass
class CurrentContext:
    """Complete real-time context snapshot."""
    timestamp: float = field(default_factory=time.time)

    # Window / App
    active_window: str = ''
    active_app: str = ''
    active_document: str = ''

    # Activity
    user_activity: str = 'idle'
    detected_mode: str = 'unknown'
    time_of_day: str = ''

    # Boolean flags — easy to check in code
    is_coding: bool = False
    is_writing: bool = False
    is_browsing: bool = False
    is_watching: bool = False
    is_gaming: bool = False
    is_in_word: bool = False
    is_in_spotify: bool = False
    is_in_discord: bool = False
    is_in_vscode: bool = False
    is_in_browser: bool = False

    # Resources
    cpu: float = 0.0
    ram_percent: float = 0.0

    # Change detection
    changed: bool = False
    activity_duration_min: float = 0.0

    def describe(self) -> str:
        parts = []
        if self.active_app:
            parts.append(f"app={self.active_app}")
        if self.user_activity not in ('idle',):
            parts.append(f"actividad={self.user_activity}")
        if self.detected_mode not in ('unknown',):
            parts.append(f"modo={self.detected_mode}")
        return ' | '.join(parts) or 'sin contexto'

    def to_dict(self) -> Dict:
        return {
            'active_window': self.active_window,
            'active_app': self.active_app,
            'active_document': self.active_document,
            'user_activity': self.user_activity,
            'detected_mode': self.detected_mode,
            'time_of_day': self.time_of_day,
            'is_coding': self.is_coding,
            'is_writing': self.is_writing,
            'is_browsing': self.is_browsing,
            'is_in_word': self.is_in_word,
            'is_in_spotify': self.is_in_spotify,
            'cpu': self.cpu,
            'ram_percent': self.ram_percent,
            'activity_duration_minutes': round(self.activity_duration_min, 1),
        }


# Activity classification
CODING_APPS    = {'code','vscode','pycharm','intellij','cursor','sublime','vim','nvim','atom'}
WRITING_APPS   = {'word','winword','notion','obsidian','typora','libreoffice','soffice','onenote','wordpad'}
GAMING_APPS    = {'steam','epicgames','origin','battlenet','gog','gamepass'}
COMM_APPS      = {'teams','slack','discord','zoom','telegram','whatsapp','skype','signal'}
WATCHING_APPS  = {'vlc','mpv','mpc-hc','potplayer','plex','davinciresolveeditor'}
DESIGN_APPS    = {'figma','photoshop','illustrator','gimp','blender','canva','inkscape','affinity'}
BROWSER_APPS   = {'chrome','firefox','msedge','edge','opera','brave','vivaldi'}
MUSIC_APPS     = {'spotify', 'foobar2000', 'musicbee', 'aimp', 'itunes'}


class ContextAwarenessSystem:
    """
    Lightweight context awareness.
    Reads active window/process every 3s.
    No GPU or heavy processing.
    """

    def __init__(self, brain=None, interval: float = UPDATE_INTERVAL):
        self._brain = brain
        self._interval = interval
        self._running = False
        self._thread: Optional[threading.Thread] = None
        self._ctx: Optional[CurrentContext] = None
        self._lock = threading.Lock()
        self._callbacks: List[Callable] = []
        self._activity_start: Dict[str, float] = {}

        # Platform detection
        self._win32_ok = False
        self._win32proc_ok = False
        try:
            import win32gui; self._win32_ok = True
        except ImportError: pass
        try:
            import win32process; self._win32proc_ok = True
        except ImportError: pass

        # Initial context
        self._ctx = self._build()

    def start(self):
        self._running = True
        self._thread = threading.Thread(
            target=self._loop,
            name='MARK10-ContextAwareness',
            daemon=True
        )
        self._thread.start()

    def stop(self):
        self._running = False

    def add_callback(self, cb: Callable):
        """Called when context changes."""
        self._callbacks.append(cb)

    def _get_active_window(self) -> str:
        if self._win32_ok:
            try:
                import win32gui
                return win32gui.GetWindowText(win32gui.GetForegroundWindow()) or ''
            except Exception: pass
        return ''

    def _get_active_app(self) -> str:
        if self._win32_ok and self._win32proc_ok:
            try:
                import win32gui, win32process, psutil
                hwnd = win32gui.GetForegroundWindow()
                _, pid = win32process.GetWindowThreadProcessId(hwnd)
                return psutil.Process(pid).name().lower().replace('.exe', '')
            except Exception: pass
        try:
            import psutil
            ignore = {'system','idle','svchost','dwm','winlogon','csrss','lsass','explorer'}
            for p in psutil.process_iter(['name','status']):
                if p.info.get('status') == 'running':
                    n = p.info['name'].lower().replace('.exe','')
                    if n not in ignore and len(n) > 2:
                        return n
        except Exception: pass
        return ''

    def _classify_activity(self, app: str, window: str) -> str:
        a = app.lower()
        w = window.lower()
        for x in CODING_APPS:
            if x in a: return 'coding'
        for x in WRITING_APPS:
            if x in a: return 'writing'
        for x in WATCHING_APPS:
            if x in a: return 'watching'
        for x in GAMING_APPS:
            if x in a: return 'gaming'
        for x in COMM_APPS:
            if x in a: return 'communication'
        for x in DESIGN_APPS:
            if x in a: return 'designing'
        for x in MUSIC_APPS:
            if x in a: return 'music'
        if any(b in a for b in BROWSER_APPS):
            for k in ('youtube','twitch','netflix','disneyplus','primevideo'):
                if k in w: return 'watching'
            for k in ('github','stackoverflow','docs.','localhost'):
                if k in w: return 'coding'
            for k in ('gmail','outlook.com','mail.'):
                if k in w: return 'communication'
            return 'browsing'
        return 'idle'

    def _mode_from_activity(self, activity: str) -> str:
        return {
            'coding': 'work', 'writing': 'work', 'designing': 'creative',
            'browsing': 'study', 'watching': 'leisure', 'gaming': 'leisure',
            'communication': 'communication', 'music': 'leisure',
        }.get(activity, 'unknown')

    def _get_resources(self):
        try:
            import psutil
            return psutil.cpu_percent(interval=None), psutil.virtual_memory().percent
        except Exception:
            return 0.0, 0.0

    def _build(self) -> CurrentContext:
        ctx = CurrentContext()
        ctx.active_window = self._get_active_window()
        ctx.active_app = self._get_active_app()

        for sep in (' - ', ' — ', ' | '):
            if sep in ctx.active_window:
                ctx.active_document = ctx.active_window.split(sep)[0].strip()
                break

        ctx.user_activity = self._classify_activity(ctx.active_app, ctx.active_window)
        ctx.detected_mode = self._mode_from_activity(ctx.user_activity)

        hour = datetime.now().hour
        ctx.time_of_day = ('morning' if 5 <= hour < 12 else
                            'afternoon' if 12 <= hour < 17 else
                            'evening' if 17 <= hour < 21 else 'night')

        cpu, ram = self._get_resources()
        ctx.cpu = cpu
        ctx.ram_percent = ram

        # Boolean flags
        a = ctx.active_app.lower()
        ctx.is_coding     = ctx.user_activity == 'coding'
        ctx.is_writing    = ctx.user_activity == 'writing'
        ctx.is_browsing   = ctx.user_activity == 'browsing'
        ctx.is_watching   = ctx.user_activity == 'watching'
        ctx.is_gaming     = ctx.user_activity == 'gaming'
        ctx.is_in_word    = any(x in a for x in ('word','winword'))
        ctx.is_in_spotify = 'spotify' in a
        ctx.is_in_discord = 'discord' in a
        ctx.is_in_vscode  = any(x in a for x in ('code','vscode'))
        ctx.is_in_browser = any(x in a for x in BROWSER_APPS)

        # Activity duration
        now = time.time()
        act = ctx.user_activity
        if act not in self._activity_start:
            self._activity_start = {act: now}
        ctx.activity_duration_min = (now - self._activity_start.get(act, now)) / 60.0

        return ctx

    def _loop(self):
        while self._running:
            try:
                new_ctx = self._build()
                prev = self._ctx
                changed = (prev is None or
                           new_ctx.active_app != prev.active_app or
                           new_ctx.user_activity != prev.user_activity)
                new_ctx.changed = changed
                with self._lock:
                    self._ctx = new_ctx
                if changed and prev:
                    for cb in self._callbacks:
                        try: cb(new_ctx)
                        except Exception: pass
            except Exception as e:
                logger.debug(f"Context loop error: {e}")
            time.sleep(self._interval)

    def get_context(self) -> Optional[CurrentContext]:
        with self._lock:
            return self._ctx

    def to_dict(self) -> Dict:
        ctx = self.get_context()
        return ctx.to_dict() if ctx else {}

    def get_status(self) -> Dict:
        ctx = self.get_context()
        return {
            'running': self._running,
            'app': ctx.active_app if ctx else '',
            'activity': ctx.user_activity if ctx else '',
            'mode': ctx.detected_mode if ctx else '',
        }
