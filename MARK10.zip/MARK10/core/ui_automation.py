"""
MARK 9 — UI Automation Engine
Full Windows UI control: click, type, read, scroll, hotkeys.
Supports: WhatsApp Web, Discord, Browser, Word, VSCode, Spotify.

Creator: Ali (Sidi3Ali)
System: MARK 9
"""

import logging
import time
import threading
from typing import Optional, List, Dict, Any, Tuple

logger = logging.getLogger('MARK9.UIAutomation')


class WindowManager:
    """Find, focus, and control Windows windows."""

    def __init__(self):
        self._win32_ok = False
        try:
            import win32gui, win32con, win32api
            self._win32_ok = True
        except ImportError:
            pass

    def find_window(self, title_contains: str) -> Optional[int]:
        """Find window handle by partial title match."""
        if not self._win32_ok:
            return None
        try:
            import win32gui
            result = []
            def enum_windows(hwnd, _):
                t = win32gui.GetWindowText(hwnd)
                if title_contains.lower() in t.lower():
                    result.append(hwnd)
            win32gui.EnumWindows(enum_windows, None)
            return result[0] if result else None
        except Exception as e:
            logger.debug(f"find_window error: {e}")
            return None

    def focus_window(self, hwnd: int) -> bool:
        """Bring window to foreground."""
        if not self._win32_ok or not hwnd:
            return False
        try:
            import win32gui, win32con
            if win32gui.IsIconic(hwnd):
                win32gui.ShowWindow(hwnd, win32con.SW_RESTORE)
            win32gui.SetForegroundWindow(hwnd)
            time.sleep(0.3)
            return True
        except Exception as e:
            logger.debug(f"focus_window error: {e}")
            return False

    def focus_by_title(self, title_contains: str) -> bool:
        """Find and focus window by title."""
        hwnd = self.find_window(title_contains)
        if hwnd:
            return self.focus_window(hwnd)
        return False

    def maximize_window(self, hwnd: int = None, title: str = None) -> bool:
        """Maximize a window."""
        if title:
            hwnd = self.find_window(title)
        if not hwnd:
            return False
        try:
            import win32gui, win32con
            win32gui.ShowWindow(hwnd, win32con.SW_MAXIMIZE)
            return True
        except Exception:
            return False

    def close_window(self, title: str) -> bool:
        """Close a window by title."""
        hwnd = self.find_window(title)
        if not hwnd:
            return False
        try:
            import win32gui, win32con
            win32gui.PostMessage(hwnd, win32con.WM_CLOSE, 0, 0)
            return True
        except Exception:
            return False

    def get_window_text(self, title: str = None, hwnd: int = None) -> str:
        """Get text content of a window using accessibility."""
        if title:
            hwnd = self.find_window(title)
        if not hwnd:
            return ''
        try:
            import uiautomation as auto
            win = auto.ControlFromHandle(hwnd)
            if win:
                return win.Name or ''
        except Exception:
            pass
        try:
            import win32gui
            return win32gui.GetWindowText(hwnd) or ''
        except Exception:
            return ''

    def list_windows(self) -> List[Dict]:
        """List all visible windows."""
        if not self._win32_ok:
            return []
        try:
            import win32gui
            windows = []
            def callback(hwnd, _):
                if win32gui.IsWindowVisible(hwnd):
                    title = win32gui.GetWindowText(hwnd)
                    if title:
                        rect = win32gui.GetWindowRect(hwnd)
                        windows.append({'hwnd': hwnd, 'title': title, 'rect': rect})
            win32gui.EnumWindows(callback, None)
            return windows
        except Exception:
            return []

    def get_window_rect(self, title: str) -> Optional[Tuple[int, int, int, int]]:
        """Get window position and size (left, top, right, bottom)."""
        hwnd = self.find_window(title)
        if not hwnd:
            return None
        try:
            import win32gui
            return win32gui.GetWindowRect(hwnd)
        except Exception:
            return None

    def arrange_windows(self, titles: List[str]) -> bool:
        """Tile windows side by side."""
        try:
            import win32gui, win32con
            import ctypes
            user32 = ctypes.windll.user32
            screen_w = user32.GetSystemMetrics(0)
            screen_h = user32.GetSystemMetrics(1)

            windows = [self.find_window(t) for t in titles if self.find_window(t)]
            if not windows:
                return False

            w_per_window = screen_w // len(windows)
            for i, hwnd in enumerate(windows):
                x = i * w_per_window
                win32gui.SetWindowPos(hwnd, win32con.HWND_TOP,
                                       x, 0, w_per_window, screen_h, 0)
            return True
        except Exception as e:
            logger.debug(f"arrange_windows error: {e}")
            return False


class MouseKeyboard:
    """Mouse and keyboard control via pyautogui + pywin32."""

    def __init__(self):
        self._pag_ok = False
        try:
            import pyautogui
            pyautogui.FAILSAFE = False  # Disable failsafe corner
            pyautogui.PAUSE = 0.05
            self._pag_ok = True
        except ImportError:
            pass

    def click(self, x: int, y: int, button: str = 'left',
               double: bool = False, delay: float = 0.0) -> bool:
        """Click at screen coordinates."""
        if delay:
            time.sleep(delay)
        if self._pag_ok:
            try:
                import pyautogui
                pyautogui.moveTo(x, y, duration=0.15)
                if double:
                    pyautogui.doubleClick(x, y, button=button)
                else:
                    pyautogui.click(x, y, button=button)
                return True
            except Exception as e:
                logger.debug(f"click error: {e}")
        return False

    def right_click(self, x: int, y: int) -> bool:
        return self.click(x, y, button='right')

    def type_text(self, text: str, interval: float = 0.03) -> bool:
        """Type text at current cursor position."""
        if self._pag_ok:
            try:
                import pyautogui
                pyautogui.typewrite(text, interval=interval)
                return True
            except Exception:
                # Fallback for non-ASCII
                try:
                    import pyperclip
                    import pyautogui
                    pyperclip.copy(text)
                    pyautogui.hotkey('ctrl', 'v')
                    return True
                except Exception as e:
                    logger.debug(f"type_text error: {e}")
        return False

    def type_text_clipboard(self, text: str) -> bool:
        """Type text via clipboard (supports all characters)."""
        try:
            import pyperclip
            pyperclip.copy(text)
            time.sleep(0.1)
            self.hotkey('ctrl', 'v')
            return True
        except Exception as e:
            logger.debug(f"clipboard type error: {e}")
            return False

    def hotkey(self, *keys) -> bool:
        """Press keyboard shortcut."""
        if self._pag_ok:
            try:
                import pyautogui
                pyautogui.hotkey(*keys)
                return True
            except Exception as e:
                logger.debug(f"hotkey error: {e}")
        return False

    def key_press(self, key: str) -> bool:
        """Press a single key."""
        if self._pag_ok:
            try:
                import pyautogui
                pyautogui.press(key)
                return True
            except Exception:
                pass
        return False

    def scroll(self, x: int, y: int, amount: int = 3,
                direction: str = 'down') -> bool:
        """Scroll at position."""
        if self._pag_ok:
            try:
                import pyautogui
                clicks = -amount if direction == 'down' else amount
                pyautogui.scroll(clicks, x=x, y=y)
                return True
            except Exception:
                pass
        return False

    def select_all(self) -> bool:
        return self.hotkey('ctrl', 'a')

    def copy(self) -> bool:
        return self.hotkey('ctrl', 'c')

    def paste(self) -> bool:
        return self.hotkey('ctrl', 'v')

    def undo(self) -> bool:
        return self.hotkey('ctrl', 'z')

    def get_clipboard(self) -> str:
        """Get current clipboard text."""
        try:
            import pyperclip
            return pyperclip.paste() or ''
        except Exception:
            return ''


class UIAController:
    """Windows UI Automation via uiautomation library."""

    def __init__(self):
        self._ok = False
        try:
            import uiautomation as auto
            self._ok = True
        except ImportError:
            pass

    def find_element(self, window_title: str = '', control_type: str = 'Edit',
                      name: str = '') -> Optional[Any]:
        """Find UI element using UIA."""
        if not self._ok:
            return None
        try:
            import uiautomation as auto
            if window_title:
                win = auto.WindowControl(searchDepth=1, SubName=window_title)
                if not win.Exists(1, 0):
                    return None
                if control_type == 'Edit':
                    return win.EditControl(searchDepth=10, Name=name) if name else \
                           win.EditControl(searchDepth=10)
                elif control_type == 'Button':
                    return win.ButtonControl(searchDepth=10, Name=name) if name else \
                           win.ButtonControl(searchDepth=10)
            else:
                if control_type == 'Edit':
                    return auto.EditControl(searchDepth=5, Name=name)
        except Exception as e:
            logger.debug(f"UIA find_element error: {e}")
        return None

    def type_in_element(self, element, text: str) -> bool:
        """Type in a UIA element."""
        if not self._ok or not element:
            return False
        try:
            element.SetFocus()
            pattern = element.GetValuePattern()
            if pattern:
                pattern.SetValue(text)
                return True
        except Exception as e:
            logger.debug(f"UIA type_in_element error: {e}")
        return False

    def click_button(self, window_title: str, button_name: str) -> bool:
        """Click a button by name in a window."""
        if not self._ok:
            return False
        try:
            import uiautomation as auto
            win = auto.WindowControl(searchDepth=1, SubName=window_title)
            if win.Exists(1, 0):
                btn = win.ButtonControl(searchDepth=10, Name=button_name)
                if btn.Exists(1, 0):
                    btn.Click()
                    return True
        except Exception as e:
            logger.debug(f"UIA click_button error: {e}")
        return False

    def get_url_from_browser(self, browser_name: str = 'Chrome') -> str:
        """Get current URL from browser address bar."""
        if not self._ok:
            return ''
        try:
            import uiautomation as auto
            win = auto.WindowControl(searchDepth=1, SubName=browser_name)
            if win.Exists(1, 0):
                edit = win.EditControl(searchDepth=10)
                if edit.Exists(1, 0):
                    pattern = edit.GetValuePattern()
                    if pattern:
                        return pattern.Value or ''
        except Exception as e:
            logger.debug(f"UIA get_url error: {e}")
        return ''


class AppAutomation:
    """High-level automation for specific apps."""

    def __init__(self, window_mgr: WindowManager, mk: MouseKeyboard,
                  uia: UIAController, vision_engine=None):
        self.wm = window_mgr
        self.mk = mk
        self.uia = uia
        self.vision = vision_engine

    # ── WhatsApp Web ─────────────────────────────────────────────────────────
    def send_whatsapp_message(self, contact: str, message: str) -> str:
        """Send WhatsApp message via WhatsApp Web in browser."""
        try:
            # Find WhatsApp window (browser)
            opened = False
            for app_name in ['WhatsApp', 'whatsapp']:
                if self.wm.focus_by_title(app_name):
                    opened = True
                    break

            if not opened:
                # Open WhatsApp Web
                import subprocess
                subprocess.Popen(['start', 'https://web.whatsapp.com'], shell=True)
                time.sleep(5)

            # Search for contact using vision
            time.sleep(1)
            self.mk.hotkey('ctrl', 'f')  # Search
            time.sleep(0.5)
            self.mk.type_text_clipboard(contact)
            time.sleep(1)
            self.mk.key_press('enter')
            time.sleep(1)

            # Type and send message
            self.mk.type_text_clipboard(message)
            time.sleep(0.3)
            self.mk.key_press('enter')
            return f"Mensaje enviado a {contact}: '{message[:40]}'"
        except Exception as e:
            return f"Error enviando WhatsApp: {e}"

    # ── Discord ───────────────────────────────────────────────────────────────
    def send_discord_message(self, channel: str, message: str) -> str:
        """Send Discord message to a channel."""
        try:
            if not self.wm.focus_by_title('Discord'):
                return "Discord no está abierto."
            time.sleep(0.5)
            # Navigate to channel
            self.mk.hotkey('ctrl', 'k')  # Quick switcher
            time.sleep(0.3)
            self.mk.type_text_clipboard(channel)
            time.sleep(0.5)
            self.mk.key_press('enter')
            time.sleep(0.5)
            self.mk.type_text_clipboard(message)
            self.mk.key_press('enter')
            return f"Mensaje enviado en #{channel}"
        except Exception as e:
            return f"Error en Discord: {e}"

    # ── Browser ───────────────────────────────────────────────────────────────
    def open_url(self, url: str, browser: str = '') -> str:
        """Open URL in browser."""
        try:
            import subprocess
            if 'chrome' in browser.lower():
                subprocess.Popen(['chrome', url], shell=True)
            elif 'firefox' in browser.lower():
                subprocess.Popen(['firefox', url], shell=True)
            else:
                subprocess.Popen(['start', url], shell=True)
            return f"Abriendo: {url}"
        except Exception as e:
            return f"Error abriendo URL: {e}"

    def browser_navigate(self, url: str) -> str:
        """Navigate active browser to URL."""
        try:
            for browser in ['Chrome', 'Firefox', 'Edge', 'Opera']:
                if self.wm.focus_by_title(browser):
                    time.sleep(0.3)
                    self.mk.hotkey('ctrl', 'l')
                    time.sleep(0.2)
                    self.mk.type_text_clipboard(url)
                    self.mk.key_press('enter')
                    return f"Navegando a: {url}"
            return "No se encontró navegador activo."
        except Exception as e:
            return f"Error navegando: {e}"

    # ── VSCode ────────────────────────────────────────────────────────────────
    def vscode_command(self, command: str) -> str:
        """Execute VSCode command via command palette."""
        try:
            if not self.wm.focus_by_title('Visual Studio Code'):
                return "VSCode no está abierto."
            self.mk.hotkey('ctrl', 'shift', 'p')
            time.sleep(0.3)
            self.mk.type_text_clipboard(command)
            time.sleep(0.3)
            self.mk.key_press('enter')
            return f"VSCode: ejecutando '{command}'"
        except Exception as e:
            return f"Error en VSCode: {e}"

    def vscode_open_terminal(self) -> str:
        """Open integrated terminal in VSCode."""
        try:
            if not self.wm.focus_by_title('Visual Studio Code'):
                return "VSCode no está abierto."
            self.mk.hotkey('ctrl', '`')
            return "Terminal VSCode abierto."
        except Exception as e:
            return f"Error: {e}"

    # ── Word / Office ─────────────────────────────────────────────────────────
    def word_save(self) -> str:
        """Save current Word document."""
        try:
            if not self.wm.focus_by_title('Word'):
                return "Word no está abierto."
            self.mk.hotkey('ctrl', 's')
            return "Documento guardado."
        except Exception as e:
            return f"Error: {e}"

    # ── Spotify ───────────────────────────────────────────────────────────────
    def spotify_play_pause(self) -> str:
        """Toggle play/pause in Spotify."""
        try:
            if self.wm.focus_by_title('Spotify'):
                self.mk.key_press('space')
                return "Spotify: play/pause."
            self.mk.hotkey('ctrl', 'alt', 'space')  # Global media key
            return "Comando play/pause enviado."
        except Exception as e:
            return f"Error Spotify: {e}"

    def spotify_next(self) -> str:
        self.mk.hotkey('ctrl', 'alt', 'right')
        return "Spotify: siguiente canción."

    def spotify_prev(self) -> str:
        self.mk.hotkey('ctrl', 'alt', 'left')
        return "Spotify: canción anterior."


class UIAutomationEngine:
    """
    MARK 9 — UI Automation Engine.
    Central entry point for all UI control operations.
    """

    def __init__(self, brain=None):
        self.brain = brain
        self._wm = WindowManager()
        self._mk = MouseKeyboard()
        self._uia = UIAController()
        self._vision = None  # Injected after init

        # Will be set after vision engine loads
        self._app_auto = AppAutomation(self._wm, self._mk, self._uia)

        logger.info(f"UI Automation: win32={self._wm._win32_ok}, "
                    f"pyautogui={self._mk._pag_ok}, uia={self._uia._ok}")

    def set_vision(self, vision_engine):
        """Inject vision engine for coordinate detection."""
        self._vision = vision_engine
        self._app_auto.vision = vision_engine

    # ── Window control ────────────────────────────────────────────────────────
    def focus_window(self, title: str) -> str:
        ok = self._wm.focus_by_title(title)
        return f"Ventana '{title}' activada." if ok else f"Ventana '{title}' no encontrada."

    def close_window(self, title: str) -> str:
        ok = self._wm.close_window(title)
        return f"Ventana '{title}' cerrada." if ok else f"No se encontró '{title}'."

    def maximize_window(self, title: str) -> str:
        hwnd = self._wm.find_window(title)
        ok = self._wm.maximize_window(hwnd=hwnd)
        return f"'{title}' maximizada." if ok else f"No se encontró '{title}'."

    def list_windows(self) -> str:
        windows = self._wm.list_windows()
        if not windows:
            return "No se detectaron ventanas."
        names = [w['title'][:50] for w in windows[:10]]
        return "Ventanas abiertas:\n" + '\n'.join(f"• {n}" for n in names)

    def arrange_windows(self, titles: List[str]) -> str:
        ok = self._wm.arrange_windows(titles)
        return "Ventanas organizadas." if ok else "Error organizando ventanas."

    # ── Mouse / Keyboard ─────────────────────────────────────────────────────
    def click(self, x: int, y: int, double: bool = False) -> str:
        ok = self._mk.click(x, y, double=double)
        return f"Click en ({x}, {y})." if ok else "Error en click."

    def type_text(self, text: str) -> str:
        ok = self._mk.type_text_clipboard(text)
        return f"Texto escrito: '{text[:40]}'" if ok else "Error escribiendo."

    def hotkey(self, *keys) -> str:
        ok = self._mk.hotkey(*keys)
        return f"Atajo: {'+'.join(keys)}" if ok else "Error en atajo."

    def scroll(self, direction: str = 'down', amount: int = 3) -> str:
        # Scroll at current mouse position
        try:
            import pyautogui
            x, y = pyautogui.position()
            ok = self._mk.scroll(x, y, amount, direction)
            return f"Scroll {direction} {amount} unidades." if ok else "Error en scroll."
        except Exception:
            return "Scroll no disponible."

    # ── Smart click: find text and click ─────────────────────────────────────
    def click_text(self, text: str) -> str:
        """Find text on screen and click it."""
        if self._vision:
            coords = self._vision.find_on_screen(text)
            if coords:
                self._mk.click(coords[0], coords[1])
                return f"Click en texto '{text}'."
        return f"No se encontró '{text}' en pantalla."

    def read_screen(self) -> str:
        """Read text from current screen."""
        if self._vision:
            text = self._vision.capture_screen_text()
            return text[:500] if text else "Sin texto detectable."
        return "Vision engine no disponible."

    # ── App-specific ──────────────────────────────────────────────────────────
    def send_whatsapp(self, contact: str, message: str) -> str:
        return self._app_auto.send_whatsapp_message(contact, message)

    def send_discord(self, channel: str, message: str) -> str:
        return self._app_auto.send_discord_message(channel, message)

    def open_url(self, url: str) -> str:
        return self._app_auto.open_url(url)

    def browser_navigate(self, url: str) -> str:
        return self._app_auto.browser_navigate(url)

    def vscode_command(self, command: str) -> str:
        return self._app_auto.vscode_command(command)

    def vscode_terminal(self) -> str:
        return self._app_auto.vscode_open_terminal()

    def word_save(self) -> str:
        return self._app_auto.word_save()

    def spotify_toggle(self) -> str:
        return self._app_auto.spotify_play_pause()

    def spotify_next(self) -> str:
        return self._app_auto.spotify_next()

    def spotify_prev(self) -> str:
        return self._app_auto.spotify_prev()

    def get_browser_url(self) -> str:
        for browser in ['Chrome', 'Firefox', 'Edge']:
            url = self._uia.get_url_from_browser(browser)
            if url:
                return url
        return ''

    def get_status(self) -> Dict:
        return {
            'win32': self._wm._win32_ok,
            'pyautogui': self._mk._pag_ok,
            'uiautomation': self._uia._ok,
            'vision_linked': self._vision is not None,
        }
