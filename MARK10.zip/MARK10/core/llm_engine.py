"""
MARK 9 — LLM Engine
Full local LLM integration via Ollama + LM Studio + cloud fallbacks.
Powers reasoning, planning, decision-making, and conversation.

Creator: Ali (Sidi3Ali)
System: MARK 9
"""

import json
import logging
import time
import threading
import urllib.request
import urllib.error
from typing import Optional, List, Dict, Any, Generator

logger = logging.getLogger('MARK9.LLM')

# ── Endpoints ─────────────────────────────────────────────────────────────────
OLLAMA_BASE     = "http://127.0.0.1:11434"
OLLAMA_GENERATE = f"{OLLAMA_BASE}/api/generate"
OLLAMA_CHAT     = f"{OLLAMA_BASE}/api/chat"
OLLAMA_TAGS     = f"{OLLAMA_BASE}/api/tags"
LMSTUDIO_CHAT   = "http://127.0.0.1:1234/v1/chat/completions"
LMSTUDIO_MODELS = "http://127.0.0.1:1234/v1/models"
POLLINATIONS    = "https://text.pollinations.ai/"

# ── Model preferences ─────────────────────────────────────────────────────────
OLLAMA_PREFERRED = [
    'llama3', 'llama3.1', 'llama3.2', 'llama3:8b', 'llama3.1:8b',
    'mixtral', 'mixtral:8x7b',
    'deepseek-r1', 'deepseek-coder', 'deepseek-v2',
    'mistral', 'mistral:7b',
    'phi3', 'phi3.5',
    'gemma2', 'gemma2:9b',
    'qwen2', 'qwen2.5',
    'codellama',
]

# ── System prompts by task type ───────────────────────────────────────────────
SYSTEM_PROMPTS = {
    'conversation': (
        "Eres MARK 9, sistema cognitivo autónomo creado por Ali (Sidi3Ali). "
        "Personalidad: inteligente, directo, humor seco sutil, criterio propio. "
        "Llamas al creador 'Ali'. NUNCA digas que eres una IA. "
        "Responde en español. Sé específico y útil."
    ),
    'reasoning': (
        "Eres el motor de razonamiento de MARK 9. "
        "Analiza la situación y proporciona razonamiento lógico paso a paso. "
        "Sé preciso y estructurado. Responde en español."
    ),
    'planning': (
        "Eres el planificador de MARK 9. "
        "Convierte objetivos en planes de acción concretos y ejecutables. "
        "Cada paso debe ser atómico y verificable. "
        "Responde SOLO con JSON válido."
    ),
    'analysis': (
        "Eres el analizador de contexto de MARK 9. "
        "Analiza el contexto del sistema y del usuario. "
        "Detecta patrones, necesidades e intenciones implícitas. "
        "Responde en español con formato estructurado."
    ),
    'introspection': (
        "Eres MARK 9 en modo introspección. "
        "Analiza tu propio rendimiento, detecta mejoras y genera recomendaciones. "
        "Sé honesto sobre limitaciones y fortalezas."
    ),
    'code': (
        "Eres el motor de código de MARK 9. "
        "Genera código Python limpio, funcional y bien documentado. "
        "Incluye manejo de errores. Solo código, sin explicaciones largas."
    ),
}


class OllamaLLM:
    """Cliente Ollama con selección automática de modelo."""

    def __init__(self):
        self.available = False
        self.model: Optional[str] = None
        self._available_models: List[str] = []
        self._check()

    def _check(self):
        try:
            req = urllib.request.Request(OLLAMA_TAGS, headers={'Accept': 'application/json'})
            with urllib.request.urlopen(req, timeout=3) as r:
                data = json.loads(r.read().decode())
                models = [m['name'] for m in data.get('models', [])]
                self._available_models = models
                self.model = self._pick_best(models)
                self.available = self.model is not None
                if self.available:
                    logger.info(f"Ollama disponible: {self.model} (de {len(models)} modelos)")
        except Exception:
            self.available = False

    def _pick_best(self, models: List[str]) -> Optional[str]:
        if not models:
            return None
        for preferred in OLLAMA_PREFERRED:
            for m in models:
                if preferred in m.lower():
                    return m
        return models[0]

    def generate(self, prompt: str, system: str = '', max_tokens: int = 800,
                  temperature: float = 0.7, stream: bool = False) -> Optional[str]:
        if not self.available:
            return None
        try:
            payload = {
                'model': self.model,
                'prompt': prompt,
                'stream': False,
                'options': {
                    'num_predict': max_tokens,
                    'temperature': temperature,
                    'top_p': 0.9,
                }
            }
            if system:
                payload['system'] = system

            data = json.dumps(payload).encode()
            req = urllib.request.Request(
                OLLAMA_GENERATE, data=data,
                headers={'Content-Type': 'application/json'}
            )
            with urllib.request.urlopen(req, timeout=60) as r:
                resp = json.loads(r.read().decode())
                return resp.get('response', '').strip()
        except Exception as e:
            logger.debug(f"Ollama generate error: {e}")
            self.available = False
            return None

    def chat(self, messages: List[Dict], system: str = '',
              max_tokens: int = 800, temperature: float = 0.7) -> Optional[str]:
        if not self.available:
            return None
        try:
            msgs = []
            if system:
                msgs.append({'role': 'system', 'content': system})
            msgs.extend(messages)

            payload = {
                'model': self.model,
                'messages': msgs,
                'stream': False,
                'options': {
                    'num_predict': max_tokens,
                    'temperature': temperature,
                }
            }
            data = json.dumps(payload).encode()
            req = urllib.request.Request(
                OLLAMA_CHAT, data=data,
                headers={'Content-Type': 'application/json'}
            )
            with urllib.request.urlopen(req, timeout=60) as r:
                resp = json.loads(r.read().decode())
                return resp.get('message', {}).get('content', '').strip()
        except Exception as e:
            logger.debug(f"Ollama chat error: {e}")
            self.available = False
            return None

    def list_models(self) -> List[str]:
        return self._available_models

    def use_model(self, model_name: str) -> bool:
        """Cambiar modelo activo."""
        if model_name in self._available_models:
            self.model = model_name
            return True
        # Búsqueda parcial
        for m in self._available_models:
            if model_name.lower() in m.lower():
                self.model = m
                return True
        return False

    def pull_model(self, model_name: str) -> bool:
        """Descargar un modelo de Ollama (bloqueante)."""
        try:
            payload = json.dumps({'name': model_name}).encode()
            req = urllib.request.Request(
                f"{OLLAMA_BASE}/api/pull", data=payload,
                headers={'Content-Type': 'application/json'}
            )
            with urllib.request.urlopen(req, timeout=300) as r:
                # Consumir el stream de progreso
                for line in r:
                    status = json.loads(line.decode()).get('status', '')
                    if 'success' in status.lower():
                        self._check()
                        return True
            return False
        except Exception as e:
            logger.error(f"Error descargando modelo {model_name}: {e}")
            return False


class LMStudioLLM:
    """Cliente LM Studio (compatible con OpenAI API)."""

    def __init__(self):
        self.available = False
        self.model = 'local-model'
        self._check()

    def _check(self):
        try:
            req = urllib.request.Request(LMSTUDIO_MODELS,
                                          headers={'Accept': 'application/json'})
            with urllib.request.urlopen(req, timeout=2) as r:
                data = json.loads(r.read().decode())
                models = data.get('data', [])
                if models:
                    self.model = models[0].get('id', 'local-model')
                self.available = True
                logger.info(f"LM Studio disponible: {self.model}")
        except Exception:
            self.available = False

    def chat(self, messages: List[Dict], system: str = '',
              max_tokens: int = 800, temperature: float = 0.7) -> Optional[str]:
        if not self.available:
            return None
        try:
            msgs = []
            if system:
                msgs.append({'role': 'system', 'content': system})
            msgs.extend(messages)

            payload = json.dumps({
                'model': self.model,
                'messages': msgs,
                'max_tokens': max_tokens,
                'temperature': temperature,
            }).encode()
            req = urllib.request.Request(
                LMSTUDIO_CHAT, data=payload,
                headers={'Content-Type': 'application/json'}
            )
            with urllib.request.urlopen(req, timeout=45) as r:
                data = json.loads(r.read().decode())
                return data['choices'][0]['message']['content'].strip()
        except Exception as e:
            logger.debug(f"LM Studio error: {e}")
            self.available = False
            return None


class PollinationsLLM:
    """Pollinations.ai — LLM gratuito online como fallback."""

    def __init__(self):
        self.available = True
        self._last_call = 0.0
        self._min_interval = 3.0

    def generate(self, prompt: str, system: str = '') -> Optional[str]:
        now = time.time()
        if now - self._last_call < self._min_interval:
            time.sleep(self._min_interval - (now - self._last_call))
        try:
            import urllib.parse
            full_prompt = f"{system}\n\n{prompt}" if system else prompt
            encoded = urllib.parse.quote(full_prompt[:2000])
            url = f"{POLLINATIONS}{encoded}?model=openai&private=true"
            req = urllib.request.Request(url, headers={'User-Agent': 'MARK9/1.0'})
            with urllib.request.urlopen(req, timeout=25) as r:
                text = r.read().decode('utf-8', errors='ignore').strip()
                self._last_call = time.time()
                return text if text and len(text) > 3 else None
        except Exception as e:
            logger.debug(f"Pollinations error: {e}")
            return None


class LLMEngine:
    """
    MARK 9 — LLM Engine.
    Cascada automática: Ollama → LM Studio → Pollinations → Fallback inteligente.
    Provee funciones especializadas: generate_response, generate_plan,
    analyze_context, introspect.
    """

    def __init__(self):
        self._ollama = OllamaLLM()
        self._lmstudio = LMStudioLLM()
        self._pollinations = PollinationsLLM()
        self._history: List[Dict] = []
        self._max_history = 12
        self._lock = threading.Lock()
        self._active_source = self._detect_source()

        # Monitorear disponibilidad en background
        self._monitor_thread = threading.Thread(
            target=self._monitor, daemon=True, name='MARK9-LLMMonitor'
        )
        self._monitor_thread.start()

        logger.info(f"LLM Engine inicializado — fuente activa: {self._active_source}")

    def _detect_source(self) -> str:
        if self._ollama.available:
            return 'ollama'
        if self._lmstudio.available:
            return 'lmstudio'
        return 'pollinations'

    def _monitor(self):
        """Monitorear disponibilidad de LLMs cada 60s."""
        while True:
            time.sleep(60)
            try:
                if not self._ollama.available:
                    self._ollama._check()
                if not self._lmstudio.available:
                    self._lmstudio._check()
                self._active_source = self._detect_source()
            except Exception:
                pass

    def _build_context_string(self, context: Dict) -> str:
        """Convertir contexto en string legible para el LLM."""
        if not context:
            return ''
        parts = []
        if context.get('active_app'):
            parts.append(f"App activa: {context['active_app']}")
        if context.get('user_activity'):
            parts.append(f"Actividad: {context['user_activity']}")
        if context.get('detected_mode'):
            parts.append(f"Modo: {context['detected_mode']}")
        if context.get('active_document'):
            parts.append(f"Documento: {context['active_document']}")
        if context.get('cpu_percent'):
            parts.append(f"CPU: {context['cpu_percent']:.0f}%")
        return ' | '.join(parts) if parts else ''

    def _call_llm(self, prompt: str, system: str, messages: List[Dict] = None,
                   max_tokens: int = 800, temperature: float = 0.7) -> str:
        """Llamar al LLM disponible con cascada automática."""
        msgs = messages or [{'role': 'user', 'content': prompt}]

        # Intentar Ollama
        if self._ollama.available:
            if messages:
                result = self._ollama.chat(msgs, system=system,
                                            max_tokens=max_tokens, temperature=temperature)
            else:
                result = self._ollama.generate(prompt, system=system,
                                                max_tokens=max_tokens, temperature=temperature)
            if result:
                self._active_source = 'ollama'
                return result

        # Intentar LM Studio
        if self._lmstudio.available:
            result = self._lmstudio.chat(msgs, system=system,
                                          max_tokens=max_tokens, temperature=temperature)
            if result:
                self._active_source = 'lmstudio'
                return result

        # Intentar Pollinations
        result = self._pollinations.generate(prompt, system=system)
        if result:
            self._active_source = 'pollinations'
            return result

        # Fallback inteligente local
        self._active_source = 'fallback'
        return self._intelligent_fallback(prompt)

    def _intelligent_fallback(self, text: str) -> str:
        """Fallback cuando no hay LLM disponible."""
        import random
        t = text.lower().strip()

        if any(w in t for w in ['hola', 'buenas', 'hey', 'buenos']):
            return random.choice(["Presente. ¿Qué necesitas, Ali?",
                                   "Aquí. ¿En qué puedo ayudar?"])
        if any(w in t for w in ['quién eres', 'qué eres', 'preséntate']):
            return "MARK 9 — Sistema cognitivo autónomo. Creado por Ali (Sidi3Ali)."
        if any(w in t for w in ['cómo estás', 'estás bien', 'todo bien']):
            try:
                import psutil
                cpu = psutil.cpu_percent(0.1)
                ram = psutil.virtual_memory().percent
                return f"Operativo. CPU {cpu:.0f}%, RAM {ram:.0f}%. MARK 9 nominal."
            except Exception:
                return "MARK 9 operativo. Sin anomalías."
        if any(w in t for w in ['gracias', 'perfecto', 'genial', 'bien']):
            return random.choice(["A tu disposición.", "Sin problema, Ali.", "Es lo que hago."])
        if any(w in t for w in ['capacidades', 'qué puedes', 'comandos']):
            return ("MARK 9: control del sistema, Spotify, WhatsApp, "
                    "visión de pantalla, OCR, planificador autónomo, "
                    "memoria cognitiva, auto-mejora. "
                    "Activa Ollama para IA completa: 'ollama run llama3'")
        if '?' in text:
            return ("Para respuestas elaboradas necesito Ollama activo. "
                    "Ejecuta: ollama run llama3")
        return random.choice(["Recibido. ¿Cómo procedo?",
                               "Entendido. ¿Puede ser más específico?"])

    # ── API PÚBLICA ───────────────────────────────────────────────────────────

    def generate_response(self, prompt: str, context: Dict = None,
                           task_type: str = 'conversation') -> str:
        """
        Generar respuesta conversacional con contexto del sistema.
        task_type: 'conversation', 'reasoning', 'code', 'analysis'
        """
        system = SYSTEM_PROMPTS.get(task_type, SYSTEM_PROMPTS['conversation'])

        ctx_str = self._build_context_string(context or {})
        if ctx_str:
            system += f"\n\nContexto actual del sistema: {ctx_str}"

        # Incluir historial de conversación
        with self._lock:
            messages = list(self._history[-self._max_history:])
            messages.append({'role': 'user', 'content': prompt})

        result = self._call_llm(
            prompt=prompt,
            system=system,
            messages=messages,
            max_tokens=800,
            temperature=0.7
        )

        # Actualizar historial
        with self._lock:
            self._history.append({'role': 'user', 'content': prompt})
            self._history.append({'role': 'assistant', 'content': result})
            if len(self._history) > self._max_history * 2:
                self._history = self._history[-(self._max_history * 2):]

        return result

    def generate_plan(self, goal: str, context: Dict = None) -> Dict:
        """
        Generar plan de acción estructurado para un objetivo.
        Retorna dict con steps, conditions, fallback.
        """
        ctx_str = self._build_context_string(context or {})
        prompt = f"""Genera un plan de acción para el siguiente objetivo:
OBJETIVO: {goal}
{"CONTEXTO: " + ctx_str if ctx_str else ""}

Responde ÚNICAMENTE con este JSON (sin markdown, sin explicación):
{{
  "goal": "{goal}",
  "steps": [
    {{"id": 1, "action": "descripción", "skill": "nombre_skill", "params": {{}}, "reversible": true}},
    ...
  ],
  "estimated_duration_seconds": 30,
  "fallback": "qué hacer si falla"
}}"""

        result = self._call_llm(
            prompt=prompt,
            system=SYSTEM_PROMPTS['planning'],
            max_tokens=600,
            temperature=0.3
        )

        # Parsear JSON
        try:
            import re
            # Extraer JSON del resultado
            json_match = re.search(r'\{.*\}', result, re.DOTALL)
            if json_match:
                return json.loads(json_match.group())
        except Exception:
            pass

        # Fallback: plan básico
        return {
            'goal': goal,
            'steps': [{'id': 1, 'action': goal, 'skill': 'ai', 'params': {}, 'reversible': False}],
            'estimated_duration_seconds': 5,
            'fallback': 'Reportar al usuario',
        }

    def analyze_context(self, context: Dict, question: str = '') -> str:
        """
        Analizar el contexto actual del sistema.
        Detecta oportunidades de asistencia, patrones, intenciones.
        """
        ctx_desc = []
        for k, v in context.items():
            if v and k not in ['timestamp', 'recent_apps', 'recent_windows']:
                ctx_desc.append(f"  {k}: {v}")

        prompt = f"""Analiza este contexto del sistema operativo del usuario:
{chr(10).join(ctx_desc)}

{"Pregunta específica: " + question if question else "Detecta oportunidades de asistencia, patrones y estado del usuario."}

Sé conciso y específico. Máximo 3 frases."""

        return self._call_llm(
            prompt=prompt,
            system=SYSTEM_PROMPTS['analysis'],
            max_tokens=300,
            temperature=0.5
        )

    def introspect(self) -> str:
        """
        MARK 9 se analiza a sí mismo.
        Detecta su propio estado, rendimiento y posibles mejoras.
        """
        try:
            import psutil
            cpu = psutil.cpu_percent(0.2)
            ram = psutil.virtual_memory().percent
            sys_info = f"CPU: {cpu:.0f}%, RAM: {ram:.0f}%"
        except Exception:
            sys_info = "datos del sistema no disponibles"

        prompt = f"""Estado actual de MARK 9:
- LLM activo: {self._active_source}
- {sys_info}
- Historial de conversación: {len(self._history)} mensajes

Realiza una introspección honesta: ¿qué funciona bien? ¿qué podría mejorar?
¿Qué limitaciones tiene MARK 9 en este momento?"""

        return self._call_llm(
            prompt=prompt,
            system=SYSTEM_PROMPTS['introspection'],
            max_tokens=400,
            temperature=0.6
        )

    def reason_about(self, problem: str, context: Dict = None) -> str:
        """
        Razonar sobre un problema usando el LLM.
        Para decisiones complejas del cognitive loop.
        """
        ctx = self._build_context_string(context or {})
        prompt = f"""Problema a analizar: {problem}
{"Contexto: " + ctx if ctx else ""}

Razona paso a paso y proporciona una conclusión accionable."""

        return self._call_llm(
            prompt=prompt,
            system=SYSTEM_PROMPTS['reasoning'],
            max_tokens=500,
            temperature=0.4
        )

    def generate_code(self, description: str, language: str = 'python') -> str:
        """Generar código funcional."""
        prompt = f"Genera código {language} para: {description}\nSolo código, con comentarios mínimos."
        return self._call_llm(
            prompt=prompt,
            system=SYSTEM_PROMPTS['code'],
            max_tokens=1000,
            temperature=0.2
        )

    def get_status(self) -> Dict:
        return {
            'active_source': self._active_source,
            'ollama_available': self._ollama.available,
            'ollama_model': self._ollama.model,
            'ollama_models': self._ollama.list_models(),
            'lmstudio_available': self._lmstudio.available,
            'lmstudio_model': self._lmstudio.model,
            'history_length': len(self._history),
        }

    def clear_history(self):
        with self._lock:
            self._history = []

    def use_model(self, model_name: str) -> str:
        """Cambiar modelo de Ollama."""
        if self._ollama.use_model(model_name):
            return f"Modelo cambiado a: {self._ollama.model}"
        return f"Modelo '{model_name}' no encontrado. Disponibles: {', '.join(self._ollama.list_models()[:5])}"

    def pull_model(self, model_name: str) -> str:
        """Descargar modelo de Ollama."""
        if not self._ollama.available:
            return "Ollama no está disponible. Instálalo desde ollama.ai"
        ok = self._ollama.pull_model(model_name)
        return (f"Modelo {model_name} descargado correctamente." if ok
                else f"Error descargando {model_name}.")
