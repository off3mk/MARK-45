"""
JARVIS v7.0 - Vision System
Visión computacional avanzada: captura, OCR completo, análisis de UI.
Creador: Ali (Sidi3Ali)
"""

import logging
import os
import time
from typing import Optional, Dict, Any, Tuple, List

logger = logging.getLogger('JARVIS.Vision')


class VisionSystem:
    """Sistema de visión computacional."""

    def __init__(self):
        self._opencv_available = False
        self._ocr_available = False
        self._screenshot_available = False
        self._init_libraries()

    def _init_libraries(self):
        """Inicializar librerías de visión."""
        try:
            import cv2
            self._opencv_available = True
            logger.info("OpenCV disponible")
        except ImportError:
            logger.debug("OpenCV no disponible")

        try:
            import pytesseract
            self._ocr_available = True
            logger.info("Tesseract OCR disponible")
        except ImportError:
            logger.debug("pytesseract no disponible")

        try:
            import PIL.ImageGrab
            self._screenshot_available = True
            logger.info("Captura de pantalla disponible")
        except ImportError:
            try:
                import mss
                self._screenshot_available = True
                self._use_mss = True
                logger.info("mss disponible para capturas")
            except ImportError:
                logger.debug("Sin soporte de captura de pantalla")

    def capture_screen(self, region: Optional[Tuple] = None) -> Optional[Any]:
        """
        Capturar pantalla completa o región específica.
        region: (left, top, right, bottom) o None para pantalla completa
        """
        try:
            if hasattr(self, '_use_mss'):
                import mss
                import mss.tools
                with mss.mss() as sct:
                    if region:
                        monitor = {"left": region[0], "top": region[1],
                                   "width": region[2] - region[0],
                                   "height": region[3] - region[1]}
                    else:
                        monitor = sct.monitors[1]
                    sct_img = sct.grab(monitor)
                    return sct_img
            else:
                from PIL import ImageGrab
                img = ImageGrab.grab(bbox=region)
                return img
        except Exception as e:
            logger.debug(f"Error capturando pantalla: {e}")
            return None

    def take_screenshot(self, save_path: Optional[str] = None) -> Optional[str]:
        """Tomar screenshot y guardarlo."""
        try:
            # Intentar con pyautogui primero
            import pyautogui
            from datetime import datetime
            timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
            if not save_path:
                workspace = os.path.join(
                    os.path.dirname(os.path.dirname(__file__)), 'workspace'
                )
                os.makedirs(workspace, exist_ok=True)
                save_path = os.path.join(workspace, f"screenshot_{timestamp}.png")

            screenshot = pyautogui.screenshot()
            screenshot.save(save_path)
            logger.info(f"Screenshot guardado: {save_path}")
            return save_path

        except Exception as e:
            logger.debug(f"Error tomando screenshot con pyautogui: {e}")
            # Fallback
            try:
                from PIL import ImageGrab
                from datetime import datetime
                timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
                if not save_path:
                    workspace = os.path.join(
                        os.path.dirname(os.path.dirname(__file__)), 'workspace'
                    )
                    os.makedirs(workspace, exist_ok=True)
                    save_path = os.path.join(workspace, f"screenshot_{timestamp}.png")
                img = ImageGrab.grab()
                img.save(save_path)
                return save_path
            except Exception as e2:
                logger.error(f"Error en screenshot fallback: {e2}")
                return None

    def read_screen_text(self, region: Optional[Tuple] = None) -> str:
        """
        Leer texto de la pantalla usando OCR.
        region: (left, top, right, bottom) o None para pantalla completa
        """
        if not self._ocr_available:
            return "OCR no disponible. Instale pytesseract y Tesseract-OCR."

        try:
            import pytesseract
            from PIL import Image

            img = self.capture_screen(region)
            if img is None:
                return "No se pudo capturar la pantalla."

            # Convertir a PIL Image si es necesario
            if not isinstance(img, Image.Image):
                if hasattr(img, 'pixels'):  # mss
                    from PIL import Image as PILImage
                    img = PILImage.frombytes('RGB', img.size, img.pixels)

            # OCR
            config = '--psm 6 -l spa+eng'
            text = pytesseract.image_to_string(img, config=config)
            cleaned = text.strip()
            logger.info(f"OCR completado: {len(cleaned)} caracteres")
            return cleaned if cleaned else "No se detectó texto en la pantalla."

        except Exception as e:
            logger.error(f"Error en OCR: {e}")
            return f"Error al leer texto: {str(e)}"

    def find_text_on_screen(self, text: str) -> Optional[Tuple[int, int]]:
        """
        Encontrar texto en pantalla y retornar posición (x, y).
        Returns: coordenadas del centro del texto o None
        """
        if not self._opencv_available or not self._ocr_available:
            logger.debug("OpenCV o OCR no disponibles para búsqueda de texto")
            return None

        try:
            import pytesseract
            import cv2
            import numpy as np
            from PIL import ImageGrab

            # Capturar pantalla
            img = ImageGrab.grab()
            img_np = np.array(img)
            img_gray = cv2.cvtColor(img_np, cv2.COLOR_RGB2GRAY)

            # OCR con data detallada
            data = pytesseract.image_to_data(img_gray, output_type=pytesseract.Output.DICT,
                                              config='-l spa+eng')

            # Buscar el texto
            for i, word in enumerate(data['text']):
                if text.lower() in word.lower():
                    x = data['left'][i] + data['width'][i] // 2
                    y = data['top'][i] + data['height'][i] // 2
                    logger.info(f"Texto '{text}' encontrado en ({x}, {y})")
                    return (x, y)

            return None

        except Exception as e:
            logger.debug(f"Error buscando texto en pantalla: {e}")
            return None

    def click_on_text(self, text: str) -> bool:
        """Encontrar texto en pantalla y hacer clic en él."""
        position = self.find_text_on_screen(text)
        if position:
            try:
                import pyautogui
                pyautogui.click(position[0], position[1])
                logger.info(f"Clic en '{text}' en posición {position}")
                return True
            except Exception as e:
                logger.error(f"Error haciendo clic: {e}")
        else:
            logger.info(f"Texto '{text}' no encontrado en pantalla")
        return False

    def analyze_screen_content(self) -> Dict[str, Any]:
        """Analizar contenido completo de la pantalla."""
        result = {
            'text': '',
            'has_error_dialog': False,
            'active_windows': [],
            'browser_open': False,
        }

        # Leer texto
        result['text'] = self.read_screen_text()

        # Detectar ventanas activas
        try:
            import psutil
            browsers = ['chrome', 'firefox', 'edge', 'opera', 'brave']
            for proc in psutil.process_iter(['name']):
                pname = proc.info['name'].lower()
                if any(b in pname for b in browsers):
                    result['browser_open'] = True
                    result['active_windows'].append(pname)
        except Exception:
            pass

        # Detectar diálogos de error en el texto
        error_keywords = ['error', 'excepción', 'exception', 'failed', 'fallo']
        text_lower = result['text'].lower()
        result['has_error_dialog'] = any(k in text_lower for k in error_keywords)

        return result

    def is_available(self) -> Dict[str, bool]:
        """Verificar disponibilidad de capacidades de visión."""
        return {
            'opencv': self._opencv_available,
            'ocr': self._ocr_available,
            'screenshot': self._screenshot_available,
        }
