"""
JARVIS v7.0 - Autonomous Engine
Aprende rutinas, monitorea apps, actúa proactivamente bajo control del usuario.
Creador: Ali (Sidi3Ali)
"""

import logging
import threading
import time
import psutil
from datetime import datetime, timedelta
from typing import Optional, Dict, List, Set, Callable, Any
from collections import Counter, defaultdict

logger = logging.getLogger('JARVIS.Autonomous')


class AppWatcher:
    """Monitorea qué aplicaciones están abiertas y cuándo."""

    def __init__(self):
        self._prev_apps: Set[str] = set()
        self._app_open_times: Dict[str, float] = {}
        self._session_apps: List[str] = []

        # Apps "de trabajo" vs "ocio"
        self._work_apps = {'code', 'vscode', 'pycharm', 'word', 'excel',
                           'outlook', 'teams', 'slack', 'notion', 'obsidian'}
        self._leisure_apps = {'spotify', 'steam', 'discord', 'netflix',
                              'vlc', 'youtube'}

    def get_current_apps(self) -> Set[str]:
        """Obtener conjunto de apps actualmente abiertas."""
        apps = set()
        try:
            for proc in psutil.process_iter(['name']):
                name = proc.info['name'].lower().replace('.exe', '')
                if len(name) > 2 and name not in {'system', 'idle', 'svchost',
                                                    'runtime', 'host', 'service',
                                                    'explorer', 'dwm', 'winlogon'}:
                    apps.add(name)
        except Exception:
            pass
        return apps

    def get_changes(self) -> Dict[str, Set[str]]:
        """Detectar apps abiertas/cerradas desde la última comprobación."""
        current = self.get_current_apps()
        opened = current - self._prev_apps
        closed = self._prev_apps - current

        # Registrar tiempos
        now = time.time()
        for app in opened:
            self._app_open_times[app] = now
            self._session_apps.append(app)

        self._prev_apps = current
        return {'opened': opened, 'closed': closed, 'current': current}

    def is_working(self) -> bool:
        """Detectar si el usuario está en modo trabajo."""
        current = self.get_current_apps()
        return bool(current & self._work_apps)

    def is_leisure(self) -> bool:
        """Detectar si el usuario está en modo ocio."""
        current = self.get_current_apps()
        return bool(current & self._leisure_apps)

    def get_session_summary(self) -> Dict:
        """Resumen de la sesión actual."""
        current = self.get_current_apps()
        work_count = len(current & self._work_apps)
        leisure_count = len(current & self._leisure_apps)
        mode = 'trabajo' if work_count > leisure_count else \
               'ocio' if leisure_count > 0 else 'neutral'
        return {
            'mode': mode,
            'active_apps': list(current),
            'work_apps': list(current & self._work_apps),
            'leisure_apps': list(current & self._leisure_apps),
        }


class RoutineLearner:
    """Aprende rutinas del usuario y las repite automáticamente."""

    def __init__(self):
        self._routine_log: List[Dict] = []  # Secuencias observadas
        self._confirmed_routines: List[Dict] = []

    def observe(self, action: str, hour: int, weekday: int):
        """Observar una acción del usuario."""
        self._routine_log.append({
            'action': action,
            'hour': hour,
            'weekday': weekday,
            'timestamp': time.time(),
        })
        # Mantener solo las últimas 1000 observaciones
        if len(self._routine_log) > 1000:
            self._routine_log = self._routine_log[-1000:]

    def detect_routines(self) -> List[Dict]:
        """Detectar rutinas repetidas automáticamente."""
        if len(self._routine_log) < 20:
            return []

        routines = []

        # Agrupar por (hora, weekday)
        buckets: Dict[tuple, List[str]] = defaultdict(list)
        for entry in self._routine_log:
            key = (entry['hour'], entry['weekday'])
            buckets[key].append(entry['action'])

        for (hour, weekday), actions in buckets.items():
            if len(actions) < 3:
                continue
            # Buscar acciones repetidas en este slot temporal
            freq = Counter(actions)
            for action, count in freq.most_common(3):
                if count >= 3:
                    confidence = min(count / 7.0, 0.95)
                    days = ['lunes', 'martes', 'miércoles', 'jueves',
                            'viernes', 'sábado', 'domingo']
                    routines.append({
                        'action': action,
                        'hour': hour,
                        'weekday': weekday,
                        'day_name': days[weekday] if 0 <= weekday < 7 else '?',
                        'frequency': count,
                        'confidence': confidence,
                    })

        return sorted(routines, key=lambda x: x['confidence'], reverse=True)

    def should_trigger_routine(self, now: datetime) -> Optional[Dict]:
        """Verificar si hay una rutina que debería ejecutarse ahora."""
        routines = self.detect_routines()
        for r in routines:
            if (r['hour'] == now.hour and
                    r['weekday'] == now.weekday() and
                    r['confidence'] > 0.6):
                return r
        return None


class AutonomousEngine:
    """
    Motor autónomo avanzado de JARVIS.
    - Monitorea apps abiertas
    - Aprende rutinas del usuario
    - Alerta sobre CPU/RAM
    - Hace sugerencias contextuales
    """

    def __init__(self, brain):
        self.brain = brain
        self._running = False
        self._thread: Optional[threading.Thread] = None
        self._app_watcher = AppWatcher()
        self._routine_learner = RoutineLearner()
        self._notified: Dict[str, float] = {}  # name → last_notify_time
        self._cooldowns: Dict[str, float] = {}
        self._last_cpu_alert = 0.0
        self._last_mem_alert = 0.0
        self._last_suggestion_hour = -1
        self._suggestions_made: Set[str] = set()

        # Thresholds configurables
        self.cpu_threshold = 85.0
        self.mem_threshold = 85.0
        self.suggestion_cooldown = 3600  # 1 hora entre sugerencias del mismo tipo

    def start(self):
        self._running = True
        self._thread = threading.Thread(target=self._loop, daemon=True)
        self._thread.start()
        logger.info("Autonomous Engine avanzado iniciado")

    def stop(self):
        self._running = False
        if self._thread:
            self._thread.join(timeout=3)

    def _loop(self):
        """Bucle principal del motor autónomo."""
        tick = 0
        while self._running:
            try:
                now = datetime.now()
                tick += 1

                # Cada 5 segundos: monitoreo de recursos
                self._check_resources(now)

                # Cada 30 segundos: cambios de apps
                if tick % 6 == 0:
                    self._check_app_changes(now)

                # Cada 5 minutos: análisis de rutinas y sugerencias
                if tick % 60 == 0:
                    self._check_routine_suggestions(now)

                # Cada hora: resumen si el usuario está activo
                if tick % 720 == 0:
                    self._hourly_summary(now)

            except Exception as e:
                logger.debug(f"Error en autonomous loop: {e}")

            time.sleep(5)

    def _check_resources(self, now: datetime):
        """Monitorear CPU y RAM, alertar si superan umbrales."""
        try:
            cpu = psutil.cpu_percent(interval=None)
            mem = psutil.virtual_memory().percent

            current_time = time.time()

            # Alerta CPU
            if cpu > self.cpu_threshold:
                if current_time - self._last_cpu_alert > 300:  # 5 min cooldown
                    self._last_cpu_alert = current_time
                    msg = (f"Señor, CPU al {cpu:.0f}%. "
                           f"Puede que algún proceso esté consumiendo demasiado. "
                           f"¿Desea que analice los procesos activos?")
                    self._notify('cpu_alert', msg)

            # Alerta RAM
            if mem > self.mem_threshold:
                if current_time - self._last_mem_alert > 300:
                    self._last_mem_alert = current_time
                    msg = (f"Señor, RAM al {mem:.0f}%. "
                           f"El sistema podría ralentizarse. "
                           f"¿Desea que libere memoria?")
                    self._notify('mem_alert', msg)

        except Exception:
            pass

    def _check_app_changes(self, now: datetime):
        """Detectar y reaccionar a cambios en apps abiertas."""
        try:
            changes = self._app_watcher.get_changes()
            opened = changes.get('opened', set())

            # Registrar en memoria cognitiva
            if self.brain and hasattr(self.brain, 'cognitive_memory') and self.brain.cognitive_memory:
                for app in opened:
                    self.brain.cognitive_memory.record_app_open(app)

            # Sugerencias basadas en apps que acaban de abrir
            for app in opened:
                suggestion = self._get_app_suggestion(app, now)
                if suggestion:
                    key = f"app_suggest_{app}_{now.hour}"
                    last = self._notified.get(key, 0)
                    if time.time() - last > self.suggestion_cooldown:
                        self._notified[key] = time.time()
                        self._notify(f'suggest_{app}', suggestion)

        except Exception as e:
            logger.debug(f"Error en app changes: {e}")

    def _get_app_suggestion(self, app: str, now: datetime) -> Optional[str]:
        """Generar sugerencia basada en qué app abrió el usuario."""
        suggestions = {
            'code': "VSCode detectado, Señor. ¿Desea que abra la documentación o prepare el entorno de desarrollo?",
            'vscode': "VSCode activo, Señor. ¿Está trabajando en algún proyecto? Puedo asistirle.",
            'spotify': "Spotify abierto, Señor. ¿Desea que ajuste el volumen o seleccione una lista de reproducción?",
            'chrome': None,  # Demasiado genérico para sugerir
            'firefox': None,
            'word': "Microsoft Word detectado, Señor. ¿Necesita asistencia con el documento?",
            'excel': "Excel activo, Señor. ¿Desea que genere algún script de automatización?",
            'obs': "OBS Studio detectado, Señor. ¿Va a iniciar una grabación o stream?",
            'steam': "Steam activo, Señor. Que disfrute de su sesión de juego.",
        }
        return suggestions.get(app)

    def _check_routine_suggestions(self, now: datetime):
        """Verificar si hay rutinas que deberían activarse."""
        try:
            # Obtener patrones de memoria cognitiva
            if not (self.brain and hasattr(self.brain, 'cognitive_memory')
                    and self.brain.cognitive_memory):
                return

            patterns = self.brain.cognitive_memory.get_patterns(min_confidence=0.5)

            for p in patterns[:3]:
                if p.get('confidence', 0) < 0.5:
                    continue

                action = p['action']
                match = False

                if p['pattern_type'] == 'hourly':
                    match = abs(p.get('time_hour', -1) - now.hour) <= 0

                elif p['pattern_type'] == 'weekly':
                    match = (p.get('day_of_week', -1) == now.weekday() and
                             now.hour == 9)  # Sugerir a las 9am del día correspondiente

                if match:
                    key = f"routine_{action}_{now.weekday()}_{now.hour}"
                    last = self._notified.get(key, 0)
                    if time.time() - last > 86400:  # Una vez al día
                        self._notified[key] = time.time()
                        days = ['lunes', 'martes', 'miércoles', 'jueves',
                                'viernes', 'sábado', 'domingo']
                        day_name = days[now.weekday()] if 0 <= now.weekday() < 7 else ''
                        msg = (f"Señor, según sus patrones, suele ejecutar "
                               f"'{action}' a esta hora"
                               f"{' los ' + day_name if day_name else ''}. "
                               f"¿Desea que lo haga automáticamente?")
                        self._notify(f'routine_{action}', msg)

        except Exception as e:
            logger.debug(f"Error en routine suggestions: {e}")

    def _hourly_summary(self, now: datetime):
        """Resumen horario del sistema si es relevante."""
        try:
            if now.hour in [9, 13, 17, 20]:
                session = self._app_watcher.get_session_summary()
                cpu = psutil.cpu_percent()
                mem = psutil.virtual_memory().percent

                if cpu > 70 or mem > 75:
                    msg = (f"Resumen del sistema, Señor: CPU {cpu:.0f}%, RAM {mem:.0f}%. "
                           f"Modo detectado: {session['mode']}.")
                    self._notify('hourly_summary', msg)
        except Exception:
            pass

    def _notify(self, event_type: str, message: str):
        """Enviar notificación al usuario."""
        logger.info(f"[AUTÓNOMO/{event_type}] {message}")

        if self.brain:
            # Voz
            if self.brain.voice:
                try:
                    self.brain.voice.speak(message, priority=False)
                except Exception:
                    pass

            # UI
            if self.brain._ui_callback:
                try:
                    self.brain._ui_callback('autonomous_notification', message)
                except Exception:
                    pass

            # Memoria
            if self.brain.memory:
                try:
                    self.brain.memory.log_event('autonomous', {'type': event_type, 'message': message})
                except Exception:
                    pass

    def observe_action(self, action: str):
        """Registrar acción para aprendizaje de rutinas."""
        now = datetime.now()
        self._routine_learner.observe(action, now.hour, now.weekday())

    def get_session_info(self) -> Dict:
        """Información sobre la sesión actual."""
        return {
            'app_session': self._app_watcher.get_session_summary(),
            'routines_detected': len(self._routine_learner.detect_routines()),
        }

    def set_threshold(self, resource: str, value: float):
        """Configurar umbrales de alerta."""
        if resource == 'cpu':
            self.cpu_threshold = value
        elif resource == 'memory':
            self.mem_threshold = value
