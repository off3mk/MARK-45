"""
core/brain.py
Cerebro Central de JARVIS v4.0 Definitivo

El núcleo neural de JARVIS. Coordina todos los subsistemas, procesa comandos,
gestiona el flujo de información entre módulos, y toma decisiones basadas
en el estado actual, contexto y objetivos del sistema.
"""

import os
import sys
import json
import re
import time
import threading
import importlib
import inspect
from typing import Dict, List, Optional, Callable, Any, Tuple
from dataclasses import dataclass
from datetime import datetime
from enum import Enum
import logging

# Configurar logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
)
logger = logging.getLogger(__name__)


class CommandPriority(Enum):
    """Prioridades de procesamiento de comandos."""
    CRITICAL = 1    # Seguridad, emergencias
    HIGH = 2        # Acciones importantes del usuario
    NORMAL = 3      # Comandos estándar
    LOW = 4         # Tareas de fondo
    BACKGROUND = 5  # Procesamiento autónomo


@dataclass
class Command:
    """
    Representa un comando a procesar por JARVIS.
    """
    id: str
    raw_input: str
    source: str  # 'user', 'voice', 'autonomous', 'system'
    priority: CommandPriority
    timestamp: datetime
    context: Dict[str, Any]
    processed: bool = False
    result: Any = None
    error: Optional[str] = None


@dataclass
class SkillInfo:
    """
    Información sobre un skill cargado.
    """
    name: str
    module_path: str
    instance: Any
    enabled: bool = True
    last_used: Optional[datetime] = None
    use_count: int = 0
    error_count: int = 0


class JarvisBrain:
    """
    Cerebro central de JARVIS.
    
    Responsabilidades:
    - Recepción y encolamiento de comandos
    - Routing de comandos a skills apropiados
    - Coordinación entre subsistemas (memoria, estado, IA, etc.)
    - Gestión del ciclo de vida de skills
    - Procesamiento del lenguaje natural básico
    - Mantenimiento del contexto conversacional
    """
    
    def __init__(self, ai_manager=None, memory=None, state_engine=None,
                 personality=None, security=None, voice=None,
                 skills_dir: str = "skills"):
        """
        Inicializa el cerebro de JARVIS.
        
        Args:
            ai_manager: Gestor de IA (local/online)
            memory: Sistema de memoria cognitiva
            state_engine: Motor de estado/conciencia
            personality: Sistema de personalidad
            security: Gestor de seguridad
            voice: Sistema de voz
            skills_dir: Directorio de skills
        """
        self.version = "4.0.0"
        
        # Subsistemas
        self.ai = ai_manager
        self.memory = memory
        self.state = state_engine
        self.personality = personality
        self.security = security
        self.voice = voice
        
        # Configuración
        self.skills_dir = skills_dir
        self.running = False
        self.processing_thread: Optional[threading.Thread] = None
        
        # Cola de comandos priorizada
        self.command_queue: List[Command] = []
        self.queue_lock = threading.RLock()
        self.max_queue_size = 100
        
        # Skills registrados
        self.skills: Dict[str, SkillInfo] = {}
        self.skill_patterns: Dict[str, List[str]] = {}  # Patrones regex por skill
        
        # Contexto de procesamiento
        self.current_command: Optional[Command] = None
        self.conversation_depth = 0
        self.last_intent: Optional[str] = None
        
        # Callbacks y hooks
        self.pre_process_hooks: List[Callable[[Command], Optional[Command]]] = []
        self.post_process_hooks: List[Callable[[Command, Any], None]] = []
        self.error_handlers: List[Callable[[Command, Exception], None]] = []
        
        # Estadísticas
        self.stats = {
            'commands_processed': 0,
            'commands_success': 0,
            'commands_failed': 0,
            'average_processing_time': 0.0
        }
        
        # Inicializar
        self._load_core_skills()
        self._setup_default_patterns()
        
        logger.info(f"JARVIS Brain v{self.version} inicializado")
    
    def _load_core_skills(self):
        """Carga los skills core del sistema."""
        core_skills = [
            ('system', 'skills.system', 'SystemSkill'),
            ('media', 'skills.media', 'MediaSkill'),
            ('internet', 'skills.internet', 'InternetSkill'),
            ('coding', 'skills.coding', 'CodingSkill'),
        ]
        
        for skill_name, module_path, class_name in core_skills:
            try:
                self._load_skill(skill_name, module_path, class_name)
            except Exception as e:
                logger.error(f"Error cargando skill {skill_name}: {e}")
    
    def _load_skill(self, name: str, module_path: str, class_name: str):
        """Carga un skill específico."""
        try:
            # Importar módulo
            module = importlib.import_module(module_path)
            skill_class = getattr(module, class_name)
            
            # Instanciar con dependencias necesarias
            if name == 'coding' and self.ai:
                instance = skill_class(self.ai)
            else:
                instance = skill_class()
            
            # Registrar
            self.skills[name] = SkillInfo(
                name=name,
                module_path=module_path,
                instance=instance,
                enabled=True
            )
            
            logger.info(f"Skill cargado: {name}")
            
        except Exception as e:
            logger.error(f"No se pudo cargar skill {name}: {e}")
            raise
    
    def _setup_default_patterns(self):
        """Configura patrones de reconocimiento por defecto."""
        self.skill_patterns = {
            'system': [
                r'abre\s+(.+)',
                r'cierra\s+(.+)',
                r'ejecuta\s+(.+)',
                r'comando\s+(.+)',
                r'screenshot',
                r'captura',
                r'minimiza',
                r'maximiza',
                r'cierra\s+ventana',
                r'información\s+del\s+sistema',
                r'procesos',
                r'termina\s+(.+)'
            ],
            'media': [
                r'spotify\s+(play|pause|next|prev|stop)',
                r'reproduce\s+música',
                r'pausa\s+música',
                r'siguiente\s+canción',
                r'volumen\s+(\d+)',
                r'sube\s+volumen',
                r'baja\s+volumen',
                r'mute',
                r'silencio',
                r'youtube\s+(.+)',
                r'pon\s+(un\s+)?temazo',
                r'música\s+(.+)'
            ],
            'internet': [
                r'busca\s+(.+)',
                r'google\s+(.+)',
                r'qué\s+(es|son)\s+(.+)',
                r'clima\s+(?:en\s+)?(.+)',
                r'tiempo\s+(?:en\s+)?(.+)',
                r'wikipedia\s+(.+)',
                r'noticias\s+(?:de\s+)?(.+)',
                r'abre\s+(https?://.+)',
                r'url\s+(.+)'
            ],
            'coding': [
                r'c[oó]digo\s+(?:para\s+)?(.+)',
                r'genera\s+(?:un\s+)?script\s+(?:de\s+)?(.+)',
                r'crea\s+(?:un\s+)?programa\s+(?:de\s+)?(.+)',
                r'python\s+(.+)',
                r'ejecuta\s+(?:el\s+)?script\s+(.+)',
                r'analiza\s+(?:el\s+)?c[oó]digo',
                r'depura\s+(.+)'
            ]
        }
    
    def start(self):
        """Inicia el procesamiento de comandos en background."""
        if self.running:
            return
        
        self.running = True
        self.processing_thread = threading.Thread(
            target=self._processing_loop,
            name="BrainProcessor",
            daemon=True
        )
        self.processing_thread.start()
        
        logger.info("Brain processor iniciado")
    
    def stop(self):
        """Detiene el procesamiento."""
        self.running = False
        if self.processing_thread:
            self.processing_thread.join(timeout=5.0)
        logger.info("Brain processor detenido")
    
    def _processing_loop(self):
        """Loop principal de procesamiento de comandos."""
        while self.running:
            try:
                # Obtener siguiente comando
                command = self._get_next_command()
                
                if command:
                    self._process_command_internal(command)
                else:
                    time.sleep(0.1)  # Esperar si no hay comandos
                    
            except Exception as e:
                logger.error(f"Error en processing loop: {e}")
                time.sleep(1)
    
    def _get_next_command(self) -> Optional[Command]:
        """Obtiene el siguiente comando de mayor prioridad."""
        with self.queue_lock:
            if not self.command_queue:
                return None
            
            # Ordenar por prioridad y timestamp
            self.command_queue.sort(
                key=lambda c: (c.priority.value, c.timestamp)
            )
            
            return self.command_queue.pop(0)
    
    def process_command(self, user_input: str, source: str = "user",
                       priority: CommandPriority = CommandPriority.NORMAL,
                       context: Dict = None) -> str:
        """
        Procesa un comando de usuario (método público principal).
        
        Args:
            user_input: Texto del comando
            source: Origen del comando ('user', 'voice', etc.)
            priority: Prioridad de procesamiento
            context: Contexto adicional
        
        Returns:
            Respuesta para el usuario
        """
        start_time = time.time()
        
        # Crear objeto comando
        command = Command(
            id=self._generate_command_id(),
            raw_input=user_input,
            source=source,
            priority=priority,
            timestamp=datetime.now(),
            context=context or {}
        )
        
        # Si es interactivo y alta prioridad, procesar inmediatamente
        if source == "user" and priority in [CommandPriority.CRITICAL, CommandPriority.HIGH]:
            return self._process_command_internal(command)
        
        # Encolar para procesamiento asíncrono
        self._enqueue_command(command)
        
        # Para comandos normales, esperar resultado con timeout
        if source == "user":
            timeout = 30.0
            elapsed = 0.0
            while elapsed < timeout:
                if command.processed:
                    break
                time.sleep(0.1)
                elapsed = time.time() - start_time
            
            if not command.processed:
                return self.personality.format_response(
                    "Procesando su solicitud, un momento por favor...",
                    context="working"
                ) if self.personality else "Procesando..."
            
            if command.error:
                return self._handle_error_response(command.error)
            
            return str(command.result) if command.result else "Completado."
        
        return command.id  # Retornar ID para tracking asíncrono
    
    def _enqueue_command(self, command: Command):
        """Agrega comando a la cola."""
        with self.queue_lock:
            if len(self.command_queue) >= self.max_queue_size:
                # Eliminar comando de menor prioridad más antiguo
                self.command_queue.sort(key=lambda c: (c.priority.value, c.timestamp))
                if self.command_queue[-1].priority.value >= command.priority.value:
                    removed = self.command_queue.pop()
                    logger.warning(f"Cola llena, eliminado: {removed.raw_input[:50]}")
                else:
                    raise Exception("Cola de comandos saturada")
            
            self.command_queue.append(command)
    
    def _process_command_internal(self, command: Command) -> str:
        """
        Procesa un comando internamente (lógica principal).
        """
        self.current_command = command
        start_time = time.time()
        
        try:
            # Pre-procesamiento (hooks)
            for hook in self.pre_process_hooks:
                modified = hook(command)
                if modified:
                    command = modified
            
            # Registrar en memoria
            if self.memory:
                self.memory.add_to_conversation("user", command.raw_input)
                self.memory.store_episode(
                    event=f"Comando recibido: {command.raw_input[:100]}",
                    importance=5 if command.priority == CommandPriority.NORMAL else 7,
                    context={'source': command.source, 'priority': command.priority.value}
                )
            
            # Actualizar estado
            if self.state:
                self.state.task_started(
                    command.id,
                    f"Procesar: {command.raw_input[:50]}",
                    "command_processing",
                    priority=command.priority.value
                )
            
            # Análisis de seguridad
            if self.security:
                is_safe, warning = self.security.check_command(command.raw_input)
                if not is_safe:
                    command.error = f"Seguridad: {warning}"
                    raise Exception(command.error)
            
            # Parseo de intención
            intent = self._parse_intent(command.raw_input)
            command.context['intent'] = intent
            
            # Enrutamiento y ejecución
            result = self._route_and_execute(command, intent)
            command.result = result
            command.processed = True
            
            # Post-procesamiento
            for hook in self.post_process_hooks:
                hook(command, result)
            
            # Actualizar estadísticas
            processing_time = time.time() - start_time
            self._update_stats(success=True, processing_time=processing_time)
            
            # Formatear respuesta
            response = self._format_response(result, intent)
            
            # Registrar respuesta
            if self.memory:
                self.memory.add_to_conversation("jarvis", response)
            
            # Actualizar estado
            if self.state:
                self.state.task_completed(command.id, success=True)
                self.state.record_skill_usage(intent.get('skill', 'unknown'))
            
            return response
            
        except Exception as e:
            logger.error(f"Error procesando comando: {e}")
            command.error = str(e)
            command.processed = True
            
            # Manejo de errores
            for handler in self.error_handlers:
                try:
                    handler(command, e)
                except:
                    pass
            
            self._update_stats(success=False, processing_time=time.time() - start_time)
            
            if self.state:
                self.state.task_completed(command.id, success=False)
            
            return self._handle_error_response(str(e))
        
        finally:
            self.current_command = None
            self.last_intent = command.context.get('intent', {}).get('action')
    
    def _parse_intent(self, user_input: str) -> Dict:
        """
        Analiza la intención del usuario a partir del texto.
        
        Returns:
            Dict con 'skill', 'action', 'params', 'confidence'
        """
        user_input_lower = user_input.lower().strip()
        
        # 1. Matching con patrones definidos
        for skill_name, patterns in self.skill_patterns.items():
            for pattern in patterns:
                match = re.search(pattern, user_input_lower)
                if match:
                    return self._build_intent_from_match(
                        skill_name, pattern, match, user_input_lower
                    )
        
        # 2. Matching con comandos exactos de skills
        for skill_name, skill_info in self.skills.items():
            if not skill_info.enabled:
                continue
            
            try:
                if hasattr(skill_info.instance, 'get_commands'):
                    commands = skill_info.instance.get_commands()
                    for cmd_pattern, action in commands.items():
                        if re.search(cmd_pattern, user_input_lower):
                            return {
                                'skill': skill_name,
                                'action': action,
                                'params': self._extract_params(user_input_lower, cmd_pattern),
                                'confidence': 0.9,
                                'method': 'skill_command'
                            }
            except:
                pass
        
        # 3. Análisis con IA si está disponible
        if self.ai:
            try:
                ai_intent = self._parse_with_ai(user_input)
                if ai_intent.get('confidence', 0) > 0.6:
                    return ai_intent
            except Exception as e:
                logger.warning(f"Error en análisis de IA: {e}")
        
        # 4. Fallback: comando desconocido
        return {
            'skill': None,
            'action': 'unknown',
            'params': {'raw': user_input},
            'confidence': 0.0,
            'method': 'fallback'
        }
    
    def _build_intent_from_match(self, skill: str, pattern: str,
                                  match: re.Match, raw_input: str) -> Dict:
        """Construye objeto de intención desde un match de regex."""
        action = self._pattern_to_action(skill, pattern)
        params = self._extract_params_from_match(match, pattern)
        
        return {
            'skill': skill,
            'action': action,
            'params': params,
            'confidence': 0.85,
            'method': 'pattern_match',
            'matched_pattern': pattern
        }
    
    def _pattern_to_action(self, skill: str, pattern: str) -> str:
        """Convierte un patrón a nombre de acción."""
        # Mapeo simple de patrones comunes a acciones
        action_map = {
            r'abre\s+(.+)': 'open_program',
            r'cierra\s+(.+)': 'close_program',
            r'ejecuta\s+(.+)': 'execute_shell',
            r'screenshot': 'screenshot',
            r'minimiza': 'minimize_window',
            r'spotify\s+(play|pause|next|prev|stop)': 'spotify_control',
            r'volumen\s+(\d+)': 'volume_set',
            r'busca\s+(.+)': 'search',
            r'clima\s+(?:en\s+)?(.+)': 'weather',
            r'c[oó]digo\s+(?:para\s+)?(.+)': 'generate_code',
            r'ejecuta\s+(?:el\s+)?script\s+(.+)': 'execute_file'
        }
        
        for pat, action in action_map.items():
            if re.search(pat, pattern):
                return action
        
        return f"action_{hash(pattern) % 10000}"
    
    def _extract_params_from_match(self, match: re.Match, pattern: str) -> Dict:
        """Extrae parámetros de un match de regex."""
        params = {}
        groups = match.groups()
        
        if groups:
            # Asignar nombres genéricos a los grupos
            for i, group in enumerate(groups):
                params[f'param_{i}' if i > 0 else 'main_param'] = group.strip()
        
        return params
    
    def _extract_params(self, user_input: str, pattern: str) -> Dict:
        """Extrae parámetros de un input dado un patrón."""
        match = re.search(pattern, user_input)
        if match:
            return self._extract_params_from_match(match, pattern)
        return {}
    
    def _parse_with_ai(self, user_input: str) -> Dict:
        """Usa IA para parsear intención cuando los patrones fallan."""
        prompt = f"""Analiza esta solicitud y responde SOLO con JSON:
Solicitud: "{user_input}"

Responde en este formato exacto:
{{
    "skill": "system|media|internet|coding|memory",
    "action": "nombre_de_accion",
    "params": {{"clave": "valor"}},
    "confidence": 0.0-1.0
}}

Si no estás seguro, usa skill: null y confidence: 0."""
        
        try:
            response = self.ai.generate(prompt, max_tokens=200)
            
            # Extraer JSON
            json_match = re.search(r'\{.*\}', response, re.DOTALL)
            if json_match:
                intent = json.loads(json_match.group())
                return intent
                
        except Exception as e:
            logger.error(f"Error en parsing con IA: {e}")
        
        return {'skill': None, 'action': 'unknown', 'params': {}, 'confidence': 0}
    
    def _route_and_execute(self, command: Command, intent: Dict) -> Any:
        """
        Enruta el comando al skill apropiado y ejecuta.
        """
        skill_name = intent.get('skill')
        action = intent.get('action')
        params = intent.get('params', {})
        
        if not skill_name:
            # Intentar respuesta conversacional con IA
            if self.ai:
                return self._conversational_response(command.raw_input)
            raise Exception("No pude entender el comando, Señor.")
        
        # Verificar skill existe y está habilitado
        if skill_name not in self.skills:
            raise Exception(f"Skill '{skill_name}' no disponible.")
        
        skill_info = self.skills[skill_name]
        if not skill_info.enabled:
            raise Exception(f"Skill '{skill_name}' está deshabilitado.")
        
        # Ejecutar
        try:
            skill_info.last_used = datetime.now()
            skill_info.use_count += 1
            
            result = skill_info.instance.execute(action, params)
            
            return result
            
        except Exception as e:
            skill_info.error_count += 1
            raise Exception(f"Error en skill {skill_name}: {e}")
    
    def _conversational_response(self, user_input: str) -> str:
        """Genera respuesta conversacional usando IA."""
        if not self.ai:
            return "No entendí el comando. ¿Podría reformularlo, Señor?"
        
        # Construir contexto
        context = ""
        if self.memory and self.memory.current_context:
            recent = self.memory.get_conversation_context(depth=3)
            context = "\n".join([
                f"{m['speaker']}: {m['content']}" 
                for m in recent
            ])
        
        prompt = f"""Eres JARVIS, asistente personal de Iron Man. 
Responde de forma breve, profesional y útil. Siempre dirígete al usuario como "Señor".

Contexto reciente:
{context}

Usuario: {user_input}

JARVIS:"""
        
        response = self.ai.generate(prompt, max_tokens=300)
        
        # Limpiar respuesta
        response = response.strip()
        if response.startswith("JARVIS:"):
            response = response[7:].strip()
        
        return response
    
    def _format_response(self, result: Any, intent: Dict) -> str:
        """Formatea el resultado para presentación al usuario."""
        if isinstance(result, str):
            formatted = result
        elif isinstance(result, dict):
            formatted = result.get('message', str(result))
        else:
            formatted = str(result)
        
        # Aplicar personalidad si está disponible
        if self.personality:
            context = 'acknowledge' if intent.get('confidence', 0) > 0.5 else 'working'
            formatted = self.personality.format_response(formatted, context)
        
        return formatted
    
    def _handle_error_response(self, error: str) -> str:
        """Formatea mensaje de error."""
        if self.personality:
            return self.personality.format_response(
                f"Disculpe, encontré un problema: {error}",
                context='error'
            )
        return f"Error: {error}"
    
    def _update_stats(self, success: bool, processing_time: float):
        """Actualiza estadísticas de procesamiento."""
        self.stats['commands_processed'] += 1
        
        if success:
            self.stats['commands_success'] += 1
        else:
            self.stats['commands_failed'] += 1
        
        # Promedio móvil de tiempo de procesamiento
        alpha = 0.1
        current_avg = self.stats['average_processing_time']
        self.stats['average_processing_time'] = (
            (1 - alpha) * current_avg + alpha * processing_time
        )
    
    def _generate_command_id(self) -> str:
        """Genera ID único para comando."""
        import uuid
        return f"cmd_{uuid.uuid4().hex[:12]}_{int(time.time()*1000)%10000}"
    
    # ==================== API PÚBLICA ====================
    
    def register_skill(self, name: str, skill_instance, patterns: List[str] = None):
        """
        Registra un nuevo skill dinámicamente.
        
        Args:
            name: Nombre del skill
            skill_instance: Instancia del skill
            patterns: Lista de patrones regex para matching
        """
        self.skills[name] = SkillInfo(
            name=name,
            module_path="dynamic",
            instance=skill_instance,
            enabled=True
        )
        
        if patterns:
            self.skill_patterns[name] = patterns
        
        logger.info(f"Skill registrado dinámicamente: {name}")
    
    def enable_skill(self, name: str) -> bool:
        """Habilita un skill."""
        if name in self.skills:
            self.skills[name].enabled = True
            return True
        return False
    
    def disable_skill(self, name: str) -> bool:
        """Deshabilita un skill."""
        if name in self.skills:
            self.skills[name].enabled = False
            return True
        return False
    
    def get_skills_status(self) -> Dict:
        """Retorna estado de todos los skills."""
        return {
            name: {
                'enabled': info.enabled,
                'use_count': info.use_count,
                'error_count': info.error_count,
                'last_used': info.last_used.isoformat() if info.last_used else None
            }
            for name, info in self.skills.items()
        }
    
    def add_pre_process_hook(self, hook: Callable[[Command], Optional[Command]]):
        """Agrega hook de pre-procesamiento."""
        self.pre_process_hooks.append(hook)
    
    def add_post_process_hook(self, hook: Callable[[Command, Any], None]):
        """Agrega hook de post-procesamiento."""
        self.post_process_hooks.append(hook)
    
    def add_error_handler(self, handler: Callable[[Command, Exception], None]):
        """Agrega manejador de errores."""
        self.error_handlers.append(handler)
    
    def get_status(self) -> Dict:
        """Retorna estado completo del cerebro."""
        return {
            'version': self.version,
            'running': self.running,
            'queue_size': len(self.command_queue),
            'current_command': self.current_command.raw_input[:50] if self.current_command else None,
            'skills_loaded': len(self.skills),
            'stats': self.stats
        }
    
    def learn_from_interaction(self, user_input: str, correct_skill: str,
                                correct_action: str):
        """
        Aprende de una corrección del usuario para mejorar matching futuro.
        """
        # Guardar como patrón adicional
        if correct_skill not in self.skill_patterns:
            self.skill_patterns[correct_skill] = []
        
        # Crear patrón simple de la frase
        pattern = re.escape(user_input.lower())
        pattern = pattern.replace(r'\ ', r'\s+')
        pattern = r'.*' + pattern + r'.*'
        
        if pattern not in self.skill_patterns[correct_skill]:
            self.skill_patterns[correct_skill].append(pattern)
            
            # Guardar en memoria
            if self.memory:
                self.memory.store_pattern(
                    'learned_command',
                    f"{correct_skill}_{hash(user_input)}",
                    {
                        'pattern': pattern,
                        'skill': correct_skill,
                        'action': correct_action,
                        'example': user_input
                    },
                    confidence=0.6
                )
            
            logger.info(f"Aprendido nuevo patrón para {correct_skill}: {user_input[:50]}")