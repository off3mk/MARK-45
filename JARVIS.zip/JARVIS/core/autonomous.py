"""
core/autonomous.py
Motor de Autonomía de JARVIS v4.0 Definitivo

Sistema de comportamiento autónomo que permite a JARVIS actuar proactivamente
sin esperar comandos del usuario. Incluye detección de patrones, predicción
de necesidades, tareas programadas y ejecución automática de rutinas.
"""

import time
import threading
import uuid
import random
from datetime import datetime, timedelta
from typing import Dict, List, Optional, Callable, Any, Set, Tuple
from dataclasses import dataclass, field
from enum import Enum, auto
import json
import os
import logging

logger = logging.getLogger(__name__)


class TriggerType(Enum):
    """Tipos de triggers para tareas autónomas."""
    TIME = "time"              # Basado en hora/fecha
    INTERVAL = "interval"      # Cada X segundos/minutos/horas
    CONDITION = "condition"    # Basado en condición del sistema
    PATTERN = "pattern"        # Basado en patrones detectados
    EVENT = "event"           # Disparado por evento específico
    PREDICTION = "prediction" # Basado en predicción de comportamiento
    PROACTIVE = "proactive"   # Decisión proactiva del sistema


class TaskPriority(Enum):
    """Prioridades de tareas autónomas."""
    CRITICAL = 10    # Ejecutar inmediatamente
    HIGH = 7         # Ejecutar lo antes posible
    NORMAL = 5       # Ejecutar cuando sea conveniente
    LOW = 3          # Ejecutar si hay recursos disponibles
    BACKGROUND = 1   # Ejecutar en segundo plano


@dataclass
class AutonomousTask:
    """
    Representa una tarea autónoma configurable.
    """
    id: str
    name: str
    description: str
    trigger_type: TriggerType
    trigger_config: Dict[str, Any]
    action: str
    action_params: Dict[str, Any]
    priority: TaskPriority = TaskPriority.NORMAL
    enabled: bool = True
    created_at: datetime = field(default_factory=datetime.now)
    last_run: Optional[datetime] = None
    next_run: Optional[datetime] = None
    run_count: int = 0
    success_count: int = 0
    fail_count: int = 0
    max_retries: int = 3
    cooldown_seconds: int = 60
    requires_confirmation: bool = False
    notify_on_complete: bool = False
    metadata: Dict = field(default_factory=dict)
    
    def to_dict(self) -> Dict:
        return {
            'id': self.id,
            'name': self.name,
            'description': self.description,
            'trigger_type': self.trigger_type.value,
            'trigger_config': self.trigger_config,
            'action': self.action,
            'action_params': self.action_params,
            'priority': self.priority.value,
            'enabled': self.enabled,
            'created_at': self.created_at.isoformat(),
            'last_run': self.last_run.isoformat() if self.last_run else None,
            'next_run': self.next_run.isoformat() if self.next_run else None,
            'run_count': self.run_count,
            'success_count': self.success_count,
            'fail_count': self.fail_count
        }


@dataclass
class UserPattern:
    """
    Patrón de comportamiento detectado del usuario.
    """
    pattern_type: str
    pattern_data: Dict[str, Any]
    confidence: float  # 0.0 - 1.0
    first_seen: datetime
    last_seen: datetime
    occurrence_count: int
    typical_times: List[int] = field(default_factory=list)  # Horas típicas (0-23)
    typical_weekdays: List[int] = field(default_factory=list)  # Días típicos (0-6)
    
    def is_active_now(self) -> bool:
        """Verifica si el patrón está activo en este momento."""
        now = datetime.now()
        hour_match = now.hour in self.typical_times if self.typical_times else True
        day_match = now.weekday() in self.typical_weekdays if self.typical_weekdays else True
        return hour_match and day_match


@dataclass
class PredictedNeed:
    """
    Necesidad predicha del usuario basada en patrones.
    """
    need_type: str
    description: str
    confidence: float
    suggested_action: str
    urgency: str  # 'immediate', 'soon', 'later'
    context: Dict[str, Any]


class PatternDetector:
    """
    Detector avanzado de patrones de comportamiento del usuario.
    Utiliza análisis temporal y secuencial para identificar hábitos.
    """
    
    def __init__(self):
        self.patterns: Dict[str, UserPattern] = {}
        self.raw_events: List[Dict] = []
        self.max_events = 1000
    
    def add_event(self, event_type: str, event_data: Dict, timestamp: datetime = None):
        """
        Agrega un evento para análisis de patrones.
        
        Args:
            event_type: Tipo de evento (app_opened, command_executed, etc.)
            event_data: Datos del evento
            timestamp: Momento del evento (default: ahora)
        """
        if timestamp is None:
            timestamp = datetime.now()
        
        event = {
            'type': event_type,
            'data': event_data,
            'timestamp': timestamp,
            'hour': timestamp.hour,
            'weekday': timestamp.weekday()
        }
        
        self.raw_events.append(event)
        
        # Mantener límite de eventos
        if len(self.raw_events) > self.max_events:
            self.raw_events.pop(0)
        
        # Analizar patrones después de agregar evento
        self._analyze_patterns()
    
    def _analyze_patterns(self):
        """Analiza eventos acumulados para detectar patrones."""
        if len(self.raw_events) < 5:
            return
        
        # Analizar patrones horarios
        self._detect_hourly_patterns()
        
        # Analizar secuencias
        self._detect_sequential_patterns()
        
        # Analizar patrones de aplicaciones
        self._detect_app_patterns()
    
    def _detect_hourly_patterns(self):
        """Detecta patrones basados en hora del día."""
        from collections import defaultdict
        
        hourly_events = defaultdict(list)
        for event in self.raw_events:
            key = f"{event['type']}_{event['data'].get('app', 'unknown')}"
            hourly_events[key].append(event['hour'])
        
        for key, hours in hourly_events.items():
            if len(hours) >= 3:
                # Encontrar horas más comunes
                from collections import Counter
                hour_counts = Counter(hours)
                most_common = hour_counts.most_common(3)
                
                if most_common[0][1] >= 3:  # Al menos 3 ocurrencias
                    pattern_id = f"hourly_{key}"
                    
                    if pattern_id not in self.patterns:
                        self.patterns[pattern_id] = UserPattern(
                            pattern_type='hourly',
                            pattern_data={'event_type': key, 'hours': [h[0] for h in most_common]},
                            confidence=min(1.0, most_common[0][1] / 10),
                            first_seen=self.raw_events[0]['timestamp'],
                            last_seen=datetime.now(),
                            occurrence_count=len(hours),
                            typical_times=[h[0] for h in most_common]
                        )
                    else:
                        pattern = self.patterns[pattern_id]
                        pattern.last_seen = datetime.now()
                        pattern.occurrence_count = len(hours)
                        pattern.confidence = min(1.0, pattern.confidence + 0.05)
    
    def _detect_sequential_patterns(self):
        """Detecta secuencias de acciones (e.g., abrir Chrome -> VSCode)."""
        if len(self.raw_events) < 10:
            return
        
        # Buscar transiciones frecuentes
        from collections import defaultdict, Counter
        
        transitions = defaultdict(list)
        
        for i in range(len(self.raw_events) - 1):
            current = self.raw_events[i]
            next_event = self.raw_events[i + 1]
            
            # Solo considerar eventos cercanos en tiempo (< 5 minutos)
            time_diff = (next_event['timestamp'] - current['timestamp']).total_seconds()
            if time_diff < 300:
                key = (current['type'], current['data'].get('app', 'unknown'))
                transitions[key].append((next_event['type'], next_event['data'].get('app', 'unknown')))
        
        # Encontrar transiciones comunes
        for (from_type, from_app), next_events in transitions.items():
            if len(next_events) >= 3:
                counter = Counter(next_events)
                most_common, count = counter.most_common(1)[0]
                
                if count >= 3:
                    pattern_id = f"seq_{from_type}_{from_app}_{most_common[0]}_{most_common[1]}"
                    
                    self.patterns[pattern_id] = UserPattern(
                        pattern_type='sequential',
                        pattern_data={
                            'from': {'type': from_type, 'app': from_app},
                            'to': {'type': most_common[0], 'app': most_common[1]},
                            'probability': count / len(next_events)
                        },
                        confidence=min(1.0, count / 10),
                        first_seen=self.raw_events[0]['timestamp'],
                        last_seen=datetime.now(),
                        occurrence_count=count
                    )
    
    def _detect_app_patterns(self):
        """Detecta patrones específicos de uso de aplicaciones."""
        from collections import defaultdict
        
        app_usage = defaultdict(lambda: {'count': 0, 'hours': [], 'weekdays': []})
        
        for event in self.raw_events:
            if event['type'] == 'app_opened':
                app = event['data'].get('app', 'unknown')
                app_usage[app]['count'] += 1
                app_usage[app]['hours'].append(event['hour'])
                app_usage[app]['weekdays'].append(event['weekday'])
        
        for app, data in app_usage.items():
            if data['count'] >= 5:
                pattern_id = f"app_usage_{app}"
                
                # Calcular horas y días típicos
                from collections import Counter
                typical_hours = [h[0] for h in Counter(data['hours']).most_common(3)]
                typical_days = [d[0] for d in Counter(data['weekdays']).most_common(3)]
                
                if pattern_id not in self.patterns:
                    self.patterns[pattern_id] = UserPattern(
                        pattern_type='app_usage',
                        pattern_data={'app': app, 'total_uses': data['count']},
                        confidence=min(1.0, data['count'] / 20),
                        first_seen=self.raw_events[0]['timestamp'],
                        last_seen=datetime.now(),
                        occurrence_count=data['count'],
                        typical_times=typical_hours,
                        typical_weekdays=typical_days
                    )
                else:
                    self.patterns[pattern_id].last_seen = datetime.now()
                    self.patterns[pattern_id].occurrence_count = data['count']
    
    def get_active_patterns(self) -> List[UserPattern]:
        """Retorna patrones que están activos en este momento."""
        return [p for p in self.patterns.values() if p.is_active_now()]
    
    def get_pattern(self, pattern_id: str) -> Optional[UserPattern]:
        """Obtiene un patrón específico por ID."""
        return self.patterns.get(pattern_id)
    
    def get_all_patterns(self) -> Dict[str, UserPattern]:
        """Retorna todos los patrones detectados."""
        return self.patterns.copy()
    
    def clear_old_patterns(self, max_age_days: int = 30):
        """Elimina patrones antiguos no actualizados."""
        cutoff = datetime.now() - timedelta(days=max_age_days)
        to_remove = [
            pid for pid, p in self.patterns.items() 
            if p.last_seen < cutoff
        ]
        for pid in to_remove:
            del self.patterns[pid]


class BehaviorPredictor:
    """
    Predictor de comportamiento basado en patrones detectados.
    """
    
    def __init__(self, pattern_detector: PatternDetector):
        self.pattern_detector = pattern_detector
        self.context_history: List[Dict] = []
        self.max_context = 50
    
    def update_context(self, context: Dict):
        """Actualiza el contexto actual del sistema."""
        self.context_history.append({
            'timestamp': datetime.now(),
            'context': context
        })
        
        if len(self.context_history) > self.max_context:
            self.context_history.pop(0)
    
    def predict_next_action(self) -> List[PredictedNeed]:
        """
        Predice próximas acciones basadas en patrones y contexto.
        
        Returns:
            Lista de necesidades predichas ordenadas por confianza
        """
        predictions = []
        current_time = datetime.now()
        
        # Obtener patrones activos
        active_patterns = self.pattern_detector.get_active_patterns()
        
        for pattern in active_patterns:
            if pattern.confidence < 0.3:
                continue
            
            if pattern.pattern_type == 'hourly':
                # Predecir acción basada en hora
                predictions.append(PredictedNeed(
                    need_type='routine',
                    description=f"Rutina habitual: {pattern.pattern_data.get('event_type', 'actividad')}",
                    confidence=pattern.confidence,
                    suggested_action='execute_routine',
                    urgency='soon',
                    context={'pattern': pattern}
                ))
            
            elif pattern.pattern_type == 'sequential':
                # Predecir siguiente paso en secuencia
                to_data = pattern.pattern_data.get('to', {})
                predictions.append(PredictedNeed(
                    need_type='continuation',
                    description=f"Continuar con {to_data.get('app', 'siguiente paso')}",
                    confidence=pattern.confidence * pattern.pattern_data.get('probability', 0.5),
                    suggested_action='open_program',
                    urgency='immediate',
                    context={'target_app': to_data.get('app')}
                ))
            
            elif pattern.pattern_type == 'app_usage':
                # Sugerir abrir aplicación habitual
                app = pattern.pattern_data.get('app')
                predictions.append(PredictedNeed(
                    need_type='app_suggestion',
                    description=f"¿Abrir {app}? Es su hora habitual de uso",
                    confidence=pattern.confidence,
                    suggested_action='open_program',
                    urgency='soon',
                    context={'program': app}
                ))
        
        # Ordenar por confianza
        predictions.sort(key=lambda x: x.confidence, reverse=True)
        
        return predictions
    
    def predict_system_needs(self, system_state: Dict) -> List[PredictedNeed]:
        """
        Predice necesidades del sistema basadas en estado actual.
        """
        predictions = []
        
        # Predecir necesidad de optimización
        if system_state.get('cpu_percent', 0) > 80:
            predictions.append(PredictedNeed(
                need_type='optimization',
                description="Sistema bajo carga alta, optimización recomendada",
                confidence=0.8,
                suggested_action='optimize_system',
                urgency='soon',
                context={'reason': 'high_cpu'}
            ))
        
        if system_state.get('memory_percent', 0) > 85:
            predictions.append(PredictedNeed(
                need_type='optimization',
                description="Memoria saturada, liberación recomendada",
                confidence=0.9,
                suggested_action='optimize_memory',
                urgency='immediate',
                context={'reason': 'high_memory'}
            ))
        
        # Predecir necesidad de descanso
        uptime_hours = system_state.get('uptime_seconds', 0) / 3600
        if uptime_hours > 4:
            predictions.append(PredictedNeed(
                need_type='wellness',
                description="Lleva varias horas de trabajo, descanso recomendado",
                confidence=min(0.9, uptime_hours / 10),
                suggested_action='suggest_break',
                urgency='later',
                context={'uptime_hours': uptime_hours}
            ))
        
        return predictions


class AutonomousEngine:
    """
    Motor de autonomía principal de JARVIS.
    
    Gestiona tareas autónomas, detecta patrones, predice necesidades
    y ejecuta acciones proactivas sin intervención del usuario.
    """
    
    # Rutinas predefinidas
    DEFAULT_ROUTINES = {
        'morning_setup': {
            'name': 'Configuración Matutina',
            'description': 'Prepara el entorno de trabajo por la mañana',
            'apps': ['chrome', 'vscode', 'spotify'],
            'volume': 30,
            'notifications': True
        },
        'focus_mode': {
            'name': 'Modo Enfoque',
            'description': 'Minimiza distracciones para trabajo concentrado',
            'close_apps': ['discord', 'telegram', 'whatsapp'],
            'volume': 10,
            'notifications': False,
            'focus_assist': True
        },
        'relax_mode': {
            'name': 'Modo Relajación',
            'description': 'Ambiente relajado para descanso',
            'apps': ['spotify'],
            'volume': 40,
            'lighting': 'warm',
            'notifications': False
        },
        'end_workday': {
            'name': 'Fin de Jornada',
            'description': 'Cierra aplicaciones de trabajo y respalda',
            'close_work_apps': True,
            'backup_workspace': True,
            'system_cleanup': True
        }
    }
    
    def __init__(self, state_engine, cognitive_memory, skill_manager):
        """
        Inicializa el motor de autonomía.
        
        Args:
            state_engine: Motor de estado para acceso a métricas
            cognitive_memory: Memoria para persistir patrones
            skill_manager: Gestor de skills para ejecutar acciones
        """
        self.state = state_engine
        self.memory = cognitive_memory
        self.skills = skill_manager
        
        self.running = False
        self.autonomous_thread: Optional[threading.Thread] = None
        self._stop_event = threading.Event()
        
        # Componentes
        self.pattern_detector = PatternDetector()
        self.behavior_predictor = BehaviorPredictor(self.pattern_detector)
        
        # Tareas autónomas
        self.tasks: Dict[str, AutonomousTask] = {}
        self.task_queue: List[str] = []  # IDs de tareas ordenadas por prioridad
        
        # Handlers de acciones
        self.action_handlers: Dict[str, Callable] = {}
        self.routine_handlers: Dict[str, Callable] = {}
        
        # Callbacks
        self.suggestion_callbacks: List[Callable[[PredictedNeed], None]] = []
        self.task_callbacks: List[Callable[[str, AutonomousTask, str], None]] = []
        
        # Configuración
        self.check_interval = 5.0  # segundos
        self.max_concurrent_tasks = 3
        self.active_tasks: Set[str] = set()
        
        # Cargar tareas guardadas
        self._load_tasks()
        self._setup_default_tasks()
        
        logger.info("AutonomousEngine inicializado")
    
    def _setup_default_tasks(self):
        """Configura tareas autónomas por defecto."""
        default_tasks = [
            AutonomousTask(
                id="health_monitor",
                name="Monitoreo de Salud del Sistema",
                description="Monitorea continuamente el estado del sistema y alerta sobre problemas",
                trigger_type=TriggerType.CONDITION,
                trigger_config={
                    'condition': 'low_health',
                    'threshold': 40,
                    'check_interval': 30
                },
                action="optimize_system",
                action_params={'aggressive': False},
                priority=TaskPriority.HIGH,
                notify_on_complete=False
            ),
            AutonomousTask(
                id="morning_routine",
                name="Rutina Matutina",
                description="Prepara el entorno de trabajo a las 8:00 AM en días laborables",
                trigger_type=TriggerType.TIME,
                trigger_config={
                    'hour': 8,
                    'minute': 0,
                    'weekdays': [0, 1, 2, 3, 4],  # Lunes a Viernes
                    'timezone': 'local'
                },
                action="execute_routine",
                action_params={'routine': 'morning_setup'},
                priority=TaskPriority.NORMAL,
                requires_confirmation=False,
                notify_on_complete=True
            ),
            AutonomousTask(
                id="focus_mode_detector",
                name="Detector de Modo Enfoque",
                description="Activa modo enfoque cuando detecta trabajo intenso",
                trigger_type=TriggerType.PATTERN,
                trigger_config={
                    'pattern': 'coding_detected',
                    'duration_minutes': 5,
                    'consecutive': True
                },
                action="execute_routine",
                action_params={'routine': 'focus_mode'},
                priority=TaskPriority.LOW,
                requires_confirmation=True,
                cooldown_seconds=3600  # 1 hora entre activaciones
            ),
            AutonomousTask(
                id="cleanup_idle",
                name="Limpieza de Inactividad",
                description="Libera recursos cuando el usuario está inactivo",
                trigger_type=TriggerType.CONDITION,
                trigger_config={
                    'condition': 'user_idle',
                    'duration_minutes': 30,
                    'close_unused_apps': True,
                    'clear_cache': True
                },
                action="cleanup_resources",
                action_params={'level': 'light'},
                priority=TaskPriority.LOW,
                notify_on_complete=False
            ),
            AutonomousTask(
                id="pattern_learning",
                name="Aprendizaje de Patrones",
                description="Analiza comportamiento del usuario periódicamente",
                trigger_type=TriggerType.INTERVAL,
                trigger_config={
                    'interval_minutes': 60
                },
                action="analyze_patterns",
                action_params={},
                priority=TaskPriority.BACKGROUND,
                notify_on_complete=False
            ),
            AutonomousTask(
                id="evening_backup",
                name="Respaldo Nocturno",
                description="Realiza respaldo del workspace a las 11:00 PM",
                trigger_type=TriggerType.TIME,
                trigger_config={
                    'hour': 23,
                    'minute': 0
                },
                action="backup_workspace",
                action_params={'full': False},
                priority=TaskPriority.NORMAL,
                notify_on_complete=True
            )
        ]
        
        for task in default_tasks:
            if task.id not in self.tasks:
                self.tasks[task.id] = task
                logger.info(f"Tarea por defecto agregada: {task.name}")
    
    def _load_tasks(self):
        """Carga tareas autónomas guardadas."""
        path = "memory/autonomous_tasks.json"
        if not os.path.exists(path):
            return
        
        try:
            with open(path, 'r', encoding='utf-8') as f:
                data = json.load(f)
            
            for task_data in data:
                # Convertir enums
                task_data['trigger_type'] = TriggerType(task_data['trigger_type'])
                task_data['priority'] = TaskPriority(task_data['priority'])
                
                # Convertir fechas
                for field in ['created_at', 'last_run', 'next_run']:
                    if task_data.get(field):
                        task_data[field] = datetime.fromisoformat(task_data[field])
                
                task = AutonomousTask(**task_data)
                self.tasks[task.id] = task
            
            logger.info(f"{len(self.tasks)} tareas cargadas")
            
        except Exception as e:
            logger.error(f"Error cargando tareas: {e}")
    
    def _save_tasks(self):
        """Persiste tareas autónomas a disco."""
        try:
            os.makedirs("memory", exist_ok=True)
            path = "memory/autonomous_tasks.json"
            
            data = [task.to_dict() for task in self.tasks.values()]
            
            with open(path, 'w', encoding='utf-8') as f:
                json.dump(data, f, indent=2, ensure_ascii=False)
                
        except Exception as e:
            logger.error(f"Error guardando tareas: {e}")
    
    def register_action_handler(self, action: str, handler: Callable):
        """
        Registra un manejador para una acción autónoma.
        
        Args:
            action: Nombre de la acción
            handler: Función que ejecuta la acción
        """
        self.action_handlers[action] = handler
        logger.debug(f"Handler registrado para acción: {action}")
    
    def register_routine_handler(self, routine: str, handler: Callable):
        """Registra un manejador para una rutina."""
        self.routine_handlers[routine] = handler
    
    def start(self):
        """Inicia el motor de autonomía."""
        if self.running:
            logger.warning("AutonomousEngine ya está corriendo")
            return
        
        logger.info("Iniciando AutonomousEngine...")
        self.running = True
        self._stop_event.clear()
        
        self.autonomous_thread = threading.Thread(
            target=self._autonomy_loop,
            name="AutonomousEngine",
            daemon=True
        )
        self.autonomous_thread.start()
        
        logger.info("AutonomousEngine iniciado")
    
    def stop(self):
        """Detiene el motor de autonomía."""
        if not self.running:
            return
        
        logger.info("Deteniendo AutonomousEngine...")
        self.running = False
        self._stop_event.set()
        
        if self.autonomous_thread and self.autonomous_thread.is_alive():
            self.autonomous_thread.join(timeout=5.0)
        
        self._save_tasks()
        logger.info("AutonomousEngine detenido")
    
    def _autonomy_loop(self):
        """Loop principal de autonomía."""
        logger.info("Loop de autonomía iniciado")
        
        while self.running and not self._stop_event.is_set():
            try:
                loop_start = time.time()
                
                # 1. Evaluar triggers de tareas programadas
                self._evaluate_scheduled_tasks()
                
                # 2. Evaluar triggers condicionales
                self._evaluate_conditional_tasks()
                
                # 3. Procesar cola de tareas
                self._process_task_queue()
                
                # 4. Generar predicciones y sugerencias
                self._generate_predictions()
                
                # 5. Verificar si debe actuar proactivamente
                if self._should_act_proactively():
                    self._proactive_action()
                
                # Calcular tiempo de espera
                elapsed = time.time() - loop_start
                sleep_time = max(0, self.check_interval - elapsed)
                
                if sleep_time > 0:
                    self._stop_event.wait(sleep_time)
                
            except Exception as e:
                logger.error(f"Error en loop de autonomía: {e}")
                time.sleep(10)
    
    def _evaluate_scheduled_tasks(self):
        """Evalúa tareas basadas en tiempo."""
        now = datetime.now()
        
        for task in self.tasks.values():
            if not task.enabled or task.id in self.active_tasks:
                continue
            
            if task.trigger_type == TriggerType.TIME:
                config = task.trigger_config
                if now.hour == config.get('hour') and now.minute == config.get('minute'):
                    # Verificar día de la semana si está especificado
                    weekdays = config.get('weekdays')
                    if weekdays is None or now.weekday() in weekdays:
                        # Verificar cooldown
                        if self._check_cooldown(task):
                            self._queue_task(task)
            
            elif task.trigger_type == TriggerType.INTERVAL:
                if task.last_run is None:
                    should_run = True
                else:
                    interval = timedelta(minutes=task.trigger_config.get('interval_minutes', 60))
                    should_run = (now - task.last_run) >= interval
                
                if should_run and self._check_cooldown(task):
                    self._queue_task(task)
    
    def _evaluate_conditional_tasks(self):
        """Evalúa tareas basadas en condiciones del sistema."""
        state = self.state.get_current_state()
        
        for task in self.tasks.values():
            if not task.enabled or task.id in self.active_tasks:
                continue
            
            if task.trigger_type != TriggerType.CONDITION:
                continue
            
            config = task.trigger_config
            condition = config.get('condition')
            should_trigger = False
            
            if condition == 'low_health':
                threshold = config.get('threshold', 40)
                if state.system_health < threshold:
                    should_trigger = True
            
            elif condition == 'user_idle':
                if not state.user_present and state.user_last_seen:
                    idle_time = (datetime.now() - state.user_last_seen).total_seconds()
                    threshold = config.get('duration_minutes', 30) * 60
                    if idle_time > threshold:
                        should_trigger = True
            
            elif condition == 'high_load':
                if state.system_load.value in ['heavy', 'critical']:
                    should_trigger = True
            
            if should_trigger and self._check_cooldown(task):
                self._queue_task(task)
    
    def _check_cooldown(self, task: AutonomousTask) -> bool:
        """Verifica si el cooldown de una tarea ha pasado."""
        if task.last_run is None:
            return True
        
        cooldown = timedelta(seconds=task.cooldown_seconds)
        return (datetime.now() - task.last_run) >= cooldown
    
    def _queue_task(self, task: AutonomousTask):
        """Agrega una tarea a la cola de ejecución."""
        if task.id not in self.task_queue:
            # Insertar manteniendo orden por prioridad
            insert_pos = 0
            for i, queued_id in enumerate(self.task_queue):
                queued_task = self.tasks[queued_id]
                if queued_task.priority.value < task.priority.value:
                    insert_pos = i + 1
                else:
                    break
            
            self.task_queue.insert(insert_pos, task.id)
            task.next_run = datetime.now()
            
            logger.info(f"Tarea '{task.name}' agregada a la cola (prioridad: {task.priority.name})")
    
    def _process_task_queue(self):
        """Procesa tareas en la cola."""
        # Limitar tareas concurrentes
        available_slots = self.max_concurrent_tasks - len(self.active_tasks)
        
        if available_slots <= 0 or not self.task_queue:
            return
        
        # Tomar las tareas de mayor prioridad
        to_execute = self.task_queue[:available_slots]
        self.task_queue = self.task_queue[available_slots:]
        
        for task_id in to_execute:
            self._execute_task(task_id)
    
    def _execute_task(self, task_id: str):
        """Ejecuta una tarea autónoma."""
        task = self.tasks.get(task_id)
        if not task:
            return
        
        self.active_tasks.add(task_id)
        task.last_run = datetime.now()
        task.run_count += 1
        
        logger.info(f"Ejecutando tarea autónoma: {task.name}")
        
        # Notificar inicio
        self._notify_task_callbacks(task_id, task, "started")
        
        try:
            # Verificar si requiere confirmación
            if task.requires_confirmation:
                # En implementación real, esto mostraría UI de confirmación
                confirmed = self._request_confirmation(task)
                if not confirmed:
                    logger.info(f"Tarea '{task.name}' cancelada por falta de confirmación")
                    task.status = "cancelled"
                    self.active_tasks.discard(task_id)
                    return
            
            # Ejecutar acción
            handler = self.action_handlers.get(task.action)
            if not handler:
                raise ValueError(f"No hay handler para acción: {task.action}")
            
            result = handler(**task.action_params)
            
            # Marcar como exitosa
            task.success_count += 1
            task.status = "completed"
            
            if task.notify_on_complete:
                self._notify_completion(task, result)
            
            logger.info(f"Tarea '{task.name}' completada exitosamente")
            self._notify_task_callbacks(task_id, task, "completed")
            
        except Exception as e:
            logger.error(f"Error ejecutando tarea '{task.name}': {e}")
            task.fail_count += 1
            task.status = "failed"
            
            # Reintentar si es necesario
            if task.fail_count < task.max_retries:
                self.task_queue.append(task_id)
                logger.info(f"Reencolando tarea '{task.name}' (intento {task.fail_count + 1})")
            
            self._notify_task_callbacks(task_id, task, "failed")
        
        finally:
            self.active_tasks.discard(task_id)
    
    def _request_confirmation(self, task: AutonomousTask) -> bool:
        """
        Solicita confirmación al usuario para ejecutar una tarea.
        En implementación real, esto mostraría una UI de confirmación.
        """
        # Por ahora, auto-confirmar tareas de bajo impacto
        if task.priority.value <= TaskPriority.LOW.value:
            return True
        
        # Para tareas de alto impacto, simular confirmación
        # (en producción, esto esperaría respuesta del usuario)
        logger.info(f"Solicitando confirmación para: {task.name}")
        return True  # Simulado
    
    def _notify_completion(self, task: AutonomousTask, result: Any):
        """Notifica al usuario la finalización de una tarea."""
        # En implementación real, esto usaría el sistema de notificaciones
        logger.info(f"Tarea completada: {task.name}")
    
    def _generate_predictions(self):
        """Genera predicciones basadas en patrones y comportamiento."""
        # Actualizar predictor con contexto actual
        state = self.state.get_current_state()
        
        context = {
            'mood': state.mood.value,
            'system_load': state.system_load.value,
            'active_tasks': len(state.active_tasks),
            'user_present': state.user_present
        }
        
        self.behavior_predictor.update_context(context)
        
        # Obtener predicciones
        behavior_predictions = self.behavior_predictor.predict_next_action()
        system_predictions = self.behavior_predictor.predict_system_needs(
            state.current_metrics.to_dict() if state.current_metrics else {}
        )
        
        all_predictions = behavior_predictions + system_predictions
        all_predictions.sort(key=lambda x: x.confidence, reverse=True)
        
        # Notificar predicciones de alta confianza
        for prediction in all_predictions[:3]:  # Top 3
            if prediction.confidence > 0.6:
                self._notify_suggestion(prediction)
    
    def _should_act_proactively(self) -> bool:
        """Determina si JARVIS debe actuar proactivamente."""
        return self.state.should_proactively_act()
    
    def _proactive_action(self):
        """Ejecuta acción proactiva basada en el estado actual."""
        state = self.state.get_current_state()
        
        if state.system_health < 30:
            # Sistema en estado crítico
            if "emergency_optimize" in self.action_handlers:
                self.action_handlers["emergency_optimize"]()
                self.state._update_mood(EmotionalState.OPTIMIZING, 0.9)
        
        elif state.system_health < 50:
            # Sistema degradado
            if "optimize_system" in self.action_handlers:
                self.action_handlers["optimize_system"](aggressive=True)
                self.state._update_mood(EmotionalState.OPTIMIZING, 0.8)
    
    def _notify_suggestion(self, prediction: PredictedNeed):
        """Notifica una sugerencia a los callbacks registrados."""
        for callback in self.suggestion_callbacks:
            try:
                callback(prediction)
            except Exception as e:
                logger.error(f"Error en suggestion callback: {e}")
    
    def _notify_task_callbacks(self, task_id: str, task: AutonomousTask, event: str):
        """Notifica eventos de tareas a los callbacks."""
        for callback in self.task_callbacks:
            try:
                callback(task_id, task, event)
            except Exception as e:
                logger.error(f"Error en task callback: {e}")
    
    # ==================== API PÚBLICA ====================
    
    def add_task(self, name: str, description: str, trigger_type: TriggerType,
                trigger_config: Dict, action: str, action_params: Dict = None,
                priority: TaskPriority = TaskPriority.NORMAL,
                requires_confirmation: bool = False,
                cooldown_seconds: int = 60) -> str:
        """
        Agrega una nueva tarea autónoma personalizada.
        
        Returns:
            ID de la tarea creada
        """
        task_id = f"custom_{uuid.uuid4().hex[:8]}"
        
        task = AutonomousTask(
            id=task_id,
            name=name,
            description=description,
            trigger_type=trigger_type,
            trigger_config=trigger_config,
            action=action,
            action_params=action_params or {},
            priority=priority,
            requires_confirmation=requires_confirmation,
            cooldown_seconds=cooldown_seconds
        )
        
        self.tasks[task_id] = task
        self._save_tasks()
        
        logger.info(f"Tarea personalizada agregada: {name} (ID: {task_id})")
        return task_id
    
    def remove_task(self, task_id: str) -> bool:
        """Elimina una tarea autónoma."""
        if task_id in self.tasks:
            del self.tasks[task_id]
            self._save_tasks()
            logger.info(f"Tarea eliminada: {task_id}")
            return True
        return False
    
    def enable_task(self, task_id: str) -> bool:
        """Habilita una tarea."""
        if task_id in self.tasks:
            self.tasks[task_id].enabled = True
            self._save_tasks()
            return True
        return False
    
    def disable_task(self, task_id: str) -> bool:
        """Deshabilita una tarea."""
        if task_id in self.tasks:
            self.tasks[task_id].enabled = False
            self._save_tasks()
            return True
        return False
    
    def record_user_event(self, event_type: str, event_data: Dict):
        """
        Registra un evento de usuario para análisis de patrones.
        """
        self.pattern_detector.add_event(event_type, event_data)
        
        # También guardar en memoria cognitiva si está disponible
        if self.memory:
            self.memory.store_event(
                event_type=event_type,
                description=f"Evento de usuario: {event_type}",
                importance=3,
                context=event_data,
                tags=['user_behavior', 'pattern_learning']
            )
    
    def get_suggestions(self) -> List[PredictedNeed]:
        """
        Obtiene sugerencias proactivas basadas en el contexto actual.
        """
        state = self.state.get_current_state()
        
        suggestions = []
        
        # Sugerencias basadas en patrones
        predictions = self.behavior_predictor.predict_next_action()
        suggestions.extend([p for p in predictions if p.confidence > 0.4])
        
        # Sugerencias basadas en estado del sistema
        if state.system_health < 60:
            suggestions.append(PredictedNeed(
                need_type='maintenance',
                description="El sistema está funcionando por debajo del óptimo",
                confidence=0.8,
                suggested_action='optimize_system',
                urgency='soon',
                context={'health': state.system_health}
            ))
        
        # Sugerencias basadas en tiempo de uso
        if state.uptime_seconds > 14400:  # 4 horas
            suggestions.append(PredictedNeed(
                need_type='wellness',
                description="Lleva 4 horas de trabajo continuo",
                confidence=0.7,
                suggested_action='suggest_break',
                urgency='later',
                context={'uptime': state.uptime_seconds}
            ))
        
        # Ordenar por confianza
        suggestions.sort(key=lambda x: x.confidence, reverse=True)
        
        return suggestions
    
    def get_active_patterns(self) -> List[UserPattern]:
        """Retorna patrones de comportamiento activos."""
        return self.pattern_detector.get_active_patterns()
    
    def execute_routine(self, routine_name: str, params: Dict = None) -> bool:
        """
        Ejecuta una rutina predefinida.
        
        Args:
            routine_name: Nombre de la rutina
            params: Parámetros adicionales
        
        Returns:
            True si se ejecutó correctamente
        """
        if routine_name not in self.DEFAULT_ROUTINES:
            logger.error(f"Rutina desconocida: {routine_name}")
            return False
        
        routine = self.DEFAULT_ROUTINES[routine_name]
        logger.info(f"Ejecutando rutina: {routine['name']}")
        
        handler = self.routine_handlers.get(routine_name)
        if handler:
            try:
                handler(routine, params or {})
                return True
            except Exception as e:
                logger.error(f"Error ejecutando rutina: {e}")
                return False
        
        # Ejecución por defecto
        return self._execute_default_routine(routine, params or {})
    
    def _execute_default_routine(self, routine: Dict, params: Dict) -> bool:
        """Ejecuta una rutina con comportamiento por defecto."""
        try:
            # Abrir aplicaciones
            for app in routine.get('apps', []):
                if 'open_program' in self.action_handlers:
                    self.action_handlers['open_program'](program=app)
            
            # Ajustar volumen
            if 'volume' in routine and 'set_volume' in self.action_handlers:
                self.action_handlers['set_volume'](level=routine['volume'])
            
            return True
        except Exception as e:
            logger.error(f"Error en rutina por defecto: {e}")
            return False
    
    def get_task_status(self, task_id: str) -> Optional[Dict]:
        """Obtiene estado de una tarea."""
        if task_id not in self.tasks:
            return None
        
        task = self.tasks[task_id]
        return {
            'id': task.id,
            'name': task.name,
            'enabled': task.enabled,
            'status': task.status,
            'run_count': task.run_count,
            'success_count': task.success_count,
            'fail_count': task.fail_count,
            'last_run': task.last_run.isoformat() if task.last_run else None,
            'next_run': task.next_run.isoformat() if task.next_run else None
        }
    
    def get_all_tasks(self) -> List[Dict]:
        """Retorna información de todas las tareas."""
        return [self.get_task_status(tid) for tid in self.tasks.keys()]
    
    def register_suggestion_callback(self, callback: Callable[[PredictedNeed], None]):
        """Registra callback para sugerencias."""
        self.suggestion_callbacks.append(callback)
    
    def register_task_callback(self, callback: Callable[[str, AutonomousTask, str], None]):
        """Registra callback para eventos de tareas."""
        self.task_callbacks.append(callback)
    
    def is_running(self) -> bool:
        """Retorna si el motor está corriendo."""
        return self.running