"""
core/cognitive_memory.py
Sistema de Memoria Cognitiva de JARVIS v4.0 Definitivo

Implementa una memoria persistente y estructurada que permite a JARVIS
recordar información a largo plazo, aprender patrones y mantener contexto
conversacional. Incluye memoria episódica, semántica y procedimental.
"""

import sqlite3
import json
import os
import time
import hashlib
import pickle
from datetime import datetime, timedelta
from typing import Dict, List, Optional, Any, Tuple, Set
from dataclasses import dataclass, asdict
from contextlib import contextmanager
import threading
import logging

logger = logging.getLogger(__name__)


@dataclass
class MemoryEntry:
    """
    Entrada individual en la memoria de JARVIS.
    """
    id: Optional[int] = None
    timestamp: datetime = None
    memory_type: str = "episodic"  # episodic, semantic, procedural, emotional
    category: str = "general"
    key: str = ""
    value: Any = None
    importance: int = 5  # 1-10
    confidence: float = 1.0  # 0.0-1.0
    context: Dict = None
    tags: List[str] = None
    expiration: Optional[datetime] = None
    access_count: int = 0
    last_accessed: Optional[datetime] = None
    
    def __post_init__(self):
        if self.timestamp is None:
            self.timestamp = datetime.now()
        if self.context is None:
            self.context = {}
        if self.tags is None:
            self.tags = []
    
    def to_dict(self) -> Dict:
        return {
            'id': self.id,
            'timestamp': self.timestamp.isoformat() if self.timestamp else None,
            'memory_type': self.memory_type,
            'category': self.category,
            'key': self.key,
            'value': self.value,
            'importance': self.importance,
            'confidence': self.confidence,
            'context': self.context,
            'tags': self.tags,
            'expiration': self.expiration.isoformat() if self.expiration else None,
            'access_count': self.access_count,
            'last_accessed': self.last_accessed.isoformat() if self.last_accessed else None
        }


@dataclass
class UserPreference:
    """
    Preferencia específica del usuario aprendida por JARVIS.
    """
    category: str
    key: str
    value: Any
    confidence: float = 1.0
    source: str = "explicit"  # explicit, inferred, learned
    first_observed: datetime = None
    last_updated: datetime = None
    update_count: int = 1
    context: Dict = None
    
    def __post_init__(self):
        if self.first_observed is None:
            self.first_observed = datetime.now()
        if self.last_updated is None:
            self.last_updated = datetime.now()
        if self.context is None:
            self.context = {}
    
    def update(self, new_value: Any, confidence: float = 1.0):
        """Actualiza la preferencia con nuevo valor."""
        self.value = new_value
        self.confidence = min(1.0, self.confidence + 0.1)
        self.last_updated = datetime.now()
        self.update_count += 1


@dataclass
class ConversationContext:
    """
    Contexto de una conversación con el usuario.
    """
    session_id: str
    started_at: datetime
    messages: List[Dict] = None
    topics: List[str] = None
    user_intent: str = ""
    jarvis_actions: List[str] = None
    emotional_tone: str = "neutral"
    
    def __post_init__(self):
        if self.messages is None:
            self.messages = []
        if self.topics is None:
            self.topics = []
        if self.jarvis_actions is None:
            self.jarvis_actions = []
    
    def add_message(self, speaker: str, content: str, metadata: Dict = None):
        """Agrega un mensaje al contexto."""
        self.messages.append({
            'timestamp': datetime.now().isoformat(),
            'speaker': speaker,
            'content': content,
            'metadata': metadata or {}
        })
        # Mantener solo últimos 50 mensajes
        if len(self.messages) > 50:
            self.messages = self.messages[-50:]
    
    def add_action(self, action: str, result: str):
        """Registra una acción ejecutada por JARVIS."""
        self.jarvis_actions.append({
            'timestamp': datetime.now().isoformat(),
            'action': action,
            'result': result
        })


class CognitiveMemory:
    """
    Sistema de memoria cognitiva completo de JARVIS.
    
    Proporciona:
    - Memoria episódica: eventos y experiencias
    - Memoria semántica: hechos y conocimientos
    - Memoria procedimental: cómo hacer cosas
    - Memoria a corto plazo: contexto conversacional
    - Memoria a largo plazo: preferencias y patrones
    """
    
    def __init__(self, db_path: str = "memory/cognitive.db",
                 cache_size: int = 1000):
        """
        Inicializa el sistema de memoria cognitiva.
        
        Args:
            db_path: Ruta a la base de datos SQLite
            cache_size: Tamaño máximo de caché en memoria
        """
        self.db_path = db_path
        self.cache_size = cache_size
        
        # Caché en memoria para acceso rápido
        self._cache: Dict[str, Any] = {}
        self._cache_order: List[str] = []  # Para LRU
        
        # Contexto de conversación actual
        self.current_context: Optional[ConversationContext] = None
        
        # Lock para thread-safety
        self._lock = threading.RLock()
        
        # Estadísticas
        self.stats = {
            'queries': 0,
            'cache_hits': 0,
            'stores': 0,
            'updates': 0
        }
        
        # Asegurar que existe el directorio
        os.makedirs(os.path.dirname(db_path), exist_ok=True)
        
        # Inicializar base de datos
        self._init_database()
        
        logger.info(f"CognitiveMemory inicializada: {db_path}")
    
    def _init_database(self):
        """Crea las tablas necesarias en SQLite."""
        with self._get_connection() as conn:
            cursor = conn.cursor()
            
            # Tabla principal de memoria
            cursor.execute("""
                CREATE TABLE IF NOT EXISTS memory_entries (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    timestamp TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                    memory_type TEXT NOT NULL,
                    category TEXT NOT NULL,
                    key TEXT NOT NULL,
                    value TEXT NOT NULL,
                    importance INTEGER DEFAULT 5,
                    confidence REAL DEFAULT 1.0,
                    context TEXT DEFAULT '{}',
                    tags TEXT DEFAULT '[]',
                    expiration TIMESTAMP,
                    access_count INTEGER DEFAULT 0,
                    last_accessed TIMESTAMP
                )
            """)
            
            # Índices para búsqueda eficiente
            cursor.execute("""
                CREATE INDEX IF NOT EXISTS idx_memory_type 
                ON memory_entries(memory_type)
            """)
            cursor.execute("""
                CREATE INDEX IF NOT EXISTS idx_category 
                ON memory_entries(category)
            """)
            cursor.execute("""
                CREATE INDEX IF NOT EXISTS idx_key 
                ON memory_entries(key)
            """)
            cursor.execute("""
                CREATE INDEX IF NOT EXISTS idx_timestamp 
                ON memory_entries(timestamp)
            """)
            
            # Tabla de preferencias de usuario
            cursor.execute("""
                CREATE TABLE IF NOT EXISTS user_preferences (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    category TEXT NOT NULL,
                    key TEXT UNIQUE NOT NULL,
                    value TEXT NOT NULL,
                    confidence REAL DEFAULT 1.0,
                    source TEXT DEFAULT 'explicit',
                    first_observed TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                    last_updated TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                    update_count INTEGER DEFAULT 1,
                    context TEXT DEFAULT '{}'
                )
            """)
            
            # Tabla de conversaciones
            cursor.execute("""
                CREATE TABLE IF NOT EXISTS conversations (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    session_id TEXT UNIQUE NOT NULL,
                    started_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                    ended_at TIMESTAMP,
                    message_count INTEGER DEFAULT 0,
                    topics TEXT DEFAULT '[]',
                    summary TEXT,
                    context_data TEXT DEFAULT '{}'
                )
            """)
            
            # Tabla de mensajes
            cursor.execute("""
                CREATE TABLE IF NOT EXISTS messages (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    conversation_id INTEGER,
                    timestamp TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                    speaker TEXT NOT NULL,
                    content TEXT NOT NULL,
                    metadata TEXT DEFAULT '{}',
                    FOREIGN KEY (conversation_id) REFERENCES conversations(id)
                )
            """)
            
            # Tabla de patrones aprendidos
            cursor.execute("""
                CREATE TABLE IF NOT EXISTS learned_patterns (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    pattern_type TEXT NOT NULL,
                    pattern_key TEXT UNIQUE NOT NULL,
                    pattern_data TEXT NOT NULL,
                    confidence REAL DEFAULT 0.5,
                    occurrence_count INTEGER DEFAULT 1,
                    first_seen TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                    last_seen TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                    active INTEGER DEFAULT 1
                )
            """)
            
            conn.commit()
            logger.info("Base de datos inicializada correctamente")
    
    @contextmanager
    def _get_connection(self):
        """Context manager para conexiones SQLite thread-safe."""
        conn = sqlite3.connect(self.db_path, check_same_thread=False)
        conn.row_factory = sqlite3.Row
        try:
            yield conn
        finally:
            conn.close()
    
    def _cache_get(self, key: str) -> Optional[Any]:
        """Obtiene valor de caché con LRU."""
        with self._lock:
            if key in self._cache:
                # Mover al final (más reciente)
                self._cache_order.remove(key)
                self._cache_order.append(key)
                self.stats['cache_hits'] += 1
                return self._cache[key]
            return None
    
    def _cache_set(self, key: str, value: Any):
        """Guarda valor en caché con LRU."""
        with self._lock:
            if key in self._cache:
                self._cache_order.remove(key)
            elif len(self._cache) >= self.cache_size:
                # Eliminar el más antiguo
                oldest = self._cache_order.pop(0)
                del self._cache[oldest]
            
            self._cache[key] = value
            self._cache_order.append(key)
    
    def _cache_invalidate(self, key: str):
        """Invalida una entrada de caché."""
        with self._lock:
            if key in self._cache:
                del self._cache[key]
                self._cache_order.remove(key)
    
    # ==================== MEMORIA EPISÓDICA ====================
    
    def store_episode(self, event: str, details: Dict = None,
                     importance: int = 5, context: Dict = None,
                     tags: List[str] = None) -> int:
        """
        Almacena un evento/episodio en la memoria.
        
        Returns:
            ID de la entrada creada
        """
        entry = MemoryEntry(
            memory_type="episodic",
            category="event",
            key=event[:100],
            value=details or {},
            importance=importance,
            context=context or {},
            tags=tags or []
        )
        
        return self._store_entry(entry)
    
    def get_episodes(self, category: str = None, since: datetime = None,
                     tags: List[str] = None, limit: int = 50) -> List[MemoryEntry]:
        """
        Recupera episodios de la memoria con filtros.
        """
        query = "SELECT * FROM memory_entries WHERE memory_type = 'episodic'"
        params = []
        
        if category:
            query += " AND category = ?"
            params.append(category)
        
        if since:
            query += " AND timestamp > ?"
            params.append(since.isoformat())
        
        if tags:
            for tag in tags:
                query += " AND tags LIKE ?"
                params.append(f"%{tag}%")
        
        query += " ORDER BY timestamp DESC LIMIT ?"
        params.append(limit)
        
        with self._get_connection() as conn:
            cursor = conn.cursor()
            cursor.execute(query, params)
            rows = cursor.fetchall()
            
            entries = []
            for row in rows:
                entry = self._row_to_entry(row)
                self._update_access_count(entry.id)
                entries.append(entry)
            
            return entries
    
    # ==================== MEMORIA SEMÁNTICA ====================
    
    def store_fact(self, subject: str, predicate: str, obj: Any,
                   confidence: float = 1.0, source: str = "inferred") -> int:
        """
        Almacena un hecho/relación en la memoria semántica.
        
        Ejemplo: store_fact("Python", "es", "lenguaje de programación")
        """
        key = f"{subject}|{predicate}"
        value = {
            'subject': subject,
            'predicate': predicate,
            'object': obj,
            'source': source
        }
        
        entry = MemoryEntry(
            memory_type="semantic",
            category="fact",
            key=key,
            value=value,
            confidence=confidence,
            tags=[subject, predicate]
        )
        
        return self._store_entry(entry)
    
    def query_fact(self, subject: str = None, predicate: str = None) -> List[Dict]:
        """
        Consulta hechos almacenados.
        """
        query = "SELECT * FROM memory_entries WHERE memory_type = 'semantic'"
        params = []
        
        if subject and predicate:
            key = f"{subject}|{predicate}"
            query += " AND key = ?"
            params.append(key)
        elif subject:
            query += " AND key LIKE ?"
            params.append(f"{subject}|%")
        elif predicate:
            query += " AND key LIKE ?"
            params.append(f"%|{predicate}")
        
        query += " ORDER BY confidence DESC"
        
        with self._get_connection() as conn:
            cursor = conn.cursor()
            cursor.execute(query, params)
            rows = cursor.fetchall()
            
            results = []
            for row in rows:
                entry = self._row_to_entry(row)
                results.append({
                    'subject': entry.value.get('subject'),
                    'predicate': entry.value.get('predicate'),
                    'object': entry.value.get('object'),
                    'confidence': entry.confidence,
                    'source': entry.value.get('source')
                })
                self._update_access_count(entry.id)
            
            return results
    
    # ==================== PREFERENCIAS DE USUARIO ====================
    
    def store_preference(self, category: str, key: str, value: Any,
                         confidence: float = 1.0, source: str = "explicit",
                         context: Dict = None):
        """
        Almacena o actualiza una preferencia del usuario.
        """
        pref_key = f"{category}:{key}"
        cached = self._cache_get(pref_key)
        
        if cached:
            # Actualizar existente
            cached.update(value, confidence)
            self._update_preference_db(cached)
        else:
            # Crear nueva
            pref = UserPreference(
                category=category,
                key=key,
                value=value,
                confidence=confidence,
                source=source,
                context=context or {}
            )
            self._store_preference_db(pref)
            self._cache_set(pref_key, pref)
        
        self.stats['stores'] += 1
        logger.info(f"Preferencia guardada: {category}.{key} = {value}")
    
    def get_preference(self, category: str, key: str, default: Any = None) -> Any:
        """
        Recupera una preferencia del usuario.
        """
        pref_key = f"{category}:{key}"
        
        # Intentar caché primero
        cached = self._cache_get(pref_key)
        if cached:
            return cached.value
        
        # Buscar en DB
        with self._get_connection() as conn:
            cursor = conn.cursor()
            cursor.execute("""
                SELECT * FROM user_preferences 
                WHERE category = ? AND key = ?
            """, (category, key))
            
            row = cursor.fetchone()
            if row:
                pref = UserPreference(
                    category=row['category'],
                    key=row['key'],
                    value=json.loads(row['value']),
                    confidence=row['confidence'],
                    source=row['source'],
                    first_observed=datetime.fromisoformat(row['first_observed']),
                    last_updated=datetime.fromisoformat(row['last_updated']),
                    update_count=row['update_count'],
                    context=json.loads(row['context'])
                )
                self._cache_set(pref_key, pref)
                return pref.value
            
            return default
    
    def get_preferences_by_category(self, category: str) -> Dict[str, Any]:
        """
        Obtiene todas las preferencias de una categoría.
        """
        with self._get_connection() as conn:
            cursor = conn.cursor()
            cursor.execute("""
                SELECT key, value FROM user_preferences 
                WHERE category = ?
            """, (category,))
            
            return {row['key']: json.loads(row['value']) for row in cursor.fetchall()}
    
    def _store_preference_db(self, pref: UserPreference):
        """Guarda preferencia en base de datos."""
        with self._get_connection() as conn:
            cursor = conn.cursor()
            cursor.execute("""
                INSERT INTO user_preferences 
                (category, key, value, confidence, source, context)
                VALUES (?, ?, ?, ?, ?, ?)
            """, (
                pref.category, pref.key,
                json.dumps(pref.value), pref.confidence,
                pref.source, json.dumps(pref.context)
            ))
            conn.commit()
    
    def _update_preference_db(self, pref: UserPreference):
        """Actualiza preferencia existente."""
        with self._get_connection() as conn:
            cursor = conn.cursor()
            cursor.execute("""
                UPDATE user_preferences 
                SET value = ?, confidence = ?, last_updated = ?, 
                    update_count = ?
                WHERE category = ? AND key = ?
            """, (
                json.dumps(pref.value), pref.confidence,
                pref.last_updated.isoformat(), pref.update_count,
                pref.category, pref.key
            ))
            conn.commit()
    
    # ==================== CONTEXTO CONVERSACIONAL ====================
    
    def start_conversation(self) -> str:
        """Inicia una nueva sesión de conversación."""
        import uuid
        session_id = str(uuid.uuid4())[:8]
        
        self.current_context = ConversationContext(
            session_id=session_id,
            started_at=datetime.now()
        )
        
        with self._get_connection() as conn:
            cursor = conn.cursor()
            cursor.execute("""
                INSERT INTO conversations (session_id, started_at)
                VALUES (?, ?)
            """, (session_id, datetime.now().isoformat()))
            conn.commit()
        
        logger.info(f"Nueva conversación iniciada: {session_id}")
        return session_id
    
    def add_to_conversation(self, speaker: str, content: str,
                           metadata: Dict = None):
        """Agrega un mensaje a la conversación actual."""
        if not self.current_context:
            self.start_conversation()
        
        self.current_context.add_message(speaker, content, metadata)
        
        # Guardar en DB
        with self._get_connection() as conn:
            cursor = conn.cursor()
            
            # Obtener ID de conversación
            cursor.execute("""
                SELECT id FROM conversations WHERE session_id = ?
            """, (self.current_context.session_id,))
            row = cursor.fetchone()
            
            if row:
                conv_id = row['id']
                cursor.execute("""
                    INSERT INTO messages 
                    (conversation_id, speaker, content, metadata)
                    VALUES (?, ?, ?, ?)
                """, (
                    conv_id, speaker, content,
                    json.dumps(metadata or {})
                ))
                
                # Actualizar contador
                cursor.execute("""
                    UPDATE conversations 
                    SET message_count = message_count + 1
                    WHERE id = ?
                """, (conv_id,))
                
                conn.commit()
    
    def get_conversation_context(self, depth: int = 5) -> List[Dict]:
        """
        Obtiene los últimos mensajes del contexto actual.
        """
        if not self.current_context:
            return []
        
        return self.current_context.messages[-depth:]
    
    def end_conversation(self, summary: str = None):
        """Finaliza la conversación actual."""
        if not self.current_context:
            return
        
        with self._get_connection() as conn:
            cursor = conn.cursor()
            cursor.execute("""
                UPDATE conversations 
                SET ended_at = ?, summary = ?, topics = ?
                WHERE session_id = ?
            """, (
                datetime.now().isoformat(),
                summary,
                json.dumps(self.current_context.topics),
                self.current_context.session_id
            ))
            conn.commit()
        
        logger.info(f"Conversación finalizada: {self.current_context.session_id}")
        self.current_context = None
    
    # ==================== PATRONES Y APRENDIZAJE ====================
    
    def store_pattern(self, pattern_type: str, pattern_key: str,
                      pattern_data: Dict, confidence: float = 0.5):
        """
        Almacena un patrón aprendido.
        """
        with self._get_connection() as conn:
            cursor = conn.cursor()
            
            # Verificar si existe
            cursor.execute("""
                SELECT id, occurrence_count, confidence FROM learned_patterns
                WHERE pattern_type = ? AND pattern_key = ?
            """, (pattern_type, pattern_key))
            
            row = cursor.fetchone()
            
            if row:
                # Actualizar
                new_count = row['occurrence_count'] + 1
                new_confidence = min(0.95, row['confidence'] + 0.05)
                
                cursor.execute("""
                    UPDATE learned_patterns
                    SET occurrence_count = ?, confidence = ?, 
                        last_seen = ?, pattern_data = ?
                    WHERE id = ?
                """, (
                    new_count, new_confidence,
                    datetime.now().isoformat(),
                    json.dumps(pattern_data),
                    row['id']
                ))
            else:
                # Crear nuevo
                cursor.execute("""
                    INSERT INTO learned_patterns
                    (pattern_type, pattern_key, pattern_data, confidence)
                    VALUES (?, ?, ?, ?)
                """, (
                    pattern_type, pattern_key,
                    json.dumps(pattern_data), confidence
                ))
            
            conn.commit()
    
    def get_patterns(self, pattern_type: str = None, min_confidence: float = 0.5,
                     limit: int = 100) -> List[Dict]:
        """
        Recupera patrones aprendidos.
        """
        query = "SELECT * FROM learned_patterns WHERE confidence >= ? AND active = 1"
        params = [min_confidence]
        
        if pattern_type:
            query += " AND pattern_type = ?"
            params.append(pattern_type)
        
        query += " ORDER BY confidence DESC, occurrence_count DESC LIMIT ?"
        params.append(limit)
        
        with self._get_connection() as conn:
            cursor = conn.cursor()
            cursor.execute(query, params)
            
            patterns = []
            for row in cursor.fetchall():
                patterns.append({
                    'type': row['pattern_type'],
                    'key': row['pattern_key'],
                    'data': json.loads(row['pattern_data']),
                    'confidence': row['confidence'],
                    'occurrences': row['occurrence_count'],
                    'first_seen': row['first_seen'],
                    'last_seen': row['last_seen']
                })
            
            return patterns
    
    # ==================== MÉTODOS AUXILIARES ====================
    
    def _store_entry(self, entry: MemoryEntry) -> int:
        """Almacena una entrada en la base de datos."""
        with self._get_connection() as conn:
            cursor = conn.cursor()
            cursor.execute("""
                INSERT INTO memory_entries
                (timestamp, memory_type, category, key, value, importance,
                 confidence, context, tags, expiration)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
            """, (
                entry.timestamp.isoformat(),
                entry.memory_type,
                entry.category,
                entry.key,
                json.dumps(entry.value),
                entry.importance,
                entry.confidence,
                json.dumps(entry.context),
                json.dumps(entry.tags),
                entry.expiration.isoformat() if entry.expiration else None
            ))
            
            entry_id = cursor.lastrowid
            conn.commit()
            
            self.stats['stores'] += 1
            return entry_id
    
    def _row_to_entry(self, row: sqlite3.Row) -> MemoryEntry:
        """Convierte una fila de DB a MemoryEntry."""
        return MemoryEntry(
            id=row['id'],
            timestamp=datetime.fromisoformat(row['timestamp']),
            memory_type=row['memory_type'],
            category=row['category'],
            key=row['key'],
            value=json.loads(row['value']),
            importance=row['importance'],
            confidence=row['confidence'],
            context=json.loads(row['context']),
            tags=json.loads(row['tags']),
            expiration=datetime.fromisoformat(row['expiration']) if row['expiration'] else None,
            access_count=row['access_count'],
            last_accessed=datetime.fromisoformat(row['last_accessed']) if row['last_accessed'] else None
        )
    
    def _update_access_count(self, entry_id: int):
        """Incrementa el contador de accesos."""
        with self._get_connection() as conn:
            cursor = conn.cursor()
            cursor.execute("""
                UPDATE memory_entries
                SET access_count = access_count + 1, last_accessed = ?
                WHERE id = ?
            """, (datetime.now().isoformat(), entry_id))
            conn.commit()
    
    def search(self, query: str, memory_type: str = None,
               limit: int = 20) -> List[MemoryEntry]:
        """
        Búsqueda textual en la memoria.
        """
        sql = """
            SELECT * FROM memory_entries 
            WHERE (key LIKE ? OR value LIKE ? OR tags LIKE ?)
        """
        params = [f"%{query}%", f"%{query}%", f"%{query}%"]
        
        if memory_type:
            sql += " AND memory_type = ?"
            params.append(memory_type)
        
        sql += " ORDER BY importance DESC, timestamp DESC LIMIT ?"
        params.append(limit)
        
        with self._get_connection() as conn:
            cursor = conn.cursor()
            cursor.execute(sql, params)
            
            return [self._row_to_entry(row) for row in cursor.fetchall()]
    
    def consolidate(self, days: int = 30):
        """
        Consolida la memoria eliminando entradas antiguas de baja importancia.
        """
        cutoff = datetime.now() - timedelta(days=days)
        
        with self._get_connection() as conn:
            cursor = conn.cursor()
            
            # Eliminar entradas episódicas antiguas de baja importancia
            cursor.execute("""
                DELETE FROM memory_entries
                WHERE memory_type = 'episodic'
                AND timestamp < ?
                AND importance < 4
                AND access_count < 2
            """, (cutoff.isoformat(),))
            
            # Eliminar patrones inactivos
            cursor.execute("""
                UPDATE learned_patterns
                SET active = 0
                WHERE last_seen < ?
                AND occurrence_count < 3
            """, (cutoff.isoformat(),))
            
            conn.commit()
        
        # Limpiar caché
        with self._lock:
            self._cache.clear()
            self._cache_order.clear()
        
        logger.info("Memoria consolidada")
    
    def get_stats(self) -> Dict:
        """Retorna estadísticas del sistema de memoria."""
        with self._get_connection() as conn:
            cursor = conn.cursor()
            
            stats = {
                'cache': {
                    'size': len(self._cache),
                    'hits': self.stats['cache_hits'],
                    'queries': self.stats['queries']
                },
                'operations': {
                    'stores': self.stats['stores'],
                    'updates': self.stats['updates']
                }
            }
            
            # Conteos por tabla
            cursor.execute("SELECT COUNT(*) FROM memory_entries")
            stats['total_entries'] = cursor.fetchone()[0]
            
            cursor.execute("SELECT COUNT(*) FROM user_preferences")
            stats['total_preferences'] = cursor.fetchone()[0]
            
            cursor.execute("SELECT COUNT(*) FROM conversations")
            stats['total_conversations'] = cursor.fetchone()[0]
            
            cursor.execute("SELECT COUNT(*) FROM learned_patterns WHERE active = 1")
            stats['active_patterns'] = cursor.fetchone()[0]
            
            return stats
    
    def get_recent_activity(self, hours: int = 24) -> List[Dict]:
        """
        Obtiene actividad reciente para análisis de patrones.
        """
        since = datetime.now() - timedelta(hours=hours)
        
        with self._get_connection() as conn:
            cursor = conn.cursor()
            
            # Combinar episodios y mensajes
            cursor.execute("""
                SELECT timestamp, category as type, key as description, 
                       context, 'episode' as source
                FROM memory_entries
                WHERE memory_type = 'episodic'
                AND timestamp > ?
                
                UNION ALL
                
                SELECT m.timestamp, 'message' as type, m.content as description,
                       m.metadata as context, 'conversation' as source
                FROM messages m
                JOIN conversations c ON m.conversation_id = c.id
                WHERE m.timestamp > ?
                
                ORDER BY timestamp DESC
            """, (since.isoformat(), since.isoformat()))
            
            activities = []
            for row in cursor.fetchall():
                activities.append({
                    'timestamp': row['timestamp'],
                    'type': row['type'],
                    'description': row['description'],
                    'context': json.loads(row['context']) if row['context'] else {},
                    'source': row['source']
                })
            
            return activities
    
    def get_user_profile(self) -> Dict:
        """
        Genera un perfil completo del usuario basado en la memoria.
        """
        profile = {
            'preferences': {},
            'habits': {},
            'patterns': [],
            'statistics': {}
        }
        
        # Preferencias por categoría
        categories = ['interface', 'notifications', 'apps', 'schedule']
        for cat in categories:
            profile['preferences'][cat] = self.get_preferences_by_category(cat)
        
        # Patrones de comportamiento
        profile['patterns'] = self.get_patterns(min_confidence=0.6, limit=10)
        
        # Estadísticas de uso
        profile['statistics'] = {
            'total_interactions': self.get_stats().get('total_entries', 0),
            'conversations': self.get_stats().get('total_conversations', 0),
            'active_patterns': self.get_stats().get('active_patterns', 0)
        }
        
        return profile