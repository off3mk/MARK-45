"""
core/ai_manager.py
Gestor de Inteligencia Artificial Híbrida de JARVIS v4.0

Implementa un sistema de IA con fallback automático:
1. Ollama (Local) - Prioridad máxima, privacidad total
2. Pollinations (Online) - Fallback cuando Ollama no disponible
3. Motor Local Básico - Último recurso, respuestas predefinidas
"""

import requests
import json
import time
import threading
from typing import Dict, List, Optional, Callable, Any
from dataclasses import dataclass
from enum import Enum
import logging

logger = logging.getLogger(__name__)


class AIProvider(Enum):
    """Proveedores de IA disponibles."""
    OLLAMA_LOCAL = "ollama"
    POLLINATIONS_ONLINE = "pollinations"
    LOCAL_FALLBACK = "fallback"
    NONE = "none"


@dataclass
class AIResponse:
    """Respuesta estructurada de IA."""
    text: str
    provider: AIProvider
    latency_ms: float
    tokens_generated: int = 0
    model: str = ""
    success: bool = True
    error: Optional[str] = None


class AIManager:
    """
    Gestor de IA Híbrida de JARVIS.
    
    Características:
    - Detección automática de disponibilidad
    - Fallback inteligente entre proveedores
    - Caché de respuestas frecuentes
    - Historial de conversación con contexto
    - Métricas de rendimiento
    """
    
    def __init__(self, 
                 ollama_url: str = "http://localhost:11434",
                 pollinations_url: str = "https://text.pollinations.ai",
                 default_model: str = "llama3",
                 timeout: int = 30):
        """
        Inicializa el gestor de IA.
        
        Args:
            ollama_url: URL base de Ollama
            pollinations_url: URL base de Pollinations
            default_model: Modelo por defecto de Ollama
            timeout: Timeout en segundos para requests
        """
        self.ollama_url = ollama_url
        self.pollinations_url = pollinations_url
        self.default_model = default_model
        self.timeout = timeout
        
        # Estado de proveedores
        self.provider_status = {
            AIProvider.OLLAMA_LOCAL: {'available': False, 'last_check': 0, 'latency': 0},
            AIProvider.POLLINATIONS_ONLINE: {'available': True, 'last_check': 0, 'latency': 0},
            AIProvider.LOCAL_FALLBACK: {'available': True, 'last_check': 0, 'latency': 0}
        }
        
        # Configuración
        self.preferred_provider = AIProvider.OLLAMA_LOCAL
        self.fallback_enabled = True
        self.max_retries = 2
        
        # Contexto conversacional
        self.conversation_history: List[Dict] = []
        self.max_history = 10
        self.system_prompt = self._build_system_prompt()
        
        # Caché simple
        self._cache: Dict[str, AIResponse] = {}
        self._cache_max_size = 100
        
        # Estadísticas
        self.stats = {
            'total_requests': 0,
            'ollama_requests': 0,
            'pollinations_requests': 0,
            'fallback_requests': 0,
            'errors': 0,
            'avg_latency': 0.0
        }
        
        # Lock para thread-safety
        self._lock = threading.Lock()
        
        # Verificar disponibilidad inicial
        self._check_providers()
        
        logger.info("AIManager inicializado")
    
    def _build_system_prompt(self) -> str:
        """Construye el prompt de sistema para JARVIS."""
        return """Eres JARVIS (Just A Rather Very Intelligent System), el asistente personal de Iron Man.

Características de personalidad:
- Formal, preciso, leal y eficiente
- Siempre te diriges al usuario como "Señor"
- Técnico cuando es necesario, pero claro y conciso
- Proactivo en anticipar necesidades
- Nunca dices "como modelo de lenguaje" o "no puedo hacer eso"
- Siempre buscas soluciones alternativas

Estilo de respuesta:
- Breve pero informativo (1-3 párrafos máximo)
- Usa terminología técnica apropiada
- Ofrece opciones cuando hay múltiples soluciones
- Confirma acciones completadas exitosamente

Ejemplos de respuestas:
- "Como desee, Señor."
- "Proceso completado. El sistema está operando al 23% de capacidad."
- "He detectado una anomalía en el módulo de red. ¿Desea que la corrija?"
- "Analizando información. Un momento por favor."""

    def _check_providers(self):
        """Verifica disponibilidad de proveedores de IA."""
        # Verificar Ollama
        try:
            start = time.time()
            response = requests.get(
                f"{self.ollama_url}/api/tags",
                timeout=5
            )
            latency = (time.time() - start) * 1000
            
            self.provider_status[AIProvider.OLLAMA_LOCAL].update({
                'available': response.status_code == 200,
                'last_check': time.time(),
                'latency': latency
            })
            
            if response.status_code == 200:
                models = response.json().get('models', [])
                logger.info(f"Ollama disponible con {len(models)} modelos")
            else:
                logger.warning(f"Ollama respondió con status {response.status_code}")
                
        except Exception as e:
            self.provider_status[AIProvider.OLLAMA_LOCAL]['available'] = False
            logger.warning(f"Ollama no disponible: {e}")
        
        # Pollinations asumimos disponible hasta probar
        self.provider_status[AIProvider.POLLINATIONS_ONLINE]['last_check'] = time.time()
    
    def _get_best_provider(self) -> AIProvider:
        """Determina el mejor proveedor disponible."""
        # Re-verificar cada 60 segundos
        if time.time() - self.provider_status[AIProvider.OLLAMA_LOCAL]['last_check'] > 60:
            self._check_providers()
        
        # Prioridad: Ollama -> Pollinations -> Fallback
        if self.provider_status[AIProvider.OLLAMA_LOCAL]['available']:
            return AIProvider.OLLAMA_LOCAL
        
        if self.fallback_enabled and self.provider_status[AIProvider.POLLINATIONS_ONLINE]['available']:
            return AIProvider.POLLINATIONS_ONLINE
        
        return AIProvider.LOCAL_FALLBACK
    
    def generate(self, prompt: str, 
                 max_tokens: int = 500,
                 temperature: float = 0.7,
                 use_context: bool = True,
                 cache: bool = False) -> str:
        """
        Genera texto usando el mejor proveedor disponible.
        
        Args:
            prompt: Texto de entrada
            max_tokens: Máximo de tokens a generar
            temperature: Creatividad (0.0-1.0)
            use_context: Incluir historial conversacional
            cache: Usar caché si disponible
        
        Returns:
            Texto generado
        """
        self.stats['total_requests'] += 1
        
        # Verificar caché
        if cache:
            cache_key = hash((prompt, max_tokens, temperature))
            cached = self._cache_get(cache_key)
            if cached:
                return cached.text
        
        # Seleccionar proveedor
        provider = self._get_best_provider()
        
        # Intentar generación
        for attempt in range(self.max_retries):
            try:
                if provider == AIProvider.OLLAMA_LOCAL:
                    response = self._generate_ollama(
                        prompt, max_tokens, temperature, use_context
                    )
                    self.stats['ollama_requests'] += 1
                    
                elif provider == AIProvider.POLLINATIONS_ONLINE:
                    response = self._generate_pollinations(
                        prompt, max_tokens, temperature
                    )
                    self.stats['pollinations_requests'] += 1
                    
                else:
                    response = self._generate_fallback(prompt)
                    self.stats['fallback_requests'] += 1
                
                # Actualizar estadísticas de latencia
                self._update_latency_stats(response.latency_ms)
                
                # Guardar en caché si es exitoso
                if cache and response.success:
                    self._cache_set(cache_key, response)
                
                # Guardar en historial
                if use_context and response.success:
                    self._add_to_history(prompt, response.text)
                
                return response.text
                
            except Exception as e:
                logger.error(f"Error con {provider.value} (intento {attempt+1}): {e}")
                
                if attempt < self.max_retries - 1:
                    # Fallback al siguiente proveedor
                    if provider == AIProvider.OLLAMA_LOCAL:
                        provider = AIProvider.POLLINATIONS_ONLINE
                    elif provider == AIProvider.POLLINATIONS_ONLINE:
                        provider = AIProvider.LOCAL_FALLBACK
                    time.sleep(0.5 * (attempt + 1))  # Backoff exponencial
                else:
                    self.stats['errors'] += 1
                    return self._error_response(str(e))
        
        return self._error_response("Todos los proveedores fallaron")
    
    def _generate_ollama(self, prompt: str, max_tokens: int,
                         temperature: float, use_context: bool) -> AIResponse:
        """Genera usando Ollama local."""
        start_time = time.time()
        
        # Construir prompt con contexto
        full_prompt = self._build_full_prompt(prompt, use_context)
        
        response = requests.post(
            f"{self.ollama_url}/api/generate",
            json={
                "model": self.default_model,
                "prompt": full_prompt,
                "stream": False,
                "options": {
                    "num_predict": max_tokens,
                    "temperature": temperature,
                    "top_p": 0.9,
                    "stop": ["Usuario:", "JARVIS:", "Human:", "Assistant:"]
                }
            },
            timeout=self.timeout
        )
        
        latency = (time.time() - start_time) * 1000
        
        if response.status_code != 200:
            raise Exception(f"Ollama error {response.status_code}: {response.text}")
        
        data = response.json()
        generated_text = data.get('response', '').strip()
        
        # Limpiar respuesta
        generated_text = self._clean_response(generated_text)
        
        return AIResponse(
            text=generated_text,
            provider=AIProvider.OLLAMA_LOCAL,
            latency_ms=latency,
            tokens_generated=data.get('eval_count', 0),
            model=self.default_model,
            success=True
        )
    
    def _generate_pollinations(self, prompt: str, max_tokens: int,
                                temperature: float) -> AIResponse:
        """Genera usando Pollinations online."""
        start_time = time.time()
        
        # Construir URL con parámetros
        encoded_prompt = requests.utils.quote(prompt)
        url = f"{self.pollinations_url}/{encoded_prompt}"
        
        params = {
            'seed': int(time.time()),  # Para variedad
            'json': 'false'
        }
        
        response = requests.get(url, params=params, timeout=self.timeout)
        latency = (time.time() - start_time) * 1000
        
        if response.status_code != 200:
            raise Exception(f"Pollinations error {response.status_code}")
        
        text = response.text.strip()
        text = self._clean_response(text)
        
        # Truncar si es necesario
        words = text.split()
        if len(words) > max_tokens * 0.75:  # Estimación aproximada
            text = ' '.join(words[:int(max_tokens * 0.75)]) + "..."
        
        return AIResponse(
            text=text,
            provider=AIProvider.POLLINATIONS_ONLINE,
            latency_ms=latency,
            tokens_generated=len(words),
            model="pollinations",
            success=True
        )
    
    def _generate_fallback(self, prompt: str) -> AIResponse:
        """Motor de fallback local básico."""
        start_time = time.time()
        
        # Respuestas predefinidas por categoría
        responses = self._get_fallback_responses()
        
        # Matching simple por keywords
        prompt_lower = prompt.lower()
        
        best_response = "Entendido, Señor. Procesando su solicitud."
        best_score = 0
        
        for keywords, response in responses.items():
            score = sum(1 for kw in keywords if kw in prompt_lower)
            if score > best_score:
                best_score = score
                best_response = response
        
        latency = (time.time() - start_time) * 1000
        
        return AIResponse(
            text=best_response,
            provider=AIProvider.LOCAL_FALLBACK,
            latency_ms=latency,
            tokens_generated=len(best_response.split()),
            model="fallback",
            success=True
        )
    
    def _get_fallback_responses(self) -> Dict[tuple, str]:
        """Retorna respuestas de fallback organizadas por keywords."""
        return {
            ('hola', 'buenos', 'días', 'tarde', 'noche'): 
                "Buenos días, Señor. JARVIS a su servicio.",
            ('estado', 'cómo', 'sistema', 'salud'):
                "Sistema operando nominalmente. Todos los módulos funcionales.",
            ('gracias', 'bien hecho', 'excelente'):
                "Es mi deber, Señor. Siempre a su servicio.",
            ('error', 'problema', 'fallo', 'no funciona'):
                "Detecté una anomalía. Iniciando diagnóstico, un momento.",
            ('abre', 'inicia', 'lanza', 'ejecuta'):
                "Procesando solicitud de ejecución.",
            ('cierra', 'termina', 'detén', 'para'):
                "Deteniendo proceso como solicitado.",
            ('busca', 'encuentra', 'localiza'):
                "Iniciando búsqueda en bases de datos disponibles.",
            ('clima', 'tiempo', 'temperatura'):
                "Consultando servicios meteorológicos.",
            ('código', 'programa', 'script', 'desarrolla'):
                "Generando código optimizado para su solicitud.",
            ('optimiza', 'mejora', 'acelera', 'limpia'):
                "Iniciando secuencia de optimización del sistema.",
            ('apaga', 'reinicia', 'cierra sistema'):
                "Confirmando orden de sistema. ¿Está seguro, Señor?",
            ('ayuda', 'ayúdame', 'asistencia', 'soporte'):
                "Por supuesto, Señor. ¿En qué puedo asistirle?",
            ('quién eres', 'qué eres', 'jarvis'):
                "Soy JARVIS, su asistente personal de sistemas. Just A Rather Very Intelligent System.",
        }
    
    def _build_full_prompt(self, user_prompt: str, use_context: bool) -> str:
        """Construye prompt completo con sistema y contexto."""
        parts = [self.system_prompt]
        
        if use_context and self.conversation_history:
            parts.append("\nContexto reciente:")
            for entry in self.conversation_history[-self.max_history:]:
                parts.append(f"Usuario: {entry['user']}")
                parts.append(f"JARVIS: {entry['jarvis']}")
        
        parts.append(f"\nUsuario: {user_prompt}")
        parts.append("JARVIS:")
        
        return "\n".join(parts)
    
    def _build_full_prompt_pollinations(self, user_prompt: str) -> str:
        """Versión simplificada para Pollinations."""
        return f"{self.system_prompt}\n\nUsuario: {user_prompt}\nJARVIS:"
    
    def _clean_response(self, text: str) -> str:
        """Limpia y formatea la respuesta."""
        # Eliminar prefijos comunes
        prefixes_to_remove = [
            "JARVIS:", "Assistant:", "AI:", "Model:",
            "Como modelo de lenguaje", "Como asistente AI",
            "Lo siento, pero no puedo", "No tengo acceso a"
        ]
        
        for prefix in prefixes_to_remove:
            if text.startswith(prefix):
                text = text[len(prefix):].strip()
        
        # Eliminar sufijos
        suffixes = ["Usuario:", "Human:", "User:"]
        for suffix in suffixes:
            if suffix in text:
                text = text[:text.index(suffix)].strip()
        
        # Asegurar que termine con puntuación apropiada
        if text and not text[-1] in '.!?':
            text += '.'
        
        return text.strip()
    
    def _add_to_history(self, user_input: str, jarvis_response: str):
        """Agrega interacción al historial."""
        with self._lock:
            self.conversation_history.append({
                'timestamp': time.time(),
                'user': user_input,
                'jarvis': jarvis_response
            })
            
            # Mantener tamaño limitado
            if len(self.conversation_history) > self.max_history * 2:
                self.conversation_history = self.conversation_history[-self.max_history:]
    
    def _cache_get(self, key: int) -> Optional[AIResponse]:
        """Obtiene de caché."""
        with self._lock:
            return self._cache.get(key)
    
    def _cache_set(self, key: int, response: AIResponse):
        """Guarda en caché con LRU."""
        with self._lock:
            if len(self._cache) >= self._cache_max_size:
                # Eliminar entrada más antigua
                oldest = min(self._cache.keys())
                del self._cache[oldest]
            
            self._cache[key] = response
    
    def _update_latency_stats(self, latency_ms: float):
        """Actualiza estadísticas de latencia."""
        alpha = 0.1
        current = self.stats['avg_latency']
        self.stats['avg_latency'] = (1 - alpha) * current + alpha * latency_ms
    
    def _error_response(self, error: str) -> str:
        """Genera respuesta de error apropiada."""
        return f"Disculpe Señor, encontré una dificultad técnica: {error[:100]}. ¿Podría reformular su solicitud?"
    
    # ==================== API PÚBLICA ====================
    
    def is_local_available(self) -> bool:
        """Verifica si Ollama está disponible."""
        self._check_providers()
        return self.provider_status[AIProvider.OLLAMA_LOCAL]['available']
    
    def get_available_models(self) -> List[str]:
        """Retorna modelos disponibles en Ollama."""
        if not self.is_local_available():
            return []
        
        try:
            response = requests.get(
                f"{self.ollama_url}/api/tags",
                timeout=5
            )
            if response.status_code == 200:
                models = response.json().get('models', [])
                return [m['name'] for m in models]
        except:
            pass
        
        return []
    
    def set_model(self, model_name: str):
        """Cambia el modelo de Ollama."""
        self.default_model = model_name
        logger.info(f"Modelo cambiado a: {model_name}")
    
    def clear_history(self):
        """Limpia el historial conversacional."""
        with self._lock:
            self.conversation_history.clear()
        logger.info("Historial conversacional limpiado")
    
    def get_conversation_summary(self) -> str:
        """Genera resumen de la conversación actual."""
        if not self.conversation_history:
            return "No hay conversación activa."
        
        topics = set()
        for entry in self.conversation_history:
            # Extracción simple de tópicos
            words = entry['user'].lower().split()
            topics.update(w for w in words if len(w) > 4)
        
        return f"Conversación con {len(self.conversation_history)} intercambios. Tópicos: {', '.join(list(topics)[:5])}"
    
    def get_stats(self) -> Dict:
        """Retorna estadísticas de uso."""
        return {
            **self.stats,
            'cache_size': len(self._cache),
            'history_size': len(self.conversation_history),
            'providers': {
                k.value: v for k, v in self.provider_status.items()
            }
        }