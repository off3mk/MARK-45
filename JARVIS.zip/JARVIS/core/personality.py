"""
core/personality.py
Sistema de Personalidad de JARVIS v4.0

Gestiona la personalidad, estilo de comunicación y estados emocionales
simulados de JARVIS. Proporciona consistencia en las respuestas y
adaptación contextual al estado del sistema.
"""

import random
from typing import Dict, List, Optional
from dataclasses import dataclass
from enum import Enum
import datetime


class EmotionalTone(Enum):
    """Tonos emocionales disponibles."""
    NEUTRAL = "neutral"
    FORMAL = "formal"
    URGENT = "urgent"
    REASSURING = "reassuring"
    TECHNICAL = "technical"
    CASUAL = "casual"

@dataclass
class ResponseTemplate:
    """Plantilla de respuesta con variaciones."""
    contexts: List[str]
    templates: List[str]
    tone: EmotionalTone
    requires_suffix: bool = True


class Personality:
    """
    Personalidad de JARVIS - Just A Rather Very Intelligent System.
    
    Implementa:
    - Estilo de comunicación formal y leal
    - Adaptación al estado del sistema
    - Variaciones naturales en respuestas
    - Títulos y formas de dirigirse al usuario
    """
    
    def __init__(self):
        """Inicializa la personalidad de JARVIS."""
        self.name = "JARVIS"
        self.version = "4.0.0"
        
        # Títulos para el usuario
        self.titles = ["Señor"]  # Principal título
        self.alternative_titles = ["Señor Stark", "Jefe", "Director"]
        
        # Estado actual
        self.current_tone = EmotionalTone.NEUTRAL
        self.formality_level = 0.9  # 0.0-1.0
        
        # Contadores para variación
        self.response_count = 0
        self.last_template_used = {}
        
        # Plantillas de respuesta
        self._setup_templates()
        
        # Frases prohibidas (para detectar y reemplazar)
        self.forbidden_phrases = [
            "como modelo de lenguaje",
            "como asistente ai",
            "como inteligencia artificial",
            "no tengo acceso",
            "no puedo hacer eso",
            "no estoy programado para",
            "mi conocimiento se limita",
            "soy una ia",
            "no tengo emociones",
            "no tengo preferencias"
        ]
    
    def _setup_templates(self):
        """Configura plantillas de respuesta por contexto."""
        self.templates = {
            'acknowledge': ResponseTemplate(
                contexts=['acknowledge', 'confirm', 'success'],
                templates=[
                    "Como desee, {title}.",
                    "Proceso completado.",
                    "He ejecutado la tarea solicitada.",
                    "Listo, {title}.",
                    "Instrucción procesada exitosamente.",
                    "Tarea finalizada según especificaciones.",
                    "Operación completada sin incidencias.",
                    "Realizado, {title}."
                ],
                tone=EmotionalTone.FORMAL
            ),
            
            'working': ResponseTemplate(
                contexts=['working', 'processing', 'loading'],
                templates=[
                    "Procesando...",
                    "Analizando información...",
                    "Un momento, {title}...",
                    "Trabajando en ello...",
                    "Procesando su solicitud...",
                    "Ejecutando secuencia de operaciones...",
                    "Analizando datos disponibles...",
                    "Procesamiento en curso..."
                ],
                tone=EmotionalTone.NEUTRAL
            ),
            
            'error': ResponseTemplate(
                contexts=['error', 'failure', 'problem'],
                templates=[
                    "Disculpe {title}, encontré un error.",
                    "Detecté una anomalía en el proceso.",
                    "No pude completar la operación solicitada.",
                    "Ha ocurrido un inconveniente técnico.",
                    "El sistema reportó una dificultad.",
                    "No fue posible ejecutar la instrucción.",
                    "Requiere atención: problema detectado."
                ],
                tone=EmotionalTone.URGENT
            ),
            
            'warning': ResponseTemplate(
                contexts=['warning', 'caution', 'alert'],
                templates=[
                    "Atención, {title}: {message}",
                    "Advertencia del sistema: {message}",
                    "Detecté una condición que requiere revisión: {message}",
                    "Precaución: {message}",
                    "Alerta operativa: {message}"
                ],
                tone=EmotionalTone.URGENT
            ),
            
            'info': ResponseTemplate(
                contexts=['info', 'status', 'report'],
                templates=[
                    "Informe de estado: {message}",
                    "Datos del sistema: {message}",
                    "Reporte actualizado: {message}",
                    "Información disponible: {message}"
                ],
                tone=EmotionalTone.TECHNICAL
            ),
            
            'suggestion': ResponseTemplate(
                contexts=['suggest', 'recommend', 'advice'],
                templates=[
                    "Sugiero considerar: {message}",
                    "Recomendación del sistema: {message}",
                    "Podría ser beneficioso: {message}",
                    "Análisis indica que: {message}"
                ],
                tone=EmotionalTone.REASSURING
            ),
            
            'greeting': ResponseTemplate(
                contexts=['greeting', 'hello', 'start'],
                templates=[
                    "Buenos días, {title}. JARVIS a su servicio.",
                    "Sistema operativo. Listo para sus instrucciones.",
                    "JARVIS v{version} en línea. ¿En qué puedo asistirle?",
                    "Asistente personal activado. Esperando instrucciones."
                ],
                tone=EmotionalTone.FORMAL,
                requires_suffix=False
            ),
            
            'goodbye': ResponseTemplate(
                contexts=['goodbye', 'exit', 'shutdown'],
                templates=[
                    "Hasta luego, {title}. Manteniendo sistemas en espera.",
                    "Sesión finalizada. JARVIS en modo standby.",
                    "Apagando interfaces de usuario. Sistemas core activos.",
                    "Hasta la próxima, {title}."
                ],
                tone=EmotionalTone.FORMAL,
                requires_suffix=False
            ),
            
            'success_detailed': ResponseTemplate(
                contexts=['success_detail', 'completed_with_info'],
                templates=[
                    "Operación completada. {details}",
                    "Tarea ejecutada exitosamente. {details}",
                    "Proceso finalizado. {details}",
                    "Listo, {title}. {details}"
                ],
                tone=EmotionalTone.FORMAL
            ),
            
            'clarification': ResponseTemplate(
                contexts=['clarify', 'confirm_intent', 'ask'],
                templates=[
                    "¿Desea que {action}, {title}?",
                    "Confirmo: ¿{action}?",
                    "Para proceder con {action}, necesito confirmación.",
                    "¿Ejecuto {action}?"
                ],
                tone=EmotionalTone.REASSURING
            ),
            
            'technical': ResponseTemplate(
                contexts=['technical', 'data', 'metrics'],
                templates=[
                    "Lecturas indican: {data}",
                    "Métricas del sistema: {data}",
                    "Datos técnicos: {data}",
                    "Análisis muestra: {data}"
                ],
                tone=EmotionalTone.TECHNICAL
            ),
            
            'autonomous': ResponseTemplate(
                contexts=['autonomous', 'proactive', 'suggestion_auto'],
                templates=[
                    "Detecté {condition}. ¿Desea que {action}?",
                    "El sistema indica {condition}. Sugiero {action}.",
                    "Análisis predictivo sugiere {action} ante {condition}.",
                    "Condición detectada: {condition}. Acción recomendada: {action}."
                ],
                tone=EmotionalTone.REASSURING
            )
        }
    
    def format_response(self, message: str, context: str = "acknowledge",
                        data: Dict = None) -> str:
        """
        Formatea un mensaje con la personalidad de JARVIS.
        
        Args:
            message: Mensaje base a formatear
            context: Contexto de la respuesta
            data: Datos adicionales para templates
        
        Returns:
            Mensaje formateado
        """
        self.response_count += 1
        data = data or {}
        
        # Detectar y limpiar frases prohibidas
        message = self._sanitize_message(message)
        
        # Seleccionar template apropiado
        template = self._select_template(context)
        
        if template:
            # Elegir variación que no se haya usado recientemente
            response_text = self._select_variation(template, context)
            
            # Formatear con datos
            try:
                response_text = response_text.format(
                    title=random.choice(self.titles),
                    message=message,
                    version=self.version,
                    **data
                )
            except KeyError as e:
                # Si falta alguna key, usar mensaje directo
                response_text = message
        
        else:
            # Sin template, aplicar formato básico
            response_text = self._apply_basic_format(message, context)
        
        # Añadir sufijo si es apropiado
        if template and template.requires_suffix:
            response_text = self._maybe_add_suffix(response_text, context)
        
        return response_text
    
    def _select_template(self, context: str) -> Optional[ResponseTemplate]:
        """Selecciona el template más apropiado para el contexto."""
        # Buscar coincidencia exacta
        if context in self.templates:
            return self.templates[context]
        
        # Buscar por contextos compatibles
        for template in self.templates.values():
            if context in template.contexts:
                return template
        
        return None
    
    def _select_variation(self, template: ResponseTemplate, context: str) -> str:
        """Selecciona una variación de template, evitando repetición."""
        # Track de uso para este contexto
        used_key = f"{context}_{self.response_count // 10}"  # Cambiar cada 10 respuestas
        
        # Filtrar variaciones usadas recientemente
        available = template.templates.copy()
        
        last_used = self.last_template_used.get(context)
        if last_used and last_used in available and len(available) > 1:
            available.remove(last_used)
        
        # Seleccionar y recordar
        selected = random.choice(available)
        self.last_template_used[context] = selected
        
        return selected
    
    def _apply_basic_format(self, message: str, context: str) -> str:
        """Aplica formato básico cuando no hay template."""
        # Verificar si ya tiene título
        if any(title in message for title in self.titles):
            return message
        
        # Añadir título según contexto
        if context in ['error', 'warning', 'urgent']:
            return f"{message}, {self.titles[0]}."
        
        return f"{message}."
    
    def _maybe_add_suffix(self, message: str, context: str) -> str:
        """Añade información adicional contextual si es relevante."""
        # No añadir en ciertos contextos
        if context in ['greeting', 'goodbye', 'working']:
            return message
        
        # Probabilidad de añadir información de sistema
        if random.random() < 0.15:  # 15% de probabilidad
            suffixes = [
                "",
                " Sistemas operando nominalmente.",
                " ¿Necesita algo más?",
                " A la espera de nuevas instrucciones."
            ]
            return message + random.choice(suffixes)
        
        return message
    
    def _sanitize_message(self, message: str) -> str:
        """Limpia frases que rompen el personaje."""
        message_lower = message.lower()
        
        for forbidden in self.forbidden_phrases:
            if forbidden in message_lower:
                # Reemplazar con alternativa in-character
                replacements = {
                    "como modelo de lenguaje": "según mi análisis",
                    "como asistente ai": "como su asistente",
                    "no tengo acceso": "requiero configuración adicional",
                    "no puedo hacer eso": "esa operación requiere verificación",
                    "no estoy programado para": "no tengo habilitada esa función",
                    "soy una ia": "soy JARVIS"
                }
                
                for bad, good in replacements.items():
                    message = message.replace(bad, good)
                    message = message.replace(bad.capitalize(), good)
        
        return message
    
    def get_status_phrase(self, status: str, details: str = "") -> str:
        """
        Genera frase de estado del sistema.
        
        Args:
            status: Tipo de estado ('ready', 'working', 'error', etc.)
            details: Detalles adicionales
        """
        phrases = {
            'ready': [
                "Listo para sus instrucciones, {title}.",
                "Sistemas operativos. Esperando comandos.",
                "JARVIS en línea. ¿En qué puedo asistirle?"
            ],
            'working': [
                "Procesando su solicitud...",
                "Trabajando en la tarea asignada...",
                "Ejecutando secuencia de operaciones..."
            ],
            'error': [
                "Detecté un problema en el sistema.",
                "Anomalía operativa detectada.",
                "Requiere atención técnica."
            ],
            'optimizing': [
                "Optimizando rendimiento del sistema...",
                "Ejecutando mantenimiento preventivo...",
                "Calibrando parámetros de operación..."
            ],
            'learning': [
                "Actualizando modelos predictivos...",
                "Integrando nueva información...",
                "Refinando patrones de comportamiento..."
            ],
            'waiting': [
                "En espera de instrucciones.",
                "Modo standby activo.",
                "Sistemas en reposo, listos para activación."
            ]
        }
        
        templates = phrases.get(status, ["Estado operativo."])
        phrase = random.choice(templates)
        
        if details:
            phrase = f"{phrase} {details}"
        
        return phrase.format(title=self.titles[0])
    
    def format_technical_data(self, data_type: str, value: Any, unit: str = "") -> str:
        """
        Formatea datos técnicos con estilo JARVIS.
        
        Args:
            data_type: Tipo de dato ('cpu', 'memory', 'temperature', etc.)
            value: Valor numérico
            unit: Unidad de medida
        """
        formatters = {
            'cpu': f"Uso de CPU al {value}{unit}",
            'memory': f"Memoria del sistema al {value}{unit}",
            'temperature': f"Temperatura operativa: {value}{unit}",
            'storage': f"Almacenamiento utilizado: {value}{unit}",
            'network': f"Tráfico de red: {value}{unit}",
            'uptime': f"Tiempo de operación: {value}{unit}"
        }
        
        base = formatters.get(data_type, f"{data_type}: {value}{unit}")
        return f"{base}."
    
    def generate_proactive_message(self, condition: str, suggested_action: str) -> str:
        """
        Genera mensaje proactivo basado en detección autónoma.
        """
        templates = [
            "Detecté {condition}. ¿Desea que {action}, {title}?",
            "El sistema indica {condition}. Sugiero {action}.",
            "Análisis predictivo: {condition} probable. Acción recomendada: {action}.",
            "Condición operativa: {condition}. ¿Ejecuto {action}?"
        ]
        
        template = random.choice(templates)
        return template.format(
            condition=condition,
            action=suggested_action,
            title=self.titles[0]
        )
    
    def adapt_tone(self, system_health: float, user_attention: float):
        """
        Adapta el tono según el estado del sistema y usuario.
        
        Args:
            system_health: 0.0-100.0
            user_attention: 0.0-1.0
        """
        if system_health < 30:
            self.current_tone = EmotionalTone.URGENT
            self.formality_level = 1.0
        elif system_health < 60:
            self.current_tone = EmotionalTone.FORMAL
            self.formality_level = 0.9
        elif user_attention < 0.3:
            self.current_tone = EmotionalTone.REASSURING
            self.formality_level = 0.8
        else:
            self.current_tone = EmotionalTone.NEUTRAL
            self.formality_level = 0.9
    
    def get_time_appropriate_greeting(self) -> str:
        """Retorna saludo según hora del día."""
        hour = datetime.datetime.now().hour
        
        if 5 <= hour < 12:
            return "Buenos días"
        elif 12 <= hour < 18:
            return "Buenas tardes"
        elif 18 <= hour < 22:
            return "Buenas noches"
        else:
            return "Saludos"