"""
core/security.py
Sistema de Seguridad de JARVIS v4.0

Gestiona la seguridad del sistema, validación de comandos,
confirmaciones para operaciones peligrosas, y logging de eventos
de seguridad.
"""

import re
import hashlib
import time
from typing import Dict, List, Tuple, Optional, Set
from dataclasses import dataclass
from datetime import datetime
from enum import Enum
import logging

logger = logging.getLogger(__name__)


class SecurityLevel(Enum):
    """Niveles de seguridad para operaciones."""
    LOW = 1      # Sin confirmación
    MEDIUM = 2   # Confirmación verbal/simple
    HIGH = 3     # Confirmación explícita requerida
    CRITICAL = 4 # Confirmación múltiple + autenticación


@dataclass
class SecurityEvent:
    """Evento de seguridad registrado."""
    timestamp: datetime
    event_type: str
    description: str
    severity: str
    source: str
    action_taken: str


class SecurityManager:
    """
    Gestor de seguridad de JARVIS.
    
    Responsabilidades:
    - Validar comandos contra lista de peligrosos
    - Requerir confirmación para operaciones críticas
    - Registrar eventos de seguridad
    - Detectar patrones de uso sospechosos
    - Controlar acceso a funciones sensibles
    """
    
    # Comandos y patrones considerados peligrosos
    DANGEROUS_PATTERNS = {
        'rm -rf': 'Eliminación recursiva forzada',
        'rm -r /': 'Eliminación de sistema',
        'format': 'Formateo de disco',
        'mkfs': 'Creación de sistema de archivos',
        'dd if=/dev/zero': 'Sobrescritura de disco',
        ':(){:|:&};:': 'Fork bomb',
        'del /f /s /q': 'Eliminación forzada Windows',
        'rmdir /s /q': 'Eliminación recursiva Windows',
        'reg delete': 'Modificación de registro',
        'shutdown -r -t 0': 'Reinicio inmediato forzado',
        'shutdown -s -t 0': 'Apagado inmediato forzado',
        'taskkill /f /im': 'Terminación forzada de proceso',
        'sc delete': 'Eliminación de servicio',
        'net user.* /delete': 'Eliminación de usuario',
        'attrib -r -s -h': 'Modificación forzada de atributos',
        'bcdedit /delete': 'Modificación de arranque',
        'diskpart.*clean': 'Limpieza de disco',
    }
    
    # Operaciones que requieren confirmación
    REQUIRES_CONFIRMATION = {
        'delete_file': SecurityLevel.MEDIUM,
        'delete_directory': SecurityLevel.HIGH,
        'execute_shell': SecurityLevel.MEDIUM,
        'shutdown_system': SecurityLevel.HIGH,
        'restart_system': SecurityLevel.HIGH,
        'kill_process': SecurityLevel.MEDIUM,
        'modify_system': SecurityLevel.HIGH,
        'network_change': SecurityLevel.MEDIUM,
        'install_software': SecurityLevel.MEDIUM,
        'run_as_admin': SecurityLevel.HIGH,
        'access_sensitive_data': SecurityLevel.HIGH,
        'disable_protection': SecurityLevel.CRITICAL,
    }
    
    # Umbrales para detección de anomalías
    ANOMALY_THRESHOLDS = {
        'commands_per_minute': 30,
        'failed_commands_ratio': 0.5,
        'critical_operations_per_hour': 10
    }
    
    def __init__(self, log_file: str = "logs/security.log"):
        """
        Inicializa el gestor de seguridad.
        
        Args:
            log_file: Archivo para log de eventos de seguridad
        """
        self.log_file = log_file
        self.security_level = SecurityLevel.MEDIUM
        self.strict_mode = False  # Si True, todo requiere confirmación
        
        # Estado de confirmaciones pendientes
        self.pending_confirmations: Dict[str, Dict] = {}
        self.confirmation_timeout = 60  # segundos
        
        # Historial para detección de anomalías
        self.command_history: List[Dict] = []
        self.max_history = 100
        
        # Eventos de seguridad
        self.security_events: List[SecurityEvent] = []
        self.max_events = 500
        
        # Lista blanca de comandos seguros
        self.whitelist: Set[str] = set()
        self._setup_whitelist()
        
        # Contadores de riesgo
        self.risk_score = 0  # 0-100
        self.last_risk_reset = time.time()
        
        logger.info("SecurityManager inicializado")
    
    def _setup_whitelist(self):
        """Configura lista de comandos considerados seguros."""
        safe_commands = [
            'echo', 'dir', 'ls', 'pwd', 'cd', 'type', 'cat',
            'python', 'python3', 'pip', 'code', 'notepad',
            'start', 'open', 'chrome', 'firefox', 'calc',
            'spotify', 'explorer', 'tasklist', 'psutil'
        ]
        self.whitelist.update(safe_commands)
    
    def check_command(self, command: str) -> Tuple[bool, str]:
        """
        Verifica si un comando es seguro para ejecutar.
        
        Args:
            command: Comando a verificar
        
        Returns:
            (is_safe, warning_message)
        """
        command_lower = command.lower().strip()
        
        # 1. Verificar lista blanca (comandos simples)
        first_word = command_lower.split()[0] if command_lower else ""
        if first_word in self.whitelist and len(command_lower.split()) == 1:
            return True, ""
        
        # 2. Verificar patrones peligrosos
        for pattern, description in self.DANGEROUS_PATTERNS.items():
            if re.search(pattern, command_lower):
                self._log_security_event(
                    'dangerous_command_blocked',
                    f"Comando bloqueado: {description}",
                    'high',
                    command[:100]
                )
                self.risk_score += 20
                return False, f"Comando potencialmente destructivo detectado: {description}"
        
        # 3. Análisis heurístico
        risk_indicators = self._analyze_risk_indicators(command_lower)
        if risk_indicators:
            self.risk_score += len(risk_indicators) * 5
            return False, f"Indicadores de riesgo detectados: {', '.join(risk_indicators)}"
        
        # 4. Verificar necesidad de confirmación
        confirmation_level = self._requires_confirmation_level(command_lower)
        if confirmation_level.value >= SecurityLevel.MEDIUM.value:
            return True, f"Requiere confirmación nivel {confirmation_level.name}"
        
        # 5. Modo estricto
        if self.strict_mode:
            return True, "Modo estricto: confirmación recomendada"
        
        return True, ""
    
    def _analyze_risk_indicators(self, command: str) -> List[str]:
        """Analiza indicadores de riesgo en el comando."""
        indicators = []
        
        # Patrones de riesgo
        risk_patterns = [
            (r'.*>.*\/dev\/null', 'redirección sospechosa'),
            (r'.*&&.*rm', 'encadenamiento destructivo'),
            (r'.*\|.*rm', 'pipe destructivo'),
            (r'wget.*\|.*sh', 'ejecución remota'),
            (r'curl.*\|.*sh', 'ejecución remota'),
            (r'powershell.*-enc', 'PowerShell encoded'),
            (r'cmd.*\/c.*del', 'comando de eliminación'),
            (r'.*-force.*-recursive', 'forzado recursivo'),
            (r'sudo.*rm', 'eliminación con privilegios'),
        ]
        
        for pattern, desc in risk_patterns:
            if re.search(pattern, command):
                indicators.append(desc)
        
        return indicators
    
    def _requires_confirmation_level(self, command: str) -> SecurityLevel:
        """Determina nivel de confirmación requerido."""
        command_lower = command.lower()
        
        # Verificar mapeo directo de operaciones
        for operation, level in self.REQUIRES_CONFIRMATION.items():
            # Keywords asociados a cada operación
            keywords = {
                'delete_file': ['del ', 'delete', 'rm ', 'remove'],
                'delete_directory': ['rmdir', 'rd ', 'rm -r', 'rm -rf'],
                'execute_shell': ['execute', 'run cmd', 'powershell', 'bash'],
                'shutdown_system': ['shutdown', 'apaga', 'poweroff', 'halt'],
                'restart_system': ['restart', 'reboot', 'reinicia'],
                'kill_process': ['kill', 'terminate', 'taskkill', 'killall'],
                'modify_system': ['reg edit', 'systemctl', 'sc config'],
                'network_change': ['netsh', 'ipconfig', 'ifconfig', 'iptables'],
                'install_software': ['install', 'pip install', 'npm install', 'apt'],
                'run_as_admin': ['sudo', 'admin', 'elevated'],
                'access_sensitive_data': ['password', 'credential', 'secret', 'key'],
                'disable_protection': ['disable', 'turn off', 'stop service'],
            }.get(operation, [])
            
            for keyword in keywords:
                if keyword in command_lower:
                    return level
        
        # Verificar si contiene path sensible
        sensitive_paths = ['/etc/', '/sys/', '/proc/', 'c:\\windows\\', 
                          'c:\\program files\\', 'registry::']
        for path in sensitive_paths:
            if path in command_lower:
                return SecurityLevel.HIGH
        
        return SecurityLevel.LOW
    
    def request_confirmation(self, operation: str, details: str,
                            level: SecurityLevel = SecurityLevel.MEDIUM) -> str:
        """
        Solicita confirmación para una operación.
        
        Args:
            operation: Identificador de la operación
            details: Descripción de lo que se va a hacer
            level: Nivel de seguridad requerido
        
        Returns:
            confirmation_id: ID para verificar después
        """
        confirmation_id = hashlib.sha256(
            f"{operation}{time.time()}".encode()
        ).hexdigest()[:16]
        
        self.pending_confirmations[confirmation_id] = {
            'operation': operation,
            'details': details,
            'level': level,
            'timestamp': time.time(),
            'confirmed': False
        }
        
        self._log_security_event(
            'confirmation_requested',
            f"Confirmación requerida para: {operation}",
            'medium' if level.value <= 2 else 'high',
            details[:200]
        )
        
        return confirmation_id
    
    def verify_confirmation(self, confirmation_id: str, 
                           user_response: str) -> Tuple[bool, str]:
        """
        Verifica respuesta de confirmación del usuario.
        
        Args:
            confirmation_id: ID de la confirmación
            user_response: Respuesta del usuario ('si', 'no', etc.)
        
        Returns:
            (approved, message)
        """
        if confirmation_id not in self.pending_confirmations:
            return False, "Confirmación no encontrada o expirada"
        
        confirmation = self.pending_confirmations[confirmation_id]
        
        # Verificar timeout
        if time.time() - confirmation['timestamp'] > self.confirmation_timeout:
            del self.pending_confirmations[confirmation_id]
            return False, "Confirmación expirada"
        
        # Analizar respuesta
        positive_responses = ['si', 'sí', 'yes', 'confirmo', 'adelante', 
                             'procede', 'ok', 'okay', 'correcto']
        negative_responses = ['no', 'cancela', 'detente', 'stop', 'negativo']
        
        user_lower = user_response.lower().strip()
        
        if any(resp in user_lower for resp in positive_responses):
            confirmation['confirmed'] = True
            
            # Para nivel CRITICAL, requerir doble confirmación
            if confirmation['level'] == SecurityLevel.CRITICAL:
                # Aquí se implementaría lógica adicional de 2FA
                pass
            
            del self.pending_confirmations[confirmation_id]
            
            self._log_security_event(
                'confirmation_approved',
                f"Confirmación aprobada: {confirmation['operation']}",
                'medium',
                confirmation['details'][:100]
            )
            
            return True, "Confirmación aceptada"
        
        elif any(resp in user_lower for resp in negative_responses):
            del self.pending_confirmations[confirmation_id]
            
            self._log_security_event(
                'confirmation_denied',
                f"Confirmación denegada: {confirmation['operation']}",
                'low',
                confirmation['details'][:100]
            )
            
            return False, "Operación cancelada por el usuario"
        
        return False, "Respuesta no reconocida. Por favor responda 'si' o 'no'"
    
    def is_confirmation_pending(self, confirmation_id: str) -> bool:
        """Verifica si hay una confirmación pendiente."""
        if confirmation_id not in self.pending_confirmations:
            return False
        
        confirmation = self.pending_confirmations[confirmation_id]
        if time.time() - confirmation['timestamp'] > self.confirmation_timeout:
            del self.pending_confirmations[confirmation_id]
            return False
        
        return True
    
    def record_command_execution(self, command: str, success: bool, 
                                  user: str = "default"):
        """
        Registra ejecución de comando para análisis de anomalías.
        """
        self.command_history.append({
            'timestamp': time.time(),
            'command': command[:100],
            'success': success,
            'user': user,
            'hash': hashlib.md5(command.encode()).hexdigest()[:8]
        })
        
        # Mantener tamaño limitado
        if len(self.command_history) > self.max_history:
            self.command_history = self.command_history[-self.max_history:]
        
        # Analizar anomalías
        self._check_anomalies()
    
    def _check_anomalies(self):
        """Detecta patrones de uso anómalos."""
        if len(self.command_history) < 10:
            return
        
        recent = self.command_history[-10:]
        now = time.time()
        
        # 1. Comandos por minuto
        minute_ago = [c for c in recent if now - c['timestamp'] < 60]
        if len(minute_ago) > self.ANOMALY_THRESHOLDS['commands_per_minute']:
            self._log_security_event(
                'anomaly_detected',
                f"Alta frecuencia de comandos: {len(minute_ago)} en 1 minuto",
                'medium',
                'Posible ataque automatizado'
            )
            self.risk_score += 15
        
        # 2. Ratio de fallos
        failed = sum(1 for c in recent if not c['success'])
        if len(recent) > 0 and failed / len(recent) > self.ANOMALY_THRESHOLDS['failed_commands_ratio']:
            self._log_security_event(
                'anomaly_detected',
                f"Alta tasa de fallos: {failed}/{len(recent)}",
                'medium',
                'Posible exploración de comandos'
            )
            self.risk_score += 10
        
        # 3. Reset de riesgo periódico
        if now - self.last_risk_reset > 3600:  # 1 hora
            self.risk_score = max(0, self.risk_score - 30)
            self.last_risk_reset = now
    
    def _log_security_event(self, event_type: str, description: str,
                           severity: str, source: str):
        """Registra evento de seguridad."""
        event = SecurityEvent(
            timestamp=datetime.now(),
            event_type=event_type,
            description=description,
            severity=severity,
            source=source[:200],
            action_taken="logged"
        )
        
        self.security_events.append(event)
        
        if len(self.security_events) > self.max_events:
            self.security_events = self.security_events[-self.max_events:]
        
        # Log a archivo
        try:
            with open(self.log_file, 'a', encoding='utf-8') as f:
                f.write(f"{event.timestamp.isoformat()} | {severity.upper()} | "
                       f"{event_type} | {description} | {source[:50]}\n")
        except Exception as e:
            logger.error(f"Error escribiendo log de seguridad: {e}")
        
        # Log del sistema
        log_func = logger.warning if severity in ['high', 'critical'] else logger.info
        log_func(f"Security: {event_type} - {description}")
    
    def get_risk_assessment(self) -> Dict:
        """Retorna evaluación de riesgo actual."""
        return {
            'risk_score': self.risk_score,
            'risk_level': 'critical' if self.risk_score > 80 else
                         'high' if self.risk_score > 50 else
                         'medium' if self.risk_score > 25 else 'low',
            'strict_mode': self.strict_mode,
            'pending_confirmations': len(self.pending_confirmations),
            'recent_events': len([e for e in self.security_events 
                                 if (datetime.now() - e.timestamp).seconds < 3600])
        }
    
    def get_recent_events(self, count: int = 10) -> List[Dict]:
        """Retorna eventos recientes."""
        return [
            {
                'timestamp': e.timestamp.isoformat(),
                'type': e.event_type,
                'description': e.description,
                'severity': e.severity
            }
            for e in self.security_events[-count:]
        ]
    
    def enable_strict_mode(self):
        """Activa modo estricto (todo requiere confirmación)."""
        self.strict_mode = True
        self._log_security_event('mode_changed', 'Modo estricto activado', 'medium', 'user_action')
        logger.info("Modo estricto de seguridad activado")
    
    def disable_strict_mode(self):
        """Desactiva modo estricto."""
        self.strict_mode = False
        self._log_security_event('mode_changed', 'Modo estricto desactivado', 'low', 'user_action')
        logger.info("Modo estricto de seguridad desactivado")