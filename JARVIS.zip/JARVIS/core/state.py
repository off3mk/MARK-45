"""
core/state.py
Sistema de Conciencia Operativa de JARVIS v4.0 Definitivo

Gestiona el estado emocional, la salud del sistema, las tareas activas,
y proporciona la "conciencia" que permite a JARVIS actuar proactivamente.
"""

import psutil
import time
import threading
from enum import Enum, auto
from dataclasses import dataclass, field
from typing import Dict, List, Optional, Callable, Any, Set
from datetime import datetime, timedelta
import json
import os
import logging


# Configuración de logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)


class EmotionalState(Enum):
    """
    Estados emocionales de JARVIS que afectan su comportamiento,
    tono de respuesta y nivel de proactividad.
    """
    NEUTRAL = "neutral"
    FOCUSED = "focused"
    ALERT = "alert"
    IDLE = "idle"
    PROCESSING = "processing"
    CONCERNED = "concerned"
    OPTIMIZING = "optimizing"
    LEARNING = "learning"
    ASSISTING = "assisting"
    STANDBY = "standby"


class ThreatLevel(Enum):
    """
    Niveles de amenaza del sistema que activan diferentes
    protocolos de seguridad y respuesta.
    """
    NONE = 0
    LOW = 1
    MEDIUM = 2
    HIGH = 3
    CRITICAL = 4


class SystemLoad(Enum):
    """
    Categorización de la carga del sistema para decisiones
    de optimización y gestión de recursos.
    """
    IDLE = "idle"           # < 20% CPU
    LIGHT = "light"         # 20-40% CPU
    MODERATE = "moderate"   # 40-70% CPU
    HEAVY = "heavy"         # 70-90% CPU
    CRITICAL = "critical"   # > 90% CPU


@dataclass
class TaskInfo:
    """
    Información detallada sobre una tarea en ejecución.
    """
    id: str
    name: str
    type: str
    priority: int  # 1-10, 10 es máxima prioridad
    started: datetime
    estimated_duration: Optional[int] = None  # segundos
    progress: float = 0.0  # 0.0 - 1.0
    status: str = "running"  # running, paused, completed, failed
    metadata: Dict = field(default_factory=dict)
    
    def to_dict(self) -> Dict:
        return {
            'id': self.id,
            'name': self.name,
            'type': self.type,
            'priority': self.priority,
            'started': self.started.isoformat(),
            'estimated_duration': self.estimated_duration,
            'progress': self.progress,
            'status': self.status,
            'metadata': self.metadata
        }


@dataclass
class SystemMetrics:
    """
    Métricas detalladas del sistema operativo.
    """
    timestamp: datetime
    cpu_percent: float
    cpu_per_core: List[float]
    memory_percent: float
    memory_available_gb: float
    memory_total_gb: float
    disk_percent: float
    disk_free_gb: float
    network_sent_mb: float
    network_recv_mb: float
    boot_time: datetime
    process_count: int
    thread_count: int
    
    def to_dict(self) -> Dict:
        return {
            'timestamp': self.timestamp.isoformat(),
            'cpu_percent': self.cpu_percent,
            'cpu_per_core': self.cpu_per_core,
            'memory_percent': self.memory_percent,
            'memory_available_gb': self.memory_available_gb,
            'memory_total_gb': self.memory_total_gb,
            'disk_percent': self.disk_percent,
            'disk_free_gb': self.disk_free_gb,
            'network_sent_mb': self.network_sent_mb,
            'network_recv_mb': self.network_recv_mb,
            'boot_time': self.boot_time.isoformat() if self.boot_time else None,
            'process_count': self.process_count,
            'thread_count': self.thread_count
        }


@dataclass
class JarvisState:
    """
    Estado completo de JARVIS en un momento dado.
    Esta es la "conciencia" del sistema.
    """
    # Estado emocional
    mood: EmotionalState = EmotionalState.NEUTRAL
    mood_intensity: float = 0.5  # 0.0 - 1.0
    previous_mood: EmotionalState = EmotionalState.NEUTRAL
    mood_history: List[tuple] = field(default_factory=list)  # [(timestamp, mood, intensity)]
    
    # Métricas del sistema
    current_metrics: Optional[SystemMetrics] = None
    metrics_history: List[SystemMetrics] = field(default_factory=list)
    system_health: float = 100.0  # 0-100
    system_load: SystemLoad = SystemLoad.IDLE
    
    # Tareas
    active_tasks: Dict[str, TaskInfo] = field(default_factory=dict)
    completed_tasks_today: int = 0
    failed_tasks_today: int = 0
    task_queue: List[TaskInfo] = field(default_factory=list)
    
    # Usuario
    user_present: bool = False
    user_last_seen: Optional[datetime] = None
    user_session_start: Optional[datetime] = None
    user_attention_level: float = 1.0  # 0.0 - 1.0
    
    # Seguridad
    threat_level: ThreatLevel = ThreatLevel.NONE
    security_alerts: List[Dict] = field(default_factory=list)
    security_events_today: int = 0
    
    # Rendimiento
    uptime_seconds: float = 0.0
    start_time: datetime = field(default_factory=datetime.now)
    last_optimization: Optional[datetime] = None
    optimization_count: int = 0
    
    # Errores y estabilidad
    errors_today: int = 0
    warnings_today: int = 0
    last_error: Optional[str] = None
    stability_score: float = 100.0  # 0-100
    
    # Aprendizaje
    patterns_detected_today: int = 0
    skills_used_today: Dict[str, int] = field(default_factory=dict)
    
    def to_dict(self) -> Dict:
        """Convierte el estado a diccionario para serialización."""
        return {
            'mood': self.mood.value,
            'mood_intensity': self.mood_intensity,
            'previous_mood': self.previous_mood.value,
            'system_health': self.system_health,
            'system_load': self.system_load.value,
            'active_tasks_count': len(self.active_tasks),
            'completed_tasks_today': self.completed_tasks_today,
            'user_present': self.user_present,
            'threat_level': self.threat_level.value,
            'uptime_seconds': self.uptime_seconds,
            'errors_today': self.errors_today,
            'stability_score': self.stability_score,
            'timestamp': datetime.now().isoformat()
        }
    
    def get_mood_duration(self) -> float:
        """Retorna cuánto tiempo ha estado en el mood actual (segundos)."""
        if not self.mood_history:
            return 0.0
        last_change = self.mood_history[-1][0]
        return (datetime.now() - last_change).total_seconds()


class StateEngine:
    """
    Motor de estado de JARVIS - Su "conciencia" operativa.
    
    Monitorea constantemente el sistema, gestiona el estado emocional,
    detecta anomalías, y proporciona información para decisiones autónomas.
    """
    
    # Umbrales configurables
    DEFAULT_THRESHOLDS = {
        'cpu_warning': 70.0,
        'cpu_critical': 90.0,
        'cpu_emergency': 95.0,
        'memory_warning': 75.0,
        'memory_critical': 90.0,
        'memory_emergency': 95.0,
        'disk_warning': 80.0,
        'disk_critical': 90.0,
        'health_low': 50.0,
        'health_critical': 30.0,
        'stability_min': 80.0
    }
    
    def __init__(self, memory_path: str = "memory/state.json", 
                 check_interval: float = 2.0):
        """
        Inicializa el motor de estado.
        
        Args:
            memory_path: Ruta para persistir estado
            check_interval: Segundos entre chequeos del sistema
        """
        self.state = JarvisState()
        self.memory_path = memory_path
        self.check_interval = check_interval
        
        self.running = False
        self.monitor_thread: Optional[threading.Thread] = None
        self._lock = threading.RLock()
        self._stop_event = threading.Event()
        
        # Callbacks para eventos de estado
        self.mood_callbacks: List[Callable[[EmotionalState, EmotionalState], None]] = []
        self.alert_callbacks: List[Callable[[Dict], None]] = []
        self.metric_callbacks: List[Callable[[SystemMetrics], None]] = []
        self.task_callbacks: List[Callable[[str, TaskInfo], None]] = []
        
        # Historial de métricas (para análisis de tendencias)
        self.metrics_history: List[SystemMetrics] = []
        self.max_history_size = 1000
        
        # Umbrales personalizados
        self.thresholds = self.DEFAULT_THRESHOLDS.copy()
        
        # Cargar estado previo si existe
        self._load_state()
        
        logger.info("StateEngine inicializado")
    
    def _load_state(self):
        """Carga estado persistente desde disco."""
        if not os.path.exists(self.memory_path):
            logger.info("No hay estado previo, iniciando desde cero")
            return
        
        try:
            with open(self.memory_path, 'r', encoding='utf-8') as f:
                data = json.load(f)
            
            # Restaurar contadores y configuración
            self.state.completed_tasks_today = data.get('completed_tasks_today', 0)
            self.state.optimization_count = data.get('optimization_count', 0)
            self.state.patterns_detected_today = data.get('patterns_detected_today', 0)
            
            # Restaurar mood si es válido
            mood_str = data.get('mood', 'neutral')
            try:
                self.state.mood = EmotionalState(mood_str)
            except ValueError:
                self.state.mood = EmotionalState.NEUTRAL
            
            logger.info(f"Estado cargado: {self.state.mood.value}, "
                       f"{self.state.completed_tasks_today} tareas completadas hoy")
            
        except Exception as e:
            logger.error(f"Error cargando estado: {e}")
    
    def _save_state(self):
        """Persiste estado actual a disco."""
        try:
            os.makedirs(os.path.dirname(self.memory_path), exist_ok=True)
            
            data = {
                'mood': self.state.mood.value,
                'completed_tasks_today': self.state.completed_tasks_today,
                'failed_tasks_today': self.state.failed_tasks_today,
                'optimization_count': self.state.optimization_count,
                'patterns_detected_today': self.state.patterns_detected_today,
                'skills_used_today': self.state.skills_used_today,
                'last_save': datetime.now().isoformat(),
                'uptime_seconds': self.state.uptime_seconds
            }
            
            with open(self.memory_path, 'w', encoding='utf-8') as f:
                json.dump(data, f, indent=2, ensure_ascii=False)
                
        except Exception as e:
            logger.error(f"Error guardando estado: {e}")
    
    def start(self):
        """
        Inicia el monitoreo continuo del sistema.
        Este método inicia threads de background.
        """
        if self.running:
            logger.warning("StateEngine ya está corriendo")
            return
        
        logger.info("Iniciando StateEngine...")
        self.running = True
        self._stop_event.clear()
        self.state.start_time = datetime.now()
        
        # Iniciar thread de monitoreo
        self.monitor_thread = threading.Thread(
            target=self._monitor_loop,
            name="StateMonitor",
            daemon=True
        )
        self.monitor_thread.start()
        
        # Estado inicial
        self._update_mood(EmotionalState.IDLE, 0.3)
        
        logger.info("StateEngine iniciado correctamente")
    
    def stop(self):
        """Detiene el monitoreo y guarda estado."""
        if not self.running:
            return
        
        logger.info("Deteniendo StateEngine...")
        self.running = False
        self._stop_event.set()
        
        # Esperar a que termine el thread (timeout 5 segundos)
        if self.monitor_thread and self.monitor_thread.is_alive():
            self.monitor_thread.join(timeout=5.0)
        
        self._save_state()
        logger.info("StateEngine detenido")
    
    def _monitor_loop(self):
        """
        Loop principal de monitoreo.
        Ejecuta en thread separado.
        """
        logger.info("Loop de monitoreo iniciado")
        
        while self.running and not self._stop_event.is_set():
            try:
                loop_start = time.time()
                
                # Recolectar métricas del sistema
                metrics = self._collect_metrics()
                
                # Actualizar estado con nuevas métricas
                with self._lock:
                    self.state.current_metrics = metrics
                    self.state.uptime_seconds = time.time() - self.state.start_time.timestamp()
                    
                    # Mantener historial limitado
                    self.metrics_history.append(metrics)
                    if len(self.metrics_history) > self.max_history_size:
                        self.metrics_history.pop(0)
                
                # Analizar métricas y actualizar estado
                self._analyze_metrics(metrics)
                
                # Verificar umbrales y generar alertas
                self._check_thresholds(metrics)
                
                # Actualizar estado emocional basado en contexto
                self._update_emotional_state()
                
                # Notificar suscriptores
                self._notify_metric_callbacks(metrics)
                
                # Calcular tiempo de sleep para mantener intervalo constante
                elapsed = time.time() - loop_start
                sleep_time = max(0, self.check_interval - elapsed)
                
                if sleep_time > 0:
                    self._stop_event.wait(sleep_time)
                
            except Exception as e:
                logger.error(f"Error en loop de monitoreo: {e}")
                self._record_error(str(e))
                time.sleep(5)  # Esperar más en caso de error
    
    def _collect_metrics(self) -> SystemMetrics:
        """
        Recolecta métricas completas del sistema operativo.
        
        Returns:
            SystemMetrics con datos actualizados
        """
        try:
            # CPU
            cpu_percent = psutil.cpu_percent(interval=0.5, percpu=True)
            cpu_total = sum(cpu_percent) / len(cpu_percent) if cpu_percent else 0.0
            
            # Memoria
            memory = psutil.virtual_memory()
            memory_gb = memory.total / (1024**3)
            memory_available_gb = memory.available / (1024**3)
            
            # Disco
            disk = psutil.disk_usage('/')
            disk_gb = disk.total / (1024**3)
            disk_free_gb = disk.free / (1024**3)
            
            # Red
            net_io = psutil.net_io_counters()
            net_sent_mb = net_io.bytes_sent / (1024**2)
            net_recv_mb = net_io.bytes_recv / (1024**2)
            
            # Boot time
            boot_time = datetime.fromtimestamp(psutil.boot_time())
            
            # Procesos
            process_count = len(list(psutil.process_iter()))
            thread_count = sum(p.num_threads() for p in psutil.process_iter())
            
            return SystemMetrics(
                timestamp=datetime.now(),
                cpu_percent=cpu_total,
                cpu_per_core=cpu_percent,
                memory_percent=memory.percent,
                memory_available_gb=memory_available_gb,
                memory_total_gb=memory_gb,
                disk_percent=(disk.used / disk.total) * 100,
                disk_free_gb=disk_free_gb,
                network_sent_mb=net_sent_mb,
                network_recv_mb=net_recv_mb,
                boot_time=boot_time,
                process_count=process_count,
                thread_count=thread_count
            )
            
        except Exception as e:
            logger.error(f"Error recolectando métricas: {e}")
            # Retornar métricas vacías en caso de error
            return SystemMetrics(
                timestamp=datetime.now(),
                cpu_percent=0.0,
                cpu_per_core=[],
                memory_percent=0.0,
                memory_available_gb=0.0,
                memory_total_gb=0.0,
                disk_percent=0.0,
                disk_free_gb=0.0,
                network_sent_mb=0.0,
                network_recv_mb=0.0,
                boot_time=None,
                process_count=0,
                thread_count=0
            )
    
    def _analyze_metrics(self, metrics: SystemMetrics):
        """
        Analiza métricas para determinar carga del sistema y salud.
        """
        with self._lock:
            # Determinar carga del sistema
            cpu = metrics.cpu_percent
            mem = metrics.memory_percent
            
            if cpu < 20 and mem < 40:
                self.state.system_load = SystemLoad.IDLE
            elif cpu < 40 and mem < 60:
                self.state.system_load = SystemLoad.LIGHT
            elif cpu < 70 and mem < 80:
                self.state.system_load = SystemLoad.MODERATE
            elif cpu < 90 and mem < 90:
                self.state.system_load = SystemLoad.HEAVY
            else:
                self.state.system_load = SystemLoad.CRITICAL
            
            # Calcular salud del sistema (0-100)
            health = 100.0
            
            # Penalizar por uso alto de recursos
            health -= (cpu * 0.25)  # CPU pesa 25%
            health -= (mem * 0.25)  # Memoria pesa 25%
            health -= (metrics.disk_percent * 0.15)  # Disco pesa 15%
            
            # Penalizar por errores
            health -= (self.state.errors_today * 3)
            health -= (self.state.warnings_today * 1)
            
            # Penalizar por estabilidad
            if self.state.stability_score < 50:
                health -= 20
            
            self.state.system_health = max(0.0, min(100.0, health))
    
    def _check_thresholds(self, metrics: SystemMetrics):
        """
        Verifica si las métricas exceden umbrales críticos.
        Genera alertas si es necesario.
        """
        alerts = []
        
        # CPU
        if metrics.cpu_percent > self.thresholds['cpu_emergency']:
            alerts.append({
                'level': 'emergency',
                'type': 'cpu',
                'value': metrics.cpu_percent,
                'message': f"CPU en estado crítico: {metrics.cpu_percent:.1f}%"
            })
            self._update_mood(EmotionalState.CONCERNED, 0.9)
            self.state.threat_level = ThreatLevel.CRITICAL
            
        elif metrics.cpu_percent > self.thresholds['cpu_critical']:
            alerts.append({
                'level': 'critical',
                'type': 'cpu',
                'value': metrics.cpu_percent,
                'message': f"CPU crítico: {metrics.cpu_percent:.1f}%"
            })
            self._update_mood(EmotionalState.CONCERNED, 0.8)
            self.state.threat_level = max(self.state.threat_level, ThreatLevel.HIGH)
            
        elif metrics.cpu_percent > self.thresholds['cpu_warning']:
            alerts.append({
                'level': 'warning',
                'type': 'cpu',
                'value': metrics.cpu_percent,
                'message': f"CPU alto: {metrics.cpu_percent:.1f}%"
            })
        
        # Memoria
        if metrics.memory_percent > self.thresholds['memory_emergency']:
            alerts.append({
                'level': 'emergency',
                'type': 'memory',
                'value': metrics.memory_percent,
                'message': f"Memoria crítica: {metrics.memory_percent:.1f}%"
            })
            self._update_mood(EmotionalState.CONCERNED, 0.95)
            self.state.threat_level = ThreatLevel.CRITICAL
            
        elif metrics.memory_percent > self.thresholds['memory_critical']:
            alerts.append({
                'level': 'critical',
                'type': 'memory',
                'value': metrics.memory_percent,
                'message': f"Memoria crítica: {metrics.memory_percent:.1f}%"
            })
            self._update_mood(EmotionalState.CONCERNED, 0.9)
            self.state.threat_level = max(self.state.threat_level, ThreatLevel.HIGH)
            
        elif metrics.memory_percent > self.thresholds['memory_warning']:
            alerts.append({
                'level': 'warning',
                'type': 'memory',
                'value': metrics.memory_percent,
                'message': f"Memoria alta: {metrics.memory_percent:.1f}%"
            })
        
        # Disco
        if metrics.disk_percent > self.thresholds['disk_critical']:
            alerts.append({
                'level': 'critical',
                'type': 'disk',
                'value': metrics.disk_percent,
                'message': f"Disco crítico: {metrics.disk_percent:.1f}%"
            })
            
        elif metrics.disk_percent > self.thresholds['disk_warning']:
            alerts.append({
                'level': 'warning',
                'type': 'disk',
                'value': metrics.disk_percent,
                'message': f"Disco lleno: {metrics.disk_percent:.1f}%"
            })
        
        # Salud del sistema
        if self.state.system_health < self.thresholds['health_critical']:
            alerts.append({
                'level': 'critical',
                'type': 'health',
                'value': self.state.system_health,
                'message': f"Salud del sistema crítica: {self.state.system_health:.1f}%"
            })
            self.state.threat_level = max(self.state.threat_level, ThreatLevel.HIGH)
            
        elif self.state.system_health < self.thresholds['health_low']:
            alerts.append({
                'level': 'warning',
                'type': 'health',
                'value': self.state.system_health,
                'message': f"Salud del sistema baja: {self.state.system_health:.1f}%"
            })
            self.state.threat_level = max(self.state.threat_level, ThreatLevel.MEDIUM)
        
        # Guardar alertas y notificar
        if alerts:
            with self._lock:
                self.state.security_alerts.extend(alerts)
                # Mantener solo últimas 20 alertas
                if len(self.state.security_alerts) > 20:
                    self.state.security_alerts = self.state.security_alerts[-20:]
            
            for alert in alerts:
                self._notify_alert_callbacks(alert)
    
    def _update_emotional_state(self):
        """
        Actualiza el estado emocional basado en el contexto actual.
        """
        with self._lock:
            # Si hay tareas de alta prioridad
            high_priority_tasks = [
                t for t in self.state.active_tasks.values() 
                if t.priority >= 8
            ]
            if high_priority_tasks:
                self._update_mood(EmotionalState.FOCUSED, 0.9)
                return
            
            # Si está procesando algo
            if self.state.active_tasks:
                self._update_mood(EmotionalState.PROCESSING, 0.7)
                return
            
            # Si hay problemas de salud
            if self.state.system_health < 40:
                self._update_mood(EmotionalState.CONCERNED, 0.7)
                return
            
            # Si está optimizando
            if self.state.last_optimization and \
               (datetime.now() - self.state.last_optimization).seconds < 60:
                self._update_mood(EmotionalState.OPTIMIZING, 0.8)
                return
            
            # Si el usuario no está presente
            if not self.state.user_present:
                time_since_seen = 0
                if self.state.user_last_seen:
                    time_since_seen = (datetime.now() - self.state.user_last_seen).seconds
                
                if time_since_seen > 300:  # 5 minutos
                    self._update_mood(EmotionalState.STANDBY, 0.4)
                else:
                    self._update_mood(EmotionalState.IDLE, 0.5)
                return
            
            # Estado por defecto
            if self.state.system_load == SystemLoad.IDLE:
                self._update_mood(EmotionalState.IDLE, 0.5)
            else:
                self._update_mood(EmotionalState.NEUTRAL, 0.6)
    
    def _update_mood(self, new_mood: EmotionalState, intensity: float = 0.5):
        """
        Actualiza el estado emocional si es diferente al actual.
        
        Args:
            new_mood: Nuevo estado emocional
            intensity: Intensidad del estado (0.0 - 1.0)
        """
        with self._lock:
            if self.state.mood == new_mood:
                # Actualizar intensidad si es el mismo mood
                self.state.mood_intensity = intensity
                return
            
            # Guardar historial
            self.state.previous_mood = self.state.mood
            self.state.mood_history.append((
                datetime.now(),
                self.state.mood,
                self.state.mood_intensity
            ))
            
            # Limitar historial
            if len(self.state.mood_history) > 100:
                self.state.mood_history = self.state.mood_history[-100:]
            
            # Actualizar estado
            old_mood = self.state.mood
            self.state.mood = new_mood
            self.state.mood_intensity = intensity
            
            logger.info(f"Mood cambiado: {old_mood.value} -> {new_mood.value} "
                       f"(intensidad: {intensity})")
            
            # Notificar callbacks
            self._notify_mood_callbacks(old_mood, new_mood)
    
    def _record_error(self, error_msg: str):
        """Registra un error en el estado."""
        with self._lock:
            self.state.errors_today += 1
            self.state.last_error = error_msg
            # Reducir estabilidad
            self.state.stability_score = max(0, self.state.stability_score - 5)
    
    def _record_warning(self, warning_msg: str):
        """Registra una advertencia."""
        with self._lock:
            self.state.warnings_today += 1
    
    # ==================== API PÚBLICA ====================
    
    def register_mood_callback(self, callback: Callable[[EmotionalState, EmotionalState], None]):
        """Registra callback para cambios de mood."""
        self.mood_callbacks.append(callback)
    
    def register_alert_callback(self, callback: Callable[[Dict], None]):
        """Registra callback para alertas."""
        self.alert_callbacks.append(callback)
    
    def register_metric_callback(self, callback: Callable[[SystemMetrics], None]):
        """Registra callback para nuevas métricas."""
        self.metric_callbacks.append(callback)
    
    def register_task_callback(self, callback: Callable[[str, TaskInfo], None]):
        """Registra callback para eventos de tareas."""
        self.task_callbacks.append(callback)
    
    def _notify_mood_callbacks(self, old_mood: EmotionalState, new_mood: EmotionalState):
        """Notifica cambios de mood a suscriptores."""
        for callback in self.mood_callbacks:
            try:
                callback(old_mood, new_mood)
            except Exception as e:
                logger.error(f"Error en mood callback: {e}")
    
    def _notify_alert_callbacks(self, alert: Dict):
        """Notifica alertas a suscriptores."""
        for callback in self.alert_callbacks:
            try:
                callback(alert)
            except Exception as e:
                logger.error(f"Error en alert callback: {e}")
    
    def _notify_metric_callbacks(self, metrics: SystemMetrics):
        """Notifica nuevas métricas a suscriptores."""
        for callback in self.metric_callbacks:
            try:
                callback(metrics)
            except Exception as e:
                logger.error(f"Error en metric callback: {e}")
    
    def user_detected(self, present: bool, confidence: float = 1.0):
        """
        Notifica detección de presencia del usuario.
        
        Args:
            present: True si el usuario está presente
            confidence: Confianza de la detección (0.0 - 1.0)
        """
        with self._lock:
            was_present = self.state.user_present
            self.state.user_present = present
            self.state.user_attention_level = confidence
            
            if present:
                self.state.user_last_seen = datetime.now()
                if not was_present:
                    # Usuario regresó
                    self.state.user_session_start = datetime.now()
                    self._update_mood(EmotionalState.FOCUSED, 0.8)
                    logger.info("Usuario detectado")
            else:
                if was_present:
                    # Usuario se fue
                    logger.info("Usuario ya no detectado")
                    self._update_mood(EmotionalState.IDLE, 0.4)
    
    def task_started(self, task_id: str, name: str, task_type: str = "general",
                    priority: int = 5, estimated_duration: Optional[int] = None,
                    metadata: Dict = None) -> TaskInfo:
        """
        Registra inicio de una nueva tarea.
        
        Returns:
            TaskInfo creada
        """
        task = TaskInfo(
            id=task_id,
            name=name,
            type=task_type,
            priority=priority,
            started=datetime.now(),
            estimated_duration=estimated_duration,
            status="running",
            metadata=metadata or {}
        )
        
        with self._lock:
            self.state.active_tasks[task_id] = task
        
        # Notificar
        for callback in self.task_callbacks:
            try:
                callback("started", task)
            except:
                pass
        
        # Actualizar mood si es tarea importante
        if priority >= 7:
            self._update_mood(EmotionalState.PROCESSING, 0.8)
        
        logger.info(f"Tarea iniciada: {name} (ID: {task_id}, prioridad: {priority})")
        return task
    
    def task_progress(self, task_id: str, progress: float):
        """Actualiza progreso de una tarea."""
        with self._lock:
            if task_id in self.state.active_tasks:
                self.state.active_tasks[task_id].progress = max(0.0, min(1.0, progress))
    
    def task_completed(self, task_id: str, success: bool = True, result: Any = None):
        """
        Marca una tarea como completada.
        """
        with self._lock:
            if task_id not in self.state.active_tasks:
                logger.warning(f"Intentando completar tarea desconocida: {task_id}")
                return
            
            task = self.state.active_tasks[task_id]
            task.status = "completed" if success else "failed"
            task.progress = 1.0 if success else task.progress
            
            # Mover a historial y eliminar de activas
            del self.state.active_tasks[task_id]
            
            if success:
                self.state.completed_tasks_today += 1
            else:
                self.state.failed_tasks_today += 1
        
        # Notificar
        for callback in self.task_callbacks:
            try:
                callback("completed" if success else "failed", task)
            except:
                pass
        
        # Actualizar mood si no hay más tareas
        if not self.state.active_tasks:
            self._update_mood(EmotionalState.FOCUSED, 0.6)
        
        logger.info(f"Tarea {task_id} {'completada' if success else 'fallida'}")
    
    def record_skill_usage(self, skill_name: str):
        """Registra uso de un skill."""
        with self._lock:
            if skill_name not in self.state.skills_used_today:
                self.state.skills_used_today[skill_name] = 0
            self.state.skills_used_today[skill_name] += 1
    
    def record_pattern_detected(self):
        """Registra detección de un patrón."""
        with self._lock:
            self.state.patterns_detected_today += 1
    
    def record_optimization(self):
        """Registra una optimización realizada."""
        with self._lock:
            self.state.last_optimization = datetime.now()
            self.state.optimization_count += 1
    
    def get_status_report(self) -> str:
        """
        Genera reporte de estado completo para el usuario.
        """
        with self._lock:
            mood_desc = {
                EmotionalState.NEUTRAL: "operando normalmente",
                EmotionalState.FOCUSED: "enfocado en sus tareas",
                EmotionalState.ALERT: "en estado de alerta",
                EmotionalState.IDLE: "en espera",
                EmotionalState.PROCESSING: "procesando información",
                EmotionalState.CONCERNED: "detectando anomalías",
                EmotionalState.OPTIMIZING: "optimizando el sistema",
                EmotionalState.LEARNING: "aprendiendo patrones",
                EmotionalState.ASSISTING: "asistiendo al usuario",
                EmotionalState.STANDBY: "en modo de espera"
            }
            
            report_parts = []
            
            # Estado emocional
            report_parts.append(f"Estoy {mood_desc.get(self.state.mood, 'operando')}, Señor.")
            
            # Salud del sistema
            health_status = "excelente" if self.state.system_health > 80 else \
                          "buena" if self.state.system_health > 60 else \
                          "regular" if self.state.system_health > 40 else "crítica"
            report_parts.append(f"Sistema al {self.state.system_health:.0f}% de salud ({health_status}).")
            
            # Carga
            report_parts.append(f"Carga actual: {self.state.system_load.value}.")
            
            # Tareas
            if self.state.active_tasks:
                report_parts.append(f"Procesando {len(self.state.active_tasks)} tareas activas.")
            
            # Alertas
            if self.state.security_alerts:
                critical = sum(1 for a in self.state.security_alerts if a['level'] == 'critical')
                if critical > 0:
                    report_parts.append(f"⚠️  {critical} alertas críticas requieren atención.")
            
            # Uptime
            hours = int(self.state.uptime_seconds // 3600)
            minutes = int((self.state.uptime_seconds % 3600) // 60)
            report_parts.append(f"Tiempo activo: {hours}h {minutes}m.")
            
            return " ".join(report_parts)
    
    def should_proactively_act(self) -> bool:
        """
        Determina si JARVIS debería actuar proactivamente.
        """
        with self._lock:
            # Si hay problemas graves de salud
            if self.state.system_health < 40:
                return True
            
            # Si hay amenazas de seguridad
            if self.state.threat_level.value >= 2:
                return True
            
            # Si CPU está crítica y no está ya optimizando
            if self.state.system_load == SystemLoad.CRITICAL and \
               self.state.mood != EmotionalState.OPTIMIZING:
                return True
            
            # Si hay alertas críticas sin atender
            critical_alerts = [a for a in self.state.security_alerts 
                             if a['level'] == 'critical']
            if len(critical_alerts) > 2:
                return True
            
            return False
    
    def get_optimization_suggestions(self) -> List[str]:
        """
        Genera sugerencias de optimización basadas en el estado actual.
        """
        suggestions = []
        
        with self._lock:
            if not self.state.current_metrics:
                return suggestions
            
            metrics = self.state.current_metrics
            
            if metrics.cpu_percent > 70:
                suggestions.append({
                    'priority': 'high' if metrics.cpu_percent > 85 else 'medium',
                    'category': 'cpu',
                    'suggestion': 'Cerrar aplicaciones en segundo plano de alto consumo',
                    'action': 'optimize_cpu'
                })
            
            if metrics.memory_percent > 80:
                suggestions.append({
                    'priority': 'high' if metrics.memory_percent > 90 else 'medium',
                    'category': 'memory',
                    'suggestion': 'Liberar memoria de caché y aplicaciones inactivas',
                    'action': 'optimize_memory'
                })
            
            if metrics.disk_percent > 85:
                suggestions.append({
                    'priority': 'high',
                    'category': 'disk',
                    'suggestion': 'Limpiar archivos temporales y caché del sistema',
                    'action': 'cleanup_disk'
                })
            
            if self.state.errors_today > 5:
                suggestions.append({
                    'priority': 'medium',
                    'category': 'stability',
                    'suggestion': 'Revisar logs de errores y estabilizar sistema',
                    'action': 'review_logs'
                })
        
        return suggestions
    
    def get_current_state(self) -> JarvisState:
        """Retorna copia del estado actual (thread-safe)."""
        with self._lock:
            # Retornar referencia directa pero con lock protegido
            return self.state
    
    def is_running(self) -> bool:
        """Retorna si el motor está corriendo."""
        return self.running