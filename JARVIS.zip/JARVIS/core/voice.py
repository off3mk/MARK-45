"""
core/voice.py
Sistema de Voz de JARVIS v4.0

Implementa Text-to-Speech (TTS) usando Edge TTS con voz es-ES-AlvaroNeural,
y proporciona capacidades básicas de reconocimiento de voz (STT) integrado
con el sistema de percepción de audio.
"""

import asyncio
import os
import tempfile
import threading
import queue
import time
from typing import Optional, Callable, List, Dict
from dataclasses import dataclass
from enum import Enum
import logging

logger = logging.getLogger(__name__)


class VoiceState(Enum):
    """Estados del sistema de voz."""
    IDLE = "idle"
    SPEAKING = "speaking"
    QUEUED = "queued"
    ERROR = "error"
    MUTED = "muted"


@dataclass
class SpeechRequest:
    """Solicitud de síntesis de voz."""
    text: str
    priority: int  # 1-10, mayor = más urgente
    timestamp: float
    callback: Optional[Callable] = None


class VoiceSystem:
    """
    Sistema de voz de JARVIS.
    
    Características:
    - TTS usando Edge TTS (voz es-ES-AlvaroNeural)
    - Cola de mensajes priorizada
    - Control de velocidad y volumen
    - Interrupción de speech en curso
    - Estado silenciado/mudo
    """
    
    def __init__(self, 
                 voice: str = "es-ES-AlvaroNeural",
                 rate: str = "+0%",
                 volume: float = 1.0,
                 max_queue_size: int = 10):
        """
        Inicializa el sistema de voz.
        
        Args:
            voice: ID de voz de Edge TTS
            rate: Velocidad de habla (+0%, +10%, -10%, etc.)
            volume: Volumen de salida (0.0-1.0)
            max_queue_size: Tamaño máximo de la cola de mensajes
        """
        self.voice_id = voice
        self.rate = rate
        self.volume = volume
        self.max_queue_size = max_queue_size
        
        # Estado
        self.enabled = True
        self.state = VoiceState.IDLE
        self.current_text = ""
        
        # Cola de mensajes
        self.speech_queue: queue.PriorityQueue = queue.PriorityQueue()
        self.queue_lock = threading.Lock()
        
        # Thread de procesamiento
        self.speech_thread: Optional[threading.Thread] = None
        self.running = False
        self._stop_event = threading.Event()
        
        # Interrupción
        self._current_playback = None
        self._interrupt_flag = False
        
        # Estadísticas
        self.stats = {
            'messages_spoken': 0,
            'characters_spoken': 0,
            'errors': 0,
            'avg_latency_ms': 0
        }
        
        # Verificar dependencias
        self._check_dependencies()
        
        logger.info(f"VoiceSystem inicializado con voz: {voice}")
    
    def _check_dependencies(self):
        """Verifica que las dependencias de audio estén instaladas."""
        self.dependencies_ok = True
        self.missing_deps = []
        
        try:
            import edge_tts
        except ImportError:
            self.dependencies_ok = False
            self.missing_deps.append("edge-tts")
            logger.warning("edge-tts no instalado. TTS desactivado.")
        
        try:
            import playsound
        except ImportError:
            self.dependencies_ok = False
            self.missing_deps.append("playsound")
            logger.warning("playsound no instalado. Reproducción desactivada.")
    
    def start(self):
        """Inicia el thread de procesamiento de voz."""
        if self.running or not self.enabled:
            return
        
        self.running = True
        self._stop_event.clear()
        
        self.speech_thread = threading.Thread(
            target=self._speech_loop,
            name="VoiceProcessor",
            daemon=True
        )
        self.speech_thread.start()
        
        logger.info("VoiceSystem iniciado")
    
    def stop(self):
        """Detiene el sistema de voz."""
        if not self.running:
            return
        
        self.running = False
        self._stop_event.set()
        
        # Limpiar cola
        with self.queue_lock:
            while not self.speech_queue.empty():
                try:
                    self.speech_queue.get_nowait()
                except queue.Empty:
                    break
        
        if self.speech_thread:
            self.speech_thread.join(timeout=3.0)
        
        logger.info("VoiceSystem detenido")
    
    def _speech_loop(self):
        """Loop principal de procesamiento de voz."""
        while self.running and not self._stop_event.is_set():
            try:
                # Obtener siguiente mensaje (con timeout para poder verificar _stop_event)
                try:
                    priority, request = self.speech_queue.get(timeout=0.5)
                except queue.Empty:
                    if self.state == VoiceState.SPEAKING:
                        self.state = VoiceState.IDLE
                    continue
                
                # Procesar mensaje
                self._process_speech_request(request)
                
            except Exception as e:
                logger.error(f"Error en speech loop: {e}")
                self.state = VoiceState.ERROR
                time.sleep(1)
    
    def _process_speech_request(self, request: SpeechRequest):
        """Procesa una solicitud de síntesis de voz."""
        if not self.dependencies_ok:
            logger.info(f"[TTS desactivado] {request.text[:50]}...")
            return
        
        self.state = VoiceState.SPEAKING
        self.current_text = request.text
        start_time = time.time()
        
        try:
            # Verificar interrupción
            if self._interrupt_flag:
                self._interrupt_flag = False
                return
            
            # Generar audio
            audio_path = self._synthesize(request.text)
            
            if audio_path and os.path.exists(audio_path):
                # Reproducir
                self._play_audio(audio_path)
                
                # Actualizar estadísticas
                self.stats['messages_spoken'] += 1
                self.stats['characters_spoken'] += len(request.text)
                
                latency = (time.time() - start_time) * 1000
                self._update_latency_stats(latency)
                
                # Callback si existe
                if request.callback:
                    try:
                        request.callback(True)
                    except:
                        pass
                
                # Limpiar archivo temporal
                try:
                    os.unlink(audio_path)
                except:
                    pass
            
        except Exception as e:
            logger.error(f"Error en síntesis/reproducción: {e}")
            self.stats['errors'] += 1
            
            if request.callback:
                try:
                    request.callback(False)
                except:
                    pass
        
        finally:
            self.current_text = ""
            if self.state == VoiceState.SPEAKING:
                self.state = VoiceState.IDLE
    
    def _synthesize(self, text: str) -> Optional[str]:
        """Sintetiza texto a audio usando Edge TTS."""
        import edge_tts
        
        # Crear archivo temporal
        fd, path = tempfile.mkstemp(suffix='.mp3')
        os.close(fd)
        
        # Configurar comunicación
        communicate = edge_tts.Communicate(
            text=text,
            voice=self.voice_id,
            rate=self.rate
        )
        
        # Generar (async en thread separado)
        loop = asyncio.new_event_loop()
        try:
            asyncio.set_event_loop(loop)
            loop.run_until_complete(communicate.save(path))
        finally:
            loop.close()
        
        return path
    
    def _play_audio(self, audio_path: str):
        """Reproduce archivo de audio."""
        import playsound
        
        # Verificar interrupción antes de reproducir
        if self._interrupt_flag:
            self._interrupt_flag = False
            return
        
        self._current_playback = audio_path
        
        try:
            playsound.playsound(audio_path, block=True)
        except Exception as e:
            logger.error(f"Error reproduciendo audio: {e}")
        
        self._current_playback = None
    
    def speak(self, text: str, priority: int = 5, 
              interrupt: bool = False,
              callback: Optional[Callable[[bool], None]] = None) -> bool:
        """
        Solicita síntesis de voz de un texto.
        
        Args:
            text: Texto a hablar
            priority: Prioridad (1-10, mayor = más urgente)
            interrupt: Si True, interrumpe speech actual
            callback: Función a llamar al completar (éxito/fracaso)
        
        Returns:
            True si se encoló correctamente
        """
        if not self.enabled or self.state == VoiceState.MUTED:
            logger.debug(f"[Mute] {text[:50]}...")
            return False
        
        if not text or not text.strip():
            return False
        
        # Limpiar texto para TTS
        text = self._clean_text_for_speech(text)
        
        if len(text) > 500:  # Limitar longitud
            text = text[:497] + "..."
        
        # Interrumpir si es necesario
        if interrupt and self.state == VoiceState.SPEAKING:
            self.interrupt()
        
        # Verificar tamaño de cola
        with self.queue_lock:
            if self.speech_queue.qsize() >= self.max_queue_size:
                # Eliminar mensaje de menor prioridad
                logger.warning("Cola de voz llena, omitiendo mensaje")
                return False
        
        # Crear solicitud (usar negativo de prioridad para que mayor prioridad salga primero)
        request = SpeechRequest(
            text=text,
            priority=priority,
            timestamp=time.time(),
            callback=callback
        )
        
        # Encolar
        self.speech_queue.put((-priority, request))
        self.state = VoiceState.QUEUED
        
        logger.debug(f"Encolado para hablar (prioridad {priority}): {text[:50]}...")
        return True
    
    def interrupt(self):
        """Interrumpe el speech actual."""
        if self.state == VoiceState.SPEAKING:
            self._interrupt_flag = True
            logger.info("Speech interrumpido")
            
            # Intentar detener reproducción actual (limitado por playsound)
            # playsound no soporta interrupción directa, pero marcamos la flag
            # para que el siguiente loop no reproduzca
    
    def _clean_text_for_speech(self, text: str) -> str:
        """Limpia texto para mejor síntesis de voz."""
        # Eliminar emojis
        import re
        text = re.sub(r'[^\w\s.,;:!?¿¡\-\'\"()]', '', text)
        
        # Normalizar espacios
        text = ' '.join(text.split())
        
        # Limitar caracteres especiales que confunden al TTS
        replacements = {
            '...': '.',
            '->': ' a ',
            '=>': ' igual a ',
            '==': ' igual ',
            '!=': ' diferente de ',
            '>=': ' mayor o igual ',
            '<=': ' menor o igual '
        }
        
        for old, new in replacements.items():
            text = text.replace(old, new)
        
        return text.strip()
    
    def _update_latency_stats(self, latency_ms: float):
        """Actualiza estadísticas de latencia."""
        alpha = 0.1
        current = self.stats['avg_latency_ms']
        self.stats['avg_latency_ms'] = (1 - alpha) * current + alpha * latency_ms
    
    # ==================== CONTROLES ====================
    
    def enable(self):
        """Habilita el sistema de voz."""
        self.enabled = True
        self.state = VoiceState.IDLE
        logger.info("VoiceSystem habilitado")
    
    def disable(self):
        """Deshabilita el sistema de voz."""
        self.enabled = False
        self.interrupt()
        logger.info("VoiceSystem deshabilitado")
    
    def mute(self):
        """Silencia el sistema (mantiene procesamiento pero no reproduce)."""
        self.state = VoiceState.MUTED
        self.interrupt()
        logger.info("VoiceSystem silenciado")
    
    def unmute(self):
        """Des-silencia."""
        if self.state == VoiceState.MUTED:
            self.state = VoiceState.IDLE
            logger.info("VoiceSystem activado")
    
    def set_voice(self, voice_id: str):
        """Cambia la voz utilizada."""
        self.voice_id = voice_id
        logger.info(f"Voz cambiada a: {voice_id}")
    
    def set_rate(self, rate: str):
        """
        Cambia la velocidad de habla.
        
        Args:
            rate: "+0%", "+10%", "-10%", "+20%", etc.
        """
        self.rate = rate
        logger.info(f"Velocidad de habla: {rate}")
    
    def set_volume(self, volume: float):
        """
        Establece volumen (0.0-1.0).
        Nota: El volumen real depende del sistema de audio subyacente.
        """
        self.volume = max(0.0, min(1.0, volume))
        logger.info(f"Volumen: {self.volume}")
    
    # ==================== ESTADO Y STATS ====================
    
    def is_speaking(self) -> bool:
        """Retorna si está hablando actualmente."""
        return self.state == VoiceState.SPEAKING
    
    def is_enabled(self) -> bool:
        """Retorna si el sistema está habilitado."""
        return self.enabled and self.state != VoiceState.MUTED
    
    def get_queue_size(self) -> int:
        """Retorna mensajes pendientes."""
        return self.speech_queue.qsize()
    
    def get_current_text(self) -> str:
        """Retorna texto siendo hablado actualmente."""
        return self.current_text if self.state == VoiceState.SPEAKING else ""
    
    def get_stats(self) -> Dict:
        """Retorna estadísticas del sistema de voz."""
        return {
            **self.stats,
            'state': self.state.value,
            'enabled': self.enabled,
            'voice': self.voice_id,
            'rate': self.rate,
            'queue_size': self.get_queue_size(),
            'dependencies_ok': self.dependencies_ok,
            'missing_dependencies': self.missing_deps
        }
    
    def get_available_voices(self) -> List[Dict]:
        """
        Retorna voces disponibles de Edge TTS.
        Nota: Requiere conexión a internet para listar.
        """
        if not self.dependencies_ok:
            return []
        
        try:
            import edge_tts
            
            # Voces comunes en español e inglés
            common_voices = [
                {"id": "es-ES-AlvaroNeural", "name": "Alvaro (España)", "lang": "es-ES", "gender": "Male"},
                {"id": "es-ES-ElviraNeural", "name": "Elvira (España)", "lang": "es-ES", "gender": "Female"},
                {"id": "es-MX-JorgeNeural", "name": "Jorge (México)", "lang": "es-MX", "gender": "Male"},
                {"id": "es-MX-DaliaNeural", "name": "Dalia (México)", "lang": "es-MX", "gender": "Female"},
                {"id": "en-US-GuyNeural", "name": "Guy (US)", "lang": "en-US", "gender": "Male"},
                {"id": "en-US-JennyNeural", "name": "Jenny (US)", "lang": "en-US", "gender": "Female"},
                {"id": "en-GB-RyanNeural", "name": "Ryan (UK)", "lang": "en-GB", "gender": "Male"},
            ]
            
            return common_voices
            
        except Exception as e:
            logger.error(f"Error obteniendo voces: {e}")
            return []