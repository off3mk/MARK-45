#!/usr/bin/env python3
"""
main.py
Punto de entrada de JARVIS v4.0 Definitivo

Sistema autónomo de asistencia personal estilo Iron Man.
"""

import sys
import os
import argparse
import signal
import threading
import time
from pathlib import Path

# Asegurar que los módulos locales son importables
sys.path.insert(0, str(Path(__file__).parent))

# Core
from core.brain import JarvisBrain
from core.state import StateEngine, EmotionalState
from core.autonomous import AutonomousEngine
from core.cognitive_memory import CognitiveMemory
from core.ai_manager import AIManager
from core.personality import Personality
from core.security import SecurityManager
from core.voice import VoiceSystem
from core.self_improvement import SelfImprovement

# Perception
from perception.screen_monitor import ScreenMonitor
from perception.audio_monitor import AudioMonitor
from perception.system_monitor import SystemMonitor

# UI
from ui.interface import JarvisUI


class Jarvis:
    """
    JARVIS v4.0 - Just A Rather Very Intelligent System
    
    Sistema integrado con:
    - IA híbrida (local + online)
    - Conciencia operativa y estado emocional
    - Autonomía proactiva
    - Memoria cognitiva persistente
    - Percepción continua (visión, audio, sistema)
    - Control total del PC
    - Interfaz futurista
    """
    
    VERSION = "4.0.0"
    NAME = "JARVIS"
    
    def __init__(self, mode: str = "gui", config: dict = None):
        """
        Inicializa JARVIS.
        
        Args:
            mode: 'gui', 'cli', o 'headless'
            config: Configuración personalizada
        """
        self.mode = mode
        self.config = config or {}
        self.running = False
        
        print(f"\n{'='*60}")
        print(f"  {self.NAME} v{self.VERSION}")
        print(f"  Just A Rather Very Intelligent System")
        print(f"{'='*60}\n")
        
        # Inicializar subsistemas
        self._init_core()
        self._init_perception()
        
        if mode == "gui":
            self._init_ui()
        
        print("✅ Todos los sistemas operativos")
        print(f"{'='*60}\n")
    
    def _init_core(self):
        """Inicializa núcleo del sistema."""
        print("🧠 Inicializando núcleo cognitivo...")
        
        # Memoria (primero, otros dependen de ella)
        self.memory = CognitiveMemory()
        print("  ✓ Memoria cognitiva")
        
        # Estado/Conciencia
        self.state = StateEngine()
        print("  ✓ Conciencia operativa")
        
        # IA
        self.ai = AIManager()
        print(f"  ✓ IA híbrida (Ollama: {self.ai.is_local_available()})")
        
        # Personalidad
        self.personality = Personality()
        print("  ✓ Personalidad JARVIS")
        
        # Seguridad
        self.security = SecurityManager()
        print("  ✓ Sistema de seguridad")
        
        # Voz
        self.voice = VoiceSystem()
        print("  ✓ Síntesis de voz")
        
        # Cerebro (coordina todo)
        self.brain = JarvisBrain(
            ai_manager=self.ai,
            memory=self.memory,
            state_engine=self.state,
            personality=self.personality,
            security=self.security,
            voice=self.voice
        )
        print("  ✓ Cerebro central")
        
        # Autonomía
        self.autonomous = AutonomousEngine(
            state_engine=self.state,
            cognitive_memory=self.memory,
            skill_manager=self.brain.skill_manager
        )
        self._setup_autonomous_handlers()
        print("  ✓ Motor de autonomía")
        
        # Auto-mejora
        self.self_improvement = SelfImprovement(
            skill_manager=self.brain.skill_manager,
            ai_manager=self.ai
        )
        print("  ✓ Sistema de auto-mejora")
    
    def _init_perception(self):
        """Inicializa sistemas de percepción."""
        print("👁️  Inicializando percepción...")
        
        # Visión
        self.screen_monitor = ScreenMonitor(
            callback=self._on_vision_event
        )
        print("  ✓ Visión por computadora")
        
        # Audio
        self.audio_monitor = AudioMonitor(
            wake_word="jarvis",
            callback=self._on_audio_event
        )
        print("  ✓ Monitoreo de audio")
        
        # Sistema
        self.system_monitor = SystemMonitor(
            callback=self._on_system_event
        )
        print("  ✓ Monitoreo de sistema")
    
    def _init_ui(self):
        """Inicializa interfaz gráfica."""
        print("🎨 Preparando interfaz...")
        
        self.ui = JarvisUI(
            brain=self.brain,
            state_engine=self.state,
            voice_system=self.voice,
            on_command=self.process_command
        )
        print("  ✓ Interfaz gráfica lista")
    
    def _setup_autonomous_handlers(self):
        """Configura handlers para acciones autónomas."""
        self.autonomous.register_action_handler(
            ActionType.OPTIMIZE_SYSTEM,
            self._action_optimize
        )
        self.autonomous.register_action_handler(
            ActionType.MORNING_SETUP,
            self._action_morning
        )
        self.autonomous.register_action_handler(
            ActionType.CLEANUP_RESOURCES,
            self._action_cleanup
        )
        self.autonomous.register_action_handler(
            ActionType.NOTIFY_USER,
            self._action_notify
        )
    
    def _action_optimize(self, **kwargs):
        """Acción: Optimizar sistema."""
        self.voice.speak("Detecté condiciones para optimización. Procediendo, Señor.")
        # Aquí irían acciones específicas de optimización
        return True
    
    def _action_morning(self, apps=None, **kwargs):
        """Acción: Configurar entorno matutino."""
        self.voice.speak("Buenos días. Preparando entorno de trabajo.")
        
        apps = apps or ['chrome']
        for app in apps:
            self.brain.skill_manager.execute_skill('system', 'open_program', {'program': app})
        
        self.brain.skill_manager.execute_skill('media', 'volume_set', {'level': 30})
        return True
    
    def _action_cleanup(self, **kwargs):
        """Acción: Limpiar recursos."""
        self.voice.speak("Limpiando recursos del sistema.")
        return True
    
    def _action_notify(self, message=None, **kwargs):
        """Acción: Notificar al usuario."""
        if message:
            self.voice.speak(message)
        return True
    
    def _on_vision_event(self, event):
        """Callback para eventos de visión."""
        if event.event_type.value == 'wake_word':
            self.state.user_detected(True)
    
    def _on_audio_event(self, event):
        """Callback para eventos de audio."""
        if event.event_type == AudioEventType.WAKE_WORD:
            self.voice.speak("¿Sí, Señor?")
            self.state._update_mood(EmotionalState.ALERT, 0.9)
        
        elif event.event_type == AudioEventType.TRANSCRIPTION:
            text = event.data.get('transcription', '')
            if text:
                response = self.process_command(text)
                self.voice.speak(response)
    
    def _on_system_event(self, event):
        """Callback para eventos de sistema."""
        if event['type'] == 'anomaly_detected':
            anomaly = event.get('anomaly', {})
            if anomaly.get('severity') in ['high', 'critical']:
                self.voice.speak(
                    f"Alerta del sistema: {anomaly.get('description', '')}"
                )
    
    def process_command(self, command: str) -> str:
        """
        Procesa comando del usuario.
        
        Args:
            command: Texto del comando
        
        Returns:
            Respuesta de JARVIS
        """
        # Registrar en memoria
        self.memory.store_event(
            'user_command', command,
            importance=5,
            context={'source': 'ui' if hasattr(self, 'ui') else 'cli'}
        )
        
        # Procesar
        response = self.brain.process_command(command)
        
        return response
    
    def start(self):
        """Inicia JARVIS."""
        print("🚀 Iniciando sistemas...")
        self.running = True
        
        # Iniciar subsistemas
        self.state.start()
        self.autonomous.start()
        self.system_monitor.start()
        
        if self.screen_monitor.deps_ok:
            self.screen_monitor.start()
        
        if self.audio_monitor.deps_ok:
            self.audio_monitor.start()
        
        # Mensaje de inicio
        greeting = self.personality.get_time_appropriate_greeting()
        startup_msg = f"{greeting}, Señor. {self.NAME} v{self.VERSION} en línea. Todos los sistemas operativos."
        print(f"\n🤖 {startup_msg}\n")
        
        if self.voice.enabled:
            self.voice.speak(startup_msg)
        
        # Iniciar UI o CLI
        if self.mode == "gui":
            self.ui.start()  # Bloqueante
        else:
            self._cli_loop()
    
    def _cli_loop(self):
        """Loop de interfaz de línea de comandos."""
        print("💬 Modo consola. Comandos disponibles:")
        print("  'estado' - Estado del sistema")
        print("  'memoria' - Perfil de usuario")
        print("  'ayuda' - Ayuda general")
        print("  'salir' - Apagar JARVIS\n")
        
        while self.running:
            try:
                command = input("JARVIS> ").strip()
                
                if not command:
                    continue
                
                if command.lower() in ['salir', 'exit', 'quit', 'shutdown']:
                    self.shutdown()
                    break
                
                elif command.lower() == 'estado':
                    print(self.state.get_status_report())
                
                elif command.lower() == 'memoria':
                    profile = self.memory.get_user_profile()
                    for category, prefs in profile['preferences'].items():
                        print(f"\n{category}:")
                        for k, v in prefs.items():
                            print(f"  {k}: {v}")
                
                elif command.lower() == 'ayuda':
                    print("Comandos disponibles:")
                    print("  abre [programa] - Abre aplicación")
                    print("  busca [término] - Busca en internet")
                    print("  clima [ciudad] - Información meteorológica")
                    print("  código [descripción] - Genera código Python")
                    print("  screenshot - Captura de pantalla")
                    print("  volumen [0-100] - Control de volumen")
                    print("  spotify [play/pause/next] - Control multimedia")
                
                else:
                    response = self.process_command(command)
                    print(f"\n◈ JARVIS: {response}\n")
                    
            except KeyboardInterrupt:
                print("\n")
                self.shutdown()
                break
            except Exception as e:
                print(f"\n✖ Error: {e}\n")
    
    def shutdown(self):
        """Apaga JARVIS ordenadamente."""
        print("\n🛑 Iniciando secuencia de apagado...")
        
        self.running = False
        
        # Mensaje de despedida
        goodbye = "Apagando sistemas. Hasta luego, Señor."
        print(f"🤖 {goodbye}")
        
        if self.voice.enabled:
            self.voice.speak(goodbye)
            time.sleep(2)  # Esperar que termine de hablar
        
        # Detener subsistemas
        if hasattr(self, 'autonomous'):
            self.autonomous.stop()
        if hasattr(self, 'screen_monitor'):
            self.screen_monitor.stop()
        if hasattr(self, 'audio_monitor'):
            self.audio_monitor.stop()
        if hasattr(self, 'system_monitor'):
            self.system_monitor.stop()
        if hasattr(self, 'state'):
            self.state.stop()
        
        # Consolidar memoria
        if hasattr(self, 'memory'):
            self.memory.consolidate()
        
        print("✅ JARVIS apagado correctamente")
        print(f"{'='*60}\n")


def signal_handler(signum, frame):
    """Maneja señales de sistema."""
    print("\n\nSeñal de interrupción recibida. Apagando...")
    if 'jarvis' in globals():
        globals()['jarvis'].shutdown()
    sys.exit(0)


def main():
    """Punto de entrada principal."""
    # Configurar manejo de señales
    signal.signal(signal.SIGINT, signal_handler)
    signal.signal(signal.SIGTERM, signal_handler)
    
    # Parsear argumentos
    parser = argparse.ArgumentParser(
        description='JARVIS v4.0 - Asistente Personal Inteligente'
    )
    parser.add_argument(
        '--cli', 
        action='store_true',
        help='Modo consola (sin interfaz gráfica)'
    )
    parser.add_argument(
        '--headless',
        action='store_true', 
        help='Modo headless (sin UI ni interacción)'
    )
    parser.add_argument(
        '--config',
        type=str,
        help='Archivo de configuración JSON'
    )
    
    args = parser.parse_args()
    
    # Determinar modo
    if args.headless:
        mode = "headless"
    elif args.cli:
        mode = "cli"
    else:
        mode = "gui"
    
    # Cargar config si existe
    config = {}
    if args.config and os.path.exists(args.config):
        import json
        with open(args.config, 'r') as f:
            config = json.load(f)
    
    # Iniciar JARVIS
    global jarvis
    jarvis = Jarvis(mode=mode, config=config)
    
    try:
        jarvis.start()
    except Exception as e:
        print(f"\n✖ Error fatal: {e}")
        import traceback
        traceback.print_exc()
        sys.exit(1)


if __name__ == "__main__":
    main()