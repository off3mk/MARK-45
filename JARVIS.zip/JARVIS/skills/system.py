"""
skills/system.py
Skill de Control del Sistema de JARVIS v4.0

Proporciona control total sobre el sistema operativo Windows:
- Gestión de programas y procesos
- Control de ventanas
- Automatización de UI (mouse/teclado)
- Información del sistema
- Capturas de pantalla
- Operaciones de archivos
"""

import os
import sys
import subprocess
import psutil
import pyautogui
import time
import platform
import ctypes
from typing import Dict, List, Optional, Tuple, Any
from dataclasses import dataclass
from datetime import datetime
import logging

logger = logging.getLogger(__name__)

# Intentar importar pygetwindow (Windows-specific)
try:
    import pygetwindow as gw
    PYGETWINDOW_AVAILABLE = True
except ImportError:
    PYGETWINDOW_AVAILABLE = False
    logger.warning("pygetwindow no disponible. Control de ventanas limitado.")


@dataclass
class ProcessInfo:
    """Información de un proceso."""
    pid: int
    name: str
    status: str
    cpu_percent: float
    memory_mb: float
    created: datetime
    exe: Optional[str] = None


class SystemSkill:
    """
    Skill de control total del sistema operativo.
    
    Permite a JARVIS interactuar con Windows de forma completa:
    abrir/cerrar programas, controlar ventanas, simular input,
    obtener información del sistema, etc.
    """
    
    def __init__(self):
        self.name = "system"
        self.description = "Control total del sistema operativo Windows"
        
        # Mapeo de nombres comunes a ejecutables
        self.program_aliases = {
            # Navegadores
            'chrome': {'cmd': 'chrome', 'type': 'browser'},
            'google chrome': {'cmd': 'chrome', 'type': 'browser'},
            'firefox': {'cmd': 'firefox', 'type': 'browser'},
            'edge': {'cmd': 'msedge', 'type': 'browser'},
            'microsoft edge': {'cmd': 'msedge', 'type': 'browser'},
            'opera': {'cmd': 'opera', 'type': 'browser'},
            'brave': {'cmd': 'brave', 'type': 'browser'},
            
            # Editores/IDEs
            'vscode': {'cmd': 'code', 'type': 'editor'},
            'visual studio code': {'cmd': 'code', 'type': 'editor'},
            'notepad': {'cmd': 'notepad', 'type': 'editor'},
            'notepad++': {'cmd': 'notepad++', 'type': 'editor'},
            'sublime': {'cmd': 'sublime_text', 'type': 'editor'},
            'atom': {'cmd': 'atom', 'type': 'editor'},
            
            # Multimedia
            'spotify': {'cmd': 'spotify', 'type': 'media'},
            'vlc': {'cmd': 'vlc', 'type': 'media'},
            'media player': {'cmd': 'wmplayer', 'type': 'media'},
            
            # Herramientas del sistema
            'calculadora': {'cmd': 'calc', 'type': 'utility'},
            'calculator': {'cmd': 'calc', 'type': 'utility'},
            'explorador': {'cmd': 'explorer', 'type': 'utility'},
            'file explorer': {'cmd': 'explorer', 'type': 'utility'},
            'cmd': {'cmd': 'cmd', 'type': 'terminal'},
            'terminal': {'cmd': 'cmd', 'type': 'terminal'},
            'powershell': {'cmd': 'powershell', 'type': 'terminal'},
            'panel de control': {'cmd': 'control', 'type': 'utility'},
            'task manager': {'cmd': 'taskmgr', 'type': 'utility'},
            'administrador de tareas': {'cmd': 'taskmgr', 'type': 'utility'},
            
            # Comunicación
            'discord': {'cmd': 'discord', 'type': 'communication'},
            'teams': {'cmd': 'teams', 'type': 'communication'},
            'slack': {'cmd': 'slack', 'type': 'communication'},
            'zoom': {'cmd': 'zoom', 'type': 'communication'},
            'skype': {'cmd': 'skype', 'type': 'communication'},
            
            # Productividad
            'word': {'cmd': 'winword', 'type': 'productivity'},
            'excel': {'cmd': 'excel', 'type': 'productivity'},
            'powerpoint': {'cmd': 'powerpnt', 'type': 'productivity'},
            'outlook': {'cmd': 'outlook', 'type': 'productivity'},
            'onenote': {'cmd': 'onenote', 'type': 'productivity'},
        }
        
        # Configuración de pyautogui
        pyautogui.FAILSAFE = True  # Mover mouse a esquina superior izquierda para abortar
        pyautogui.PAUSE = 0.1  # Pausa entre acciones
        
        logger.info("SystemSkill inicializado")
    
    def execute(self, command: str, params: Dict = None) -> str:
        """
        Ejecuta un comando del skill.
        
        Args:
            command: Nombre de la acción
            params: Parámetros de la acción
        
        Returns:
            Resultado de la operación
        """
        params = params or {}
        
        handlers = {
            'open_program': self.open_program,
            'close_program': self.close_program,
            'list_processes': self.list_processes,
            'get_process_info': self.get_process_info,
            'kill_process': self.kill_process,
            'minimize_window': self.minimize_window,
            'maximize_window': self.maximize_window,
            'close_window': self.close_window,
            'move_window': self.move_window,
            'resize_window': self.resize_window,
            'focus_window': self.focus_window,
            'list_windows': self.list_windows,
            'screenshot': self.screenshot,
            'type_text': self.type_text,
            'press_key': self.press_key,
            'hotkey': self.hotkey,
            'mouse_click': self.mouse_click,
            'mouse_move': self.mouse_move,
            'execute_shell': self.execute_shell,
            'get_system_info': self.get_system_info,
            'get_cpu_info': self.get_cpu_info,
            'get_memory_info': self.get_memory_info,
            'get_disk_info': self.get_disk_info,
            'empty_recycle_bin': self.empty_recycle_bin,
            'lock_workstation': self.lock_workstation,
            'shutdown': self.shutdown,
            'restart': self.restart,
            'sleep': self.sleep,
        }
        
        handler = handlers.get(command)
        if handler:
            try:
                return handler(**params)
            except Exception as e:
                logger.error(f"Error en {command}: {e}")
                return f"Error ejecutando {command}: {str(e)}"
        
        return f"Comando '{command}' no reconocido en skill system"
    
    def open_program(self, program: str, args: str = "", 
                     wait: bool = False, timeout: int = 30) -> str:
        """
        Abre un programa.
        
        Args:
            program: Nombre del programa o ruta al ejecutable
            args: Argumentos de línea de comandos
            wait: Si True, espera a que termine
            timeout: Timeout para espera
        
        Returns:
            Confirmación de apertura
        """
        program_lower = program.lower().strip()
        
        # Buscar en aliases
        if program_lower in self.program_aliases:
            info = self.program_aliases[program_lower]
            cmd = info['cmd']
            logger.info(f"Abriendo {program} ({info['type']})")
        else:
            cmd = program
            logger.info(f"Abriendo {program}")
        
        # Construir comando completo
        full_cmd = f"{cmd} {args}".strip()
        
        try:
            if wait:
                # Ejecutar y esperar
                result = subprocess.run(
                    full_cmd,
                    shell=True,
                    capture_output=True,
                    text=True,
                    timeout=timeout
                )
                return f"Programa ejecutado. Salida: {result.returncode}"
            else:
                # Ejecutar en background
                subprocess.Popen(
                    full_cmd,
                    shell=True,
                    stdout=subprocess.DEVNULL,
                    stderr=subprocess.DEVNULL
                )
                return f"Abriendo {program}, Señor."
                
        except subprocess.TimeoutExpired:
            return f"El programa no respondió en {timeout} segundos."
        except Exception as e:
            return f"No pude abrir {program}: {str(e)}"
    
    def close_program(self, program: str, force: bool = False) -> str:
        """
        Cierra un programa por nombre.
        
        Args:
            program: Nombre del programa a cerrar
            force: Si True, fuerza el cierre (kill)
        
        Returns:
            Confirmación de cierre
        """
        program_lower = program.lower()
        closed = []
        errors = []
        
        try:
            for proc in psutil.process_iter(['pid', 'name', 'exe']):
                try:
                    proc_name = proc.info['name'].lower()
                    proc_exe = (proc.info['exe'] or '').lower()
                    
                    # Coincidir por nombre o ejecutable
                    if (program_lower in proc_name or 
                        program_lower in proc_exe or
                        any(alias in proc_name for alias in 
                            [k for k, v in self.program_aliases.items() 
                             if v['cmd'] == program_lower])):
                        
                        if force:
                            proc.kill()
                        else:
                            proc.terminate()
                        
                        closed.append(proc.info['name'])
                        logger.info(f"Proceso terminado: {proc.info['name']} (PID: {proc.info['pid']})")
                        
                except (psutil.NoSuchProcess, psutil.AccessDenied):
                    continue
                except Exception as e:
                    errors.append(str(e))
            
            if closed:
                return f"{'Forzado cierre' if force else 'Cerrado'} de: {', '.join(closed)}"
            else:
                return f"No encontré {program} ejecutándose."
                
        except Exception as e:
            return f"Error cerrando programa: {str(e)}"
    
    def list_processes(self, limit: int = 20, 
                       order_by: str = 'cpu') -> List[Dict]:
        """
        Lista procesos ordenados por uso de recursos.
        
        Args:
            limit: Máximo de procesos a retornar
            order_by: 'cpu' o 'memory'
        
        Returns:
            Lista de procesos con información
        """
        processes = []
        
        for proc in psutil.process_iter(['pid', 'name', 'cpu_percent', 
                                          'memory_info', 'status', 'create_time']):
            try:
                pinfo = proc.info
                processes.append({
                    'pid': pinfo['pid'],
                    'name': pinfo['name'],
                    'cpu_percent': pinfo['cpu_percent'] or 0.0,
                    'memory_mb': pinfo['memory_info'].rss / (1024**2) if pinfo['memory_info'] else 0,
                    'status': pinfo['status'],
                    'created': datetime.fromtimestamp(pinfo['create_time']).isoformat() if pinfo['create_time'] else None
                })
            except (psutil.NoSuchProcess, psutil.AccessDenied):
                continue
        
        # Ordenar
        key = 'cpu_percent' if order_by == 'cpu' else 'memory_mb'
        processes.sort(key=lambda x: x[key], reverse=True)
        
        return processes[:limit]
    
    def get_process_info(self, pid: int) -> Optional[Dict]:
        """Obtiene información detallada de un proceso."""
        try:
            proc = psutil.Process(pid)
            with proc.oneshot():
                return {
                    'pid': pid,
                    'name': proc.name(),
                    'exe': proc.exe(),
                    'cwd': proc.cwd(),
                    'status': proc.status(),
                    'created': datetime.fromtimestamp(proc.create_time()).isoformat(),
                    'cpu_percent': proc.cpu_percent(interval=0.1),
                    'memory_mb': proc.memory_info().rss / (1024**2),
                    'threads': proc.num_threads(),
                    'connections': len(proc.connections()),
                    'open_files': len(proc.open_files())
                }
        except Exception as e:
            logger.error(f"Error obteniendo info de proceso {pid}: {e}")
            return None
    
    def kill_process(self, pid: int) -> str:
        """Termina un proceso por PID."""
        try:
            proc = psutil.Process(pid)
            name = proc.name()
            proc.terminate()
            
            # Esperar y verificar
            gone, alive = psutil.wait_procs([proc], timeout=3)
            if proc in alive:
                proc.kill()
                return f"Proceso {name} (PID {pid}) forzado a terminar."
            
            return f"Proceso {name} (PID {pid}) terminado."
            
        except Exception as e:
            return f"Error terminando proceso {pid}: {str(e)}"
    
    # ==================== CONTROL DE VENTANAS ====================
    
    def minimize_window(self, title: Optional[str] = None) -> str:
        """Minimiza una ventana."""
        if not PYGETWINDOW_AVAILABLE:
            return "Control de ventanas no disponible (instale pygetwindow)"
        
        try:
            if title:
                window = gw.getWindowsWithTitle(title)[0]
            else:
                window = gw.getActiveWindow()
            
            if window:
                window.minimize()
                return f"Ventana '{window.title}' minimizada."
            return "No se encontró ventana activa."
            
        except Exception as e:
            return f"Error: {str(e)}"
    
    def maximize_window(self, title: Optional[str] = None) -> str:
        """Maximiza una ventana."""
        if not PYGETWINDOW_AVAILABLE:
            return "Control de ventanas no disponible"
        
        try:
            if title:
                window = gw.getWindowsWithTitle(title)[0]
            else:
                window = gw.getActiveWindow()
            
            if window:
                window.maximize()
                return f"Ventana '{window.title}' maximizada."
            return "No se encontró ventana."
            
        except Exception as e:
            return f"Error: {str(e)}"
    
    def close_window(self, title: Optional[str] = None) -> str:
        """Cierra una ventana."""
        if not PYGETWINDOW_AVAILABLE:
            return "Control de ventanas no disponible"
        
        try:
            if title:
                window = gw.getWindowsWithTitle(title)[0]
            else:
                window = gw.getActiveWindow()
            
            if window:
                window.close()
                return f"Ventana '{window.title}' cerrada."
            return "No se encontró ventana."
            
        except Exception as e:
            return f"Error: {str(e)}"
    
    def move_window(self, x: int, y: int, title: Optional[str] = None) -> str:
        """Mueve una ventana a posición específica."""
        if not PYGETWINDOW_AVAILABLE:
            return "Control de ventanas no disponible"
        
        try:
            if title:
                window = gw.getWindowsWithTitle(title)[0]
            else:
                window = gw.getActiveWindow()
            
            if window:
                window.moveTo(x, y)
                return f"Ventana movida a ({x}, {y})."
            return "No se encontró ventana."
            
        except Exception as e:
            return f"Error: {str(e)}"
    
    def resize_window(self, width: int, height: int, 
                      title: Optional[str] = None) -> str:
        """Redimensiona una ventana."""
        if not PYGETWINDOW_AVAILABLE:
            return "Control de ventanas no disponible"
        
        try:
            if title:
                window = gw.getWindowsWithTitle(title)[0]
            else:
                window = gw.getActiveWindow()
            
            if window:
                window.resizeTo(width, height)
                return f"Ventana redimensionada a {width}x{height}."
            return "No se encontró ventana."
            
        except Exception as e:
            return f"Error: {str(e)}"
    
    def focus_window(self, title: str) -> str:
        """Trae una ventana al frente y la activa."""
        if not PYGETWINDOW_AVAILABLE:
            return "Control de ventanas no disponible"
        
        try:
            windows = gw.getWindowsWithTitle(title)
            if windows:
                window = windows[0]
                window.activate()
                window.restore()  # Por si está minimizada
                return f"Ventana '{window.title}' activada."
            return f"No se encontró ventana con título '{title}'."
            
        except Exception as e:
            return f"Error: {str(e)}"
    
    def list_windows(self) -> List[Dict]:
        """Lista todas las ventanas visibles."""
        if not PYGETWINDOW_AVAILABLE:
            return []
        
        try:
            windows = []
            for window in gw.getAllWindows():
                if window.title:  # Ignorar ventanas sin título
                    windows.append({
                        'title': window.title,
                        'position': (window.left, window.top),
                        'size': (window.width, window.height),
                        'is_active': window.isActive,
                        'is_maximized': window.isMaximized,
                        'is_minimized': window.isMinimized
                    })
            return windows
            
        except Exception as e:
            logger.error(f"Error listando ventanas: {e}")
            return []
    
    # ==================== AUTOMATIZACIÓN DE UI ====================
    
    def screenshot(self, filename: Optional[str] = None,
                   region: Optional[Tuple[int, int, int, int]] = None) -> str:
        """
        Captura la pantalla o una región.
        
        Args:
            filename: Nombre de archivo (opcional)
            region: (x, y, width, height) para captura parcial
        
        Returns:
            Ruta del archivo guardado
        """
        try:
            if filename is None:
                timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
                filename = f"screenshot_{timestamp}.png"
            
            # Asegurar extensión
            if not filename.endswith(('.png', '.jpg', '.jpeg')):
                filename += '.png'
            
            # Directorio por defecto
            filepath = os.path.join("screenshots", filename)
            os.makedirs("screenshots", exist_ok=True)
            
            # Capturar
            if region:
                screenshot = pyautogui.screenshot(region=region)
            else:
                screenshot = pyautogui.screenshot()
            
            screenshot.save(filepath)
            logger.info(f"Screenshot guardado: {filepath}")
            
            return f"Captura guardada: {filepath}"
            
        except Exception as e:
            return f"Error en screenshot: {str(e)}"
    
    def type_text(self, text: str, interval: float = 0.01) -> str:
        """
        Escribe texto simulando teclado.
        
        Args:
            text: Texto a escribir
            interval: Segundos entre cada tecla
        
        Returns:
            Confirmación
        """
        try:
            pyautogui.typewrite(text, interval=interval)
            return f"Texto escrito: '{text[:50]}{'...' if len(text) > 50 else ''}'"
        except Exception as e:
            return f"Error escribiendo texto: {str(e)}"
    
    def press_key(self, key: str, presses: int = 1) -> str:
        """
        Presiona una tecla específica.
        
        Args:
            key: Nombre de la tecla ('enter', 'esc', 'tab', etc.)
            presses: Número de veces
        
        Returns:
            Confirmación
        """
        try:
            for _ in range(presses):
                pyautogui.press(key)
            return f"Tecla '{key}' presionada {presses} vez{'es' if presses > 1 else ''}."
        except Exception as e:
            return f"Error: {str(e)}"
    
    def hotkey(self, *keys: str) -> str:
        """
        Ejecuta combinación de teclas.
        
        Args:
            *keys: Teclas a presionar simultáneamente
        
        Returns:
            Confirmación
        """
        try:
            pyautogui.hotkey(*keys)
            return f"Atajo {' + '.join(keys)} ejecutado."
        except Exception as e:
            return f"Error: {str(e)}"
    
    def mouse_click(self, x: Optional[int] = None, y: Optional[int] = None,
                    button: str = 'left', clicks: int = 1) -> str:
        """
        Clic del mouse en posición específica o actual.
        
        Args:
            x, y: Coordenadas (None = posición actual)
            button: 'left', 'right', 'middle'
            clicks: Número de clics
        
        Returns:
            Confirmación
        """
        try:
            if x is not None and y is not None:
                pyautogui.click(x, y, button=button, clicks=clicks)
                return f"Clic {button} en ({x}, {y}), {clicks} vez{'es' if clicks > 1 else ''}."
            else:
                pyautogui.click(button=button, clicks=clicks)
                return f"Clic {button} en posición actual."
                
        except Exception as e:
            return f"Error: {str(e)}"
    
    def mouse_move(self, x: int, y: int, duration: float = 0.25) -> str:
        """
        Mueve el mouse a coordenadas específicas.
        
        Args:
            x, y: Coordenadas destino
            duration: Segundos para el movimiento
        
        Returns:
            Confirmación
        """
        try:
            pyautogui.moveTo(x, y, duration=duration)
            return f"Mouse movido a ({x}, {y}) en {duration}s."
        except Exception as e:
            return f"Error: {str(e)}"
    
    # ==================== SHELL Y SISTEMA ====================
    
    def execute_shell(self, command: str, timeout: int = 30,
                      capture_output: bool = True) -> str:
        """
        Ejecuta comando en shell.
        
        Args:
            command: Comando a ejecutar
            timeout: Timeout en segundos
            capture_output: Si True, captura salida
        
        Returns:
            Salida del comando o confirmación
        """
        try:
            if capture_output:
                result = subprocess.run(
                    command,
                    shell=True,
                    capture_output=True,
                    text=True,
                    timeout=timeout,
                    encoding='utf-8',
                    errors='ignore'
                )
                
                output = result.stdout if result.returncode == 0 else result.stderr
                return f"Salida:\n{output[:1000]}{'...' if len(output) > 1000 else ''}"
            else:
                subprocess.Popen(
                    command,
                    shell=True,
                    stdout=subprocess.DEVNULL,
                    stderr=subprocess.DEVNULL
                )
                return f"Comando ejecutado en background."
                
        except subprocess.TimeoutExpired:
            return f"Comando excedió timeout de {timeout} segundos."
        except Exception as e:
            return f"Error ejecutando comando: {str(e)}"
    
    def get_system_info(self) -> Dict:
        """Obtiene información general del sistema."""
        return {
            'platform': platform.platform(),
            'processor': platform.processor(),
            'machine': platform.machine(),
            'node': platform.node(),
            'python_version': platform.python_version(),
            'boot_time': datetime.fromtimestamp(psutil.boot_time()).isoformat(),
            'user': os.getlogin() if hasattr(os, 'getlogin') else 'unknown'
        }
    
    def get_cpu_info(self) -> Dict:
        """Obtiene información detallada de CPU."""
        return {
            'physical_cores': psutil.cpu_count(logical=False),
            'total_cores': psutil.cpu_count(logical=True),
            'max_frequency': psutil.cpu_freq().max if psutil.cpu_freq() else None,
            'current_frequency': psutil.cpu_freq().current if psutil.cpu_freq() else None,
            'percent_per_core': psutil.cpu_percent(percpu=True, interval=0.5),
            'total_percent': psutil.cpu_percent(interval=0.5),
            'load_average': os.getloadavg() if hasattr(os, 'getloadavg') else None
        }
    
    def get_memory_info(self) -> Dict:
        """Obtiene información de memoria."""
        mem = psutil.virtual_memory()
        swap = psutil.swap_memory()
        
        return {
            'total_gb': mem.total / (1024**3),
            'available_gb': mem.available / (1024**3),
            'used_gb': mem.used / (1024**3),
            'percent': mem.percent,
            'swap_total_gb': swap.total / (1024**3),
            'swap_used_gb': swap.used / (1024**3),
            'swap_percent': swap.percent
        }
    
    def get_disk_info(self) -> List[Dict]:
        """Obtiene información de discos."""
        disks = []
        
        for partition in psutil.disk_partitions():
            try:
                usage = psutil.disk_usage(partition.mountpoint)
                disks.append({
                    'device': partition.device,
                    'mountpoint': partition.mountpoint,
                    'fstype': partition.fstype,
                    'total_gb': usage.total / (1024**3),
                    'used_gb': usage.used / (1024**3),
                    'free_gb': usage.free / (1024**3),
                    'percent': (usage.used / usage.total) * 100
                })
            except:
                continue
        
        return disks
    
    def empty_recycle_bin(self) -> str:
        """Vacía la papelera de reciclaje."""
        try:
            # Windows-specific
            import winshell
            winshell.recycle_bin().empty(confirm=False, show_progress=False, sound=False)
            return "Papelera de reciclaje vaciada."
        except:
            try:
                # Alternativa con shell
                os.system("rd /s /q %systemdrive%\\$Recycle.Bin")
                return "Papelera vaciada (método alternativo)."
            except Exception as e:
                return f"Error vaciando papelera: {str(e)}"
    
    def lock_workstation(self) -> str:
        """Bloquea la estación de trabajo."""
        try:
            ctypes.windll.user32.LockWorkStation()
            return "Estación de trabajo bloqueada."
        except Exception as e:
            return f"Error bloqueando: {str(e)}"
    
    def shutdown(self, force: bool = False, timeout: int = 0) -> str:
        """Inicia apagado del sistema."""
        try:
            flag = "/s /f /t 0" if force else f"/s /t {timeout}"
            os.system(f"shutdown {flag}")
            return f"Apagado iniciado{' (forzado)' if force else ''}."
        except Exception as e:
            return f"Error iniciando apagado: {str(e)}"
    
    def restart(self, force: bool = False, timeout: int = 0) -> str:
        """Inicia reinicio del sistema."""
        try:
            flag = "/r /f /t 0" if force else f"/r /t {timeout}"
            os.system(f"shutdown {flag}")
            return f"Reinicio iniciado{' (forzado)' if force else ''}."
        except Exception as e:
            return f"Error iniciando reinicio: {str(e)}"
    
    def sleep(self) -> str:
        """Pone el sistema en suspensión."""
        try:
            # Windows: usar powercfg
            os.system("rundll32.exe powrprof.dll,SetSuspendState 0,1,0")
            return "Sistema suspendido."
        except Exception as e:
            return f"Error suspendiendo: {str(e)}"
    
    def get_commands(self) -> Dict[str, str]:
        """Retorna mapeo de comandos para el brain."""
        return {
            r'abre\s+(.+)': 'open_program',
            r'inicia\s+(.+)': 'open_program',
            r'lanza\s+(.+)': 'open_program',
            r'ejecuta\s+(.+)': 'open_program',
            r'cierra\s+(.+)': 'close_program',
            r'termina\s+(.+)': 'close_program',
            r'mata\s+proceso\s+(\d+)': 'kill_process',
            r'procesos': 'list_processes',
            r'información\s+del\s+sistema': 'get_system_info',
            r'cpu': 'get_cpu_info',
            r'memoria': 'get_memory_info',
            r'disco': 'get_disk_info',
            r'captura\s+de\s+pantalla': 'screenshot',
            r'screenshot': 'screenshot',
            r'escribe\s+["\']?(.+)["\']?': 'type_text',
            r'presiona\s+(.+)': 'press_key',
            r'clic\s+(?:en\s+)?(\d+)[,\s]+(\d+)': 'mouse_click',
            r'mueve\s+ratón\s+a\s+(\d+)[,\s]+(\d+)': 'mouse_move',
            r'comando\s+(.+)': 'execute_shell',
            r'ejecuta\s+shell\s+(.+)': 'execute_shell',
            r'minimiza': 'minimize_window',
            r'maximiza': 'maximize_window',
            r'cierra\s+ventana': 'close_window',
            r'lista\s+ventanas': 'list_windows',
            r'enfoca\s+(.+)': 'focus_window',
            r'apaga\s+(?:el\s+)?sistema': 'shutdown',
            r'reinicia\s+(?:el\s+)?sistema': 'restart',
            r'suspende': 'sleep',
            r'bloquea\s+(?:el\s+)?equipo': 'lock_workstation',
            r'vacia\s+papelera': 'empty_recycle_bin',
        }