"""
skills/media.py
Skill de Control Multimedia de JARVIS v4.0

Control de:
- Spotify (reproducción, pausa, siguiente, etc.)
- Volumen del sistema
- YouTube (búsqueda y reproducción)
- Atajos de multimedia generales
"""

import webbrowser
import pyautogui
import subprocess
import time
from typing import Dict, List, Optional, Tuple
import logging
import requests
import re

logger = logging.getLogger(__name__)


class MediaSkill:
    """
    Skill de control multimedia.
    
    Permite controlar Spotify, volumen del sistema, y reproducir
    contenido de YouTube.
    """
    
    def __init__(self):
        self.name = "media"
        self.description = "Control de multimedia y audio"
        
        # URLs de playlists predefinidas
        self.playlists = {
            'focus': 'https://open.spotify.com/playlist/37i9dQZF1DX4wta20PHgwo',
            'workout': 'https://open.spotify.com/playlist/37i9dQZF1DX76WlfdnjLAp',
            'relax': 'https://open.spotify.com/playlist/37i9dQZF1DX4WY7g6yisp8',
            'party': 'https://open.spotify.com/playlist/37i9dQZF1DX0XUsuxWHRQd',
            'jazz': 'https://open.spotify.com/playlist/37i9dQZF1DX0SM0LYsmbMT',
            'classical': 'https://open.spotify.com/playlist/37i9dQZF1DWWEJlAGA9gs0',
            'rock': 'https://open.spotify.com/playlist/37i9dQZF1DX48mLm3Mf1NJ',
            'electronic': 'https://open.spotify.com/playlist/37i9dQZF1DX6GwdWRQMQpq',
            'temazo': 'https://youtu.be/LIzPbnIp2QM',
        }
        
        # Estado actual
        self.current_playlist = None
        self.volume_level = 50  # 0-100
        
        logger.info("MediaSkill inicializado")
    
    def execute(self, command: str, params: Dict = None) -> str:
        """
        Ejecuta comando multimedia.
        """
        params = params or {}
        
        handlers = {
            'spotify_play': self.spotify_play,
            'spotify_pause': self.spotify_pause,
            'spotify_next': self.spotify_next,
            'spotify_previous': self.spotify_previous,
            'spotify_playlist': self.spotify_playlist,
            'spotify_search': self.spotify_search,
            'volume_set': self.volume_set,
            'volume_up': self.volume_up,
            'volume_down': self.volume_down,
            'mute': self.mute,
            'unmute': self.unmute,
            'youtube_play': self.youtube_play,
            'youtube_search': self.youtube_search,
            'media_key': self.media_key,
            'play_pause': self.play_pause,
            'stop_media': self.stop_media,
            'play_temazo': self.play_temazo,
        }
        
        handler = handlers.get(command)
        if handler:
            try:
                return handler(**params)
            except Exception as e:
                logger.error(f"Error en {command}: {e}")
                return f"Error en control multimedia: {str(e)}"
        
        return f"Comando multimedia '{command}' no reconocido"
    
    # ==================== SPOTIFY ====================
    
    def spotify_play(self) -> str:
        """Inicia reproducción en Spotify."""
        try:
            pyautogui.press('playpause')
            subprocess.Popen('spotify', shell=True)
            return "Reproduciendo música, Señor."
        except Exception as e:
            return f"Error controlando Spotify: {str(e)}"
    
    def spotify_pause(self) -> str:
        """Pausa reproducción."""
        try:
            pyautogui.press('playpause')
            return "Música pausada."
        except Exception as e:
            return f"Error: {str(e)}"
    
    def spotify_next(self) -> str:
        """Siguiente canción."""
        try:
            pyautogui.press('nexttrack')
            return "Siguiente canción."
        except Exception as e:
            return f"Error: {str(e)}"
    
    def spotify_previous(self) -> str:
        """Canción anterior."""
        try:
            pyautogui.press('prevtrack')
            return "Canción anterior."
        except Exception as e:
            return f"Error: {str(e)}"
    
    def spotify_playlist(self, name: str = None, url: str = None) -> str:
        """
        Abre una playlist específica.
        """
        if url:
            webbrowser.open(url)
            return f"Abriendo playlist: {url[:50]}..."
        
        if name and name.lower() in self.playlists:
            url = self.playlists[name.lower()]
            webbrowser.open(url)
            self.current_playlist = name
            return f"Abriendo playlist '{name}', Señor."
        
        if name:
            search_url = f"https://open.spotify.com/search/{name.replace(' ', '%20')}"
            webbrowser.open(search_url)
            return f"Buscando '{name}' en Spotify."
        
        return "Especifique nombre de playlist o URL."
    
    def spotify_search(self, query: str) -> str:
        """Busca en Spotify."""
        search_url = f"https://open.spotify.com/search/{query.replace(' ', '%20')}"
        webbrowser.open(search_url)
        return f"Buscando '{query}' en Spotify."
    
    # ==================== VOLUMEN ====================
    
    def volume_set(self, level: int) -> str:
        try:
            level = max(0, min(100, int(level)))
            
            for _ in range(50):
                pyautogui.press('volumedown')
            
            steps = int(level / 2)
            for _ in range(steps):
                pyautogui.press('volumeup')
            
            self.volume_level = level
            return f"Volumen ajustado a {level}%."
        except Exception as e:
            return f"Error ajustando volumen: {str(e)}"
    
    def volume_up(self, amount: int = 10) -> str:
        try:
            steps = int(amount / 2)
            for _ in range(steps):
                pyautogui.press('volumeup')
            
            self.volume_level = min(100, self.volume_level + amount)
            return f"Volumen subido al {self.volume_level}%."
        except Exception as e:
            return f"Error: {str(e)}"
    
    def volume_down(self, amount: int = 10) -> str:
        try:
            steps = int(amount / 2)
            for _ in range(steps):
                pyautogui.press('volumedown')
            
            self.volume_level = max(0, self.volume_level - amount)
            return f"Volumen bajado al {self.volume_level}%."
        except Exception as e:
            return f"Error: {str(e)}"
    
    def mute(self) -> str:
        try:
            pyautogui.press('volumemute')
            return "Audio silenciado."
        except Exception as e:
            return f"Error: {str(e)}"
    
    def unmute(self) -> str:
        return self.mute()
    
    # ==================== YOUTUBE ====================
    
    def youtube_play(self, video_id: str = None, url: str = None,
                     search: str = None) -> str:
        if url:
            webbrowser.open(url)
            return "Abriendo video de YouTube."
        
        if video_id:
            url = f"https://www.youtube.com/watch?v={video_id}"
            webbrowser.open(url)
            return "Reproduciendo video."
        
        if search:
            query = search.replace(' ', '+')
            url = f"https://www.youtube.com/results?search_query={query}"
            webbrowser.open(url)
            return f"Buscando '{search}' en YouTube."
        
        webbrowser.open("https://www.youtube.com")
        return "Abriendo YouTube."
    
    def youtube_search(self, query: str) -> str:
        return self.youtube_play(search=query)
    
    # ==================== CONTROLES GENERALES ====================
    
    def media_key(self, key: str) -> str:
        key_map = {
            'play': 'playpause',
            'pause': 'playpause',
            'stop': 'stop',
            'next': 'nexttrack',
            'previous': 'prevtrack',
            'prev': 'prevtrack',
        }
        
        mapped = key_map.get(key.lower(), key)
        
        try:
            pyautogui.press(mapped)
            return f"Tecla multimedia '{key}' enviada."
        except Exception as e:
            return f"Error: {str(e)}"
    
    def play_pause(self) -> str:
        return self.media_key('play')
    
    def stop_media(self) -> str:
        return self.media_key('stop')
    
    # ==================== COMANDOS ESPECIALES ====================
    
    def play_temazo(self) -> str:
        webbrowser.open(self.playlists['temazo'])
        return "Reproduciendo temazo clásico, Señor."
    
    def get_commands(self) -> Dict[str, str]:
        return {
            r'spotify\s+(play|reproduce)': 'spotify_play',
            r'spotify\s+(pause|pausa)': 'spotify_pause',
            r'spotify\s+(next|siguiente)': 'spotify_next',
            r'spotify\s+(prev|anterior|atrás)': 'spotify_previous',
            r'playlist\s+(.+)': 'spotify_playlist',
            r'pon\s+(?:un\s+)?temazo': 'play_temazo',
            r'volumen\s+(\d+)': 'volume_set',
            r'sube\s+volumen(?:\s+(\d+))?': 'volume_up',
            r'baja\s+volumen(?:\s+(\d+))?': 'volume_down',
            r'mute|silencio': 'mute',
            r'youtube\s+(.+)': 'youtube_search',
            r'busca\s+(?:en\s+)?youtube\s+(.+)': 'youtube_search',
            r'reproduce\s+(?:en\s+)?youtube\s+(.+)': 'youtube_play',
            r'pausa?\s*música': 'play_pause',
            r'detiene?\s*música': 'stop_media',
            r'siguiente\s+canción': 'spotify_next',
            r'canción\s+anterior': 'spotify_previous',
        }
