"""
skills/internet.py
Skill de Internet y Búsquedas de JARVIS v4.0

Proporciona:
- Búsquedas en Google/DuckDuckGo
- Información meteorológica
- Búsquedas en Wikipedia
- Noticias
- Apertura de URLs
- Traducciones
- Información de IP/geolocalización
"""

import webbrowser
import requests
import urllib.parse
import re
from typing import Dict, List, Optional, Any
from datetime import datetime
import logging

logger = logging.getLogger(__name__)


class InternetSkill:
    """
    Skill de búsquedas e información de internet.
    """
    
    def __init__(self):
        self.name = "internet"
        self.description = "Búsquedas web, clima, Wikipedia y más"
        
        # APIs y endpoints
        self.weather_service = "wttr.in"
        self.news_sources = [
            'https://news.ycombinator.com',
            'https://feeds.bbci.co.uk/news/rss.xml'
        ]
        
        # Session para requests
        self.session = requests.Session()
        self.session.headers.update({
            'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36'
        })
        
        logger.info("InternetSkill inicializado")
    
    def execute(self, command: str, params: Dict = None) -> str:
        """
        Ejecuta comando de internet.
        """
        params = params or {}
        
        handlers = {
            'search': self.search,
            'search_duckduckgo': self.search_duckduckgo,
            'weather': self.weather,
            'weather_detailed': self.weather_detailed,
            'wikipedia': self.wikipedia,
            'wikipedia_search': self.wikipedia_search,
            'open_url': self.open_url,
            'news': self.news,
            'translate': self.translate,
            'ip_info': self.ip_info,
            'define': self.define,
            'calculate': self.calculate,
        }
        
        handler = handlers.get(command)
        if handler:
            try:
                return handler(**params)
            except Exception as e:
                logger.error(f"Error en {command}: {e}")
                return f"Error en búsqueda: {str(e)}"
        
        return f"Comando '{command}' no reconocido"
    
    def search(self, query: str, engine: str = 'duckduckgo') -> str:
        """
        Realiza búsqueda web.
        """
        if engine == 'google':
            url = f"https://www.google.com/search?q={urllib.parse.quote(query)}"
        else:
            url = f"https://duckduckgo.com/?q={urllib.parse.quote(query)}"
        
        webbrowser.open(url)
        return f"Buscando '{query}' en {engine}, Señor."
    
    def search_duckduckgo(self, query: str) -> str:
        return self.search(query, 'duckduckgo')
    
    def weather(self, city: str = "Madrid", format: str = "simple") -> str:
        try:
            if format == 'simple':
                url = f"https://{self.weather_service}/{urllib.parse.quote(city)}?format=%C+%t"
            else:
                url = f"https://{self.weather_service}/{urllib.parse.quote(city)}?format=4"
            
            response = self.session.get(url, timeout=10)
            
            if response.status_code == 200:
                weather_text = response.text.strip()
                return f"Clima en {city}: {weather_text}"
            else:
                return f"No pude obtener el clima de {city} (status {response.status_code})"
                
        except Exception as e:
            logger.error(f"Error obteniendo clima: {e}")
            url = f"https://www.google.com/search?q=weather+{urllib.parse.quote(city)}"
            webbrowser.open(url)
            return f"Buscando clima de {city} en navegador."
    
    def weather_detailed(self, city: str = "Madrid") -> str:
        try:
            url = f"https://{self.weather_service}/{urllib.parse.quote(city)}"
            response = self.session.get(url, timeout=10)
            
            if response.status_code == 200:
                lines = response.text.split('\n')
                result = []
                for line in lines[:10]:
                    if line.strip() and not line.startswith('Location'):
                        result.append(line.strip())
                
                return f"Clima detallado en {city}:\n" + '\n'.join(result[:5])
            
            return self.weather(city, 'simple')
            
        except Exception:
            return self.weather(city, 'simple')
    
    def wikipedia(self, query: str, language: str = "es") -> str:
        encoded_query = query.replace(' ', '_')
        url = f"https://{language}.wikipedia.org/wiki/{urllib.parse.quote(encoded_query)}"
        
        webbrowser.open(url)
        return f"Abriendo Wikipedia: {query}"
    
    def wikipedia_search(self, query: str, language: str = "es") -> str:
        try:
            api_url = f"https://{language}.wikipedia.org/w/api.php"
            params = {
                'action': 'query',
                'list': 'search',
                'srsearch': query,
                'format': 'json',
                'srlimit': 3
            }
            
            response = self.session.get(api_url, params=params, timeout=10)
            data = response.json()
            
            results = data.get('query', {}).get('search', [])
            if results:
                title = results[0]['title']
                return self.wikipedia(title, language)
            
            return f"No encontré resultados en Wikipedia para '{query}'"
            
        except Exception as e:
            logger.error(f"Error en Wikipedia API: {e}")
            return self.wikipedia(query, language)
    
    def open_url(self, url: str, new_tab: bool = True) -> str:
        if not url.startswith(('http://', 'https://')):
            url = 'https://' + url
        
        try:
            if new_tab:
                webbrowser.open_new_tab(url)
            else:
                webbrowser.open(url)
            return f"Abriendo {url[:60]}{'...' if len(url) > 60 else ''}"
        except Exception as e:
            return f"Error abriendo URL: {str(e)}"
    
    def news(self, topic: Optional[str] = None, source: str = 'hackernews') -> str:
        if source == 'hackernews':
            url = "https://news.ycombinator.com"
            if topic:
                url += f"/search?q={urllib.parse.quote(topic)}"
        else:
            url = "https://news.google.com"
            if topic:
                url += f"/search?q={urllib.parse.quote(topic)}"
        
        webbrowser.open(url)
        
        if topic:
            return f"Buscando noticias sobre '{topic}'."
        return "Abriendo noticias tecnológicas."
    
    def translate(self, text: str, 
                  target_lang: str = "es",
                  source_lang: str = "auto") -> str:
        try:
            url = "https://api.mymemory.translated.net/get"
            params = {
                'q': text,
                'langpair': f"{source_lang}|{target_lang}"
            }
            
            response = self.session.get(url, params=params, timeout=10)
            data = response.json()
            
            if data.get('responseStatus') == 200:
                translated = data['responseData']['translatedText']
                return f"Traducción: '{translated}'"
            else:
                encoded = urllib.parse.quote(text)
                url = f"https://translate.google.com/?sl={source_lang}&tl={target_lang}&text={encoded}"
                webbrowser.open(url)
                return f"Abriendo Google Translate para: '{text[:50]}...'"
                
        except Exception as e:
            logger.error(f"Error en traducción: {e}")
            encoded = urllib.parse.quote(text)
            url = f"https://translate.google.com/?sl={source_lang}&tl={target_lang}&text={encoded}"
            webbrowser.open(url)
            return f"Abriendo traductor para: '{text[:50]}...'"
    
    def ip_info(self) -> str:
        try:
            response = self.session.get("https://ipinfo.io/json", timeout=10)
            data = response.json()
            
            info = {
                'ip': data.get('ip', 'unknown'),
                'city': data.get('city', 'unknown'),
                'region': data.get('region', 'unknown'),
                'country': data.get('country', 'unknown'),
                'org': data.get('org', 'unknown')
            }
            
            return (f"Información de red: IP {info['ip']}, "
                   f"Ubicación: {info['city']}, {info['country']}, "
                   f"Proveedor: {info['org']}")
                   
        except Exception as e:
            logger.error(f"Error obteniendo IP info: {e}")
            return "No pude obtener información de red."
    
    def define(self, word: str) -> str:
        try:
            url = f"https://api.dictionaryapi.dev/api/v2/entries/en/{urllib.parse.quote(word)}"
            response = self.session.get(url, timeout=10)
            
            if response.status_code == 200:
                data = response.json()[0]
                meanings = data.get('meanings', [])
                
                if meanings:
                    first_def = meanings[0]['definitions'][0]['definition']
                    return f"Definición de '{word}': {first_def}"
            
            search_url = f"https://www.google.com/search?q=define+{urllib.parse.quote(word)}"
            webbrowser.open(search_url)
            return f"Buscando definición de '{word}'."
            
        except Exception:
            search_url = f"https://www.google.com/search?q=define+{urllib.parse.quote(word)}"
            webbrowser.open(search_url)
            return f"Buscando definición de '{word}'."
    
    def calculate(self, expression: str) -> str:
        try:
            url = f"https://www.google.com/search?q={urllib.parse.quote(expression)}"
            webbrowser.open(url)
            return f"Calculando: {expression}"
        except Exception as e:
            return f"Error: {str(e)}"
    
    def get_commands(self) -> Dict[str, str]:
        return {
            r'busca\s+(.+)': 'search',
            r'google\s+(.+)': 'search',
            r'clima\s+(?:en\s+)?(.+)': 'weather',
            r'tiempo\s+(?:en\s+)?(.+)': 'weather',
            r'weather\s+(?:in\s+)?(.+)': 'weather',
            r'wikipedia\s+(.+)': 'wikipedia',
            r'wiki\s+(.+)': 'wikipedia',
            r'abre\s+(https?://\S+)': 'open_url',
            r'url\s+(https?://\S+)': 'open_url',
            r'noticias(?:\s+sobre\s+(.+))?': 'news',
            r'news(?:\s+about\s+(.+))?': 'news',
            r'traduce\s+["\']?(.+)["\']?(?:\s+a\s+(\w+))?': 'translate',
            r'translate\s+["\']?(.+)["\']?': 'translate',
            r'mi\s+ip': 'ip_info',
            r'ip\s+info': 'ip_info',
            r'qué\s+(?:significa|es)\s+(.+)': 'define',
            r'define\s+(.+)': 'define',
            r'calcula\s+(.+)': 'calculate',
            r'cuánto\s+es\s+(.+)': 'calculate',
        }
