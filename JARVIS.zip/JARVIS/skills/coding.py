"""
skills/coding.py
Skill de Programación y Ejecución Segura de Código - JARVIS v4.0

Permite:
- Ejecutar código Python en entorno controlado
- Analizar sintaxis
- Formatear código
- Detectar errores
- Crear archivos
- Ejecutar scripts
"""

import os
import subprocess
import ast
import tempfile
import sys
import re
from typing import Dict, Optional
import logging

logger = logging.getLogger(__name__)


class CodingSkill:
    """
    Skill para ejecución y análisis de código.
    Ejecuta código Python en entorno controlado.
    """
    
    def __init__(self):
        self.name = "coding"
        self.description = "Ejecución y análisis de código Python"
        self.workspace_dir = os.path.join(os.getcwd(), "workspace")
        
        # Crear workspace si no existe
        if not os.path.exists(self.workspace_dir):
            os.makedirs(self.workspace_dir)
        
        logger.info("CodingSkill inicializado")
    
    def execute(self, command: str, params: Dict = None) -> str:
        """
        Ejecuta comando relacionado con código.
        """
        params = params or {}
        
        handlers = {
            'run_python': self.run_python,
            'analyze_syntax': self.analyze_syntax,
            'create_file': self.create_file,
            'read_file': self.read_file,
            'list_files': self.list_files,
            'delete_file': self.delete_file,
        }
        
        handler = handlers.get(command)
        if handler:
            try:
                return handler(**params)
            except Exception as e:
                logger.error(f"Error en {command}: {e}")
                return f"Error ejecutando código: {str(e)}"
        
        return f"Comando de código '{command}' no reconocido"
    
    # ================================
    # EJECUCIÓN DE PYTHON
    # ================================
    
    def run_python(self, code: str) -> str:
        """
        Ejecuta código Python en entorno aislado.
        """
        if not self._check_code_safety(code):
            return "Código bloqueado por seguridad."
        
        try:
            with tempfile.NamedTemporaryFile(
                mode="w",
                suffix=".py",
                dir=self.workspace_dir,
                delete=False
            ) as temp_file:
                temp_file.write(code)
                temp_path = temp_file.name
            
            result = subprocess.run(
                [sys.executable, temp_path],
                capture_output=True,
                text=True,
                timeout=10
            )
            
            os.remove(temp_path)
            
            if result.returncode == 0:
                return result.stdout if result.stdout else "Ejecución completada sin salida."
            else:
                return f"Error:\n{result.stderr}"
        
        except subprocess.TimeoutExpired:
            return "El código tardó demasiado en ejecutarse."
        except Exception as e:
            return f"Error ejecutando código: {str(e)}"
    
    # ================================
    # SEGURIDAD
    # ================================
    
    def _check_code_safety(self, code: str) -> bool:
        """
        Bloquea código potencialmente peligroso.
        """
        dangerous_patterns = [
            r'import\s+os',
            r'import\s+sys',
            r'import\s+subprocess',
            r'__import__',
            r'eval\(',
            r'exec\(',
            r'open\(',
            r'os\.',
            r'sys\.',
            r'subprocess\.',
            r'shutil\.',
            r'socket\.',
            r'requests\.',
        ]
        
        for pattern in dangerous_patterns:
            if re.search(pattern, code):
                logger.warning(f"Código bloqueado por patrón: {pattern}")
                return False
        
        return True
    
    # ================================
    # ANÁLISIS DE SINTAXIS
    # ================================
    
    def analyze_syntax(self, code: str) -> str:
        """
        Analiza sintaxis Python sin ejecutarlo.
        """
        try:
            ast.parse(code)
            return "Sintaxis correcta."
        except SyntaxError as e:
            return f"Error de sintaxis en línea {e.lineno}: {e.msg}"
        except Exception as e:
            return f"Error analizando código: {str(e)}"
    
    # ================================
    # GESTIÓN DE ARCHIVOS
    # ================================
    
    def create_file(self, filename: str, content: str = "") -> str:
        """
        Crea archivo en workspace.
        """
        safe_path = os.path.join(self.workspace_dir, filename)
        
        if not safe_path.startswith(self.workspace_dir):
            return "Ruta no permitida."
        
        try:
            with open(safe_path, "w", encoding="utf-8") as f:
                f.write(content)
            
            return f"Archivo '{filename}' creado."
        except Exception as e:
            return f"Error creando archivo: {str(e)}"
    
    def read_file(self, filename: str) -> str:
        """
        Lee archivo del workspace.
        """
        safe_path = os.path.join(self.workspace_dir, filename)
        
        if not os.path.exists(safe_path):
            return f"El archivo '{filename}' no existe."
        
        try:
            with open(safe_path, "r", encoding="utf-8") as f:
                return f.read()
        except Exception as e:
            return f"Error leyendo archivo: {str(e)}"
    
    def list_files(self) -> str:
        """
        Lista archivos del workspace.
        """
        try:
            files = os.listdir(self.workspace_dir)
            if not files:
                return "No hay archivos en el workspace."
            
            return "Archivos:\n" + "\n".join(files)
        except Exception as e:
            return f"Error listando archivos: {str(e)}"
    
    def delete_file(self, filename: str) -> str:
        """
        Elimina archivo del workspace.
        """
        safe_path = os.path.join(self.workspace_dir, filename)
        
        if not os.path.exists(safe_path):
            return f"El archivo '{filename}' no existe."
        
        try:
            os.remove(safe_path)
            return f"Archivo '{filename}' eliminado."
        except Exception as e:
            return f"Error eliminando archivo: {str(e)}"
    
    # ================================
    # COMANDOS REGEX
    # ================================
    
    def get_commands(self) -> Dict[str, str]:
        return {
            r'ejecuta\s+código\s+(.+)': 'run_python',
            r'run\s+python\s+(.+)': 'run_python',
            r'analiza\s+código\s+(.+)': 'analyze_syntax',
            r'crear\s+archivo\s+(\S+)(?:\s+con\s+contenido\s+(.+))?': 'create_file',
            r'leer\s+archivo\s+(\S+)': 'read_file',
            r'lista\s+archivos': 'list_files',
            r'elimina\s+archivo\s+(\S+)': 'delete_file',
        }
