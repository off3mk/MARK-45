"""
ui/interface.py
Interfaz Gráfica de JARVIS v4.0

Diseño futurista estilo Iron Man con:
- Panel de chat principal
- Visualización de estado del sistema
- Logs en tiempo real
- Indicadores visuales de actividad
- Tema oscuro con acentos cian/azul
"""

import tkinter as tk
from tkinter import ttk, scrolledtext, Frame, Label, Entry, Button
import threading
import time
from datetime import datetime
from typing import Optional, Callable, Dict, List
import logging

logger = logging.getLogger(__name__)


class JarvisUI:
    """
    Interfaz gráfica futurista de JARVIS.
    
    Paleta de colores:
    - Fondo: #0a0a0a (negro casi puro)
    - Primario: #00d4ff (cian brillante)
    - Secundario: #00ff88 (verde neón)
    - Alerta: #ff4444 (rojo)
    - Advertencia: #ffaa00 (naranja)
    - Texto: #e0e0e0 (gris claro)
    """
    
    def __init__(self, brain, state_engine, voice_system,
                 on_command: Optional[Callable[[str], None]] = None):
        """
        Inicializa la interfaz.
        
        Args:
            brain: Instancia de JarvisBrain
            state_engine: Instancia de StateEngine
            voice_system: Instancia de VoiceSystem
            on_command: Callback para comandos de usuario
        """
        self.brain = brain
        self.state = state_engine
        self.voice = voice_system
        self.on_command = on_command
        
        # Configuración de colores
        self.colors = {
            'bg': '#0a0a0a',
            'bg_secondary': '#1a1a1a',
            'bg_tertiary': '#2a2a2a',
            'primary': '#00d4ff',
            'secondary': '#00ff88',
            'alert': '#ff4444',
            'warning': '#ffaa00',
            'text': '#e0e0e0',
            'text_dim': '#808080',
            'border': '#00d4ff'
        }
        
        # Fuentes
        self.fonts = {
            'header': ('Consolas', 24, 'bold'),
            'subheader': ('Consolas', 14, 'bold'),
            'body': ('Consolas', 11),
            'small': ('Consolas', 9),
            'mono': ('Courier New', 10)
        }
        
        # Estado de UI
        self.root: Optional[tk.Tk] = None
        self.running = False
        self.update_thread: Optional[threading.Thread] = None
        
        # Widgets principales
        self.chat_history: Optional[scrolledtext.ScrolledText] = None
        self.input_field: Optional[Entry] = None
        self.status_label: Optional[Label] = None
        self.system_status: Optional[Label] = None
        self.log_text: Optional[scrolledtext.ScrolledText] = None
        
        # Indicadores
        self.mood_indicator: Optional[Label] = None
        self.activity_indicator: Optional[Label] = None
        
        logger.info("JarvisUI inicializada")
    
    def start(self):
        """Inicia la interfaz gráfica (bloqueante)."""
        self.root = tk.Tk()
        self.root.title("JARVIS v4.0 - Asistente Personal")
        self.root.geometry("1200x800")
        self.root.configure(bg=self.colors['bg'])
        self.root.minsize(900, 600)
        
        # Configurar cierre
        self.root.protocol("WM_DELETE_WINDOW", self._on_close)
        
        # Crear widgets
        self._create_layout()
        
        # Iniciar actualizaciones
        self.running = True
        self.update_thread = threading.Thread(target=self._update_loop, daemon=True)
        self.update_thread.start()
        
        # Mensaje inicial
        self._add_system_message("JARVIS v4.0 Sistema Operativo")
        self._add_jarvis_message("Buenos días, Señor. JARVIS en línea y listo para sus instrucciones.")
        
        # Iniciar loop principal
        logger.info("UI iniciada")
        self.root.mainloop()
    
    def stop(self):
        """Detiene la interfaz."""
        self.running = False
        if self.root:
            self.root.after(0, self.root.quit)
    
    def _on_close(self):
        """Maneja cierre de ventana."""
        self.running = False
        if self.on_command:
            self.on_command("SHUTDOWN")
        self.root.destroy()
    
    def _create_layout(self):
        """Crea el layout de la interfaz."""
        # Frame principal
        main_frame = Frame(self.root, bg=self.colors['bg'])
        main_frame.pack(fill=tk.BOTH, expand=True, padx=10, pady=10)
        
        # ========== HEADER ==========
        header_frame = Frame(main_frame, bg=self.colors['bg'])
        header_frame.pack(fill=tk.X, pady=(0, 10))
        
        # Título
        title = Label(
            header_frame,
            text="◆ JARVIS v4.0",
            font=self.fonts['header'],
            fg=self.colors['primary'],
            bg=self.colors['bg']
        )
        title.pack(side=tk.LEFT)
        
        # Indicador de estado
        self.activity_indicator = Label(
            header_frame,
            text="●",
            font=('Arial', 16),
            fg=self.colors['secondary'],
            bg=self.colors['bg']
        )
        self.activity_indicator.pack(side=tk.RIGHT, padx=10)
        
        # Mood indicator
        self.mood_indicator = Label(
            header_frame,
            text="NEUTRAL",
            font=self.fonts['small'],
            fg=self.colors['text_dim'],
            bg=self.colors['bg']
        )
        self.mood_indicator.pack(side=tk.RIGHT, padx=10)
        
        # ========== PANEL CENTRAL ==========
        center_frame = Frame(main_frame, bg=self.colors['bg'])
        center_frame.pack(fill=tk.BOTH, expand=True)
        
        # Panel izquierdo: Chat (70%)
        left_frame = Frame(center_frame, bg=self.colors['bg'])
        left_frame.pack(side=tk.LEFT, fill=tk.BOTH, expand=True, padx=(0, 5))
        
        # Área de chat
        chat_frame = Frame(left_frame, bg=self.colors['bg_secondary'],
                          highlightbackground=self.colors['border'],
                          highlightthickness=1)
        chat_frame.pack(fill=tk.BOTH, expand=True)
        
        # Historial de chat
        self.chat_history = scrolledtext.ScrolledText(
            chat_frame,
            wrap=tk.WORD,
            font=self.fonts['body'],
            bg=self.colors['bg_secondary'],
            fg=self.colors['text'],
            insertbackground=self.colors['primary'],
            relief=tk.FLAT,
            padx=10,
            pady=10
        )
        self.chat_history.pack(fill=tk.BOTH, expand=True, padx=5, pady=5)
        self.chat_history.config(state=tk.DISABLED)
        
        # Configurar tags de colores
        self.chat_history.tag_config("user", foreground=self.colors['secondary'], 
                                     font=('Consolas', 11, 'bold'))
        self.chat_history.tag_config("jarvis", foreground=self.colors['primary'],
                                     font=('Consolas', 11, 'bold'))
        self.chat_history.tag_config("system", foreground=self.colors['text_dim'],
                                     font=('Consolas', 10))
        self.chat_history.tag_config("error", foreground=self.colors['alert'])
        self.chat_history.tag_config("warning", foreground=self.colors['warning'])
        self.chat_history.tag_config("timestamp", foreground=self.colors['text_dim'],
                                     font=('Consolas', 9))
        
        # Campo de entrada
        input_frame = Frame(left_frame, bg=self.colors['bg'], pady=10)
        input_frame.pack(fill=tk.X)
        
        self.input_field = Entry(
            input_frame,
            font=self.fonts['body'],
            bg=self.colors['bg_secondary'],
            fg=self.colors['text'],
            insertbackground=self.colors['primary'],
            relief=tk.FLAT,
            highlightbackground=self.colors['border'],
            highlightthickness=1
        )
        self.input_field.pack(side=tk.LEFT, fill=tk.X, expand=True, padx=(0, 10))
        self.input_field.bind('<Return>', self._on_send)
        self.input_field.bind('<KP_Enter>', self._on_send)
        
        # Botón enviar
        send_btn = Button(
            input_frame,
            text="➤ ENVIAR",
            command=self._on_send,
            bg=self.colors['primary'],
            fg=self.colors['bg'],
            font=('Consolas', 10, 'bold'),
            relief=tk.FLAT,
            activebackground=self.colors['secondary'],
            cursor='hand2'
        )
        send_btn.pack(side=tk.RIGHT)
        
        # Panel derecho: Estado y Logs (30%)
        right_frame = Frame(center_frame, bg=self.colors['bg'], width=350)
        right_frame.pack(side=tk.RIGHT, fill=tk.Y, padx=(5, 0))
        right_frame.pack_propagate(False)
        
        # Estado del sistema
        status_frame = Frame(right_frame, bg=self.colors['bg_secondary'],
                            highlightbackground=self.colors['border'],
                            highlightthickness=1)
        status_frame.pack(fill=tk.X, pady=(0, 10))
        
        Label(
            status_frame,
            text="ESTADO DEL SISTEMA",
            font=self.fonts['subheader'],
            fg=self.colors['primary'],
            bg=self.colors['bg_secondary']
        ).pack(pady=5)
        
        self.system_status = Label(
            status_frame,
            text="Inicializando...",
            font=self.fonts['small'],
            fg=self.colors['text'],
            bg=self.colors['bg_secondary'],
            justify=tk.LEFT,
            wraplength=330
        )
        self.system_status.pack(padx=10, pady=5, fill=tk.X)
        
        # Logs del sistema
        log_frame = Frame(right_frame, bg=self.colors['bg_secondary'],
                         highlightbackground=self.colors['border'],
                         highlightthickness=1)
        log_frame.pack(fill=tk.BOTH, expand=True)
        
        Label(
            log_frame,
            text="LOGS DEL SISTEMA",
            font=self.fonts['subheader'],
            fg=self.colors['primary'],
            bg=self.colors['bg_secondary']
        ).pack(pady=5)
        
        self.log_text = scrolledtext.ScrolledText(
            log_frame,
            wrap=tk.WORD,
            font=self.fonts['mono'],
            bg=self.colors['bg_secondary'],
            fg=self.colors['text_dim'],
            height=15,
            relief=tk.FLAT,
            padx=5,
            pady=5
        )
        self.log_text.pack(fill=tk.BOTH, expand=True, padx=5, pady=5)
        self.log_text.config(state=tk.DISABLED)
        
        # Configurar tags de logs
        self.log_text.tag_config("info", foreground=self.colors['text_dim'])
        self.log_text.tag_config("warning", foreground=self.colors['warning'])
        self.log_text.tag_config("error", foreground=self.colors['alert'])
        self.log_text.tag_config("success", foreground=self.colors['secondary'])
    
    def _on_send(self, event=None):
        """Maneja envío de mensaje."""
        text = self.input_field.get().strip()
        if not text:
            return
        
        # Limpiar entrada
        self.input_field.delete(0, tk.END)
        
        # Mostrar mensaje de usuario
        self._add_user_message(text)
        
        # Procesar comando
        if self.on_command:
            # Ejecutar en thread para no bloquear UI
            threading.Thread(
                target=self._process_command,
                args=(text,),
                daemon=True
            ).start()
    
    def _process_command(self, text: str):
        """Procesa comando en background."""
        try:
            response = self.on_command(text)
            if response:
                self.root.after(0, lambda: self._add_jarvis_message(response))
        except Exception as e:
            logger.error(f"Error procesando comando: {e}")
            self.root.after(0, lambda: self._add_system_message(f"Error: {str(e)}", "error"))
    
    def _add_user_message(self, text: str):
        """Agrega mensaje del usuario al chat."""
        self._add_message("Usuario", text, "user", "👤")
    
    def _add_jarvis_message(self, text: str):
        """Agrega mensaje de JARVIS al chat."""
        self._add_message("JARVIS", text, "jarvis", "◈")
        # Hablar si está habilitado
        if self.voice:
            self.voice.speak(text, priority=5)
    
    def _add_system_message(self, text: str, level: str = "info"):
        """Agrega mensaje del sistema."""
        prefix = "⚙" if level == "info" else "⚠" if level == "warning" else "✖"
        self._add_message("Sistema", text, "system", prefix)
    
    def _add_message(self, sender: str, text: str, tag: str, prefix: str):
        """Agrega mensaje al historial."""
        if not self.chat_history:
            return
        
        self.chat_history.config(state=tk.NORMAL)
        
        # Timestamp
        timestamp = datetime.now().strftime("%H:%M:%S")
        self.chat_history.insert(tk.END, f"[{timestamp}] ", "timestamp")
        
        # Prefijo y nombre
        self.chat_history.insert(tk.END, f"{prefix} {sender}: ", tag)
        
        # Mensaje
        self.chat_history.insert(tk.END, f"{text}\n\n")
        
        # Auto-scroll
        self.chat_history.see(tk.END)
        self.chat_history.config(state=tk.DISABLED)
    
    def add_log(self, message: str, level: str = "info"):
        """Agrega entrada al log."""
        if not self.log_text:
            return
        
        self.log_text.config(state=tk.NORMAL)
        
        timestamp = datetime.now().strftime("%H:%M:%S")
        self.log_text.insert(tk.END, f"[{timestamp}] {message}\n", level)
        
        # Limitar tamaño
        if float(self.log_text.index('end')) > 1000:
            self.log_text.delete('1.0', '100.0')
        
        self.log_text.see(tk.END)
        self.log_text.config(state=tk.DISABLED)
    
    def _update_loop(self):
        """Loop de actualización de estado."""
        while self.running:
            try:
                if self.root and self.state:
                    # Actualizar en thread principal
                    self.root.after(0, self._update_status)
                
                time.sleep(1)
                
            except Exception as e:
                logger.error(f"Error en update loop: {e}")
                time.sleep(2)
    
    def _update_status(self):
        """Actualiza indicadores de estado."""
        if not self.state:
            return
        
        state = self.state.state
        
        # Actualizar mood
        if self.mood_indicator:
            mood_text = state.mood.value.upper()
            mood_colors = {
                'neutral': self.colors['text_dim'],
                'focused': self.colors['primary'],
                'alert': self.colors['alert'],
                'idle': self.colors['text_dim'],
                'processing': self.colors['warning'],
                'concerned': self.colors['alert'],
                'optimizing': self.colors['secondary']
            }
            self.mood_indicator.config(
                text=mood_text,
                fg=mood_colors.get(state.mood.value, self.colors['text'])
            )
        
        # Actualizar indicador de actividad
        if self.activity_indicator:
            # Parpadear si está procesando
            if state.active_tasks:
                current_color = self.activity_indicator.cget('fg')
                new_color = self.colors['secondary'] if current_color == self.colors['primary'] else self.colors['primary']
                self.activity_indicator.config(fg=new_color)
            else:
                self.activity_indicator.config(fg=self.colors['secondary'])
        
        # Actualizar texto de estado
        if self.system_status:
            health_color = (self.colors['secondary'] if state.system_health > 70 
                          else self.colors['warning'] if state.system_health > 40 
                          else self.colors['alert'])
            
            status_text = (
                f"Estado: {state.mood.value}\n"
                f"Salud: {state.system_health:.1f}%\n"
                f"Carga: {state.system_load.value}\n"
                f"Tareas: {len(state.active_tasks)}\n"
                f"Completadas hoy: {state.completed_tasks_today}\n"
                f"Errores: {state.errors_today}"
            )
            
            self.system_status.config(text=status_text, fg=health_color)
    
    def set_status(self, text: str):
        """Establece texto de estado manualmente."""
        if self.status_label:
            self.status_label.config(text=text)
    
    def show_notification(self, title: str, message: str, 
                          notification_type: str = "info"):
        """
        Muestra notificación visual.
        """
        # Crear ventana de notificación flotante
        popup = tk.Toplevel(self.root)
        popup.title("")
        popup.geometry("300x100")
        popup.configure(bg=self.colors['bg_secondary'])
        popup.overrideredirect(True)  # Sin bordes
        
        # Posicionar en esquina
        popup.geometry("+{}+{}".format(
            self.root.winfo_x() + self.root.winfo_width() - 320,
            self.root.winfo_y() + 50
        ))
        
        # Color según tipo
        color = (self.colors['primary'] if notification_type == "info"
                else self.colors['warning'] if notification_type == "warning"
                else self.colors['alert'])
        
        Label(
            popup,
            text=title,
            font=self.fonts['subheader'],
            fg=color,
            bg=self.colors['bg_secondary']
        ).pack(pady=(10, 5))
        
        Label(
            popup,
            text=message,
            font=self.fonts['body'],
            fg=self.colors['text'],
            bg=self.colors['bg_secondary'],
            wraplength=280
        ).pack()
        
        # Auto-cerrar
        popup.after(5000, popup.destroy)