"""
perception/audio_monitor.py
Sistema de Monitoreo de Audio de JARVIS v4.0

Implementa:
- Detección de palabra clave (wake word) "Jarvis"
- Reconocimiento de voz continuo (STT)
- Análisis de nivel de audio
- Detección de actividad de voz (VAD)
"""

import threading
import time
import numpy as np
import wave
import tempfile
import os
from typing import Optional, Callable, Dict, List, Any
from dataclasses import dataclass
from datetime import datetime
from enum import Enum
import logging

logger = logging.getLogger(__name__)


# Intentar importar dependencias opcionales
try:
    import pyaudio
    import webrtcvad
    PYAUDIO_AVAILABLE = True
except ImportError:
    PYAUDIO_AVAILABLE = False
    logger.warning("PyAudio no disponible. Audio desactivado.")

try:
    import whisper
    WHISPER_AVAILABLE = True
except ImportError:
    WHISPER_AVAILABLE = False
    logger.warning("Whisper no disponible. STT limitado.")


class AudioEventType(Enum):
    """Tipos de eventos de audio."""
    WAKE_WORD = "wake_word"
    SPEECH_START = "speech_start"
    SPEECH_END = "speech_end"
    TRANSCRIPTION = "transcription"
    AUDIO_LEVEL = "audio_level"
    SILENCE = "silence"
    ERROR = "error"


@dataclass
class AudioEvent:
    """Evento de audio detectado."""
    event_type: AudioEventType
    timestamp: datetime
    data: Any
    confidence: Optional[float] = None


class AudioMonitor:
    """
    Monitor de audio con wake word detection y STT.
    
    Características:
    - Detección de "Jarvis" como palabra clave
    - Grabación continua con VAD
    - Transcripción usando Whisper
    - Análisis de niveles de audio
    """
    
    # Configuración de audio
    FORMAT = None  # Se inicializa en __init__ si pyaudio está disponible
    CHANNELS = 1
    RATE = 16000  # Whisper requiere 16kHz
    CHUNK = 1024
    RECORD_SECONDS = 5
    
    # Configuración VAD
    VAD_AGGRESSIVENESS = 2  # 0-3, mayor = más agresivo (menos sensible)
    
    def __init__(self, 
                 wake_word: str = "jarvis",
                 callback: Optional[Callable[[AudioEvent], None]] = None,
                 enable_stt: bool = True,
                 stt_model: str = "base"):
        """
        Inicializa el monitor de audio.
        
        Args:
            wake_word: Palabra clave para activación
            callback: Función para eventos de audio
            enable_stt: Habilitar reconocimiento de voz
            stt_model: Modelo Whisper a usar (tiny, base, small, medium)
        """
        self.wake_word = wake_word.lower()
        self.callback = callback
        self.enable_stt = enable_stt and WHISPER_AVAILABLE
        self.stt_model_name = stt_model
        
        # Estado
        self.running = False
        self.audio_thread: Optional[threading.Thread] = None
        self._stop_event = threading.Event()
        
        # PyAudio
        self.audio: Optional[Any] = None
        self.stream: Optional[Any] = None
        
        # VAD
        self.vad: Optional[Any] = None
        if PYAUDIO_AVAILABLE:
            try:
                self.vad = webrtcvad.Vad(self.VAD_AGGRESSIVENESS)
            except:
                pass
        
        # STT (Whisper)
        self.whisper_model: Optional[Any] = None
        if self.enable_stt:
            self._load_whisper()
        
        # Estado de grabación
        self.is_recording = False
        self.recording_buffer: List[bytes] = []
        self.silence_counter = 0
        self.max_silence_chunks = 30  # ~1 segundo de silencio
        
        # Wake word detection simple
        self.wake_word_buffer: List[np.ndarray] = []
        self.wake_word_buffer_size = int(self.RATE / self.CHUNK * 2)  # 2 segundos
        
        # Nivel de audio actual
        self.current_audio_level = 0.0
        self.speech_threshold = 500  # Umbral para detección de voz
        
        # Estadísticas
        self.stats = {
            'audio_events': 0,
            'wake_words_detected': 0,
            'transcriptions': 0,
            'errors': 0,
            'avg_audio_level': 0.0
        }
        
        # Configurar formato si está disponible
        if PYAUDIO_AVAILABLE:
            self.FORMAT = pyaudio.paInt16
        
        logger.info(f"AudioMonitor inicializado (wake word: '{wake_word}')")
    
    def _load_whisper(self):
        """Carga modelo Whisper para STT."""
        try:
            logger.info(f"Cargando modelo Whisper: {self.stt_model_name}")
            self.whisper_model = whisper.load_model(self.stt_model_name)
            logger.info("Modelo Whisper cargado")
        except Exception as e:
            logger.error(f"Error cargando Whisper: {e}")
            self.enable_stt = False
            self.whisper_model = None
    
    def start(self):
        """Inicia el monitoreo de audio."""
        if self.running:
            return
        
        if not PYAUDIO_AVAILABLE:
            logger.error("No se puede iniciar: PyAudio no disponible")
            return
        
        self.running = True
        self._stop_event.clear()
        
        # Inicializar PyAudio
        try:
            self.audio = pyaudio.PyAudio()
            self.stream = self.audio.open(
                format=self.FORMAT,
                channels=self.CHANNELS,
                rate=self.RATE,
                input=True,
                frames_per_buffer=self.CHUNK,
                stream_callback=None
            )
            self.stream.start_stream()
        except Exception as e:
            logger.error(f"Error inicializando audio: {e}")
            self.running = False
            return
        
        # Iniciar thread de procesamiento
        self.audio_thread = threading.Thread(
            target=self._audio_loop,
            name="AudioMonitor",
            daemon=True
        )
        self.audio_thread.start()
        
        logger.info("AudioMonitor iniciado")
    
    def stop(self):
        """Detiene el monitoreo de audio."""
        if not self.running:
            return
        
        self.running = False
        self._stop_event.set()
        
        if self.audio_thread:
            self.audio_thread.join(timeout=3.0)
        
        # Cerrar stream
        if self.stream:
            self.stream.stop_stream()
            self.stream.close()
        if self.audio:
            self.audio.terminate()
        
        logger.info("AudioMonitor detenido")
    
    def _audio_loop(self):
        """Loop principal de procesamiento de audio."""
        logger.info("Loop de audio iniciado")
        
        while self.running and not self._stop_event.is_set():
            try:
                # Leer audio
                if not self.stream:
                    time.sleep(0.1)
                    continue
                
                data = self.stream.read(self.CHUNK, exception_on_overflow=False)
                audio_data = np.frombuffer(data, dtype=np.int16)
                
                # Calcular nivel de audio
                level = np.abs(audio_data).mean()
                self.current_audio_level = level
                self._update_audio_stats(level)
                
                # Detectar wake word si no está grabando
                if not self.is_recording:
                    self._detect_wake_word(audio_data, data)
                
                # Procesar grabación activa
                else:
                    self._process_recording(audio_data, data, level)
                
                # Notificar nivel de audio periódicamente
                if self.stats['audio_events'] % 50 == 0 and self.callback:
                    self.callback(AudioEvent(
                        event_type=AudioEventType.AUDIO_LEVEL,
                        timestamp=datetime.now(),
                        data={'level': level, 'threshold': self.speech_threshold},
                        confidence=level / 1000.0
                    ))
                
                self.stats['audio_events'] += 1
                
                # Pequeña pausa para no saturar CPU
                time.sleep(0.001)
                
            except Exception as e:
                logger.error(f"Error en loop de audio: {e}")
                self.stats['errors'] += 1
                time.sleep(0.1)
    
    def _detect_wake_word(self, audio_data: np.ndarray, raw_data: bytes):
        """
        Detección simple de wake word basada en energía y patrón.
        
        Nota: Esto es una implementación básica. Para producción,
        se recomienda usar Porcupine o similar.
        """
        # Agregar a buffer circular
        self.wake_word_buffer.append(audio_data)
        if len(self.wake_word_buffer) > self.wake_word_buffer_size:
            self.wake_word_buffer.pop(0)
        
        # Detección por energía y duración
        if len(self.wake_word_buffer) >= self.wake_word_buffer_size // 2:
            # Analizar buffer
            combined = np.concatenate(self.wake_word_buffer)
            
            # Características simples
            energy = np.abs(combined).mean()
            
            # Si hay suficiente energía (posible voz)
            if energy > self.speech_threshold * 1.5:
                # Patrón temporal simple: busca picos característicos de "Jarvis"
                # (sílabas: jar-vis = 2 picos de energía)
                
                # Dividir en ventanas
                window_size = len(combined) // 4
                energies = []
                for i in range(4):
                    window = combined[i*window_size:(i+1)*window_size]
                    energies.append(np.abs(window).mean())
                
                # Patrón esperado: bajo-alto-bajo-alto (silencio-jar-silencio-vis)
                if len(energies) == 4:
                    # Normalizar
                    max_e = max(energies)
                    if max_e > 0:
                        normalized = [e/max_e for e in energies]
                        
                        # Patrón: picos en posiciones 1 y 3
                        if (normalized[1] > 0.6 and normalized[3] > 0.6 and
                            normalized[0] < 0.4 and normalized[2] < 0.5):
                            
                            # Wake word detectado!
                            self.stats['wake_words_detected'] += 1
                            logger.info(f"Wake word '{self.wake_word}' detectado!")
                            
                            # Notificar
                            if self.callback:
                                self.callback(AudioEvent(
                                    event_type=AudioEventType.WAKE_WORD,
                                    timestamp=datetime.now(),
                                    data={'confidence': 0.7, 'method': 'energy_pattern'},
                                    confidence=0.7
                                ))
                            
                            # Iniciar grabación
                            self._start_recording()
                            
                            # Limpiar buffer
                            self.wake_word_buffer.clear()
    
    def _start_recording(self):
        """Inicia grabación de comando de voz."""
        self.is_recording = True
        self.recording_buffer = []
        self.silence_counter = 0
        
        logger.debug("Grabación iniciada")
        
        if self.callback:
            self.callback(AudioEvent(
                event_type=AudioEventType.SPEECH_START,
                timestamp=datetime.now(),
                data={}
            ))
    
    def _process_recording(self, audio_data: np.ndarray, 
                           raw_data: bytes, level: float):
        """Procesa audio durante grabación activa."""
        # Agregar a buffer
        self.recording_buffer.append(raw_data)
        
        # Detectar silencio (fin de comando)
        if level < self.speech_threshold * 0.5:
            self.silence_counter += 1
        else:
            self.silence_counter = 0
        
        # Condiciones de parada
        max_chunks = int(self.RATE / self.CHUNK * self.RECORD_SECONDS)
        
        if self.silence_counter > self.max_silence_chunks:
            # Silencio detectado, finalizar
            logger.debug("Silencio detectado, finalizando grabación")
            self._finalize_recording()
        elif len(self.recording_buffer) > max_chunks:
            # Máximo tiempo alcanzado
            logger.debug("Tiempo máximo de grabación alcanzado")
            self._finalize_recording()
    
    def _finalize_recording(self):
        """Finaliza grabación y procesa."""
        if not self.recording_buffer:
            self.is_recording = False
            return
        
        # Guardar audio temporal
        temp_file = None
        try:
            with tempfile.NamedTemporaryFile(suffix='.wav', delete=False) as f:
                temp_file = f.name
                
                # Escribir WAV
                with wave.open(f, 'wb') as wf:
                    wf.setnchannels(self.CHANNELS)
                    wf.setsampwidth(2)  # 16-bit
                    wf.setframerate(self.RATE)
                    wf.writeframes(b''.join(self.recording_buffer))
            
            # Notificar fin de speech
            if self.callback:
                self.callback(AudioEvent(
                    event_type=AudioEventType.SPEECH_END,
                    timestamp=datetime.now(),
                    data={'duration': len(self.recording_buffer) * self.CHUNK / self.RATE}
                ))
            
            # Transcribir si está habilitado
            if self.enable_stt and self.whisper_model:
                transcription = self._transcribe(temp_file)
                
                if transcription:
                    self.stats['transcriptions'] += 1
                    
                    if self.callback:
                        self.callback(AudioEvent(
                            event_type=AudioEventType.TRANSCRIPTION,
                            timestamp=datetime.now(),
                            data={
                                'text': transcription,
                                'audio_file': temp_file,
                                'duration': len(self.recording_buffer) * self.CHUNK / self.RATE
                            },
                            confidence=0.8
                        ))
            
        except Exception as e:
            logger.error(f"Error finalizando grabación: {e}")
            self.stats['errors'] += 1
            
            if self.callback:
                self.callback(AudioEvent(
                    event_type=AudioEventType.ERROR,
                    timestamp=datetime.now(),
                    data={'error': str(e)}
                ))
        
        finally:
            # Limpiar
            self.is_recording = False
            self.recording_buffer = []
            self.silence_counter = 0
            
            # Eliminar archivo temporal
            if temp_file and os.path.exists(temp_file):
                try:
                    os.unlink(temp_file)
                except:
                    pass
    
    def _transcribe(self, audio_file: str) -> Optional[str]:
        """
        Transcribe audio usando Whisper.
        """
        if not self.whisper_model:
            return None
        
        try:
            result = self.whisper_model.transcribe(
                audio_file,
                language="es",
                task="transcribe",
                fp16=False  # Para CPU
            )
            
            text = result.get("text", "").strip()
            
            if text:
                logger.info(f"Transcrito: {text[:50]}...")
                return text
            
            return None
            
        except Exception as e:
            logger.error(f"Error en transcripción: {e}")
            return None
    
    def _update_audio_stats(self, level: float):
        """Actualiza estadísticas de nivel de audio."""
        alpha = 0.05
        self.stats['avg_audio_level'] = (
            (1 - alpha) * self.stats['avg_audio_level'] + alpha * level
        )
    
    def is_listening(self) -> bool:
        """Retorna si está escuchando activamente."""
        return self.is_recording
    
    def get_audio_level(self) -> float:
        """Retorna nivel actual de audio."""
        return self.current_audio_level
    
    def force_recording_start(self):
        """Fuerza inicio de grabación (para testing)."""
        self._start_recording()
    
    def force_recording_stop(self):
        """Fuerza fin de grabación."""
        if self.is_recording:
            self._finalize_recording()
    
    def get_stats(self) -> Dict:
        """Retorna estadísticas del monitor de audio."""
        return {
            **self.stats,
            'running': self.running,
            'is_recording': self.is_recording,
            'stt_enabled': self.enable_stt,
            'wake_word': self.wake_word,
            'buffer_size': len(self.recording_buffer) if self.is_recording else 0
        }