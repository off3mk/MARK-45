"""
perception/system_monitor.py
Monitoreo del Sistema de JARVIS v4.0

Extensión del StateEngine enfocado en monitoreo continuo
con detección de anomalías y alertas proactivas.
"""

import psutil
import threading
import time
from typing import Dict, List, Optional, Callable, Any
from dataclasses import dataclass
from datetime import datetime
from enum import Enum
import logging

logger = logging.getLogger(__name__)


class AnomalyType(Enum):
    """Tipos de anomalías detectables."""
    CPU_SPIKE = "cpu_spike"
    MEMORY_LEAK = "memory_leak"
    DISK_SLOW = "disk_slow"
    NETWORK_ANOMALY = "network_anomaly"
    PROCESS_ZOMBIE = "process_zombie"
    TEMPERATURE_HIGH = "temperature_high"


@dataclass
class Anomaly:
    """Anomalía detectada."""
    type: AnomalyType
    severity: str  # 'low', 'medium', 'high', 'critical'
    description: str
    timestamp: datetime
    metric_value: float
    threshold: float
    suggested_action: str


class SystemMonitor:
    """
    Monitor de sistema con detección de anomalías.
    
    Trabaja en conjunto con StateEngine pero enfocado en
    detección proactiva de problemas.
    """
    
    def __init__(self, 
                 callback: Optional[Callable[[Dict], None]] = None,
                 check_interval: float = 3.0):
        """
        Inicializa el monitor de sistema.
        
        Args:
            callback: Función para alertas y anomalías
            check_interval: Segundos entre chequeos
        """
        self.callback = callback
        self.check_interval = check_interval
        
        # Estado
        self.running = False
        self.monitor_thread: Optional[threading.Thread] = None
        self._stop_event = threading.Event()
        
        # Historial de métricas para detección de tendencias
        self.metric_history: Dict[str, List[tuple]] = {
            'cpu': [],      # (timestamp, value)
            'memory': [],
            'disk_io': [],
            'network': []
        }
        self.max_history = 100
        
        # Anomalías detectadas
        self.anomalies: List[Anomaly] = []
        self.max_anomalies = 50
        
        # Umbrales de anomalía
        self.thresholds = {
            'cpu_spike': 2.0,      # Multiplicador sobre promedio
            'memory_growth': 10.0,  # MB por minuto
            'disk_slow': 100.0,     # ms de latencia
            'network_drop': 0.5,    # Ratio de paquetes perdidos
        }
        
        # Estadísticas
        self.stats = {
            'checks_performed': 0,
            'anomalies_detected': 0,
            'alerts_sent': 0,
            'false_positives': 0
        }
        
        logger.info("SystemMonitor inicializado")
    
    def start(self):
        """Inicia el monitoreo."""
        if self.running:
            return
        
        self.running = True
        self._stop_event.clear()
        
        self.monitor_thread = threading.Thread(
            target=self._monitor_loop,
            name="SystemMonitor",
            daemon=True
        )
        self.monitor_thread.start()
        
        logger.info("SystemMonitor iniciado")
    
    def stop(self):
        """Detiene el monitoreo."""
        if not self.running:
            return
        
        self.running = False
        self._stop_event.set()
        
        if self.monitor_thread:
            self.monitor_thread.join(timeout=3.0)
        
        logger.info("SystemMonitor detenido")
    
    def _monitor_loop(self):
        """Loop principal de monitoreo."""
        while self.running and not self._stop_event.is_set():
            try:
                start_time = time.time()
                
                # Recolectar métricas
                metrics = self._collect_metrics()
                
                # Guardar en historial
                self._update_history(metrics)
                
                # Detectar anomalías
                anomalies = self._detect_anomalies(metrics)
                
                # Notificar si hay anomalías
                if anomalies and self.callback:
                    for anomaly in anomalies:
                        self.callback({
                            'type': 'anomaly_detected',
                            'timestamp': datetime.now().isoformat(),
                            'anomaly': {
                                'type': anomaly.type.value,
                                'severity': anomaly.severity,
                                'description': anomaly.description,
                                'suggested_action': anomaly.suggested_action
                            }
                        })
                        self.stats['alerts_sent'] += 1
                
                # Notificar snapshot periódico
                if self.callback and self.stats['checks_performed'] % 10 == 0:
                    self.callback({
                        'type': 'system_snapshot',
                        'timestamp': datetime.now().isoformat(),
                        'metrics': metrics
                    })
                
                self.stats['checks_performed'] += 1
                
                # Esperar siguiente ciclo
                elapsed = time.time() - start_time
                sleep_time = max(0, self.check_interval - elapsed)
                self._stop_event.wait(sleep_time)
                
            except Exception as e:
                logger.error(f"Error en monitoreo: {e}")
                time.sleep(1)
    
    def _collect_metrics(self) -> Dict:
        """Recolecta métricas del sistema."""
        metrics = {
            'timestamp': datetime.now().isoformat(),
            'cpu': {
                'percent': psutil.cpu_percent(interval=0.5, percpu=True),
                'freq': psutil.cpu_freq()._asdict() if psutil.cpu_freq() else None
            },
            'memory': {
                'percent': psutil.virtual_memory().percent,
                'available_mb': psutil.virtual_memory().available / (1024**2),
                'used_mb': psutil.virtual_memory().used / (1024**2)
            },
            'disk': {
                'percent': psutil.disk_usage('/').percent,
                'read_mb': 0,  # Requiere psutil.disk_io_counters()
                'write_mb': 0
            },
            'network': {
                'sent_mb': psutil.net_io_counters().bytes_sent / (1024**2),
                'recv_mb': psutil.net_io_counters().bytes_recv / (1024**2),
                'packets_sent': psutil.net_io_counters().packets_sent,
                'packets_recv': psutil.net_io_counters().packets_recv
            },
            'processes': len(list(psutil.process_iter()))
        }
        
        # I/O de disco si está disponible
        try:
            io = psutil.disk_io_counters()
            metrics['disk']['read_mb'] = io.read_bytes / (1024**2)
            metrics['disk']['write_mb'] = io.write_bytes / (1024**2)
        except:
            pass
        
        return metrics
    
    def _update_history(self, metrics: Dict):
        """Actualiza historial de métricas."""
        now = time.time()
        
        # CPU promedio
        cpu_avg = sum(metrics['cpu']['percent']) / len(metrics['cpu']['percent'])
        self.metric_history['cpu'].append((now, cpu_avg))
        
        # Memoria
        self.metric_history['memory'].append((now, metrics['memory']['used_mb']))
        
        # Limitar tamaño
        for key in self.metric_history:
            if len(self.metric_history[key]) > self.max_history:
                self.metric_history[key] = self.metric_history[key][-self.max_history:]
    
    def _detect_anomalies(self, metrics: Dict) -> List[Anomaly]:
        """Detecta anomalías basadas en métricas e historial."""
        anomalies = []
        
        # 1. CPU Spike
        if len(self.metric_history['cpu']) >= 10:
            recent_avg = sum(v for _, v in self.metric_history['cpu'][-5:]) / 5
            older_avg = sum(v for _, v in self.metric_history['cpu'][-10:-5]) / 5
            
            if older_avg > 10 and recent_avg > older_avg * self.thresholds['cpu_spike']:
                anomalies.append(Anomaly(
                    type=AnomalyType.CPU_SPIKE,
                    severity='high' if recent_avg > 90 else 'medium',
                    description=f"CPU aumentó de {older_avg:.1f}% a {recent_avg:.1f}%",
                    timestamp=datetime.now(),
                    metric_value=recent_avg,
                    threshold=older_avg * self.thresholds['cpu_spike'],
                    suggested_action='Verificar procesos de alto consumo'
                ))
        
        # 2. Memory Leak (crecimiento sostenido)
        if len(self.metric_history['memory']) >= 20:
            recent = self.metric_history['memory'][-20:]
            first_half = sum(v for _, v in recent[:10]) / 10
            second_half = sum(v for _, v in recent[10:]) / 10
            
            growth = second_half - first_half  # MB
            
            if growth > self.thresholds['memory_growth'] * 2:  # 20 MB en 20 ciclos
                anomalies.append(Anomaly(
                    type=AnomalyType.MEMORY_LEAK,
                    severity='high' if growth > 50 else 'medium',
                    description=f"Memoria creció {growth:.1f} MB en poco tiempo",
                    timestamp=datetime.now(),
                    metric_value=growth,
                    threshold=self.thresholds['memory_growth'] * 2,
                    suggested_action='Verificar fugas de memoria en aplicaciones'
                ))
        
        # 3. Disco casi lleno
        if metrics['disk']['percent'] > 95:
            anomalies.append(Anomaly(
                type=AnomalyType.DISK_SLOW,
                severity='critical',
                description=f"Disco al {metrics['disk']['percent']:.1f}% de capacidad",
                timestamp=datetime.now(),
                metric_value=metrics['disk']['percent'],
                threshold=95,
                suggested_action='Liberar espacio en disco inmediatamente'
            ))
        
        # Guardar anomalías
        for anomaly in anomalies:
            self.anomalies.append(anomaly)
            self.stats['anomalies_detected'] += 1
        
        if len(self.anomalies) > self.max_anomalies:
            self.anomalies = self.anomalies[-self.max_anomalies:]
        
        return anomalies
    
    def get_recent_anomalies(self, count: int = 10) -> List[Dict]:
        """Retorna anomalías recientes."""
        return [
            {
                'type': a.type.value,
                'severity': a.severity,
                'description': a.description,
                'timestamp': a.timestamp.isoformat(),
                'suggested_action': a.suggested_action
            }
            for a in self.anomalies[-count:]
        ]
    
    def get_trends(self) -> Dict:
        """Retorna tendencias de métricas."""
        trends = {}
        
        for metric_name, history in self.metric_history.items():
            if len(history) >= 10:
                recent = [v for _, v in history[-10:]]
                older = [v for _, v in history[-20:-10]] if len(history) >= 20 else recent
                
                trends[metric_name] = {
                    'current': recent[-1],
                    'avg_recent': sum(recent) / len(recent),
                    'avg_older': sum(older) / len(older),
                    'trend': 'increasing' if sum(recent) > sum(older) * 1.1 else
                            'decreasing' if sum(recent) < sum(older) * 0.9 else 'stable'
                }
        
        return trends
    
    def get_stats(self) -> Dict:
        """Retorna estadísticas del monitor."""
        return {
            **self.stats,
            'running': self.running,
            'anomalies_stored': len(self.anomalies),
            'history_size': {k: len(v) for k, v in self.metric_history.items()}
        }