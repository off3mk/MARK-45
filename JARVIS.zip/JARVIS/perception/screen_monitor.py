"""
perception/screen_monitor.py
Sistema de Visión por Computadora de JARVIS v4.0

Implementa capacidades de visión mediante:
- Captura de pantalla continua
- OCR (Reconocimiento Óptico de Caracteres)
- Detección de elementos de UI
- Análisis de contenido visual
"""

import numpy as np
import cv2
import pyautogui
import pytesseract
from PIL import Image, ImageGrab
import threading
import time
import queue
from typing import Dict, List, Optional, Tuple, Callable, Any, Set
from dataclasses import dataclass
from datetime import datetime
from enum import Enum
import logging
import os

logger = logging.getLogger(__name__)


class VisionEventType(Enum):
    """Tipos de eventos de visión."""
    SCREEN_CAPTURE = "screen_capture"
    TEXT_DETECTED = "text_detected"
    UI_ELEMENT_FOUND = "ui_element_found"
    CHANGE_DETECTED = "change_detected"
    OCR_COMPLETE = "ocr_complete"


@dataclass
class BoundingBox:
    """Caja delimitadora para elementos detectados."""
    x: int
    y: int
    width: int
    height: int
    
    @property
    def center(self) -> Tuple[int, int]:
        """Retorna centro de la caja."""
        return (self.x + self.width // 2, self.y + self.height // 2)
    
    @property
    def area(self) -> int:
        """Retorna área de la caja."""
        return self.width * self.height
    
    def contains(self, point: Tuple[int, int]) -> bool:
        """Verifica si un punto está dentro de la caja."""
        px, py = point
        return (self.x <= px <= self.x + self.width and
                self.y <= py <= self.y + self.height)
    
    def to_dict(self) -> Dict:
        return {
            'x': self.x, 'y': self.y,
            'width': self.width, 'height': self.height,
            'center': self.center
        }


@dataclass
class DetectedElement:
    """Elemento detectado en la pantalla."""
    element_type: str  # 'button', 'text_field', 'checkbox', 'label', etc.
    text: str
    bbox: BoundingBox
    confidence: float
    metadata: Dict = None
    
    def __post_init__(self):
        if self.metadata is None:
            self.metadata = {}
    
    def to_dict(self) -> Dict:
        return {
            'type': self.element_type,
            'text': self.text,
            'bbox': self.bbox.to_dict(),
            'confidence': self.confidence,
            'metadata': self.metadata
        }


@dataclass
class VisionEvent:
    """Evento de visión procesado."""
    event_type: VisionEventType
    timestamp: datetime
    data: Any
    region: Optional[BoundingBox] = None


class ScreenMonitor:
    """
    Monitor de pantalla con capacidades de visión por computadora.
    
    Características:
    - Captura continua de pantalla
    - OCR en tiempo real
    - Detección de elementos UI
    - Diferenciación de cambios
    - Búsqueda de elementos por texto
    """
    
    def __init__(self, 
                 capture_interval: float = 2.0,
                 enable_ocr: bool = True,
                 enable_ui_detection: bool = True,
                 ocr_language: str = 'spa+eng',
                 callback: Optional[Callable[[VisionEvent], None]] = None):
        """
        Inicializa el monitor de pantalla.
        
        Args:
            capture_interval: Segundos entre capturas
            enable_ocr: Habilitar reconocimiento de texto
            enable_ui_detection: Habilitar detección de UI
            ocr_language: Idiomas para OCR (códigos Tesseract)
            callback: Función a llamar con eventos detectados
        """
        self.capture_interval = capture_interval
        self.enable_ocr = enable_ocr
        self.enable_ui_detection = enable_ui_detection
        self.ocr_language = ocr_language
        self.callback = callback
        
        # Estado
        self.running = False
        self.monitor_thread: Optional[threading.Thread] = None
        self._stop_event = threading.Event()
        
        # Datos de captura
        self.last_screenshot: Optional[np.ndarray] = None
        self.last_screenshot_time: Optional[datetime] = None
        self.current_elements: List[DetectedElement] = []
        self.detected_text: str = ""
        
        # Configuración OCR
        self.ocr_config = f'--oem 3 --psm 6 -l {ocr_language}'
        
        # Cola de procesamiento
        self.processing_queue: queue.Queue = queue.Queue(maxsize=5)
        self.processor_thread: Optional[threading.Thread] = None
        
        # Historial de cambios
        self.change_history: List[Dict] = []
        self.max_history = 50
        
        # Regiones de interés
        self.regions_of_interest: List[BoundingBox] = []
        
        # Estadísticas
        self.stats = {
            'captures': 0,
            'ocr_runs': 0,
            'ui_detections': 0,
            'elements_found': 0,
            'errors': 0
        }
        
        # Verificar dependencias
        self._check_dependencies()
        
        logger.info("ScreenMonitor inicializado")
    
    def _check_dependencies(self):
        """Verifica que las dependencias estén instaladas."""
        self.deps_ok = True
        
        # Verificar Tesseract
        try:
            pytesseract.get_tesseract_version()
        except Exception as e:
            logger.warning(f"Tesseract no disponible: {e}")
            self.enable_ocr = False
            self.deps_ok = False
        
        # Verificar OpenCV
        try:
            cv2.__version__
        except:
            logger.error("OpenCV no disponible")
            self.deps_ok = False
    
    def start(self):
        """Inicia el monitoreo de pantalla."""
        if self.running:
            return
        
        if not self.deps_ok:
            logger.error("No se puede iniciar: dependencias faltantes")
            return
        
        self.running = True
        self._stop_event.clear()
        
        # Thread de captura
        self.monitor_thread = threading.Thread(
            target=self._capture_loop,
            name="ScreenCapture",
            daemon=True
        )
        self.monitor_thread.start()
        
        # Thread de procesamiento (OCR/UI)
        if self.enable_ocr or self.enable_ui_detection:
            self.processor_thread = threading.Thread(
                target=self._processing_loop,
                name="VisionProcessor",
                daemon=True
            )
            self.processor_thread.start()
        
        logger.info("ScreenMonitor iniciado")
    
    def stop(self):
        """Detiene el monitoreo."""
        if not self.running:
            return
        
        self.running = False
        self._stop_event.set()
        
        if self.monitor_thread:
            self.monitor_thread.join(timeout=3.0)
        if self.processor_thread:
            self.processor_thread.join(timeout=3.0)
        
        logger.info("ScreenMonitor detenido")
    
    def _capture_loop(self):
        """Loop principal de captura de pantalla."""
        while self.running and not self._stop_event.is_set():
            try:
                start_time = time.time()
                
                # Capturar pantalla
                screenshot = self._capture_screen()
                
                if screenshot is not None:
                    self.last_screenshot = screenshot
                    self.last_screenshot_time = datetime.now()
                    self.stats['captures'] += 1
                    
                    # Detectar cambios significativos
                    if self._significant_change(screenshot):
                        # Encolar para procesamiento
                        try:
                            self.processing_queue.put_nowait(screenshot.copy())
                        except queue.Full:
                            pass  # Omitir si la cola está llena
                    
                    # Notificar captura
                    if self.callback:
                        self.callback(VisionEvent(
                            event_type=VisionEventType.SCREEN_CAPTURE,
                            timestamp=datetime.now(),
                            data={'size': screenshot.shape}
                        ))
                
                # Esperar siguiente captura
                elapsed = time.time() - start_time
                sleep_time = max(0, self.capture_interval - elapsed)
                self._stop_event.wait(sleep_time)
                
            except Exception as e:
                logger.error(f"Error en captura: {e}")
                self.stats['errors'] += 1
                time.sleep(1)
    
    def _processing_loop(self):
        """Loop de procesamiento de imágenes (OCR/UI)."""
        while self.running and not self._stop_event.is_set():
            try:
                # Obtener imagen de la cola
                screenshot = self.processing_queue.get(timeout=0.5)
                
                elements = []
                
                # OCR
                if self.enable_ocr:
                    text, text_elements = self._perform_ocr(screenshot)
                    self.detected_text = text
                    elements.extend(text_elements)
                    self.stats['ocr_runs'] += 1
                
                # Detección de UI
                if self.enable_ui_detection:
                    ui_elements = self._detect_ui_elements(screenshot)
                    elements.extend(ui_elements)
                    self.stats['ui_detections'] += 1
                
                # Actualizar elementos actuales
                self.current_elements = elements
                self.stats['elements_found'] += len(elements)
                
                # Notificar elementos encontrados
                if elements and self.callback:
                    for elem in elements[:5]:  # Limitar notificaciones
                        self.callback(VisionEvent(
                            event_type=VisionEventType.UI_ELEMENT_FOUND,
                            timestamp=datetime.now(),
                            data=elem.to_dict(),
                            region=elem.bbox
                        ))
                
            except queue.Empty:
                continue
            except Exception as e:
                logger.error(f"Error en procesamiento: {e}")
                self.stats['errors'] += 1
    
    def _capture_screen(self) -> Optional[np.ndarray]:
        """Captura la pantalla completa."""
        try:
            # Usar PIL para captura
            screenshot = ImageGrab.grab()
            # Convertir a numpy array (OpenCV format)
            return cv2.cvtColor(np.array(screenshot), cv2.COLOR_RGB2BGR)
        except Exception as e:
            logger.error(f"Error capturando pantalla: {e}")
            return None
    
    def _significant_change(self, new_screenshot: np.ndarray) -> bool:
        """Detecta si hay cambios significativos respecto a la captura anterior."""
        if self.last_screenshot is None or len(self.change_history) == 0:
            return True
        
        try:
            # Redimensionar para comparación rápida
            small_new = cv2.resize(new_screenshot, (320, 180))
            small_old = cv2.resize(self.last_screenshot, (320, 180))
            
            # Calcular diferencia
            diff = cv2.absdiff(small_new, small_old)
            diff_score = np.mean(diff)
            
            # Umbral de cambio
            return diff_score > 5.0  # Ajustar según sensibilidad deseada
            
        except:
            return True
    
    def _perform_ocr(self, image: np.ndarray) -> Tuple[str, List[DetectedElement]]:
        """
        Realiza OCR en la imagen.
        
        Returns:
            (texto_completo, lista_de_elementos_detectados)
        """
        try:
            # Convertir a escala de grises para OCR
            gray = cv2.cvtColor(image, cv2.COLOR_BGR2GRAY)
            
            # Mejorar contraste
            _, binary = cv2.threshold(gray, 0, 255, cv2.THRESH_BINARY + cv2.THRESH_OTSU)
            
            # OCR completo
            full_text = pytesseract.image_to_string(
                binary, 
                config=self.ocr_config
            ).strip()
            
            # OCR con datos de posición (para detectar elementos individuales)
            data = pytesseract.image_to_data(
                binary,
                config=self.ocr_config,
                output_type=pytesseract.Output.DICT
            )
            
            elements = []
            n_boxes = len(data['text'])
            
            for i in range(n_boxes):
                text = data['text'][i].strip()
                conf = int(data['conf'][i])
                
                # Filtrar por confianza y contenido
                if conf > 60 and len(text) > 2:
                    x, y, w, h = data['left'][i], data['top'][i], data['width'][i], data['height'][i]
                    
                    # Determinar tipo de elemento
                    elem_type = self._classify_text_element(text, w, h)
                    
                    elements.append(DetectedElement(
                        element_type=elem_type,
                        text=text,
                        bbox=BoundingBox(x, y, w, h),
                        confidence=conf / 100.0,
                        metadata={'ocr_confidence': conf}
                    ))
            
            return full_text, elements
            
        except Exception as e:
            logger.error(f"Error en OCR: {e}")
            return "", []
    
    def _classify_text_element(self, text: str, width: int, height: int) -> str:
        """Clasifica un elemento de texto por su apariencia."""
        # Heurísticas simples
        if height < 20:
            return 'label'
        elif text.lower() in ['ok', 'aceptar', 'cancelar', 'cerrar', 'guardar', 
                             'siguiente', 'atrás', 'enviar', 'buscar']:
            return 'button'
        elif width > 200 and height > 30:
            return 'text_field'
        elif text.startswith('☐') or text.startswith('[ ]'):
            return 'checkbox'
        elif text.startswith('○') or text.startswith('( )'):
            return 'radio'
        else:
            return 'text'
    
    def _detect_ui_elements(self, image: np.ndarray) -> List[DetectedElement]:
        """
        Detecta elementos de UI usando visión por computadora clásica.
        """
        elements = []
        
        try:
            # Detección de botones (rectángulos con texto)
            gray = cv2.cvtColor(image, cv2.COLOR_BGR2GRAY)
            blurred = cv2.GaussianBlur(gray, (5, 5), 0)
            
            # Detección de bordes
            edges = cv2.Canny(blurred, 50, 150)
            
            # Encontrar contornos
            contours, _ = cv2.findContours(
                edges, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE
            )
            
            for cnt in contours:
                x, y, w, h = cv2.boundingRect(cnt)
                
                # Filtrar por tamaño (botones típicos)
                if 40 < w < 400 and 25 < h < 100 and w > h * 1.5:
                    # Verificar si tiene texto (usar ROI para OCR rápido)
                    roi = gray[y:y+h, x:x+w]
                    text = pytesseract.image_to_string(
                        roi, 
                        config='--psm 7 -l spa+eng'  # PSM 7 = single line
                    ).strip()
                    
                    if text and len(text) < 50:
                        elements.append(DetectedElement(
                            element_type='button',
                            text=text,
                            bbox=BoundingBox(x, y, w, h),
                            confidence=0.7,
                            metadata={'detected_by': 'contour'}
                        ))
            
            # Detección de campos de texto (rectángulos horizontales largos)
            # Usar análisis de líneas horizontales
            horizontal_kernel = cv2.getStructuringElement(cv2.MORPH_RECT, (40, 1))
            horizontal_lines = cv2.morphologyEx(edges, cv2.MORPH_OPEN, horizontal_kernel)
            
            h_contours, _ = cv2.findContours(
                horizontal_lines, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE
            )
            
            for cnt in h_contours:
                x, y, w, h = cv2.boundingRect(cnt)
                if w > 150 and 20 < h < 50:
                    elements.append(DetectedElement(
                        element_type='text_field_candidate',
                        text='',
                        bbox=BoundingBox(x, y, w, h),
                        confidence=0.5,
                        metadata={'detected_by': 'line_analysis'}
                    ))
        
        except Exception as e:
            logger.error(f"Error en detección de UI: {e}")
        
        return elements
    
    def find_element(self, text_query: str, 
                     element_type: Optional[str] = None) -> Optional[DetectedElement]:
        """
        Busca un elemento en la pantalla por texto.
        
        Args:
            text_query: Texto a buscar
            element_type: Tipo específico de elemento (opcional)
        
        Returns:
            Elemento encontrado o None
        """
        query_lower = text_query.lower()
        
        for elem in self.current_elements:
            # Coincidencia exacta o parcial
            if query_lower in elem.text.lower() or elem.text.lower() in query_lower:
                if element_type is None or elem.element_type == element_type:
                    return elem
        
        return None
    
    def find_all_elements(self, text_query: str) -> List[DetectedElement]:
        """Encuentra todos los elementos que coincidan con el texto."""
        query_lower = text_query.lower()
        matches = []
        
        for elem in self.current_elements:
            if query_lower in elem.text.lower():
                matches.append(elem)
        
        return matches
    
    def click_element(self, element: DetectedElement, 
                     double: bool = False) -> bool:
        """
        Hace clic en un elemento detectado.
        
        Args:
            element: Elemento a clickear
            double: Si True, doble clic
        
        Returns:
            True si tuvo éxito
        """
        try:
            x, y = element.bbox.center
            
            if double:
                pyautogui.doubleClick(x, y)
            else:
                pyautogui.click(x, y)
            
            logger.info(f"Clic en elemento '{element.text}' en ({x}, {y})")
            return True
            
        except Exception as e:
            logger.error(f"Error al hacer clic: {e}")
            return False
    
    def click_text(self, text: str, double: bool = False) -> bool:
        """
        Busca texto en pantalla y hace clic en él.
        
        Args:
            text: Texto a buscar y clickear
            double: Doble clic
        
        Returns:
            True si encontró y clickeó
        """
        element = self.find_element(text)
        if element:
            return self.click_element(element, double)
        return False
    
    def read_screen_region(self, region: BoundingBox) -> str:
        """
        Lee texto de una región específica de la pantalla.
        
        Args:
            region: Región a leer
        
        Returns:
            Texto detectado
        """
        if self.last_screenshot is None:
            return ""
        
        try:
            # Extraer ROI
            x, y, w, h = region.x, region.y, region.width, region.height
            roi = self.last_screenshot[y:y+h, x:x+w]
            
            # OCR
            gray = cv2.cvtColor(roi, cv2.COLOR_BGR2GRAY)
            text = pytesseract.image_to_string(
                gray,
                config=f'--psm 6 -l {self.ocr_language}'
            )
            
            return text.strip()
            
        except Exception as e:
            logger.error(f"Error leyendo región: {e}")
            return ""
    
    def wait_for_element(self, text: str, timeout: float = 10.0,
                         check_interval: float = 0.5) -> Optional[DetectedElement]:
        """
        Espera hasta que aparezca un elemento en pantalla.
        
        Args:
            text: Texto del elemento a esperar
            timeout: Tiempo máximo de espera
            check_interval: Intervalo entre chequeos
        
        Returns:
            Elemento cuando aparece, o None si timeout
        """
        start_time = time.time()
        
        while time.time() - start_time < timeout:
            element = self.find_element(text)
            if element:
                return element
            
            time.sleep(check_interval)
        
        return None
    
    def add_region_of_interest(self, bbox: BoundingBox):
        """Agrega una región para monitoreo prioritario."""
        self.regions_of_interest.append(bbox)
    
    def clear_regions_of_interest(self):
        """Limpia regiones de interés."""
        self.regions_of_interest.clear()
    
    def get_screen_description(self) -> str:
        """
        Genera descripción textual del contenido de la pantalla.
        """
        if not self.current_elements:
            return "No se detectaron elementos en la pantalla."
        
        # Agrupar por tipo
        by_type: Dict[str, List[str]] = {}
        for elem in self.current_elements:
            t = elem.element_type
            if t not in by_type:
                by_type[t] = []
            by_type[t].append(elem.text[:30])  # Limitar longitud
        
        description_parts = []
        
        if 'button' in by_type:
            buttons = by_type['button']
            description_parts.append(f"Botones visibles: {', '.join(buttons[:5])}")
        
        if 'text_field' in by_type or 'text_field_candidate' in by_type:
            description_parts.append("Campos de texto detectados")
        
        if 'label' in by_type:
            labels = by_type['label']
            description_parts.append(f"Etiquetas: {', '.join(labels[:3])}")
        
        # Texto general
        if self.detected_text:
            lines = [l.strip() for l in self.detected_text.split('\n') if l.strip()]
            if lines:
                description_parts.append(f"Texto principal: {' | '.join(lines[:3])}")
        
        return " | ".join(description_parts) if description_parts else "Pantalla analizada."
    
    def get_stats(self) -> Dict:
        """Retorna estadísticas del monitor."""
        return {
            **self.stats,
            'running': self.running,
            'last_capture': self.last_screenshot_time.isoformat() if self.last_screenshot_time else None,
            'current_elements': len(self.current_elements),
            'ocr_enabled': self.enable_ocr,
            'ui_detection_enabled': self.enable_ui_detection
        }