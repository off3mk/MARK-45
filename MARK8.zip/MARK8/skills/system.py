"""
JARVIS v4.0 - System Skill
Control total del PC: programas, ventanas, mouse, teclado, procesos.
"""

import logging
import os
import subprocess
import sys
import platform
import time
from typing import Optional, Dict, Any

logger = logging.getLogger('JARVIS.Skills.System')

# Aplicaciones conocidas en Windows
APP_REGISTRY = {
    'chrome': ['chrome', 'google chrome', 'chromium'],
    'firefox': ['firefox', 'mozilla firefox'],
    'edge': ['msedge', 'microsoft edge', 'edge'],
    'vscode': ['code', 'visual studio code', 'vscode', 'vs code'],
    'notepad': ['notepad', 'bloc de notas'],
    'notepad++': ['notepad++'],
    'spotify': ['spotify'],
    'discord': ['discord'],
    'telegram': ['telegram'],
    'whatsapp': ['whatsapp'],
    'word': ['winword', 'word', 'microsoft word'],
    'excel': ['excel', 'microsoft excel'],
    'powerpoint': ['powerpnt', 'powerpoint'],
    'explorer': ['explorer', 'explorador', 'archivos'],
    'cmd': ['cmd', 'command prompt', 'símbolo del sistema'],
    'powershell': ['powershell'],
    'terminal': ['wt', 'windows terminal', 'terminal'],
    'calculator': ['calc', 'calculadora'],
    'paint': ['mspaint', 'paint'],
    'taskmgr': ['taskmgr', 'administrador de tareas'],
    'obs': ['obs', 'obs studio'],
    'steam': ['steam'],
    'vlc': ['vlc'],
}

APP_EXECUTABLES = {
    'chrome': 'chrome.exe',
    'firefox': 'firefox.exe',
    'edge': 'msedge.exe',
    'vscode': 'code.exe',
    'notepad': 'notepad.exe',
    'notepad++': 'notepad++.exe',
    'spotify': 'spotify.exe',
    'discord': 'discord.exe',
    'word': 'winword.exe',
    'excel': 'excel.exe',
    'powerpoint': 'powerpnt.exe',
    'explorer': 'explorer.exe',
    'cmd': 'cmd.exe',
    'powershell': 'powershell.exe',
    'terminal': 'wt.exe',
    'calculator': 'calc.exe',
    'paint': 'mspaint.exe',
    'taskmgr': 'taskmgr.exe',
    'obs': 'obs64.exe',
    'steam': 'steam.exe',
    'vlc': 'vlc.exe',
}


class SystemSkill:
    """Skill de control del sistema operativo."""

    def __init__(self, brain):
        self.brain = brain
        self._is_windows = platform.system() == 'Windows'
        self._pending_shutdown_action = None

        # Importar librerías opcionales
        self._pyautogui = None
        self._pygetwindow = None
        self._pynput = None
        self._psutil = None
        self._win32 = None

        self._init_libs()

    def _init_libs(self):
        """Inicializar librerías de control del sistema."""
        try:
            import pyautogui
            self._pyautogui = pyautogui
            pyautogui.FAILSAFE = True
        except ImportError:
            pass

        try:
            import pygetwindow as gw
            self._pygetwindow = gw
        except ImportError:
            pass

        try:
            from pynput import keyboard, mouse
            self._pynput_keyboard = keyboard
            self._pynput_mouse = mouse
            self._pynput = True
        except ImportError:
            pass

        try:
            import psutil
            self._psutil = psutil
        except ImportError:
            pass

        if self._is_windows:
            try:
                import win32api
                import win32gui
                import win32con
                self._win32api = win32api
                self._win32gui = win32gui
                self._win32con = win32con
                self._win32 = True
            except ImportError:
                pass

    def _normalize_app_name(self, app: str) -> str:
        """Normalizar nombre de aplicación."""
        app_lower = app.lower().strip()
        for canonical, aliases in APP_REGISTRY.items():
            if app_lower == canonical or app_lower in aliases:
                return canonical
        return app_lower

    def open_app(self, app: str = '') -> str:
        """Abrir aplicación."""
        if not app:
            return "Especifique qué aplicación desea abrir, Señor."

        canonical = self._normalize_app_name(app)
        logger.info(f"Abriendo aplicación: {canonical} (original: {app})")

        # Primero verificar si ya está abierta
        if self._is_app_running(canonical):
            self.focus_app(canonical)
            return f"'{app}' ya está en ejecución. Trayendo al frente, Señor."

        # Intentar abrir por ejecutable registrado
        if canonical in APP_EXECUTABLES:
            exe = APP_EXECUTABLES[canonical]
            if self._launch_app(exe):
                return f"'{app}' iniciado correctamente, Señor."

        # Intentar directamente con el nombre proporcionado
        if self._launch_app(app):
            return f"'{app}' iniciado, Señor."

        return f"No pude encontrar '{app}'. Verifique que esté instalado, Señor."

    def _launch_app(self, app_name: str) -> bool:
        """Lanzar aplicación."""
        if self._is_windows:
            try:
                subprocess.Popen([app_name], shell=True,
                                 creationflags=subprocess.CREATE_NO_WINDOW
                                 if hasattr(subprocess, 'CREATE_NO_WINDOW') else 0)
                time.sleep(1.5)
                return True
            except Exception:
                try:
                    os.startfile(app_name)
                    return True
                except Exception as e:
                    logger.debug(f"Error abriendo {app_name}: {e}")
        else:
            try:
                subprocess.Popen([app_name])
                return True
            except Exception as e:
                logger.debug(f"Error: {e}")
        return False

    def _is_app_running(self, app_name: str) -> bool:
        """Verificar si una aplicación está ejecutándose."""
        if not self._psutil:
            return False
        try:
            exe = APP_EXECUTABLES.get(app_name, app_name)
            exe_lower = exe.lower().replace('.exe', '')
            for proc in self._psutil.process_iter(['name']):
                pname = proc.info['name'].lower().replace('.exe', '')
                if exe_lower in pname or pname in exe_lower:
                    return True
        except Exception:
            pass
        return False

    def close_app(self, app: str = '') -> str:
        """Cerrar aplicación."""
        if not app:
            return "Especifique qué aplicación desea cerrar, Señor."

        canonical = self._normalize_app_name(app)
        exe = APP_EXECUTABLES.get(canonical, app)
        exe_lower = exe.lower()

        closed = False
        if self._psutil:
            try:
                for proc in self._psutil.process_iter(['name', 'pid']):
                    pname = proc.info['name'].lower()
                    if exe_lower in pname or proc.info['name'].lower() in exe_lower:
                        proc.terminate()
                        closed = True
                        logger.info(f"Proceso {proc.info['name']} terminado")
            except Exception as e:
                logger.error(f"Error cerrando {app}: {e}")

        if not closed and self._is_windows:
            result = subprocess.run(
                ['taskkill', '/F', '/IM', exe],
                capture_output=True, text=True
            )
            closed = result.returncode == 0

        return (f"'{app}' cerrado correctamente, Señor." if closed
                else f"No pude cerrar '{app}'. Verifique que esté en ejecución, Señor.")

    def focus_app(self, app: str = '') -> str:
        """Traer ventana al frente."""
        if not self._pygetwindow:
            return "Control de ventanas no disponible, Señor."

        canonical = self._normalize_app_name(app)
        try:
            windows = self._pygetwindow.getAllWindows()
            for win in windows:
                if canonical in win.title.lower() or app.lower() in win.title.lower():
                    win.activate()
                    return f"Ventana '{win.title}' traída al frente, Señor."
        except Exception as e:
            logger.debug(f"Error trayendo ventana: {e}")

        return f"No encontré ventana de '{app}', Señor."

    def minimize_window(self, app: str = 'active') -> str:
        """Minimizar ventana."""
        if not self._pygetwindow:
            # Fallback con pyautogui
            if self._pyautogui:
                import pyautogui
                pyautogui.hotkey('win', 'down')
                return "Ventana minimizada, Señor."
            return "Control de ventanas no disponible, Señor."

        try:
            if app == 'active' or not app:
                windows = self._pygetwindow.getActiveWindow()
                if windows:
                    windows.minimize()
                    return "Ventana activa minimizada, Señor."
            else:
                canonical = self._normalize_app_name(app)
                for win in self._pygetwindow.getAllWindows():
                    if canonical in win.title.lower() or app.lower() in win.title.lower():
                        win.minimize()
                        return f"Ventana '{win.title}' minimizada, Señor."
        except Exception as e:
            logger.debug(f"Error minimizando: {e}")

        # Fallback
        if self._pyautogui:
            self._pyautogui.hotkey('win', 'down')
            return "Ventana minimizada, Señor."

        return "No pude minimizar la ventana, Señor."

    def maximize_window(self, app: str = 'active') -> str:
        """Maximizar ventana."""
        if self._pyautogui:
            self._pyautogui.hotkey('win', 'up')
            return "Ventana maximizada, Señor."

        if self._pygetwindow:
            try:
                win = self._pygetwindow.getActiveWindow()
                if win:
                    win.maximize()
                    return "Ventana maximizada, Señor."
            except Exception:
                pass

        return "No pude maximizar la ventana, Señor."

    def screenshot(self) -> str:
        """Tomar captura de pantalla."""
        try:
            if self.brain and hasattr(self.brain, 'vision') and self.brain.vision:
                path = self.brain.vision.take_screenshot()
                if path:
                    return f"Captura guardada en: {path}, Señor."

            # Fallback directo
            import pyautogui
            from datetime import datetime
            timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
            workspace = os.path.join(os.path.dirname(os.path.dirname(__file__)), 'workspace')
            os.makedirs(workspace, exist_ok=True)
            path = os.path.join(workspace, f"screenshot_{timestamp}.png")
            pyautogui.screenshot(path)
            return f"Captura guardada: {path}, Señor."

        except Exception as e:
            logger.error(f"Error tomando screenshot: {e}")
            return f"No pude tomar la captura: {str(e)}, Señor."

    def type_text(self, text: str = '') -> str:
        """Escribir texto en la aplicación activa."""
        if not text:
            return "No se especificó texto para escribir, Señor."

        if self._pyautogui:
            try:
                time.sleep(0.3)
                self._pyautogui.typewrite(text, interval=0.05)
                return f"Texto escrito correctamente, Señor."
            except Exception as e:
                logger.error(f"Error escribiendo texto: {e}")

        return "Control de teclado no disponible, Señor."

    def press_hotkey(self, keys: str = '') -> str:
        """Presionar combinación de teclas."""
        if not keys:
            return "Especifique las teclas, Señor."

        if self._pyautogui:
            try:
                key_list = [k.strip() for k in keys.split('+')]
                self._pyautogui.hotkey(*key_list)
                return f"Teclas '{keys}' presionadas, Señor."
            except Exception as e:
                logger.error(f"Error en hotkey: {e}")

        return "Control de teclado no disponible, Señor."

    def run_command(self, command: str = '') -> str:
        """Ejecutar comando de shell."""
        if not command:
            return "No se especificó el comando, Señor."

        logger.info(f"Ejecutando comando: {command}")
        try:
            result = subprocess.run(
                command,
                shell=True,
                capture_output=True,
                text=True,
                timeout=30,
                encoding='utf-8',
                errors='replace'
            )
            output = result.stdout.strip() or result.stderr.strip()
            if output:
                # Limitar salida larga
                if len(output) > 500:
                    output = output[:500] + "...\n[Salida truncada]"
                return f"Resultado:\n{output}"
            return "Comando ejecutado sin salida, Señor."
        except subprocess.TimeoutExpired:
            return "El comando excedió el tiempo límite, Señor."
        except Exception as e:
            return f"Error ejecutando comando: {str(e)}, Señor."

    def system_info(self) -> str:
        """Obtener información del sistema."""
        try:
            info_lines = []
            info_lines.append(f"Sistema: {platform.system()} {platform.release()}")

            if self._psutil:
                cpu = self._psutil.cpu_percent(interval=1)
                mem = self._psutil.virtual_memory()
                disk = self._psutil.disk_usage('/')

                info_lines.append(f"CPU: {cpu:.1f}% ({self._psutil.cpu_count()} núcleos)")
                info_lines.append(f"RAM: {mem.percent:.1f}% ({mem.used // (1024**3):.1f}GB / {mem.total // (1024**3):.1f}GB)")
                info_lines.append(f"Disco: {disk.percent:.1f}% ({disk.free // (1024**3):.1f}GB libres)")

                # Procesos activos
                procs = len(list(self._psutil.process_iter()))
                info_lines.append(f"Procesos activos: {procs}")

            return "Información del sistema:\n" + "\n".join(info_lines) + "\n\nA sus órdenes, Señor."
        except Exception as e:
            return f"Error obteniendo información: {str(e)}"

    def list_processes(self, filter_name: str = '') -> str:
        """Listar procesos activos."""
        if not self._psutil:
            return "psutil no disponible, Señor."

        try:
            processes = []
            for proc in self._psutil.process_iter(['name', 'pid', 'cpu_percent', 'memory_percent']):
                pinfo = proc.info
                if filter_name and filter_name.lower() not in pinfo['name'].lower():
                    continue
                processes.append(pinfo)

            processes.sort(key=lambda x: x.get('cpu_percent', 0), reverse=True)
            top_procs = processes[:10]

            lines = ["Top procesos por CPU:", ""]
            for p in top_procs:
                lines.append(
                    f"  {p['name'][:30]:<30} PID:{p['pid']:<6} "
                    f"CPU:{p.get('cpu_percent', 0):.1f}% "
                    f"RAM:{p.get('memory_percent', 0):.1f}%"
                )

            return "\n".join(lines)
        except Exception as e:
            return f"Error listando procesos: {str(e)}"

    def kill_process(self, process_name: str = '') -> str:
        """Terminar proceso por nombre."""
        if not process_name:
            return "Especifique el nombre del proceso, Señor."

        if not self._psutil:
            return "psutil no disponible, Señor."

        killed = []
        try:
            for proc in self._psutil.process_iter(['name', 'pid']):
                if process_name.lower() in proc.info['name'].lower():
                    proc.terminate()
                    killed.append(f"{proc.info['name']} (PID: {proc.info['pid']})")
        except Exception as e:
            logger.error(f"Error terminando proceso: {e}")

        if killed:
            return f"Procesos terminados: {', '.join(killed)}, Señor."
        return f"No se encontraron procesos con nombre '{process_name}', Señor."

    def shutdown(self) -> str:
        """Apagar el sistema."""
        if self._is_windows:
            subprocess.run(['shutdown', '/s', '/t', '60'], shell=True)
            return "Sistema programado para apagarse en 60 segundos, Señor."
        else:
            subprocess.run(['shutdown', '-h', '+1'])
            return "Sistema programado para apagarse en 1 minuto, Señor."

    def restart(self) -> str:
        """Reiniciar el sistema."""
        if self._is_windows:
            subprocess.run(['shutdown', '/r', '/t', '60'], shell=True)
            return "Sistema programado para reiniciarse en 60 segundos, Señor."
        else:
            subprocess.run(['shutdown', '-r', '+1'])
            return "Sistema programado para reiniciarse en 1 minuto, Señor."

    def cancel_shutdown(self) -> str:
        """Cancelar apagado programado."""
        if self._is_windows:
            subprocess.run(['shutdown', '/a'], shell=True)
            return "Apagado cancelado, Señor."
        else:
            subprocess.run(['shutdown', '-c'])
            return "Apagado cancelado, Señor."

    def automation_mode(self, mode: str = '') -> str:
        """Ejecutar modo de automatización predefinido."""
        if self.brain and self.brain.planner:
            plan = self.brain.planner.create_plan(f"modo {mode}")
            if plan:
                return self.brain.planner.execute_plan(plan)
        return f"Iniciando modo '{mode}', Señor."

    def cancel(self) -> str:
        """Cancelar operación pendiente."""
        return "Operación cancelada, Señor."
