"""
MARK 8 — Cognitive Core Loop
Sistema autónomo cognitivo continuo.

Fases: Percepción → Análisis → Decisión → Ejecución → Memoria

Creador: Ali (Sidi3Ali)
Sistema: MARK 8
"""

import logging
import threading
import time
from typing import Optional, Dict, Any, List, Callable
from datetime import datetime
from dataclasses import dataclass, field

logger = logging.getLogger('MARK8.CognitiveLoop')

# ── Configuración del loop ────────────────────────────────────────────────────
LOOP_INTERVAL_FAST = 2.0   # Percepción básica: cada 2 segundos
LOOP_INTERVAL_SLOW = 15.0  # Análisis profundo: cada 15 segundos
LOOP_INTERVAL_HOURLY = 3600  # Resumen horario


@dataclass
class CognitiveState:
    """Estado cognitivo actual del sistema MARK 8."""
    # Percepción
    active_window: str = ''
    active_app: str = ''
    active_document: str = ''
    browser_url: str = ''
    user_activity: str = 'unknown'   # idle, typing, browsing, coding, watching, gaming
    media_playing: bool = False
    media_app: str = ''

    # Sistema
    cpu_percent: float = 0.0
    ram_percent: float = 0.0
    battery_percent: Optional[float] = None
    uptime_seconds: float = 0.0

    # Análisis
    detected_mode: str = 'unknown'   # work, study, leisure, creative, communication
    user_stress_level: str = 'low'   # low, medium, high
    assistance_opportunity: Optional[str] = None

    # Tiempo
    timestamp: datetime = field(default_factory=datetime.now)
    session_duration_minutes: float = 0.0


class PerceptionPhase:
    """Fase 1: Percepción del entorno."""

    def __init__(self):
        self._win32_ok = False
        self._try_init()

    def _try_init(self):
        try:
            import win32gui
            self._win32_ok = True
        except ImportError:
            pass

    def get_active_window(self) -> str:
        """Obtener título de la ventana activa."""
        if self._win32_ok:
            try:
                import win32gui
                hwnd = win32gui.GetForegroundWindow()
                return win32gui.GetWindowText(hwnd) or ''
            except Exception:
                pass
        return ''

    def get_active_app(self) -> str:
        """Obtener nombre del proceso activo."""
        try:
            import psutil
            if self._win32_ok:
                import win32gui, win32process
                hwnd = win32gui.GetForegroundWindow()
                _, pid = win32process.GetWindowThreadProcessId(hwnd)
                proc = psutil.Process(pid)
                return proc.name().lower().replace('.exe', '')
            # Fallback: proceso más reciente con ventana
            for proc in psutil.process_iter(['name', 'status']):
                if proc.info['status'] == 'running':
                    name = proc.info['name'].lower().replace('.exe', '')
                    if name not in {'system', 'idle', 'svchost', 'dwm', 'winlogon'}:
                        return name
        except Exception:
            pass
        return ''

    def get_active_document(self, window_title: str) -> str:
        """Extraer nombre de documento del título de ventana."""
        separators = [' - ', ' — ', ' | ', ': ']
        for sep in separators:
            if sep in window_title:
                parts = window_title.split(sep)
                return parts[0].strip()
        return ''

    def detect_user_activity(self, app: str, window: str) -> str:
        """Inferir actividad del usuario basándose en la app activa."""
        app_lower = app.lower()
        win_lower = window.lower()

        coding_apps = {'code', 'vscode', 'pycharm', 'intellij', 'sublime', 'vim', 'nvim',
                       'notepad++', 'atom', 'cursor', 'windsurf'}
        browsing_apps = {'chrome', 'firefox', 'edge', 'opera', 'brave', 'safari'}
        office_apps = {'word', 'winword', 'excel', 'powerpoint', 'outlook', 'libreoffice',
                       'soffice', 'onedrive', 'onenote'}
        media_apps = {'vlc', 'mpv', 'mpc-hc', 'potplayer', 'netflix', 'prime video',
                      'spotify', 'itunes', 'musicbee', 'foobar2000'}
        gaming_apps = {'steam', 'epicgames', 'origin', 'battlenet', 'gog'}
        comm_apps = {'teams', 'slack', 'discord', 'zoom', 'skype', 'telegram', 'whatsapp'}
        design_apps = {'figma', 'photoshop', 'illustrator', 'canva', 'gimp', 'blender',
                       'inkscape', 'premiere', 'aftereffects', 'davinci'}

        for a in coding_apps:
            if a in app_lower:
                return 'coding'
        for a in browsing_apps:
            if a in app_lower:
                # Sub-clasificar browsing
                if any(k in win_lower for k in ['youtube', 'twitch', 'netflix']):
                    return 'watching'
                if any(k in win_lower for k in ['github', 'stackoverflow', 'docs', 'mdn']):
                    return 'coding'
                return 'browsing'
        for a in office_apps:
            if a in app_lower:
                return 'writing'
        for a in media_apps:
            if a in app_lower:
                return 'watching'
        for a in gaming_apps:
            if a in app_lower:
                return 'gaming'
        for a in comm_apps:
            if a in app_lower:
                return 'communication'
        for a in design_apps:
            if a in app_lower:
                return 'designing'

        return 'idle'

    def is_media_playing(self) -> tuple:
        """Detectar si hay audio/video reproduciéndose."""
        try:
            import psutil
            media_procs = {'spotify', 'vlc', 'mpv', 'mpc-hc', 'potplayer',
                           'winamp', 'foobar2000', 'musicbee', 'itunes',
                           'chrome', 'firefox', 'edge'}
            for proc in psutil.process_iter(['name']):
                name = proc.info['name'].lower().replace('.exe', '')
                if name in media_procs:
                    return True, name
        except Exception:
            pass
        return False, ''

    def get_system_stats(self) -> Dict[str, float]:
        """Obtener métricas del sistema."""
        try:
            import psutil
            cpu = psutil.cpu_percent(interval=None)
            ram = psutil.virtual_memory().percent
            battery = None
            try:
                bat = psutil.sensors_battery()
                battery = bat.percent if bat else None
            except Exception:
                pass
            boot = psutil.boot_time()
            uptime = time.time() - boot
            return {'cpu': cpu, 'ram': ram, 'battery': battery, 'uptime': uptime}
        except Exception:
            return {'cpu': 0.0, 'ram': 0.0, 'battery': None, 'uptime': 0.0}

    def perceive(self) -> CognitiveState:
        """Ejecutar percepción completa y retornar estado."""
        state = CognitiveState()
        state.timestamp = datetime.now()

        state.active_window = self.get_active_window()
        state.active_app = self.get_active_app()
        state.active_document = self.get_active_document(state.active_window)
        state.user_activity = self.detect_user_activity(state.active_app, state.active_window)
        state.media_playing, state.media_app = self.is_media_playing()

        stats = self.get_system_stats()
        state.cpu_percent = stats['cpu']
        state.ram_percent = stats['ram']
        state.battery_percent = stats['battery']
        state.uptime_seconds = stats['uptime']

        return state


class AnalysisPhase:
    """Fase 2: Análisis del contexto percibido."""

    # Mapeo actividad → modo de trabajo
    ACTIVITY_TO_MODE = {
        'coding': 'work',
        'writing': 'work',
        'designing': 'creative',
        'browsing': 'study',
        'watching': 'leisure',
        'gaming': 'leisure',
        'communication': 'communication',
        'idle': 'unknown',
    }

    def analyze(self, state: CognitiveState,
                 prev_state: Optional[CognitiveState]) -> CognitiveState:
        """Analizar el estado percibido y enriquecerlo."""

        # Detectar modo
        state.detected_mode = self.ACTIVITY_TO_MODE.get(state.user_activity, 'unknown')

        # Detectar nivel de estrés (heurística: alta CPU + trabajo intenso)
        if state.cpu_percent > 80 and state.ram_percent > 75:
            state.user_stress_level = 'high'
        elif state.cpu_percent > 60 or state.ram_percent > 65:
            state.user_stress_level = 'medium'
        else:
            state.user_stress_level = 'low'

        # Detectar oportunidades de asistencia
        state.assistance_opportunity = self._detect_opportunity(state, prev_state)

        return state

    def _detect_opportunity(self, state: CognitiveState,
                              prev: Optional[CognitiveState]) -> Optional[str]:
        """Detectar si hay una oportunidad de asistir al usuario."""

        # Cambio de modo detectado
        if prev and prev.detected_mode != state.detected_mode:
            if state.detected_mode == 'work':
                return 'mode_switch_to_work'
            if state.detected_mode == 'leisure':
                return 'mode_switch_to_leisure'
            if state.detected_mode == 'creative':
                return 'mode_switch_to_creative'

        # CPU muy alta
        if state.cpu_percent > 85 and (not prev or prev.cpu_percent <= 85):
            return 'high_cpu'

        # RAM crítica
        if state.ram_percent > 90 and (not prev or prev.ram_percent <= 90):
            return 'critical_ram'

        # Batería baja
        if (state.battery_percent is not None and
                state.battery_percent < 15 and
                (not prev or prev.battery_percent is None or prev.battery_percent >= 15)):
            return 'low_battery'

        # Actividad de codificación detectada
        if state.user_activity == 'coding' and (not prev or prev.user_activity != 'coding'):
            return 'coding_started'

        # Comunicación activa
        if state.user_activity == 'communication' and (not prev or prev.user_activity != 'communication'):
            return 'communication_started'

        return None


class DecisionPhase:
    """Fase 3: Toma de decisiones autónoma."""

    def __init__(self):
        # Throttle: no repetir la misma acción en cooldown
        self._cooldowns: Dict[str, float] = {}
        self._default_cooldown = 1800  # 30 min entre notificaciones del mismo tipo

    def decide(self, state: CognitiveState) -> Optional[Dict]:
        """Decidir si actuar y qué acción tomar."""
        opp = state.assistance_opportunity
        if not opp:
            return None

        key = f"{opp}_{state.detected_mode}"
        now = time.time()
        if now - self._cooldowns.get(key, 0) < self._default_cooldown:
            return None  # En cooldown

        action = self._build_action(opp, state)
        if action:
            self._cooldowns[key] = now
        return action

    def _build_action(self, opportunity: str, state: CognitiveState) -> Optional[Dict]:
        """Construir descripción de acción basada en la oportunidad."""
        actions = {
            'mode_switch_to_work': {
                'type': 'notify',
                'message': f"Modo trabajo detectado. Activando configuración de enfoque.",
                'sub': 'focus_mode',
            },
            'mode_switch_to_leisure': {
                'type': 'notify',
                'message': "Modo ocio detectado. ¿Quieres que ponga algo de música?",
                'sub': 'suggest_music',
            },
            'mode_switch_to_creative': {
                'type': 'notify',
                'message': "Modo creativo detectado. Optimizando entorno.",
                'sub': 'creative_mode',
            },
            'high_cpu': {
                'type': 'alert',
                'message': f"CPU al {state.cpu_percent:.0f}%. ¿Analizo los procesos activos?",
                'sub': 'cpu_alert',
            },
            'critical_ram': {
                'type': 'alert',
                'message': f"RAM al {state.ram_percent:.0f}%. Memoria crítica.",
                'sub': 'ram_alert',
            },
            'low_battery': {
                'type': 'alert',
                'message': f"Batería al {state.battery_percent:.0f}%. Conecta el cargador, Ali.",
                'sub': 'battery_alert',
            },
            'coding_started': {
                'type': 'assist',
                'message': f"Codificación detectada en {state.active_app}. Aquí si me necesitas.",
                'sub': 'coding_assist',
            },
            'communication_started': {
                'type': 'info',
                'message': f"Sesión de comunicación en {state.active_app}.",
                'sub': 'comm_info',
            },
        }
        return actions.get(opportunity)


class ExecutionPhase:
    """Fase 4: Ejecución de acciones decididas."""

    def __init__(self, brain=None):
        self.brain = brain
        self._executed: List[Dict] = []

    def execute(self, action: Optional[Dict], state: CognitiveState):
        """Ejecutar una acción autónoma."""
        if not action:
            return

        atype = action.get('type', 'notify')
        message = action.get('message', '')
        sub = action.get('sub', '')

        logger.info(f"[MARK8/EXECUTE] {atype.upper()}: {message}")

        # Notificar al usuario
        if self.brain:
            if self.brain.voice and message:
                try:
                    self.brain.voice.speak(message, priority=False)
                except Exception:
                    pass
            if self.brain._ui_callback and message:
                try:
                    self.brain._ui_callback('autonomous_notification', {
                        'type': atype,
                        'sub': sub,
                        'message': message,
                        'state': state,
                    })
                except Exception:
                    pass

        # Acciones sub-específicas
        if sub == 'focus_mode' and self.brain:
            self._activate_focus_mode()
        elif sub == 'suggest_music' and self.brain:
            self._suggest_music(state)

        self._executed.append({'action': action, 'time': time.time()})

    def _activate_focus_mode(self):
        """Activar modo enfoque: silenciar notificaciones, ajustar audio."""
        try:
            # Reducir volumen suavemente
            if self.brain and self.brain.skill_manager:
                self.brain.skill_manager.execute('media', 'set_volume', {'level': 25})
        except Exception:
            pass

    def _suggest_music(self, state: CognitiveState):
        """Sugerir música apropiada para el contexto."""
        try:
            spotify = getattr(self.brain, '_spotify', None)
            if spotify and spotify.is_available():
                rec = spotify.get_smart_recommendation()
                if self.brain.voice:
                    self.brain.voice.speak(rec, priority=False)
        except Exception:
            pass


class MemoryPhase:
    """Fase 5: Almacenar contexto en memoria cognitiva."""

    def __init__(self, brain=None):
        self.brain = brain
        self._context_history: List[CognitiveState] = []
        self._max_history = 500

    def memorize(self, state: CognitiveState):
        """Guardar estado en memoria."""
        self._context_history.append(state)
        if len(self._context_history) > self._max_history:
            self._context_history = self._context_history[-self._max_history:]

        # Guardar en memoria cognitiva persistente
        if self.brain and self.brain.cognitive_memory:
            try:
                self.brain.cognitive_memory.log_action(
                    action=state.user_activity,
                    skill='cognitive_loop',
                    params={
                        'app': state.active_app,
                        'mode': state.detected_mode,
                        'window': state.active_window[:100],
                    },
                    context=state.detected_mode,
                )
            except Exception:
                pass

    def get_history(self, n: int = 20) -> List[CognitiveState]:
        return self._context_history[-n:]

    def get_mode_duration(self, mode: str) -> float:
        """Minutos en un modo concreto en la sesión actual."""
        count = sum(1 for s in self._context_history if s.detected_mode == mode)
        return count * (LOOP_INTERVAL_FAST / 60.0)


class CognitiveLoop:
    """
    MARK 8 — Cognitive Core Loop
    Ejecuta continuamente las 5 fases cognitivas en thread independiente.
    Es el corazón autónomo del sistema.
    """

    def __init__(self, brain=None):
        self.brain = brain
        self._running = False
        self._thread: Optional[threading.Thread] = None
        self._paused = False

        # Fases
        self._perception = PerceptionPhase()
        self._analysis = AnalysisPhase()
        self._decision = DecisionPhase()
        self._execution = ExecutionPhase(brain=brain)
        self._memory = MemoryPhase(brain=brain)

        # Estado
        self.current_state: Optional[CognitiveState] = None
        self._prev_state: Optional[CognitiveState] = None
        self._session_start = time.time()
        self._cycle_count = 0

        # Callbacks externos
        self._state_callbacks: List[Callable] = []

    def start(self):
        """Iniciar el cognitive loop en background."""
        self._running = True
        self._thread = threading.Thread(
            target=self._loop,
            name='MARK8-CognitiveLoop',
            daemon=True
        )
        self._thread.start()
        logger.info("MARK 8 Cognitive Loop iniciado.")

    def stop(self):
        """Detener el loop."""
        self._running = False
        if self._thread:
            self._thread.join(timeout=5)
        logger.info("MARK 8 Cognitive Loop detenido.")

    def pause(self):
        self._paused = True

    def resume(self):
        self._paused = False

    def _loop(self):
        """Bucle principal cognitivo."""
        last_slow = 0.0
        last_hourly = 0.0

        while self._running:
            try:
                if self._paused:
                    time.sleep(1)
                    continue

                now = time.time()
                self._cycle_count += 1

                # ── Fase 1: Percepción (siempre) ─────────────────────────
                state = self._perception.perceive()
                state.session_duration_minutes = (now - self._session_start) / 60.0

                # ── Fase 2: Análisis ─────────────────────────────────────
                state = self._analysis.analyze(state, self._prev_state)

                # ── Fase 3: Decisión ─────────────────────────────────────
                action = self._decision.decide(state)

                # ── Fase 4: Ejecución ────────────────────────────────────
                if action:
                    self._execution.execute(action, state)

                # ── Fase 5: Memoria ──────────────────────────────────────
                self._memory.memorize(state)

                # Actualizar estado actual
                self._prev_state = self.current_state
                self.current_state = state

                # Notificar a callbacks externos
                for cb in self._state_callbacks:
                    try:
                        cb(state)
                    except Exception:
                        pass

                # ── Análisis profundo cada 15s ───────────────────────────
                if now - last_slow >= LOOP_INTERVAL_SLOW:
                    last_slow = now
                    self._slow_analysis(state)

                # ── Resumen horario ──────────────────────────────────────
                if now - last_hourly >= LOOP_INTERVAL_HOURLY:
                    last_hourly = now
                    self._hourly_summary(state)

            except Exception as e:
                logger.debug(f"Error en cognitive loop: {e}")

            time.sleep(LOOP_INTERVAL_FAST)

    def _slow_analysis(self, state: CognitiveState):
        """Análisis profundo cada 15 segundos."""
        try:
            history = self._memory.get_history(20)
            if not history:
                return

            # Calcular modo dominante
            from collections import Counter
            modes = [s.detected_mode for s in history if s.detected_mode != 'unknown']
            if modes:
                dominant = Counter(modes).most_common(1)[0][0]
                logger.debug(f"Modo dominante (últimos 20 ciclos): {dominant}")

            # Advertir si CPU sigue alta
            high_cpu_count = sum(1 for s in history if s.cpu_percent > 80)
            if high_cpu_count > 10 and self.brain and self.brain.voice:
                pass  # Ya se alertó en la fase de decisión

        except Exception as e:
            logger.debug(f"Error en slow analysis: {e}")

    def _hourly_summary(self, state: CognitiveState):
        """Generar resumen horario si hay actividad."""
        try:
            hour = datetime.now().hour
            if hour not in [9, 12, 17, 20, 22]:
                return

            work_mins = self._memory.get_mode_duration('work')
            if work_mins < 10:
                return

            msg = (f"Resumen: {work_mins:.0f} minutos en modo trabajo esta sesión. "
                   f"CPU promedio estable.")

            if self.brain and self.brain.voice:
                self.brain.voice.speak(msg, priority=False)

        except Exception as e:
            logger.debug(f"Error en hourly summary: {e}")

    def add_state_callback(self, callback: Callable):
        """Registrar callback para recibir actualizaciones de estado."""
        self._state_callbacks.append(callback)

    def get_current_state(self) -> Optional[CognitiveState]:
        return self.current_state

    def get_status(self) -> Dict:
        s = self.current_state
        return {
            'running': self._running,
            'paused': self._paused,
            'cycles': self._cycle_count,
            'session_minutes': (time.time() - self._session_start) / 60.0,
            'current_app': s.active_app if s else '',
            'current_mode': s.detected_mode if s else '',
            'activity': s.user_activity if s else '',
            'cpu': s.cpu_percent if s else 0.0,
            'ram': s.ram_percent if s else 0.0,
        }
