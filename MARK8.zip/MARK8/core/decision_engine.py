"""
MARK 8 — Autonomous Decision Engine
Motor de toma de decisiones autónoma basado en contexto.

Creador: Ali (Sidi3Ali)
Sistema: MARK 8
"""

import logging
import time
import json
import os
import threading
from typing import Optional, Dict, List, Any, Callable
from datetime import datetime
from dataclasses import dataclass, field

logger = logging.getLogger('MARK8.DecisionEngine')

DECISIONS_LOG = os.path.join(
    os.path.dirname(os.path.dirname(__file__)), 'memory', 'decisions.json'
)


@dataclass
class Decision:
    """Una decisión autónoma tomada por MARK 8."""
    decision_id: str
    trigger: str
    condition: str
    action_type: str          # notify, execute, suggest, adjust
    action_payload: Dict
    confidence: float         # 0.0 - 1.0
    timestamp: str = field(default_factory=lambda: datetime.now().isoformat())
    executed: bool = False
    outcome: str = ''


class DecisionRule:
    """Regla de decisión: Condición → Acción."""

    def __init__(self, rule_id: str, name: str,
                 condition: Callable, action: Dict,
                 priority: int = 5, cooldown: float = 1800):
        self.rule_id = rule_id
        self.name = name
        self.condition = condition
        self.action = action
        self.priority = priority           # 1 (máx) - 10 (mín)
        self.cooldown = cooldown           # segundos entre activaciones
        self._last_triggered: float = 0.0
        self.enabled = True

    def evaluate(self, context: Dict) -> bool:
        """Evaluar si la condición se cumple."""
        if not self.enabled:
            return False
        now = time.time()
        if now - self._last_triggered < self.cooldown:
            return False
        try:
            return self.condition(context)
        except Exception:
            return False

    def trigger(self) -> Dict:
        self._last_triggered = time.time()
        return self.action.copy()


class RuleEngine:
    """Motor de reglas para toma de decisiones."""

    def __init__(self):
        self._rules: List[DecisionRule] = []
        self._build_default_rules()

    def _build_default_rules(self):
        """Construir reglas predeterminadas del sistema."""

        # ── Reglas de modo de trabajo ────────────────────────────────────────
        self._rules.append(DecisionRule(
            rule_id='work_mode_detected',
            name='Modo trabajo activado',
            condition=lambda ctx: (
                ctx.get('user_activity') in {'coding', 'writing', 'spreadsheet'} and
                ctx.get('detected_mode') == 'work'
            ),
            action={
                'type': 'suggest',
                'message': 'Modo trabajo detectado. ¿Activo el modo enfoque?',
                'sub': 'focus_mode',
                'auto': False,
            },
            priority=3,
            cooldown=3600,
        ))

        self._rules.append(DecisionRule(
            rule_id='long_work_session',
            name='Sesión de trabajo larga',
            condition=lambda ctx: (
                ctx.get('user_activity') in {'coding', 'writing'} and
                ctx.get('activity_duration_minutes', 0) > 90
            ),
            action={
                'type': 'notify',
                'message': 'Llevas más de 90 minutos trabajando. Considera un descanso, Ali.',
                'sub': 'break_reminder',
                'auto': False,
            },
            priority=4,
            cooldown=5400,  # 90 min
        ))

        # ── Reglas de recursos del sistema ──────────────────────────────────
        self._rules.append(DecisionRule(
            rule_id='high_cpu_alert',
            name='CPU elevada',
            condition=lambda ctx: ctx.get('cpu_percent', 0) > 85,
            action={
                'type': 'alert',
                'message': 'CPU al {cpu_percent:.0f}%. ¿Analizo los procesos activos?',
                'sub': 'cpu_alert',
                'auto': False,
            },
            priority=2,
            cooldown=300,
        ))

        self._rules.append(DecisionRule(
            rule_id='critical_ram',
            name='RAM crítica',
            condition=lambda ctx: ctx.get('ram_percent', 0) > 90,
            action={
                'type': 'alert',
                'message': 'Memoria al {ram_percent:.0f}%. Sistema en riesgo de ralentizarse.',
                'sub': 'ram_alert',
                'auto': False,
            },
            priority=2,
            cooldown=300,
        ))

        self._rules.append(DecisionRule(
            rule_id='low_battery',
            name='Batería baja',
            condition=lambda ctx: (
                ctx.get('battery_percent') is not None and
                ctx.get('battery_percent', 100) < 15 and
                not ctx.get('battery_charging', False)
            ),
            action={
                'type': 'alert',
                'message': 'Batería al {battery_percent:.0f}%. Conecta el cargador.',
                'sub': 'battery_alert',
                'auto': False,
            },
            priority=1,
            cooldown=600,
        ))

        # ── Reglas de ocio / música ──────────────────────────────────────────
        self._rules.append(DecisionRule(
            rule_id='leisure_music_suggest',
            name='Sugerir música en ocio',
            condition=lambda ctx: (
                ctx.get('detected_mode') == 'leisure' and
                not ctx.get('media_playing', False)
            ),
            action={
                'type': 'suggest',
                'message': 'Modo ocio detectado. ¿Pongo algo de música?',
                'sub': 'play_music',
                'auto': False,
            },
            priority=6,
            cooldown=7200,
        ))

        # ── Reglas de codificación ───────────────────────────────────────────
        self._rules.append(DecisionRule(
            rule_id='coding_assist_offer',
            name='Ofrecer asistencia de código',
            condition=lambda ctx: (
                ctx.get('user_activity') == 'coding' and
                ctx.get('active_app', '') in {'code', 'vscode', 'pycharm', 'cursor'}
            ),
            action={
                'type': 'info',
                'message': 'Codificando en {active_app}. Disponible para ayudar con código, errores o documentación.',
                'sub': 'coding_available',
                'auto': False,
            },
            priority=7,
            cooldown=3600,
        ))

        # ── Reglas de comunicación ───────────────────────────────────────────
        self._rules.append(DecisionRule(
            rule_id='meeting_detected',
            name='Reunión/meeting detectado',
            condition=lambda ctx: (
                ctx.get('user_activity') == 'communication' and
                ctx.get('active_app', '') in {'teams', 'zoom', 'meet'}
            ),
            action={
                'type': 'info',
                'message': 'Sesión de {active_app} activa. Silenciando notificaciones proactivas.',
                'sub': 'meeting_mode',
                'auto': True,
            },
            priority=3,
            cooldown=3600,
        ))

    def evaluate_all(self, context: Dict) -> List[Decision]:
        """Evaluar todas las reglas y retornar las que se activan."""
        triggered = []
        for rule in sorted(self._rules, key=lambda r: r.priority):
            if rule.evaluate(context):
                action = rule.trigger()
                # Rellenar variables en el mensaje
                msg = action.get('message', '')
                try:
                    msg = msg.format(**context)
                    action['message'] = msg
                except Exception:
                    pass
                d = Decision(
                    decision_id=f"{rule.rule_id}_{int(time.time())}",
                    trigger=rule.rule_id,
                    condition=rule.name,
                    action_type=action.get('type', 'notify'),
                    action_payload=action,
                    confidence=0.85,
                )
                triggered.append(d)

        return triggered

    def add_rule(self, rule: DecisionRule):
        """Agregar una regla personalizada."""
        self._rules.append(rule)

    def disable_rule(self, rule_id: str):
        for r in self._rules:
            if r.rule_id == rule_id:
                r.enabled = False

    def enable_rule(self, rule_id: str):
        for r in self._rules:
            if r.rule_id == rule_id:
                r.enabled = True


class AutonomousDecisionEngine:
    """
    MARK 8 — Motor de Decisiones Autónomas.
    Evalúa contexto en tiempo real y decide si actuar sin intervención del usuario.
    Todas las acciones son notificaciones o sugerencias — el usuario siempre tiene control.
    """

    def __init__(self, brain=None):
        self.brain = brain
        self._rule_engine = RuleEngine()
        self._decisions_log: List[Decision] = []
        self._lock = threading.Lock()
        self._enabled = True

        # Modo reunión: silenciar notificaciones proactivas
        self._meeting_mode = False
        self._meeting_mode_until: float = 0.0

    def process_context(self, context_dict: Dict) -> List[Decision]:
        """
        Evaluar contexto y ejecutar decisiones apropiadas.
        Retorna lista de decisiones tomadas.
        """
        if not self._enabled:
            return []

        # En modo reunión, no interrumpir
        if self._meeting_mode and time.time() < self._meeting_mode_until:
            return []

        decisions = self._rule_engine.evaluate_all(context_dict)

        for decision in decisions:
            self._execute_decision(decision)
            with self._lock:
                self._decisions_log.append(decision)
                if len(self._decisions_log) > 200:
                    self._decisions_log = self._decisions_log[-200:]

        return decisions

    def _execute_decision(self, decision: Decision):
        """Ejecutar una decisión — notificar al usuario."""
        payload = decision.action_payload
        message = payload.get('message', '')
        sub = payload.get('sub', '')
        auto = payload.get('auto', False)

        logger.info(f"[MARK8/DECISION] {decision.condition}: {message}")

        if not self.brain:
            return

        # Activar acciones automáticas
        if auto and sub == 'meeting_mode':
            self._activate_meeting_mode()
            return

        # Notificar al usuario
        if message:
            if self.brain.voice:
                try:
                    self.brain.voice.speak(message, priority=False)
                except Exception:
                    pass

            if self.brain._ui_callback:
                try:
                    self.brain._ui_callback('decision_notification', {
                        'decision_id': decision.decision_id,
                        'type': decision.action_type,
                        'sub': sub,
                        'message': message,
                        'auto': auto,
                    })
                except Exception:
                    pass

        decision.executed = True

    def _activate_meeting_mode(self):
        """Silenciar notificaciones durante 2 horas."""
        self._meeting_mode = True
        self._meeting_mode_until = time.time() + 7200
        logger.info("Modo reunión activado — notificaciones silenciadas 2h.")

    def add_custom_rule(self, rule_id: str, name: str,
                         condition: Callable, action: Dict,
                         priority: int = 5, cooldown: float = 1800):
        """Añadir regla personalizada de decisión."""
        rule = DecisionRule(rule_id, name, condition, action, priority, cooldown)
        self._rule_engine.add_rule(rule)

    def disable_rule(self, rule_id: str):
        self._rule_engine.disable_rule(rule_id)

    def enable(self):
        self._enabled = True

    def disable(self):
        self._enabled = False

    def get_recent_decisions(self, n: int = 10) -> List[Dict]:
        with self._lock:
            return [
                {
                    'id': d.decision_id,
                    'trigger': d.trigger,
                    'message': d.action_payload.get('message', ''),
                    'time': d.timestamp,
                    'executed': d.executed,
                }
                for d in self._decisions_log[-n:]
            ]

    def get_status(self) -> Dict:
        return {
            'enabled': self._enabled,
            'meeting_mode': self._meeting_mode,
            'rules_count': len(self._rule_engine._rules),
            'decisions_made': len(self._decisions_log),
        }
