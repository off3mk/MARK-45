"""
MARK 8 — Context Awareness System
Rastreo continuo del contexto del usuario en tiempo real.

Creador: Ali (Sidi3Ali)
Sistema: MARK 8
"""

import logging
import threading
import time
from dataclasses import dataclass, field
from typing import Optional, Dict, List, Any
from datetime import datetime

logger = logging.getLogger('MARK8.ContextAwareness')


@dataclass
class CurrentContext:
    """Objeto de contexto completo del entorno actual."""

    # Ventana / App
    active_window: str = ''
    active_app: str = ''
    active_document: str = ''

    # Navegación web
    active_browser: str = ''
    active_browser_url: str = ''
    active_browser_title: str = ''

    # Actividad del usuario
    user_activity: str = 'idle'          # idle, coding, writing, browsing, watching, gaming, communicating, designing
    detected_mode: str = 'unknown'       # work, study, leisure, creative, communication
    activity_duration_minutes: float = 0.0

    # Media
    media_playing: bool = False
    media_app: str = ''
    media_track: str = ''

    # Sistema
    cpu_percent: float = 0.0
    ram_percent: float = 0.0
    battery_percent: Optional[float] = None
    battery_charging: bool = False
    screen_locked: bool = False

    # Hora
    timestamp: datetime = field(default_factory=datetime.now)
    hour_of_day: int = field(default_factory=lambda: datetime.now().hour)
    day_of_week: int = field(default_factory=lambda: datetime.now().weekday())
    time_of_day: str = ''               # morning, afternoon, evening, night

    # Historial reciente
    recent_apps: List[str] = field(default_factory=list)
    recent_windows: List[str] = field(default_factory=list)

    def to_dict(self) -> Dict:
        return {
            'active_window': self.active_window,
            'active_app': self.active_app,
            'active_document': self.active_document,
            'browser_url': self.active_browser_url,
            'user_activity': self.user_activity,
            'detected_mode': self.detected_mode,
            'media_playing': self.media_playing,
            'media_app': self.media_app,
            'cpu': self.cpu_percent,
            'ram': self.ram_percent,
            'battery': self.battery_percent,
            'time_of_day': self.time_of_day,
            'timestamp': self.timestamp.isoformat(),
        }

    def describe(self) -> str:
        """Descripción en lenguaje natural del contexto actual."""
        parts = []
        if self.active_app:
            parts.append(f"App: {self.active_app}")
        if self.active_document:
            parts.append(f"Doc: {self.active_document}")
        if self.user_activity and self.user_activity != 'idle':
            parts.append(f"Actividad: {self.user_activity}")
        if self.media_playing:
            parts.append(f"Media: {self.media_app}")
        if self.cpu_percent > 70:
            parts.append(f"CPU: {self.cpu_percent:.0f}%")
        return ' | '.join(parts) if parts else 'Sistema inactivo'


class BrowserTracker:
    """Rastrear URL activa del navegador."""

    def __init__(self):
        self._win32_ok = False
        try:
            import win32gui
            self._win32_ok = True
        except ImportError:
            pass

    def get_active_browser_url(self, browser_name: str) -> str:
        """Intentar obtener URL del navegador activo."""
        # Método 1: accesibilidad UIA
        if self._win32_ok:
            try:
                import uiautomation as auto
                browsers = {
                    'chrome': 'Chrome',
                    'firefox': 'Firefox',
                    'edge': 'Edge',
                    'opera': 'Opera',
                    'brave': 'Brave',
                }
                for key, name in browsers.items():
                    if key in browser_name.lower():
                        win = auto.WindowControl(searchDepth=1, SubName=name)
                        if win.Exists(0, 0):
                            # Buscar barra de direcciones
                            edit = win.EditControl(searchDepth=10)
                            if edit.Exists(1, 0):
                                return edit.GetValuePattern().Value or ''
            except Exception:
                pass
        return ''

    def get_browser_from_window(self, window_title: str, app_name: str) -> str:
        """Detectar qué navegador está activo."""
        for b in ['chrome', 'firefox', 'edge', 'opera', 'brave', 'safari']:
            if b in app_name.lower():
                return b
        return ''


class MediaTracker:
    """Rastrear media reproduciéndose."""

    def get_current_media(self) -> Dict[str, Any]:
        """Obtener información de media actual."""
        result = {'playing': False, 'app': '', 'track': ''}

        # Intentar via Windows Media Session (SMTC)
        try:
            # Windows 10/11: winsdk o pywinmedia
            import asyncio

            async def _get_media():
                try:
                    from winsdk.windows.media.control import (
                        GlobalSystemMediaTransportControlsSessionManager as MediaManager
                    )
                    manager = await MediaManager.request_async()
                    session = manager.get_current_session()
                    if session:
                        info = await session.try_get_media_properties_async()
                        if info:
                            return {
                                'playing': True,
                                'app': session.source_app_user_model_id or '',
                                'track': f"{info.artist} - {info.title}" if info.artist else info.title,
                            }
                except ImportError:
                    pass
                return None

            try:
                loop = asyncio.new_event_loop()
                media = loop.run_until_complete(_get_media())
                loop.close()
                if media:
                    return media
            except Exception:
                pass

        except Exception:
            pass

        # Fallback: detectar por proceso
        try:
            import psutil
            media_procs = {'spotify', 'vlc', 'mpv', 'mpc-hc', 'foobar2000',
                           'musicbee', 'itunes', 'winamp', 'potplayer'}
            for proc in psutil.process_iter(['name']):
                name = proc.info['name'].lower().replace('.exe', '')
                if name in media_procs:
                    return {'playing': True, 'app': name, 'track': ''}
        except Exception:
            pass

        return result


class SystemStateTracker:
    """Rastrear estado del sistema."""

    def get_state(self) -> Dict[str, Any]:
        try:
            import psutil
            cpu = psutil.cpu_percent(interval=None)
            ram = psutil.virtual_memory().percent
            battery = None
            charging = False
            try:
                bat = psutil.sensors_battery()
                if bat:
                    battery = bat.percent
                    charging = bat.power_plugged
            except Exception:
                pass

            screen_locked = self._is_screen_locked()

            return {
                'cpu': cpu,
                'ram': ram,
                'battery': battery,
                'charging': charging,
                'screen_locked': screen_locked,
            }
        except Exception:
            return {'cpu': 0.0, 'ram': 0.0, 'battery': None, 'charging': False, 'screen_locked': False}

    def _is_screen_locked(self) -> bool:
        try:
            import ctypes
            user32 = ctypes.windll.User32
            return user32.GetForegroundWindow() == 0
        except Exception:
            return False


class ContextAwarenessSystem:
    """
    MARK 8 — Sistema de Conciencia del Contexto.
    Rastreo continuo de ventana, app, URL, media, actividad y estado del sistema.
    Se actualiza automáticamente cada N segundos en background.
    """

    UPDATE_INTERVAL = 3.0   # Segundos entre actualizaciones

    def __init__(self, brain=None):
        self.brain = brain
        self._current: Optional[CurrentContext] = None
        self._prev: Optional[CurrentContext] = None
        self._lock = threading.Lock()
        self._running = False
        self._thread: Optional[threading.Thread] = None

        self._browser_tracker = BrowserTracker()
        self._media_tracker = MediaTracker()
        self._system_tracker = SystemStateTracker()

        # Historial reciente
        self._app_history: List[str] = []
        self._window_history: List[str] = []
        self._activity_start: Dict[str, float] = {}  # actividad → tiempo inicio

        # Win32
        self._win32_ok = False
        self._proc_win32_ok = False
        try:
            import win32gui
            self._win32_ok = True
        except ImportError:
            pass
        try:
            import win32process
            self._proc_win32_ok = True
        except ImportError:
            pass

    def start(self):
        """Iniciar monitoreo en background."""
        self._running = True
        self._thread = threading.Thread(
            target=self._update_loop,
            name='MARK8-ContextAwareness',
            daemon=True
        )
        self._thread.start()
        logger.info("Context Awareness System iniciado.")

    def stop(self):
        self._running = False
        if self._thread:
            self._thread.join(timeout=3)

    def _update_loop(self):
        while self._running:
            try:
                ctx = self._build_context()
                with self._lock:
                    self._prev = self._current
                    self._current = ctx
            except Exception as e:
                logger.debug(f"Error en context update: {e}")
            time.sleep(self.UPDATE_INTERVAL)

    def _build_context(self) -> CurrentContext:
        ctx = CurrentContext()
        ctx.timestamp = datetime.now()
        ctx.hour_of_day = ctx.timestamp.hour
        ctx.day_of_week = ctx.timestamp.weekday()
        ctx.time_of_day = self._get_time_of_day(ctx.hour_of_day)

        # Ventana y app activa
        ctx.active_window = self._get_active_window()
        ctx.active_app = self._get_active_app()
        ctx.active_document = self._extract_document(ctx.active_window)

        # Historial
        if ctx.active_app and ctx.active_app not in self._app_history[-3:]:
            self._app_history.append(ctx.active_app)
            self._app_history = self._app_history[-20:]
        if ctx.active_window and ctx.active_window not in self._window_history[-3:]:
            self._window_history.append(ctx.active_window)
            self._window_history = self._window_history[-20:]

        ctx.recent_apps = list(self._app_history[-5:])
        ctx.recent_windows = list(self._window_history[-5:])

        # Navegador
        ctx.active_browser = self._browser_tracker.get_browser_from_window(
            ctx.active_window, ctx.active_app
        )
        if ctx.active_browser:
            ctx.active_browser_url = self._browser_tracker.get_active_browser_url(
                ctx.active_browser
            )
            ctx.active_browser_title = ctx.active_window

        # Actividad
        ctx.user_activity = self._detect_activity(ctx.active_app, ctx.active_window)
        ctx.detected_mode = self._detect_mode(ctx.user_activity, ctx.active_browser_url)
        ctx.activity_duration_minutes = self._get_activity_duration(ctx.user_activity)

        # Media
        media = self._media_tracker.get_current_media()
        ctx.media_playing = media['playing']
        ctx.media_app = media['app']
        ctx.media_track = media['track']

        # Sistema
        sys_state = self._system_tracker.get_state()
        ctx.cpu_percent = sys_state['cpu']
        ctx.ram_percent = sys_state['ram']
        ctx.battery_percent = sys_state['battery']
        ctx.battery_charging = sys_state['charging']
        ctx.screen_locked = sys_state['screen_locked']

        return ctx

    def _get_active_window(self) -> str:
        if self._win32_ok:
            try:
                import win32gui
                return win32gui.GetWindowText(win32gui.GetForegroundWindow()) or ''
            except Exception:
                pass
        return ''

    def _get_active_app(self) -> str:
        if self._win32_ok and self._proc_win32_ok:
            try:
                import win32gui, win32process, psutil
                hwnd = win32gui.GetForegroundWindow()
                _, pid = win32process.GetWindowThreadProcessId(hwnd)
                return psutil.Process(pid).name().lower().replace('.exe', '')
            except Exception:
                pass
        try:
            import psutil
            for p in psutil.process_iter(['name', 'status']):
                if p.info['status'] == 'running':
                    n = p.info['name'].lower().replace('.exe', '')
                    if n not in {'system', 'idle', 'svchost', 'dwm', 'winlogon', 'csrss'}:
                        return n
        except Exception:
            pass
        return ''

    def _extract_document(self, window_title: str) -> str:
        for sep in [' - ', ' — ', ' | ']:
            if sep in window_title:
                return window_title.split(sep)[0].strip()
        return ''

    def _detect_activity(self, app: str, window: str) -> str:
        a = app.lower()
        w = window.lower()

        categories = {
            'coding': {'code', 'vscode', 'pycharm', 'intellij', 'sublime', 'vim', 'cursor', 'windsurf', 'nvim'},
            'writing': {'word', 'winword', 'libreoffice', 'soffice', 'notion', 'obsidian', 'onenote', 'typora'},
            'designing': {'figma', 'photoshop', 'illustrator', 'gimp', 'blender', 'inkscape', 'canva'},
            'gaming': {'steam', 'epicgames', 'origin', 'battlenet', 'gog'},
            'communication': {'teams', 'slack', 'discord', 'zoom', 'skype', 'telegram', 'whatsapp'},
            'watching': {'vlc', 'mpv', 'mpc-hc', 'potplayer', 'plex', 'netflix'},
            'spreadsheet': {'excel', 'calc'},
            'presentation': {'powerpoint', 'impress'},
        }

        for activity, apps in categories.items():
            for candidate in apps:
                if candidate in a:
                    return activity

        # Navegador: sub-detectar
        if any(b in a for b in ['chrome', 'firefox', 'edge', 'opera', 'brave']):
            if any(k in w for k in ['youtube', 'twitch', 'netflix']):
                return 'watching'
            if any(k in w for k in ['github', 'stackoverflow', 'mdn', 'docs', 'documentation']):
                return 'coding'
            if any(k in w for k in ['gmail', 'outlook', 'mail']):
                return 'communication'
            return 'browsing'

        return 'idle'

    def _detect_mode(self, activity: str, url: str = '') -> str:
        mapping = {
            'coding': 'work',
            'writing': 'work',
            'spreadsheet': 'work',
            'presentation': 'work',
            'designing': 'creative',
            'browsing': 'study',
            'watching': 'leisure',
            'gaming': 'leisure',
            'communication': 'communication',
        }
        return mapping.get(activity, 'unknown')

    def _get_time_of_day(self, hour: int) -> str:
        if 5 <= hour < 12:
            return 'morning'
        elif 12 <= hour < 17:
            return 'afternoon'
        elif 17 <= hour < 21:
            return 'evening'
        return 'night'

    def _get_activity_duration(self, activity: str) -> float:
        """Minutos continuos en la actividad actual."""
        now = time.time()
        if activity not in self._activity_start:
            self._activity_start = {activity: now}
            return 0.0
        return (now - self._activity_start[activity]) / 60.0

    def get_context(self) -> Optional[CurrentContext]:
        """Obtener contexto actual (thread-safe)."""
        with self._lock:
            return self._current

    def get_summary(self) -> str:
        """Resumen del contexto en lenguaje natural."""
        ctx = self.get_context()
        if not ctx:
            return "Contexto no disponible."
        return ctx.describe()

    def get_change_summary(self) -> Optional[str]:
        """Describir qué cambió respecto al contexto anterior."""
        with self._lock:
            curr, prev = self._current, self._prev
        if not curr or not prev:
            return None

        changes = []
        if curr.active_app != prev.active_app and curr.active_app:
            changes.append(f"App: {prev.active_app} → {curr.active_app}")
        if curr.detected_mode != prev.detected_mode and curr.detected_mode != 'unknown':
            changes.append(f"Modo: {prev.detected_mode} → {curr.detected_mode}")
        if curr.media_playing != prev.media_playing:
            changes.append("Media iniciada" if curr.media_playing else "Media detenida")

        return '; '.join(changes) if changes else None
