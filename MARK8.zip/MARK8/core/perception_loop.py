"""
MARK 8 — Continuous Perception Loop
Monitoreo continuo del entorno sin bloquear el sistema principal.

Creador: Ali (Sidi3Ali)
Sistema: MARK 8
"""

import logging
import threading
import time
import psutil
from typing import Optional, Dict, List, Set, Callable, Any
from datetime import datetime
from collections import deque

logger = logging.getLogger('MARK8.PerceptionLoop')


class ProcessMonitor:
    """Monitorear procesos activos del sistema."""

    _IGNORE = frozenset({
        'system', 'idle', 'svchost', 'runtime', 'host', 'service',
        'explorer', 'dwm', 'winlogon', 'csrss', 'lsass', 'smss',
        'wininit', 'services', 'spoolsv', 'taskmgr', 'conhost',
    })

    def get_user_processes(self) -> Set[str]:
        """Obtener procesos de usuario (sin procesos del sistema)."""
        procs = set()
        try:
            for proc in psutil.process_iter(['name']):
                name = proc.info['name'].lower().replace('.exe', '').strip()
                if len(name) > 2 and name not in self._IGNORE:
                    procs.add(name)
        except Exception:
            pass
        return procs

    def get_process_details(self, name: str) -> Optional[Dict]:
        """Obtener detalles de un proceso por nombre."""
        try:
            for proc in psutil.process_iter(['name', 'pid', 'cpu_percent', 'memory_percent', 'status']):
                if proc.info['name'].lower().replace('.exe', '') == name.lower():
                    return {
                        'name': name,
                        'pid': proc.info['pid'],
                        'cpu': proc.info['cpu_percent'],
                        'memory': proc.info['memory_percent'],
                        'status': proc.info['status'],
                    }
        except Exception:
            pass
        return None

    def get_top_consumers(self, n: int = 5) -> List[Dict]:
        """Obtener los N procesos con mayor uso de CPU."""
        try:
            procs = []
            for p in psutil.process_iter(['name', 'cpu_percent', 'memory_percent']):
                try:
                    procs.append({
                        'name': p.info['name'].lower().replace('.exe', ''),
                        'cpu': p.info['cpu_percent'] or 0.0,
                        'mem': p.info['memory_percent'] or 0.0,
                    })
                except Exception:
                    pass
            return sorted(procs, key=lambda x: x['cpu'], reverse=True)[:n]
        except Exception:
            return []


class NetworkMonitor:
    """Monitorear actividad de red."""

    def __init__(self):
        self._prev_bytes = (0, 0)
        self._prev_time = time.time()

    def get_network_speed(self) -> Dict[str, float]:
        """Obtener velocidad de red en KB/s."""
        try:
            stats = psutil.net_io_counters()
            now = time.time()
            dt = now - self._prev_time
            if dt > 0:
                sent_kbs = (stats.bytes_sent - self._prev_bytes[0]) / dt / 1024
                recv_kbs = (stats.bytes_recv - self._prev_bytes[1]) / dt / 1024
                self._prev_bytes = (stats.bytes_sent, stats.bytes_recv)
                self._prev_time = now
                return {'sent_kbs': round(sent_kbs, 1), 'recv_kbs': round(recv_kbs, 1)}
        except Exception:
            pass
        return {'sent_kbs': 0.0, 'recv_kbs': 0.0}


class AudioDetector:
    """Detectar si hay audio activo en el sistema."""

    def is_audio_playing(self) -> bool:
        """Detectar si hay reproducción de audio activa."""
        try:
            import psutil
            audio_procs = {
                'spotify', 'vlc', 'mpv', 'mpc-hc', 'foobar2000',
                'musicbee', 'itunes', 'winamp', 'potplayer', 'audacious',
                'chrome', 'firefox', 'edge',  # Pueden reproducir audio
                'discord',  # Calls / streams
            }
            for proc in psutil.process_iter(['name']):
                name = proc.info['name'].lower().replace('.exe', '')
                if name in audio_procs:
                    return True
        except Exception:
            pass
        return False

    def get_audio_apps(self) -> List[str]:
        """Obtener apps que podrían estar reproduciendo audio."""
        active = []
        try:
            import psutil
            audio_procs = {
                'spotify', 'vlc', 'mpv', 'mpc-hc', 'foobar2000',
                'musicbee', 'itunes', 'winamp', 'potplayer'
            }
            for proc in psutil.process_iter(['name']):
                name = proc.info['name'].lower().replace('.exe', '')
                if name in audio_procs:
                    active.append(name)
        except Exception:
            pass
        return active


class WindowMonitor:
    """Monitorear cambios en ventanas activas."""

    def __init__(self):
        self._win32_ok = False
        try:
            import win32gui
            self._win32_ok = True
        except ImportError:
            pass

    def get_foreground_window(self) -> str:
        if self._win32_ok:
            try:
                import win32gui
                return win32gui.GetWindowText(win32gui.GetForegroundWindow()) or ''
            except Exception:
                pass
        return ''

    def get_all_visible_windows(self) -> List[str]:
        """Listar títulos de todas las ventanas visibles."""
        if not self._win32_ok:
            return []
        try:
            import win32gui
            titles = []
            def callback(hwnd, _):
                t = win32gui.GetWindowText(hwnd)
                if t and win32gui.IsWindowVisible(hwnd):
                    titles.append(t)
            win32gui.EnumWindows(callback, None)
            return titles
        except Exception:
            return []


class PerceptionSnapshot:
    """Instantánea completa de percepción."""

    def __init__(self):
        self.timestamp: datetime = datetime.now()
        self.active_window: str = ''
        self.running_processes: Set[str] = set()
        self.new_processes: Set[str] = set()
        self.closed_processes: Set[str] = set()
        self.cpu: float = 0.0
        self.ram: float = 0.0
        self.audio_playing: bool = False
        self.audio_apps: List[str] = []
        self.network_sent_kbs: float = 0.0
        self.network_recv_kbs: float = 0.0
        self.top_consumers: List[Dict] = []


class PerceptionLoop:
    """
    MARK 8 — Perception Loop continuo.
    Monitorea apps, audio, ventanas y recursos del sistema
    en background sin bloquear el sistema principal.

    Proporciona snapshots e historial de cambios detectados.
    """

    FAST_INTERVAL = 2.0    # Percepción rápida: ventana activa, audio
    SLOW_INTERVAL = 10.0   # Percepción profunda: procesos, red, top consumers

    def __init__(self, brain=None):
        self.brain = brain
        self._running = False
        self._thread_fast: Optional[threading.Thread] = None
        self._thread_slow: Optional[threading.Thread] = None

        self._proc_monitor = ProcessMonitor()
        self._net_monitor = NetworkMonitor()
        self._audio_detector = AudioDetector()
        self._window_monitor = WindowMonitor()

        # Estado actual
        self._snapshot: Optional[PerceptionSnapshot] = None
        self._prev_snapshot: Optional[PerceptionSnapshot] = None
        self._lock = threading.Lock()

        # Historial
        self._history: deque = deque(maxlen=100)
        self._change_log: deque = deque(maxlen=50)

        # Callbacks externos
        self._change_callbacks: List[Callable] = []

        # Estado previo de procesos
        self._prev_procs: Set[str] = set()

    def start(self):
        """Iniciar loops de percepción."""
        self._running = True

        self._thread_fast = threading.Thread(
            target=self._fast_loop,
            name='MARK8-Perception-Fast',
            daemon=True
        )
        self._thread_slow = threading.Thread(
            target=self._slow_loop,
            name='MARK8-Perception-Slow',
            daemon=True
        )

        self._thread_fast.start()
        self._thread_slow.start()
        logger.info("Perception Loop iniciado (fast + slow).")

    def stop(self):
        self._running = False
        logger.info("Perception Loop detenido.")

    def _fast_loop(self):
        """Loop rápido: ventana activa, audio básico."""
        while self._running:
            try:
                snap = self._snapshot or PerceptionSnapshot()
                snap.timestamp = datetime.now()
                snap.active_window = self._window_monitor.get_foreground_window()
                snap.audio_playing = self._audio_detector.is_audio_playing()

                try:
                    snap.cpu = psutil.cpu_percent(interval=None)
                    snap.ram = psutil.virtual_memory().percent
                except Exception:
                    pass

                with self._lock:
                    self._snapshot = snap

            except Exception as e:
                logger.debug(f"Error en fast loop: {e}")

            time.sleep(self.FAST_INTERVAL)

    def _slow_loop(self):
        """Loop lento: procesos, red, top consumers, cambios."""
        while self._running:
            try:
                snap = PerceptionSnapshot()
                snap.timestamp = datetime.now()
                snap.active_window = self._window_monitor.get_foreground_window()

                # Procesos
                current_procs = self._proc_monitor.get_user_processes()
                snap.running_processes = current_procs
                snap.new_processes = current_procs - self._prev_procs
                snap.closed_processes = self._prev_procs - current_procs
                self._prev_procs = current_procs.copy()

                # Sistema
                try:
                    snap.cpu = psutil.cpu_percent(interval=0.5)
                    snap.ram = psutil.virtual_memory().percent
                except Exception:
                    pass

                # Audio
                snap.audio_apps = self._audio_detector.get_audio_apps()
                snap.audio_playing = len(snap.audio_apps) > 0

                # Red
                net = self._net_monitor.get_network_speed()
                snap.network_sent_kbs = net['sent_kbs']
                snap.network_recv_kbs = net['recv_kbs']

                # Top consumers
                snap.top_consumers = self._proc_monitor.get_top_consumers(5)

                # Guardar
                with self._lock:
                    self._prev_snapshot = self._snapshot
                    self._snapshot = snap

                # Registrar en historial
                self._history.append(snap)

                # Detectar y reportar cambios
                changes = self._detect_changes(snap)
                if changes:
                    for change in changes:
                        self._change_log.append(change)
                    for cb in self._change_callbacks:
                        try:
                            cb(changes, snap)
                        except Exception:
                            pass

                    # Reportar apps nuevas a memoria cognitiva
                    if self.brain and self.brain.cognitive_memory:
                        for app in snap.new_processes:
                            try:
                                self.brain.cognitive_memory.record_app_open(app)
                            except Exception:
                                pass

            except Exception as e:
                logger.debug(f"Error en slow loop: {e}")

            time.sleep(self.SLOW_INTERVAL)

    def _detect_changes(self, snap: PerceptionSnapshot) -> List[Dict]:
        """Detectar cambios significativos en el sistema."""
        changes = []
        with self._lock:
            prev = self._prev_snapshot

        if not prev:
            return []

        # Nuevas apps abiertas
        for app in snap.new_processes:
            changes.append({'type': 'app_opened', 'app': app, 'time': snap.timestamp.isoformat()})

        # Apps cerradas relevantes
        for app in snap.closed_processes:
            if app in {'code', 'vscode', 'word', 'excel', 'chrome', 'firefox'}:
                changes.append({'type': 'app_closed', 'app': app, 'time': snap.timestamp.isoformat()})

        # CPU alta
        if snap.cpu > 85 and prev.cpu <= 85:
            changes.append({'type': 'cpu_high', 'value': snap.cpu, 'time': snap.timestamp.isoformat()})

        # RAM alta
        if snap.ram > 88 and prev.ram <= 88:
            changes.append({'type': 'ram_high', 'value': snap.ram, 'time': snap.timestamp.isoformat()})

        # Audio iniciado/detenido
        if snap.audio_playing != prev.audio_playing:
            changes.append({
                'type': 'audio_started' if snap.audio_playing else 'audio_stopped',
                'apps': snap.audio_apps,
                'time': snap.timestamp.isoformat()
            })

        return changes

    def get_snapshot(self) -> Optional[PerceptionSnapshot]:
        """Obtener snapshot más reciente."""
        with self._lock:
            return self._snapshot

    def get_running_apps(self) -> Set[str]:
        snap = self.get_snapshot()
        return snap.running_processes if snap else set()

    def get_recent_changes(self, n: int = 10) -> List[Dict]:
        return list(self._change_log)[-n:]

    def add_change_callback(self, callback: Callable):
        """Registrar callback para recibir cambios detectados."""
        self._change_callbacks.append(callback)

    def get_system_summary(self) -> str:
        """Resumen del estado del sistema en lenguaje natural."""
        snap = self.get_snapshot()
        if not snap:
            return "Sistema sin datos de percepción."

        parts = [f"CPU {snap.cpu:.0f}%, RAM {snap.ram:.0f}%"]

        if snap.top_consumers:
            top = snap.top_consumers[0]
            if top['cpu'] > 20:
                parts.append(f"Mayor consumidor: {top['name']} ({top['cpu']:.0f}% CPU)")

        if snap.audio_playing and snap.audio_apps:
            parts.append(f"Audio: {', '.join(snap.audio_apps[:2])}")

        if snap.network_recv_kbs > 500:
            parts.append(f"Red: ↓{snap.network_recv_kbs:.0f} KB/s")

        return '. '.join(parts) + '.'

    def is_app_running(self, app_name: str) -> bool:
        """Comprobar si una app está corriendo."""
        snap = self.get_snapshot()
        if not snap:
            return False
        name_lower = app_name.lower().replace('.exe', '')
        return any(name_lower in p for p in snap.running_processes)

    def get_status(self) -> Dict:
        snap = self.get_snapshot()
        return {
            'running': self._running,
            'processes_monitored': len(snap.running_processes) if snap else 0,
            'audio_playing': snap.audio_playing if snap else False,
            'cpu': snap.cpu if snap else 0.0,
            'ram': snap.ram if snap else 0.0,
            'recent_changes': len(self._change_log),
        }
