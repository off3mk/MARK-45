"""
JARVIS v4.0 - Sistema de Seguridad
Protección y confirmación para operaciones críticas.
"""

import logging
import re
from typing import Dict, Optional

logger = logging.getLogger('JARVIS.Security')


class SecuritySystem:
    """Sistema de seguridad para operaciones críticas."""

    DANGEROUS_COMMANDS = [
        'rm -rf', 'format', 'del /f', 'deltree',
        'shutdown', 'restart', ':(){:|:&};:', 'dd if=',
    ]

    DANGEROUS_ACTIONS = [
        'shutdown', 'restart', 'delete_file',
        'run_script', 'format_drive'
    ]

    NEEDS_CONFIRMATION = [
        'shutdown', 'restart', 'delete_file',
        'execute_dangerous', 'run_script'
    ]

    def __init__(self):
        self._pending_confirmation: Optional[Dict] = None
        self._security_level = 'normal'  # low, normal, high

    def check_command(self, text: str, intent: Dict) -> bool:
        """
        Verificar si un comando es seguro.
        Returns True si es seguro, False si debe bloquearse.
        """
        action = intent.get('action', '')
        params = intent.get('params', {})

        # Verificar acciones peligrosas
        if action in self.DANGEROUS_ACTIONS:
            logger.warning(f"Acción crítica detectada: {action}")
            return self._handle_dangerous_action(action, params)

        # Verificar comandos shell peligrosos
        if action == 'run_command':
            command = params.get('command', '')
            if self._is_dangerous_command(command):
                logger.warning(f"Comando peligroso bloqueado: {command}")
                return False

        # Verificar código peligroso
        if action == 'run_script':
            code = params.get('code', '')
            if self._has_dangerous_code(code):
                logger.warning(f"Código peligroso detectado")
                return self._handle_dangerous_action(action, params)

        return True

    def _is_dangerous_command(self, command: str) -> bool:
        """Verificar si un comando de shell es peligroso."""
        cmd_lower = command.lower()
        for dangerous in self.DANGEROUS_COMMANDS:
            if dangerous in cmd_lower:
                return True
        return False

    def _has_dangerous_code(self, code: str) -> bool:
        """Verificar si el código contiene operaciones peligrosas."""
        dangerous_patterns = [
            r'\bos\.remove\b', r'\bshutil\.rmtree\b',
            r'\bsubprocess\b.*shell\s*=\s*True',
            r'\beval\s*\(', r'\bexec\s*\(',
        ]
        for pattern in dangerous_patterns:
            if re.search(pattern, code):
                return True
        return False

    def _handle_dangerous_action(self, action: str, params: Dict) -> bool:
        """Manejar acción peligrosa - solicitar confirmación."""
        if action in self.NEEDS_CONFIRMATION:
            self._pending_confirmation = {'action': action, 'params': params}
            logger.info(f"Acción {action} requiere confirmación del usuario")
            return False  # Bloquear hasta confirmación
        return False

    def confirm_pending_action(self) -> Optional[Dict]:
        """Obtener acción pendiente de confirmación y limpiarla."""
        action = self._pending_confirmation
        self._pending_confirmation = None
        return action

    def has_pending_confirmation(self) -> bool:
        """Verificar si hay una confirmación pendiente."""
        return self._pending_confirmation is not None

    def get_security_warning(self, action: str) -> str:
        """Obtener mensaje de advertencia de seguridad."""
        warnings = {
            'shutdown': "apagar el sistema completamente",
            'restart': "reiniciar el sistema",
            'delete_file': "eliminar archivos permanentemente",
            'run_script': "ejecutar código en el sistema",
        }
        action_desc = warnings.get(action, f"ejecutar '{action}'")
        return (f"Esta acción requiere confirmación: {action_desc}. "
                f"Responda 'confirmar' para proceder o 'cancelar' para abortar, Señor.")
