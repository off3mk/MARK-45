"""
MARK 8 — Fully Autonomous Cognitive System
Núcleo central del sistema MARK 8.

Coordina:
  - Cognitive Loop continuo
  - Context Awareness en tiempo real
  - Decision Engine autónomo
  - Perception Loop
  - Self Improvement Engine
  - Todos los módulos v7 existentes

Creador: Ali (Sidi3Ali)
Sistema: MARK 8
"""

import logging
import threading
import time
import queue
from typing import Optional, Callable, Dict, Any

logger = logging.getLogger('MARK8.Brain')

# ── MARCA DE IDENTIDAD DEL SISTEMA ──────────────────────────────────────────
SYSTEM_NAME = "MARK 8"
SYSTEM_VERSION = "8.0"
CREATOR_NAME = "Ali"
CREATOR_ALIAS = "Sidi3Ali"
WATERMARK = f"{SYSTEM_NAME} — Created by {CREATOR_NAME} ({CREATOR_ALIAS})"
# ────────────────────────────────────────────────────────────────────────────


class Mark8Brain:
    """
    Núcleo central de MARK 8 — Fully Autonomous Cognitive System.
    Coordina todos los subsistemas en tiempo real.
    """

    def __init__(self):
        self.initialized = False
        self.running = False
        self.command_queue = queue.PriorityQueue()
        self._ui_callback: Optional[Callable] = None
        self._modules: Dict[str, Any] = {}
        self.lock = threading.Lock()

        # ── Módulos heredados de MARK 6/7 ────────────────────────────────────
        self.state = None
        self.memory = None
        self.cognitive_memory = None
        self.intent_engine = None
        self.ai_manager = None
        self.personality = None
        self.executor = None
        self.voice = None
        self.autonomous = None
        self.reasoning = None
        self.planner = None
        self.security = None
        self.skill_manager = None

        # ── Módulos MARK 7 ────────────────────────────────────────────────────
        self.user_identity = None
        self.startup_manager = None
        self.ui_control = None
        self.audio_monitor = None
        self._spotify = None

        # ── Módulos MARK 8 NUEVOS ─────────────────────────────────────────────
        self.cognitive_loop = None
        self.context_awareness = None
        self.decision_engine = None
        self.perception_loop = None
        self.self_improvement = None

    def initialize(self):
        """Inicializar todos los módulos de MARK 8."""
        logger.info(f"{'='*55}")
        logger.info(f"  Iniciando {SYSTEM_NAME} — {WATERMARK}")
        logger.info(f"{'='*55}")

        try:
            # ── Módulos base (orden importa) ──────────────────────────────────
            self._load_state()
            self._load_memory()
            self._load_cognitive_memory()
            self._load_ai_manager()
            self._load_personality()
            self._load_security()
            self._load_intent_engine()
            self._load_reasoning()
            self._load_planner()
            self._load_executor()
            self._load_voice()
            self._load_skills()
            self._load_autonomous()

            # ── Módulos MARK 7 ────────────────────────────────────────────────
            self._load_user_identity()
            self._load_ui_control()
            self._load_audio_monitor()
            self._load_startup_manager()

            # ── Módulos MARK 8 NUEVOS ─────────────────────────────────────────
            self._load_context_awareness()
            self._load_perception_loop()
            self._load_decision_engine()
            self._load_cognitive_loop()
            self._load_self_improvement()

            self.initialized = True
            self.running = True

            # Iniciar procesador de comandos
            self._start_command_processor()

            logger.info(f"{SYSTEM_NAME} completamente inicializado.")

        except Exception as e:
            logger.error(f"Error durante inicialización: {e}", exc_info=True)
            self.initialized = True
            self.running = True

    # ── LOADERS BASE ──────────────────────────────────────────────────────────

    def _load_state(self):
        try:
            from core.state import JarvisState
            self.state = JarvisState()
            self.state.start()
            logger.info("✓ State Engine")
        except Exception as e:
            logger.warning(f"State Engine: {e}")

    def _load_memory(self):
        try:
            from core.memory import MemorySystem
            self.memory = MemorySystem()
            self.memory.initialize()
            logger.info("✓ Memory System")
        except Exception as e:
            logger.warning(f"Memory System: {e}")

    def _load_cognitive_memory(self):
        try:
            from core.cognitive_memory import CognitiveMemory
            self.cognitive_memory = CognitiveMemory()
            self.cognitive_memory.initialize()
            logger.info("✓ Cognitive Memory")
        except Exception as e:
            logger.warning(f"Cognitive Memory: {e}")

    def _load_ai_manager(self):
        try:
            from core.ai_manager import AIManager
            self.ai_manager = AIManager()
            logger.info("✓ AI Manager")
        except Exception as e:
            logger.warning(f"AI Manager: {e}")

    def _load_personality(self):
        try:
            from core.personality import JarvisPersonality
            self.personality = JarvisPersonality(self.ai_manager)
            logger.info("✓ Personality Engine")
        except Exception as e:
            logger.warning(f"Personality Engine: {e}")

    def _load_security(self):
        try:
            from core.security import SecuritySystem
            self.security = SecuritySystem()
            logger.info("✓ Security System")
        except Exception as e:
            logger.warning(f"Security System: {e}")

    def _load_intent_engine(self):
        try:
            from core.intent_engine import SemanticIntentEngine
            self.intent_engine = SemanticIntentEngine()
            logger.info("✓ Intent Engine")
        except Exception as e:
            logger.warning(f"Intent Engine: {e}")

    def _load_reasoning(self):
        try:
            from core.reasoning import ReasoningEngine
            self.reasoning = ReasoningEngine(self)
            logger.info("✓ Reasoning Engine")
        except Exception as e:
            logger.warning(f"Reasoning Engine: {e}")

    def _load_planner(self):
        try:
            from core.planner import TaskPlanner
            self.planner = TaskPlanner(self)
            logger.info("✓ Task Planner")
        except Exception as e:
            logger.warning(f"Task Planner: {e}")

    def _load_executor(self):
        try:
            from core.executor import CommandExecutor
            self.executor = CommandExecutor(self)
            logger.info("✓ Command Executor")
        except Exception as e:
            logger.warning(f"Command Executor: {e}")

    def _load_voice(self):
        try:
            from core.voice import VoiceSystem
            self.voice = VoiceSystem()
            logger.info("✓ Voice System")
        except Exception as e:
            logger.warning(f"Voice System: {e}")

    def _load_skills(self):
        try:
            from core.skills import SkillManager
            self.skill_manager = SkillManager(self)
            self.skill_manager.load_all_skills()
            logger.info("✓ Skill Manager")
        except Exception as e:
            logger.warning(f"Skill Manager: {e}")

    def _load_autonomous(self):
        try:
            from core.autonomous import AutonomousEngine
            self.autonomous = AutonomousEngine(self)
            self.autonomous.start()
            logger.info("✓ Autonomous Engine (legacy)")
        except Exception as e:
            logger.warning(f"Autonomous Engine: {e}")

    # ── LOADERS MARK 7 ────────────────────────────────────────────────────────

    def _load_user_identity(self):
        try:
            from core.user_identity import UserIdentitySystem
            self.user_identity = UserIdentitySystem()
            profile = self.user_identity.load_or_create_profile(voice=self.voice)
            if self.personality:
                self.personality.load_user_context(
                    preferred_name=profile.get('preferred_name', CREATOR_NAME),
                    is_creator=bool(profile.get('creator_flag', 0)),
                    formality=profile.get('formality', 'formal')
                )
            name = profile.get('preferred_name', '?')
            creator = bool(profile.get('creator_flag', 0))
            logger.info(f"✓ User Identity — {name} (creator={creator})")
        except Exception as e:
            logger.warning(f"User Identity: {e}")

    def _load_ui_control(self):
        try:
            from core.ui_control import UIController
            self.ui_control = UIController()
            logger.info("✓ UI Control")
        except Exception as e:
            logger.warning(f"UI Control: {e}")

    def _load_audio_monitor(self):
        try:
            from core.audio_monitor import AudioMonitor
            self.audio_monitor = AudioMonitor(brain=self)
            logger.info("✓ Audio Monitor")
        except Exception as e:
            logger.warning(f"Audio Monitor: {e}")

    def _load_startup_manager(self):
        try:
            from core.startup_manager import StartupManager
            self.startup_manager = StartupManager(brain=self)
            logger.info("✓ Startup Manager")
        except Exception as e:
            logger.warning(f"Startup Manager: {e}")

    # ── LOADERS MARK 8 ────────────────────────────────────────────────────────

    def _load_context_awareness(self):
        try:
            from core.context_awareness import ContextAwarenessSystem
            self.context_awareness = ContextAwarenessSystem(brain=self)
            self.context_awareness.start()
            logger.info("✓ Context Awareness System")
        except Exception as e:
            logger.warning(f"Context Awareness: {e}")

    def _load_perception_loop(self):
        try:
            from core.perception_loop import PerceptionLoop
            self.perception_loop = PerceptionLoop(brain=self)
            self.perception_loop.start()
            logger.info("✓ Perception Loop")
        except Exception as e:
            logger.warning(f"Perception Loop: {e}")

    def _load_decision_engine(self):
        try:
            from core.decision_engine import AutonomousDecisionEngine
            self.decision_engine = AutonomousDecisionEngine(brain=self)
            # Conectar con el cognitive loop vía callback
            logger.info("✓ Decision Engine")
        except Exception as e:
            logger.warning(f"Decision Engine: {e}")

    def _load_cognitive_loop(self):
        try:
            from core.cognitive_loop import CognitiveLoop
            self.cognitive_loop = CognitiveLoop(brain=self)

            # Conectar decision engine al cognitive loop
            if self.decision_engine:
                def on_state_update(state):
                    try:
                        ctx = state.__dict__.copy()
                        # Convertir datetime a string para evitar errores
                        if 'timestamp' in ctx:
                            ctx['timestamp'] = ctx['timestamp'].isoformat()
                        self.decision_engine.process_context(ctx)
                    except Exception:
                        pass
                self.cognitive_loop.add_state_callback(on_state_update)

            self.cognitive_loop.start()
            logger.info("✓ Cognitive Loop (MARK 8 Core)")
        except Exception as e:
            logger.warning(f"Cognitive Loop: {e}")

    def _load_self_improvement(self):
        try:
            from core.self_improvement_engine import SelfImprovementEngine
            self.self_improvement = SelfImprovementEngine(brain=self)
            self.self_improvement.schedule_periodic_analysis()
            logger.info("✓ Self Improvement Engine")
        except Exception as e:
            logger.warning(f"Self Improvement Engine: {e}")

    # ── PROCESAMIENTO DE COMANDOS ─────────────────────────────────────────────

    def _start_command_processor(self):
        def processor():
            while self.running:
                try:
                    if not self.command_queue.empty():
                        priority, cmd_data = self.command_queue.get(timeout=0.1)
                        self._execute_queued_command(cmd_data)
                except queue.Empty:
                    pass
                except Exception as e:
                    logger.error(f"Error en procesador de comandos: {e}")
                time.sleep(0.05)

        t = threading.Thread(target=processor, daemon=True, name='MARK8-CmdProcessor')
        t.start()

    def _execute_queued_command(self, cmd_data: dict):
        try:
            command = cmd_data.get('command', '')
            callback = cmd_data.get('callback')
            result = self.process_command(command)
            if callback:
                callback(result)
        except Exception as e:
            logger.error(f"Error ejecutando comando: {e}")

    def process_command(self, user_input: str) -> str:
        """
        Procesar input del usuario con el pipeline completo de MARK 8.
        NLU → Reasoning → Personalidad → TTS.
        """
        if not user_input or not user_input.strip():
            return ""

        user_input = user_input.strip()
        logger.info(f"[{SYSTEM_NAME}] Input: '{user_input[:80]}'")

        try:
            # Guardar en memoria
            if self.memory:
                try:
                    self.memory.save_message('user', user_input)
                except Exception:
                    pass
            if self.state:
                try:
                    self.state.update_interaction()
                except Exception:
                    pass

            # NLU
            nlu_result = {'intent': 'ai_chat', 'confidence': 0.5,
                          'entities': {}, 'context': {},
                          'emotional_tone': 'neutral', 'needs_ai': True}
            try:
                from core.nlu import get_nlu
                nlu_result = get_nlu().understand(user_input)
            except Exception as e:
                logger.debug(f"NLU error: {e}")

            # Razonamiento
            response = ''
            if self.reasoning:
                try:
                    response = self.reasoning.reason(user_input, nlu_result)
                except Exception as e:
                    logger.error(f"Reasoning error: {e}", exc_info=True)

            if not response or len(response.strip()) < 3:
                response = self._ask_ai(user_input)

            # Personalidad
            if self.personality and response:
                try:
                    response = self.personality.format_response(response)
                except Exception:
                    pass

            # Guardar respuesta
            if self.memory:
                try:
                    self.memory.save_message('mark8', response)
                except Exception:
                    pass

            try:
                from core.nlu import get_nlu
                get_nlu().add_bot_response(response)
            except Exception:
                pass

            # TTS
            self.speak(response)
            return response

        except Exception as e:
            logger.error(f"process_command error: {e}", exc_info=True)
            return f"Error interno: {str(e)[:80]}"

    def _ask_ai(self, text: str) -> str:
        if self.ai_manager:
            try:
                return self.ai_manager.ask(text)
            except Exception:
                pass
        return f"No pude procesar: '{text[:60]}'"

    def speak(self, text: str, priority: bool = False):
        """TTS."""
        if self.voice and text:
            try:
                self.voice.speak(text, priority=priority)
            except Exception as e:
                logger.debug(f"TTS error: {e}")

    def set_ui_callback(self, callback: Callable):
        self._ui_callback = callback

    def update_ui(self, event_type: str, data: Any = None):
        if self._ui_callback:
            try:
                self._ui_callback(event_type, data)
            except Exception:
                pass

    def queue_command(self, command: str, priority: int = 5,
                       callback: Optional[Callable] = None):
        self.command_queue.put((priority, {
            'command': command,
            'callback': callback,
            'timestamp': time.time(),
        }))

    def get_context(self):
        """Obtener contexto actual del sistema."""
        if self.context_awareness:
            return self.context_awareness.get_context()
        if self.cognitive_loop:
            return self.cognitive_loop.get_current_state()
        return None

    def shutdown(self):
        logger.info(f"Apagando {SYSTEM_NAME}...")
        self.running = False

        for attr in ['cognitive_loop', 'context_awareness', 'perception_loop',
                     'autonomous', 'state']:
            module = getattr(self, attr, None)
            if module:
                for method in ['stop', 'close']:
                    if hasattr(module, method):
                        try:
                            getattr(module, method)()
                            break
                        except Exception:
                            pass

        if self.memory:
            try:
                self.memory.close()
            except Exception:
                pass

        logger.info(f"{SYSTEM_NAME} apagado correctamente.")

    def get_status(self) -> dict:
        status = {
            'system': SYSTEM_NAME,
            'creator': f"{CREATOR_NAME} ({CREATOR_ALIAS})",
            'initialized': self.initialized,
            'running': self.running,
            'modules': {
                'state': self.state is not None,
                'memory': self.memory is not None,
                'ai_manager': self.ai_manager is not None,
                'voice': self.voice is not None,
                'cognitive_loop': self.cognitive_loop is not None,
                'context_awareness': self.context_awareness is not None,
                'decision_engine': self.decision_engine is not None,
                'perception_loop': self.perception_loop is not None,
                'self_improvement': self.self_improvement is not None,
                'user_identity': self.user_identity is not None,
                'ui_control': self.ui_control is not None,
            }
        }

        if self.cognitive_loop:
            status['cognitive_loop'] = self.cognitive_loop.get_status()
        if self.perception_loop:
            status['perception_loop'] = self.perception_loop.get_status()
        if self.decision_engine:
            status['decision_engine'] = self.decision_engine.get_status()
        if self.state:
            status['system_state'] = self.state.get_state()

        return status


# Alias de compatibilidad con código que usa JarvisBrain
JarvisBrain = Mark8Brain
