"""
JARVIS v4.0 - State Engine (Conciencia Operativa)
Monitorea y mantiene el estado interno del sistema.
"""

import logging
import threading
import time
import psutil
import platform
from datetime import datetime
from typing import Dict, Any, Optional, Callable

logger = logging.getLogger('JARVIS.State')


class JarvisState:
    """Motor de estado interno - la conciencia operativa de JARVIS."""

    MOOD_NEUTRAL = 'neutral'
    MOOD_FOCUSED = 'focused'
    MOOD_ALERT = 'alert'
    MOOD_IDLE = 'idle'
    MOOD_PROCESSING = 'processing'
    MOOD_WARNING = 'warning'

    def __init__(self):
        self._state: Dict[str, Any] = {
            'mood': self.MOOD_NEUTRAL,
            'cpu_usage': 0.0,
            'memory_usage': 0.0,
            'disk_usage': 0.0,
            'active_tasks': [],
            'priorities': [],
            'user_presence': True,
            'system_health': 100,
            'threat_level': 0,
            'last_interaction': datetime.now().isoformat(),
            'uptime_start': datetime.now().isoformat(),
            'network_status': 'unknown',
            'battery_level': -1,
            'temperature': 0.0,
        }

        self._running = False
        self._monitor_thread: Optional[threading.Thread] = None
        self._callbacks: list = []
        self._lock = threading.Lock()

        # Umbrales de alerta
        self._thresholds = {
            'cpu_warning': 80.0,
            'cpu_critical': 95.0,
            'memory_warning': 80.0,
            'memory_critical': 95.0,
            'disk_warning': 85.0,
            'idle_timeout': 300,  # 5 minutos
        }

        self._last_interaction = time.time()
        self._notified_states: set = set()

    def start(self):
        """Iniciar monitoreo del sistema."""
        self._running = True
        self._monitor_thread = threading.Thread(target=self._monitor_loop, daemon=True)
        self._monitor_thread.start()
        logger.info("State Engine iniciado.")

    def stop(self):
        """Detener monitoreo."""
        self._running = False
        if self._monitor_thread:
            self._monitor_thread.join(timeout=2)
        logger.info("State Engine detenido.")

    def _monitor_loop(self):
        """Bucle principal de monitoreo."""
        while self._running:
            try:
                self._update_system_metrics()
                self._update_mood()
                self._check_alerts()
            except Exception as e:
                logger.debug(f"Error en monitor loop: {e}")
            time.sleep(5)  # Actualizar cada 5 segundos

    def _update_system_metrics(self):
        """Actualizar métricas del sistema."""
        try:
            cpu = psutil.cpu_percent(interval=1)
            mem = psutil.virtual_memory()
            disk = psutil.disk_usage('/')

            with self._lock:
                self._state['cpu_usage'] = cpu
                self._state['memory_usage'] = mem.percent
                self._state['disk_usage'] = disk.percent

            # Calcular salud del sistema
            health = 100
            if cpu > self._thresholds['cpu_critical']:
                health -= 30
            elif cpu > self._thresholds['cpu_warning']:
                health -= 15

            if mem.percent > self._thresholds['memory_critical']:
                health -= 30
            elif mem.percent > self._thresholds['memory_warning']:
                health -= 15

            if disk.percent > self._thresholds['disk_warning']:
                health -= 10

            with self._lock:
                self._state['system_health'] = max(0, health)

            # Batería (si existe)
            try:
                battery = psutil.sensors_battery()
                if battery:
                    with self._lock:
                        self._state['battery_level'] = int(battery.percent)
            except Exception:
                pass

            # Red
            try:
                net = psutil.net_io_counters()
                with self._lock:
                    self._state['network_status'] = 'connected' if net.bytes_sent > 0 else 'disconnected'
            except Exception:
                pass

        except Exception as e:
            logger.debug(f"Error actualizando métricas: {e}")

    def _update_mood(self):
        """Actualizar estado de ánimo basado en métricas."""
        with self._lock:
            cpu = self._state['cpu_usage']
            mem = self._state['memory_usage']
            tasks = len(self._state['active_tasks'])
            idle_time = time.time() - self._last_interaction

        # Determinar mood
        new_mood = self.MOOD_NEUTRAL

        if cpu > self._thresholds['cpu_critical'] or mem > self._thresholds['memory_critical']:
            new_mood = self.MOOD_WARNING
        elif cpu > self._thresholds['cpu_warning'] or mem > self._thresholds['memory_warning']:
            new_mood = self.MOOD_ALERT
        elif tasks > 0:
            new_mood = self.MOOD_PROCESSING
        elif idle_time > self._thresholds['idle_timeout']:
            new_mood = self.MOOD_IDLE
        else:
            new_mood = self.MOOD_NEUTRAL

        with self._lock:
            self._state['mood'] = new_mood

    def _check_alerts(self):
        """Verificar condiciones de alerta y notificar."""
        with self._lock:
            cpu = self._state['cpu_usage']
            mem = self._state['memory_usage']
            mood = self._state['mood']

        # CPU alta
        if cpu > self._thresholds['cpu_critical'] and 'cpu_critical' not in self._notified_states:
            self._notified_states.add('cpu_critical')
            self._notify_alert('cpu_critical', f"CPU al {cpu:.0f}% - Carga crítica detectada, Señor.")
        elif cpu < self._thresholds['cpu_warning'] and 'cpu_critical' in self._notified_states:
            self._notified_states.discard('cpu_critical')

        # Memoria alta
        if mem > self._thresholds['memory_critical'] and 'mem_critical' not in self._notified_states:
            self._notified_states.add('mem_critical')
            self._notify_alert('mem_critical', f"Memoria al {mem:.0f}% - Nivel crítico, Señor.")
        elif mem < self._thresholds['memory_warning'] and 'mem_critical' in self._notified_states:
            self._notified_states.discard('mem_critical')

    def _notify_alert(self, alert_type: str, message: str):
        """Notificar alerta a los callbacks registrados."""
        for callback in self._callbacks:
            try:
                callback('alert', alert_type, message)
            except Exception as e:
                logger.debug(f"Error en callback de alerta: {e}")

    def register_callback(self, callback: Callable):
        """Registrar callback para recibir notificaciones de estado."""
        self._callbacks.append(callback)

    def get_state(self) -> Dict[str, Any]:
        """Obtener estado actual completo."""
        with self._lock:
            return dict(self._state)

    def get_value(self, key: str, default=None):
        """Obtener un valor específico del estado."""
        with self._lock:
            return self._state.get(key, default)

    def set_value(self, key: str, value: Any):
        """Establecer un valor en el estado."""
        with self._lock:
            self._state[key] = value

    def add_task(self, task: str):
        """Añadir tarea activa."""
        with self._lock:
            if task not in self._state['active_tasks']:
                self._state['active_tasks'].append(task)

    def remove_task(self, task: str):
        """Remover tarea activa."""
        with self._lock:
            if task in self._state['active_tasks']:
                self._state['active_tasks'].remove(task)

    def update_interaction(self):
        """Actualizar timestamp de última interacción."""
        self._last_interaction = time.time()
        with self._lock:
            self._state['last_interaction'] = datetime.now().isoformat()
            self._state['user_presence'] = True

    def get_status_report(self) -> str:
        """Generar reporte de estado formateado para JARVIS."""
        state = self.get_state()
        cpu = state['cpu_usage']
        mem = state['memory_usage']
        disk = state['disk_usage']
        health = state['system_health']
        mood = state['mood']

        return (f"CPU: {cpu:.1f}% | RAM: {mem:.1f}% | "
                f"Disco: {disk:.1f}% | Salud: {health}% | Estado: {mood}")
