"""
JARVIS v7.0 - User Identity System
Gestión de identidad de usuario con reconocimiento del creador.
Creador: Ali (Sidi3Ali)
"""

import logging
import os
import sqlite3
import json
import getpass
import socket
import threading
from datetime import datetime
from typing import Optional, Dict, Any

logger = logging.getLogger('JARVIS.UserIdentity')

DB_PATH = os.path.join(os.path.dirname(os.path.dirname(__file__)), 'memory', 'user_profiles.db')

# ── IDENTIDAD DEL CREADOR ────────────────────────────────────────────────────
CREATOR_IDENTITY = {
    "name": "Ali",
    "alias": "Sidi3Ali",
    "creator_flag": True,
    "watermark": "JARVIS v7.0 — Created by Ali (Sidi3Ali)",
    "priority_level": "MAXIMUM",
    "autonomy_level": "FULL",
    "access_level": "UNRESTRICTED",
}


class UserIdentitySystem:
    """
    Sistema de identidad de usuario.
    - Detecta automáticamente el usuario de Windows
    - Reconoce al creador Ali (Sidi3Ali) con privilegios máximos
    - En primer inicio pregunta nombre preferido, idioma, formalidad
    - Persiste perfiles en SQLite
    """

    def __init__(self):
        self.db_path = DB_PATH
        self._conn: Optional[sqlite3.Connection] = None
        self._lock = threading.Lock()
        self._current_user: Optional[Dict] = None
        self._initialize_db()

    def _initialize_db(self):
        os.makedirs(os.path.dirname(self.db_path), exist_ok=True)
        self._conn = sqlite3.connect(self.db_path, check_same_thread=False)
        self._conn.row_factory = sqlite3.Row
        self._create_tables()

    def _create_tables(self):
        with self._lock:
            self._conn.executescript("""
                CREATE TABLE IF NOT EXISTS user_profiles (
                    user_id INTEGER PRIMARY KEY AUTOINCREMENT,
                    windows_username TEXT UNIQUE NOT NULL,
                    preferred_name TEXT NOT NULL,
                    hostname TEXT,
                    creator_flag INTEGER DEFAULT 0,
                    language TEXT DEFAULT 'es',
                    formality TEXT DEFAULT 'formal',
                    voice_name TEXT DEFAULT 'es-ES-AlvaroNeural',
                    interaction_style TEXT DEFAULT 'JARVIS',
                    created_at TEXT,
                    last_seen TEXT,
                    extra_data TEXT
                );

                CREATE TABLE IF NOT EXISTS creator_metadata (
                    key TEXT PRIMARY KEY,
                    value TEXT NOT NULL
                );
            """)
            # Insertar metadatos del creador
            for k, v in CREATOR_IDENTITY.items():
                self._conn.execute(
                    "INSERT OR REPLACE INTO creator_metadata (key, value) VALUES (?, ?)",
                    (k, str(v))
                )
            self._conn.commit()

    def detect_windows_user(self) -> str:
        """Detectar usuario de Windows actual."""
        try:
            return getpass.getuser()
        except Exception:
            return os.environ.get('USERNAME', os.environ.get('USER', 'usuario'))

    def get_hostname(self) -> str:
        try:
            return socket.gethostname()
        except Exception:
            return 'PC'

    def is_creator(self, windows_username: str, preferred_name: str = '') -> bool:
        """
        Determinar si este usuario es Ali (el creador).
        Comprueba por username, nombre preferido o alias.
        """
        name_lower = preferred_name.lower()
        user_lower = windows_username.lower()
        creator_indicators = ['ali', 'sidi3ali', 'sidi_3ali', 'sidi 3ali']
        return any(ind in user_lower or ind in name_lower for ind in creator_indicators)

    def load_or_create_profile(self, voice=None) -> Dict:
        """
        Cargar perfil del usuario actual o crear uno nuevo si es el primer inicio.
        Pregunta por voz si voice está disponible.
        """
        windows_user = self.detect_windows_user()
        hostname = self.get_hostname()

        with self._lock:
            row = self._conn.execute(
                "SELECT * FROM user_profiles WHERE windows_username = ?",
                (windows_user,)
            ).fetchone()

        if row:
            profile = dict(row)
            # Actualizar last_seen
            with self._lock:
                self._conn.execute(
                    "UPDATE user_profiles SET last_seen = ? WHERE windows_username = ?",
                    (datetime.now().isoformat(), windows_user)
                )
                self._conn.commit()
            self._current_user = profile
            logger.info(f"Perfil cargado: {profile['preferred_name']} (creator={profile['creator_flag']})")
            return profile

        # ── Primer inicio en este PC ─────────────────────────────────────────
        logger.info(f"Primer inicio detectado para usuario: {windows_user}")
        profile = self._first_time_setup(windows_user, hostname, voice)
        self._current_user = profile
        return profile

    def _first_time_setup(self, windows_user: str, hostname: str, voice=None) -> Dict:
        """
        Configuración inicial: preguntar nombre, idioma, formalidad.
        Usa voz si disponible, sino consola.
        """

        def say(text: str):
            if voice:
                try:
                    voice.speak(text, priority=True)
                except Exception:
                    pass
            print(f"\nJARVIS > {text}")

        def ask(question: str) -> str:
            say(question)
            try:
                return input("Tú > ").strip()
            except Exception:
                return ""

        say("Sistema JARVIS v7.0 iniciado. Primer uso detectado en este equipo.")
        say("Necesito conocerte para personalizar mi asistencia.")

        preferred_name = ask("¿Cómo deseas que te llame?") or windows_user
        language = ask("¿Idioma preferido? Español o English?") or "español"
        formality_raw = ask("¿Prefieres trato formal (Señor) o informal (por nombre)?") or "formal"
        formality = "formal" if "formal" in formality_raw.lower() else "informal"

        creator_flag = 1 if self.is_creator(windows_user, preferred_name) else 0

        if creator_flag:
            say(f"Bienvenido, Ali. Identidad de creador verificada. Acceso completo concedido.")
        else:
            say(f"Encantado de conocerte, {preferred_name}. Configuración completada.")

        now = datetime.now().isoformat()
        profile = {
            'windows_username': windows_user,
            'preferred_name': preferred_name,
            'hostname': hostname,
            'creator_flag': creator_flag,
            'language': 'es' if 'español' in language.lower() or 'spanish' in language.lower() else 'en',
            'formality': formality,
            'voice_name': 'es-ES-AlvaroNeural',
            'interaction_style': 'JARVIS',
            'created_at': now,
            'last_seen': now,
            'extra_data': json.dumps({}),
        }

        with self._lock:
            self._conn.execute(
                """INSERT OR REPLACE INTO user_profiles
                   (windows_username, preferred_name, hostname, creator_flag, language,
                    formality, voice_name, interaction_style, created_at, last_seen, extra_data)
                   VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)""",
                (profile['windows_username'], profile['preferred_name'], profile['hostname'],
                 profile['creator_flag'], profile['language'], profile['formality'],
                 profile['voice_name'], profile['interaction_style'],
                 profile['created_at'], profile['last_seen'], profile['extra_data'])
            )
            self._conn.commit()

        return profile

    def get_current_user(self) -> Optional[Dict]:
        return self._current_user

    def get_preferred_name(self) -> str:
        if self._current_user:
            return self._current_user.get('preferred_name', 'Señor')
        return 'Señor'

    def is_current_user_creator(self) -> bool:
        if self._current_user:
            return bool(self._current_user.get('creator_flag', 0))
        return False

    def get_formality(self) -> str:
        if self._current_user:
            return self._current_user.get('formality', 'formal')
        return 'formal'

    def update_preference(self, key: str, value: Any):
        """Actualizar preferencia del usuario actual."""
        if not self._current_user:
            return
        win_user = self._current_user['windows_username']
        try:
            with self._lock:
                self._conn.execute(
                    f"UPDATE user_profiles SET {key} = ? WHERE windows_username = ?",
                    (str(value), win_user)
                )
                self._conn.commit()
            self._current_user[key] = value
        except Exception as e:
            logger.debug(f"Error actualizando preferencia {key}: {e}")

    def get_creator_metadata(self) -> Dict:
        """Obtener metadatos del creador (nunca eliminables)."""
        return CREATOR_IDENTITY.copy()

    def get_address_form(self) -> str:
        """
        Cómo dirigirse al usuario según formalidad.
        Si es el creador, usa 'Ali'.
        Si formal → 'Señor'.
        Si informal → nombre preferido.
        """
        if not self._current_user:
            return 'Señor'
        if self.is_current_user_creator():
            return 'Ali'
        formality = self._current_user.get('formality', 'formal')
        if formality == 'formal':
            return 'Señor'
        return self._current_user.get('preferred_name', 'Señor')

    def close(self):
        if self._conn:
            try:
                self._conn.close()
            except Exception:
                pass


# Instancia global
_identity_system: Optional[UserIdentitySystem] = None


def get_identity() -> UserIdentitySystem:
    global _identity_system
    if _identity_system is None:
        _identity_system = UserIdentitySystem()
    return _identity_system
