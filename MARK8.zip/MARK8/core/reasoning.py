"""
MARK 8 - Reasoning Engine
==========================================
Motor de razonamiento completo. Usa NLU para entender TODO.
"""

import re
import os
import json
import logging
import random
import subprocess
from typing import Optional, List, Dict, Any, Tuple
from datetime import datetime

logger = logging.getLogger('MARK.Reason')


class LocalKnowledge:
    """Base de conocimiento local extenso."""

    TECH = {
        'python': {
            'desc': "Python: legible, versátil, ecosistema enorme. Domina en IA/ML, data science, scripting y backend.",
            'pros': "Sintaxis clara, pandas/numpy/sklearn, FastAPI, Django. El mejor para empezar.",
            'cons': "Más lento que compilados. GIL limita threads. No ideal para apps móviles nativas.",
            'opinion': "Python es la navaja suiza. Para la mayoría de proyectos es la elección correcta.",
        },
        'javascript': {
            'desc': "JavaScript: único lenguaje nativo del navegador. Con Node.js también en backend.",
            'pros': "Omnipresente en web. React/Vue/Angular. npm tiene millones de paquetes.",
            'cons': "Caótico sin TypeScript. Inconsistencias históricas.",
            'opinion': "Para web frontend, obligatorio. TypeScript mejora la experiencia en proyectos grandes.",
        },
        'typescript': {
            'desc': "TypeScript = JavaScript con tipos estáticos. Desarrollado por Microsoft.",
            'pros': "Detecta errores en compilación. Mejor autocompletado. Más mantenible.",
            'cons': "Más verbose. Requiere compilación.",
            'opinion': "En proyectos medianos/grandes, TypeScript siempre.",
        },
        'rust': {
            'desc': "Rust: velocidad de C/C++ con seguridad de memoria garantizada en compilación.",
            'pros': "Sin GC. Sin segfaults. Concurrencia segura. Rendimiento top.",
            'cons': "Curva muy pronunciada. Borrow checker complejo.",
            'opinion': "El futuro para sistemas. Si necesita velocidad y seguridad, es la elección.",
        },
        'java': {
            'desc': "Java: verbose pero robusto. Plataforma empresarial con JVM.",
            'pros': "Enterprise grade. Android nativo. Spring Boot. Ecosistema maduro.",
            'cons': "Muy verbose. Boilerplate excesivo.",
            'opinion': "Para enterprise y Android está bien. Python o Kotlin suelen ser más productivos.",
        },
        'kotlin': {
            'desc': "Kotlin: Java moderno y conciso. Lenguaje oficial de Android.",
            'pros': "Conciso vs Java. Null safety. Coroutines. Interop con Java.",
            'cons': "Compilación más lenta.",
            'opinion': "Si hace Android o Java, Kotlin siempre sobre Java puro.",
        },
        'go': {
            'desc': "Go (Golang): compilado, tipado, concurrencia nativa con goroutines.",
            'pros': "Binarios únicos. Concurrencia simple. Docker/Kubernetes/Terraform en Go.",
            'cons': "Error handling verbose. Menos expresivo.",
            'opinion': "Excelente para microservicios y herramientas de sistemas.",
        },
        'react': {
            'desc': "React: librería de UI de Facebook. Componentes, Virtual DOM.",
            'pros': "Más popular para frontend. React Native para móvil. Ecosistema enorme.",
            'cons': "Solo UI (necesita otras libs).",
            'opinion': "El estándar de facto para frontend. Si va a buscar trabajo en web, React.",
        },
        'vue': {
            'desc': "Vue.js: framework progresivo, más fácil que React.",
            'pros': "Curva de aprendizaje suave. Documentación excelente.",
            'cons': "Menos demanda laboral que React.",
            'opinion': "Para proyectos personales, Vue es un placer. Para empresa, React.",
        },
        'django': {
            'desc': "Django: framework web Python completo. 'Batteries included'.",
            'pros': "Admin automático. ORM potente. Seguridad por defecto.",
            'cons': "Monolítico. Sobredimensionado para APIs simples.",
            'opinion': "Para web apps completas con BD y admin, Django es imbatible.",
        },
        'fastapi': {
            'desc': "FastAPI: framework Python moderno para APIs. Async nativo, tipado.",
            'pros': "Muy rápido. Documentación automática. Async.",
            'cons': "Ecosistema más pequeño que Django.",
            'opinion': "Para APIs REST modernas, FastAPI es la mejor opción en Python.",
        },
        'docker': {
            'desc': "Docker: contenedores. Mismo entorno en desarrollo y producción.",
            'pros': "Reproducibilidad. Despliegue fácil. Aislamiento.",
            'cons': "Overhead de aprendizaje.",
            'opinion': "Si trabaja en equipo o despliega en servidor, Docker es esencial.",
        },
        'git': {
            'desc': "Git: control de versiones. Esencial para cualquier proyecto.",
            'pros': "Historial completo. Ramas para features. Colaboración.",
            'cons': "Curva inicial para merge/rebase.",
            'opinion': "Git es obligatorio. Sin excusas.",
        },
        'linux': {
            'desc': "Linux: sistema operativo open source. Base de servidores.",
            'pros': "Gratuito. Servidores (99% web). Terminal potente.",
            'cons': "Compatibilidad limitada con software comercial.",
            'opinion': "Para desarrollo, Linux o Mac. Para servidores, siempre Linux.",
        },
    }

    CONVERSATIONAL = {
        'greetings': [
            "Presente. ¿Qué necesita, Señor?",
            "Aquí. ¿En qué puedo asistirle?",
            "Online. ¿Qué tiene en mente?",
            "A su servicio. ¿Qué ocurre?",
            "Sistema activo. ¿En qué le ayudo?",
            "Listo. ¿Qué necesita?",
        ],
        'greetings_morning': [
            "Buenos días, Señor. ¿Empezamos bien el día?",
            "Mañana detectada. Sistema listo.",
            "Buenos días. ¿Qué toca hoy?",
        ],
        'greetings_night': [
            "Buenas noches. ¿Trabajando tarde?",
            "Noche detectada. ¿Proyecto urgente o insomnio?",
            "Todavía en pie. ¿Qué necesita?",
            "Madrugada de productividad. ¿En qué le ayudo?",
        ],
        'thanks': [
            "Sin problema.", "De nada.", "A su disposición.",
            "Es lo que hago.", "Para eso estoy, Señor.",
        ],
        'farewell': [
            "Hasta luego. Sistema en standby.",
            "Que descanse, Señor.",
            "Nos vemos. Sistema en espera.",
        ],
        'identity': [
            "MARK 8 — Sistema autónomo cognitivo, creado por Ali (Sidi3Ali). A sus órdenes.",
            "Soy MARK 8, el asistente autónomo de Ali. Sistema cognitivo completo.",
            "MARK 8. Fully Autonomous Cognitive System. Creado por Sidi3Ali.",
        ],
        'capabilities': ["""MARK 8 puede:
• Cognitive Loop: percibo y actúo autónomamente en tiempo real
• Sistema: CPU/RAM, apps, volumen, capturas, control de UI
• Medios: Spotify, YouTube, música contextual automática
• Web: búsquedas, noticias, investigación
• Código: generar, analizar, ejecutar scripts Python
• Archivos: Word/PDF/TXT/CSV — leer, mejorar, resumir
• WhatsApp: enviar mensajes automáticamente
• Audio: grabar y transcribir con autorización
• Autostart: iniciarme con Windows
• IA: preguntas libres, razonamiento, redacción

Hable en lenguaje natural. Sin comandos exactos."""],
    }

    def get_tech_info(self, text: str) -> Optional[str]:
        tl = text.lower()
        opinion_words = ['opinas', 'piensas', 'recomiendas', 'mejor', 'bueno', 'ventajas',
                          'desventajas', 'pros', 'contras', 'vale la pena', 'aprendo', 'aprender']

        # Comparaciones entre tecnologías
        found_techs = [t for t in self.TECH if t in tl]
        if len(found_techs) >= 2:
            parts = []
            for t in found_techs[:3]:
                d = self.TECH[t]
                opinion = d.get('opinion', d.get('desc', ''))
                parts.append(f"**{t.upper()}**: {opinion}")
            return '\n'.join(parts) + "\n\n¿Para qué proyecto lo necesita?"

        # Tecnología única
        for tech_name, data in self.TECH.items():
            if tech_name in tl:
                has_opinion = any(w in tl for w in opinion_words)
                if has_opinion:
                    parts = []
                    if 'opinion' in data:
                        parts.append(data['opinion'])
                    if 'pros' in data:
                        parts.append(f"Ventajas: {data['pros']}")
                    if 'cons' in data:
                        parts.append(f"Contras: {data['cons']}")
                    return '\n'.join(parts)
                else:
                    return data['desc']
        return None


class ActionExecutor:
    """Ejecuta acciones del sistema operativo."""

    APPS = {
        'chrome': 'chrome', 'chromium': 'chromium', 'firefox': 'firefox',
        'edge': 'msedge', 'brave': 'brave',
        'vscode': 'code', 'vs code': 'code', 'code': 'code',
        'notepad': 'notepad', 'notepad++': 'notepad++',
        'terminal': 'cmd', 'cmd': 'cmd', 'powershell': 'powershell',
        'spotify': 'spotify', 'vlc': 'vlc', 'discord': 'discord',
        'steam': 'steam', 'telegram': 'telegram',
        'calculadora': 'calc', 'calculator': 'calc', 'calc': 'calc',
        'paint': 'mspaint', 'explorer': 'explorer',
        'word': 'winword', 'excel': 'excel', 'powerpoint': 'powerpnt',
        'gimp': 'gimp', 'obs': 'obs', 'zoom': 'zoom', 'slack': 'slack',
    }

    def open_app(self, app_name: str) -> str:
        import platform
        al = app_name.lower().strip()
        exe = self.APPS.get(al, al)
        try:
            if platform.system() == 'Windows':
                subprocess.Popen(exe, shell=True, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
            else:
                subprocess.Popen([exe], stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
            return f"'{app_name.capitalize()}' iniciado."
        except Exception:
            return f"No encontré '{app_name}'. ¿Está instalado?"

    def open_url(self, url: str) -> str:
        import webbrowser
        if not url.startswith('http'):
            url = 'https://' + url
        webbrowser.open(url)
        return f"Abriendo {url}"

    def search_web(self, query: str) -> str:
        import webbrowser, urllib.parse
        webbrowser.open('https://www.google.com/search?q=' + urllib.parse.quote(query))
        return f"Buscando '{query}' en Google."

    def open_youtube(self, query: str) -> str:
        import webbrowser, urllib.parse
        webbrowser.open('https://www.youtube.com/results?search_query=' + urllib.parse.quote(query))
        return f"Buscando '{query}' en YouTube."

    def get_system_info(self) -> str:
        try:
            import psutil, platform
            cpu = psutil.cpu_percent(interval=0.5)
            mem = psutil.virtual_memory()
            disk = psutil.disk_usage('/')
            return (f"Sistema: {platform.system()} {platform.release()}\n"
                    f"CPU: {cpu:.1f}% ({psutil.cpu_count()} núcleos)\n"
                    f"RAM: {mem.percent:.1f}% ({mem.used/1e9:.1f}GB / {mem.total/1e9:.1f}GB)\n"
                    f"Disco: {disk.percent:.1f}% ({disk.free/1e9:.1f}GB libres)\n"
                    f"Procesos: {len(psutil.pids())}")
        except Exception as e:
            return f"Error: {e}"

    def set_volume(self, action: str, level: Optional[int] = None) -> str:
        import platform
        sys = platform.system()
        try:
            if sys == 'Windows':
                try:
                    from ctypes import cast, POINTER
                    from comtypes import CLSCTX_ALL
                    from pycaw.pycaw import AudioUtilities, IAudioEndpointVolume
                    devices = AudioUtilities.GetSpeakers()
                    iface = devices.Activate(IAudioEndpointVolume._iid_, CLSCTX_ALL, None)
                    vol = cast(iface, POINTER(IAudioEndpointVolume))
                    if action == 'mute':
                        vol.SetMute(1, None); return "Silenciado."
                    elif level is not None:
                        vol.SetMasterVolumeLevelScalar(max(0.0, min(1.0, level/100)), None)
                        return f"Volumen al {level}%."
                    elif action == 'up':
                        cur = vol.GetMasterVolumeLevelScalar()
                        vol.SetMasterVolumeLevelScalar(min(1.0, cur + 0.1), None)
                        return f"Volumen subido al {int(min(1.0, cur+0.1)*100)}%."
                    elif action == 'down':
                        cur = vol.GetMasterVolumeLevelScalar()
                        vol.SetMasterVolumeLevelScalar(max(0.0, cur - 0.1), None)
                        return f"Volumen bajado al {int(max(0.0, cur-0.1)*100)}%."
                except ImportError:
                    # Fallback nircmd
                    cmd = {'mute': ['nircmd.exe', 'mutesysvolume', '1'],
                            'up': ['nircmd.exe', 'changesysvolume', '6553'],
                            'down': ['nircmd.exe', 'changesysvolume', '-6553']}.get(action, [])
                    if cmd:
                        subprocess.run(cmd, check=False, capture_output=True)
                        return f"Volumen {action}."
            elif sys == 'Linux':
                cmds = {'mute': 'amixer set Master mute', 'up': 'amixer set Master 10%+',
                         'down': 'amixer set Master 10%-'}
                if level is not None:
                    os.system(f'amixer set Master {level}%'); return f"Volumen al {level}%."
                elif action in cmds:
                    os.system(cmds[action]); return f"Volumen {action}."
        except Exception as e:
            logger.debug(f"Volume: {e}")
        return f"Comando de volumen enviado ({action})."

    def take_screenshot(self) -> str:
        import platform
        ts = datetime.now().strftime('%Y%m%d_%H%M%S')
        fp = os.path.expanduser(f'~/Desktop/screenshot_{ts}.png')
        sys = platform.system()
        try:
            if sys == 'Windows':
                try:
                    import pyautogui
                    pyautogui.screenshot(fp); return f"Captura: {fp}"
                except ImportError:
                    subprocess.run(['snippingtool', '/clip'], shell=True)
                    return "Herramienta de recorte abierta."
            elif sys == 'Linux':
                subprocess.run(['scrot', fp]); return f"Captura: {fp}"
            elif sys == 'Darwin':
                subprocess.run(['screencapture', fp]); return f"Captura: {fp}"
        except Exception as e:
            return f"Error captura: {e}"
        return "Captura intentada."


class FileProcessor:
    """Lee y procesa cualquier tipo de archivo."""

    SUPPORTED_EXT = {'docx', 'doc', 'pdf', 'txt', 'md', 'py', 'js', 'ts',
                      'html', 'css', 'json', 'xml', 'csv', 'xlsx', 'xls',
                      'jpg', 'jpeg', 'png', 'gif', 'cpp', 'c', 'java', 'go',
                      'rb', 'php', 'rs', 'swift', 'kt', 'sh', 'bat', 'ps1'}

    def read(self, filepath: str) -> Tuple[Optional[str], str]:
        """Lee archivo. Devuelve (content, file_type)."""
        # Buscar el archivo
        if not os.path.exists(filepath):
            for d in ['/mnt/user-data/uploads', 'uploads',
                       os.path.expanduser('~/Downloads'),
                       os.path.expanduser('~/Desktop')]:
                cand = os.path.join(d, os.path.basename(filepath))
                if os.path.exists(cand):
                    filepath = cand
                    break
            else:
                return None, "not_found"

        ext = filepath.rsplit('.', 1)[-1].lower() if '.' in filepath else ''

        try:
            # Texto plano / código
            if ext in {'txt', 'md', 'html', 'css', 'py', 'js', 'ts', 'json',
                        'xml', 'sh', 'bat', 'ps1', 'cpp', 'c', 'java', 'go',
                        'rb', 'php', 'rs', 'swift', 'kt'}:
                for enc in ['utf-8', 'latin-1', 'cp1252']:
                    try:
                        with open(filepath, 'r', encoding=enc) as f:
                            return f.read(), ext.upper()
                    except UnicodeDecodeError:
                        continue

            elif ext == 'docx':
                try:
                    import docx
                    doc = docx.Document(filepath)
                    parts = [p.text for p in doc.paragraphs if p.text.strip()]
                    for table in doc.tables:
                        for row in table.rows:
                            row_text = ' | '.join(c.text.strip() for c in row.cells if c.text.strip())
                            if row_text:
                                parts.append(row_text)
                    return '\n'.join(parts), 'Word Document'
                except ImportError:
                    return "[Instale python-docx: pip install python-docx]", 'Word Document'

            elif ext == 'pdf':
                for lib in ['pypdf2', 'pdfminer']:
                    try:
                        if lib == 'pypdf2':
                            import PyPDF2
                            with open(filepath, 'rb') as f:
                                r = PyPDF2.PdfReader(f)
                                return '\n'.join(p.extract_text() or '' for p in r.pages), 'PDF'
                        else:
                            import pdfminer.high_level
                            return pdfminer.high_level.extract_text(filepath), 'PDF'
                    except ImportError:
                        continue
                return "[Instale PyPDF2: pip install PyPDF2]", 'PDF'

            elif ext == 'csv':
                import csv
                rows = []
                with open(filepath, 'r', encoding='utf-8', errors='replace') as f:
                    for i, row in enumerate(csv.reader(f)):
                        if i > 200: rows.append("..."); break
                        rows.append(' | '.join(row))
                return '\n'.join(rows), 'CSV'

            elif ext in {'xlsx', 'xls'}:
                try:
                    import openpyxl
                    wb = openpyxl.load_workbook(filepath, read_only=True, data_only=True)
                    sheets = []
                    for sn in wb.sheetnames[:3]:
                        ws = wb[sn]
                        rows = []
                        for i, row in enumerate(ws.iter_rows(values_only=True)):
                            if i > 200: break
                            rt = ' | '.join(str(c) if c is not None else '' for c in row)
                            if rt.strip('| '): rows.append(rt)
                        sheets.append(f"[Hoja: {sn}]\n" + '\n'.join(rows))
                    return '\n\n'.join(sheets), 'Excel'
                except ImportError:
                    return "[Instale openpyxl: pip install openpyxl]", 'Excel'

            elif ext in {'jpg', 'jpeg', 'png', 'gif'}:
                size = os.path.getsize(filepath)
                try:
                    from PIL import Image
                    img = Image.open(filepath)
                    return (f"[Imagen: {img.size[0]}x{img.size[1]}px, {size/1024:.1f}KB]\n"
                            f"Formato: {img.format}, Modo: {img.mode}"), 'Image'
                except ImportError:
                    return f"[Imagen: {os.path.basename(filepath)}, {size/1024:.1f}KB]", 'Image'

        except Exception as e:
            return f"Error leyendo archivo: {e}", ext.upper()

        return None, ext.upper()

    def find_latest_upload(self) -> Optional[str]:
        candidates = []
        for d in ['/mnt/user-data/uploads', 'uploads',
                   os.path.expanduser('~/Downloads')]:
            if os.path.exists(d):
                for f in os.listdir(d):
                    fp = os.path.join(d, f)
                    if os.path.isfile(fp):
                        ext = f.rsplit('.', 1)[-1].lower() if '.' in f else ''
                        if ext in self.SUPPORTED_EXT:
                            candidates.append((os.path.getmtime(fp), fp))
        return max(candidates, key=lambda x: x[0])[1] if candidates else None


class CodeGenerator:
    """Genera scripts Python y código."""

    TEMPLATES = {
        'calculadora': '''#!/usr/bin/env python3
"""Calculadora con historial - generada por MARK."""

def calcular(a, b, op):
    if op == '+': return a + b
    if op == '-': return a - b
    if op == '*': return a * b
    if op == '/' and b != 0: return a / b
    if op == '/' and b == 0: return "Error: división por cero"
    if op == '**' or op == '^': return a ** b
    if op == '%': return a % b
    return f"Operador '{op}' no reconocido"

historial = []
print("Calculadora MARK | Ops: + - * / ** % | 'q' para salir | 'hist' para historial")
while True:
    try:
        ent = input("> ").strip()
        if ent.lower() in ('q', 'salir', 'exit'): break
        if ent.lower() == 'hist':
            print("Historial:", *historial[-10:], sep="\\n  ") if historial else print("  Sin historial.")
            continue
        partes = ent.split()
        if len(partes) == 3:
            a, op, b = float(partes[0]), partes[1], float(partes[2])
            res = calcular(a, b, op)
        else:
            res = eval(ent, {"__builtins__": {}})
        print(f"  = {res}")
        historial.append(f"{ent} = {res}")
    except Exception as e:
        print(f"  Error: {e}")
''',
        'organizador': '''#!/usr/bin/env python3
"""Organizador de archivos por tipo - generado por MARK."""
import os, shutil
from pathlib import Path

CATEGORIAS = {
    'Imágenes': {'.jpg', '.jpeg', '.png', '.gif', '.bmp', '.svg', '.webp'},
    'Documentos': {'.pdf', '.docx', '.doc', '.txt', '.xlsx', '.pptx', '.odt'},
    'Código': {'.py', '.js', '.ts', '.html', '.css', '.java', '.cpp', '.go', '.rs'},
    'Vídeos': {'.mp4', '.avi', '.mkv', '.mov', '.wmv'},
    'Audio': {'.mp3', '.wav', '.flac', '.aac', '.ogg'},
    'Comprimidos': {'.zip', '.rar', '.7z', '.tar', '.gz'},
}

def organizar(directorio="."):
    base = Path(directorio)
    movidos = 0
    for f in base.iterdir():
        if f.is_file() and not f.name.startswith('.'):
            ext = f.suffix.lower()
            cat = next((c for c, exts in CATEGORIAS.items() if ext in exts), 'Otros')
            dest = base / cat
            dest.mkdir(exist_ok=True)
            shutil.move(str(f), dest / f.name)
            print(f"  {f.name} → {cat}/")
            movidos += 1
    print(f"\\n✓ {movidos} archivos organizados")

import sys
organizar(sys.argv[1] if len(sys.argv) > 1 else ".")
''',
        'monitor_sistema': '''#!/usr/bin/env python3
"""Monitor del sistema en tiempo real - generado por MARK."""
import time, psutil, os

def limpiar():
    os.system('cls' if os.name == 'nt' else 'clear')

print("Monitor del Sistema MARK | Ctrl+C para salir")
try:
    while True:
        limpiar()
        cpu = psutil.cpu_percent(interval=1)
        mem = psutil.virtual_memory()
        disk = psutil.disk_usage('/')
        procs = sorted(psutil.process_iter(['name', 'cpu_percent', 'memory_percent']),
                        key=lambda p: p.info['cpu_percent'], reverse=True)
        
        print(f"{'='*50}")
        print(f"CPU:   {cpu:5.1f}%  {'█'*int(cpu/5)}")
        print(f"RAM:   {mem.percent:5.1f}%  {mem.used/1e9:.1f}/{mem.total/1e9:.1f}GB")
        print(f"Disco: {disk.percent:5.1f}%  {disk.free/1e9:.1f}GB libres")
        print(f"{'='*50}")
        print("Top procesos:")
        for p in procs[:5]:
            try:
                print(f"  {p.info['name'][:20]:<20} CPU:{p.info['cpu_percent']:5.1f}% RAM:{p.info['memory_percent']:4.1f}%")
            except: pass
        print(f"{'='*50}")
        print("[Actualizando cada 2s | Ctrl+C para salir]")
        time.sleep(2)
except KeyboardInterrupt:
    print("\\nMonitor detenido.")
''',
        'descargar_video': '''#!/usr/bin/env python3
"""Descargador de vídeos de YouTube - generado por MARK."""
# Requiere: pip install yt-dlp
import subprocess, sys

def descargar(url, formato='mp4', calidad='best'):
    cmd = ['yt-dlp', '-f', f'bestvideo[ext={formato}]+bestaudio/best[ext={formato}]/best',
           '--merge-output-format', formato, url]
    print(f"Descargando: {url}")
    result = subprocess.run(cmd, capture_output=False)
    return result.returncode == 0

if __name__ == "__main__":
    url = sys.argv[1] if len(sys.argv) > 1 else input("URL del vídeo: ").strip()
    if descargar(url):
        print("✓ Descargado correctamente")
    else:
        print("✗ Error al descargar. ¿Está yt-dlp instalado? (pip install yt-dlp)")
''',
        'api_rest': '''#!/usr/bin/env python3
"""API REST básica con FastAPI - generada por MARK."""
# Requiere: pip install fastapi uvicorn
from fastapi import FastAPI, HTTPException
from pydantic import BaseModel
from typing import List, Optional
import uvicorn

app = FastAPI(title="Mi API", version="1.0.0")

# Modelo de datos
class Item(BaseModel):
    id: Optional[int] = None
    nombre: str
    descripcion: Optional[str] = None
    precio: float

# Base de datos en memoria
items_db: List[Item] = []
contador = 0

@app.get("/")
def raiz():
    return {"mensaje": "API funcionando", "items": len(items_db)}

@app.get("/items", response_model=List[Item])
def listar_items():
    return items_db

@app.post("/items", response_model=Item)
def crear_item(item: Item):
    global contador
    contador += 1
    item.id = contador
    items_db.append(item)
    return item

@app.get("/items/{item_id}", response_model=Item)
def obtener_item(item_id: int):
    item = next((i for i in items_db if i.id == item_id), None)
    if not item:
        raise HTTPException(404, "Item no encontrado")
    return item

@app.delete("/items/{item_id}")
def eliminar_item(item_id: int):
    global items_db
    items_db = [i for i in items_db if i.id != item_id]
    return {"eliminado": item_id}

if __name__ == "__main__":
    uvicorn.run(app, host="0.0.0.0", port=8000, reload=True)
    # Docs en: http://localhost:8000/docs
''',
    }

    def generate(self, description: str, ai_manager=None) -> str:
        desc_l = description.lower()

        # Buscar template
        template_map = {
            'calculadora': 'calculadora', 'calcul': 'calculadora',
            'organiza': 'organizador', 'orden': 'organizador',
            'monitor': 'monitor_sistema', 'sistema tiempo real': 'monitor_sistema',
            'descarga video': 'descargar_video', 'youtube descarga': 'descargar_video',
            'api': 'api_rest', 'rest': 'api_rest', 'fastapi': 'api_rest',
        }
        for keyword, template_key in template_map.items():
            if keyword in desc_l and template_key in self.TEMPLATES:
                code = self.TEMPLATES[template_key]
                fp = self._save(code, template_key)
                lines = code.count('\n')
                return (f"Script '{template_key}' generado ({lines} líneas) → {fp}\n\n"
                        f"```python\n{code[:600]}{'...' if len(code) > 600 else ''}\n```")

        # Usar IA
        if ai_manager:
            code = ai_manager.generate_code(description)
            if code and len(code) > 30:
                blocks = re.findall(r'```(?:python|py)?\n(.*?)```', code, re.DOTALL)
                actual = blocks[0].strip() if blocks else code.strip()
                name = re.sub(r'[^\w]', '_', description[:25].lower())
                fp = self._save(actual, name)
                lines = actual.count('\n')
                return (f"Script generado ({lines} líneas) → {fp}\n\n"
                        f"```python\n{actual[:700]}{'...' if len(actual) > 700 else ''}\n```")

        templates_list = ', '.join(self.TEMPLATES.keys())
        return (f"Para scripts personalizados necesito LM Studio activo (127.0.0.1:1234).\n"
                f"Templates listos sin IA: {templates_list}.\n"
                f"¿Quiere uno de esos?")

    def _save(self, code: str, name: str) -> str:
        workspace = os.path.join(os.path.dirname(os.path.dirname(__file__)), 'workspace')
        os.makedirs(workspace, exist_ok=True)
        safe = re.sub(r'[^\w\-]', '_', name)[:30]
        fp = os.path.join(workspace, f"{safe}.py")
        with open(fp, 'w', encoding='utf-8') as f:
            f.write(code)
        return fp


class DeepReasoner:
    """Motor de razonamiento principal."""

    def __init__(self, brain):
        self.brain       = brain
        self.knowledge   = LocalKnowledge()
        self.executor    = ActionExecutor()
        self.file_proc   = FileProcessor()
        self.code_gen    = CodeGenerator()
        self._history: List[Dict] = []
        # Estado de archivo actual
        self._file_path: Optional[str]    = None
        self._file_content: Optional[str] = None
        self._file_type: Optional[str]    = None
        self._last_greeting: Optional[str] = None

    def reason(self, user_input: str, nlu_result: Dict) -> str:
        """Punto de entrada principal — v7.0."""
        text   = user_input.strip()
        intent = nlu_result.get('intent', 'ai_chat')
        ents   = nlu_result.get('entities', {})
        ctx    = nlu_result.get('context', {})
        tone   = nlu_result.get('emotional_tone', 'neutral')

        # 0. Frustración
        if tone == 'frustrated':
            r = self._frustration()
            self._push(text, r)
            return r

        # 1. Conversación básica
        r = self._conversational(text, intent, ctx)
        if r:
            self._push(text, r)
            return r

        # v7.0 — Control de UI y aplicaciones
        r = self._ui_action(text)
        if r:
            self._push(text, r)
            return r

        # v7.0 — Spotify
        r = self._spotify_action(text)
        if r:
            self._push(text, r)
            return r

        # v7.0 — Audio monitor
        r = self._audio_action(text)
        if r:
            self._push(text, r)
            return r

        # v7.0 — Autostart
        r = self._startup_action(text)
        if r:
            self._push(text, r)
            return r

        # 2. Acciones del sistema
        r = self._system_action(text, intent, ents)
        if r:
            self._push(text, r)
            return r

        # 3. Archivos
        r = self._file_action(text, intent, ents)
        if r:
            self._push(text, r)
            return r

        # 4. Generación de código
        if intent == 'code_generate':
            r = self.code_gen.generate(
                ents.get('description', text),
                getattr(self.brain, 'ai_manager', None)
            )
            self._push(text, r)
            return r

        # 5. Conocimiento local
        r = self.knowledge.get_tech_info(text)
        if r:
            self._push(text, r)
            return r

        # 6. IA
        r = self._ask_ai(text, nlu_result)
        self._push(text, r)
        return r

    # ── v7.0 Handlers ───────────────────────────────────────────────────────

    def _ui_action(self, text: str) -> Optional[str]:
        """Manejar comandos de control de interfaz de usuario."""
        tl = text.lower()
        ui = getattr(self.brain, 'ui_control', None)
        if not ui:
            return None

        # WhatsApp
        if 'whatsapp' in tl and any(w in tl for w in ['envía', 'manda', 'escribe', 'responde', 'mensaje']):
            contact = 'mamá' if any(w in tl for w in ['mamá', 'mama', 'madre']) else \
                      'papá' if any(w in tl for w in ['papá', 'papa', 'padre']) else ''
            if contact:
                ok = ui.send_whatsapp_message(contact, text)
                return (f"Mensaje enviado por WhatsApp a {contact}." if ok
                        else "No pude enviar el mensaje. ¿Tiene WhatsApp abierto?")
            return "¿A quién desea enviar el mensaje de WhatsApp?"

        # Cerrar ventana
        if any(w in tl for w in ['cierra', 'cerrar']):
            for app in ['chrome', 'firefox', 'word', 'excel', 'notepad']:
                if app in tl:
                    ok = ui.close_window(app)
                    return f"Ventana {app} cerrada." if ok else f"No encontré una ventana de {app}."

        # Maximizar ventana
        if any(w in tl for w in ['maximiza', 'maximizar']):
            for app in ['chrome', 'firefox', 'word', 'excel', 'code', 'vscode']:
                if app in tl:
                    ui.maximize_window(app)
                    return f"Ventana {app} maximizada."

        # Listar ventanas
        if 'ventanas' in tl and any(w in tl for w in ['lista', 'qué', 'cuáles', 'abiertas']):
            windows = ui.get_all_windows()
            if windows:
                return "Ventanas abiertas: " + ", ".join(windows[:5]) + ("..." if len(windows) > 5 else ".")
            return "No detecté ventanas abiertas."

        # Click en texto de pantalla
        if any(w in tl for w in ['haz click en', 'clickea', 'pulsa']):
            import re as _re
            match = _re.search(r'(?:haz click en|clickea|pulsa)\s+["\']?(.+?)["\']?\s*$', tl)
            if match:
                target = match.group(1)
                vision = getattr(self.brain, 'vision', None)
                if vision:
                    pos = vision.find_text_on_screen(target)
                    if pos:
                        ui.click(pos[0], pos[1])
                        return f"Click realizado en '{target}'."
                return f"No encontré '{target}' en pantalla."

        return None

    def _spotify_action(self, text: str) -> Optional[str]:
        """Manejar comandos de Spotify."""
        tl = text.lower()
        spotify_kws = ['spotify', 'canción', 'reproducir música', 'pon música',
                       'pausar música', 'siguiente canción', 'anterior canción',
                       'playlist', 'lista de reproducción', 'volumen de spotify',
                       'qué suena', 'gustos musicales', 'recomienda música']
        if not any(w in tl for w in spotify_kws):
            return None

        spotify = getattr(self.brain, '_spotify', None)
        if not spotify:
            try:
                from skills.spotify_skill import SpotifySkill
                spotify = SpotifySkill(brain=self.brain)
                if self.brain:
                    self.brain._spotify = spotify
            except Exception:
                return None

        if any(w in tl for w in ['pausa', 'pausar', 'para la música', 'detén']):
            return spotify.pause()
        if any(w in tl for w in ['siguiente', 'skip', 'next']):
            return spotify.next_track()
        if any(w in tl for w in ['anterior', 'volver atrás', 'prev']):
            return spotify.previous_track()
        if any(w in tl for w in ['qué suena', 'canción actual', 'qué está sonando']):
            t = spotify.get_current_track()
            return (f"Sonando: '{t['title']}' de {t['artist']}." if t
                    else "No hay nada reproduciéndose en Spotify.")
        if any(w in tl for w in ['gustos', 'perfil musical', 'qué música me gusta']):
            return spotify.get_music_taste_summary()
        if any(w in tl for w in ['recomienda', 'sugiéreme', 'qué pongo']):
            return spotify.get_smart_recommendation()
        if 'playlist' in tl or 'lista de reproducción' in tl:
            import re as _re
            m = _re.search(r'(?:playlist|lista)\s+(?:llamada\s+)?["\']?(.+?)["\']?\s*$', tl)
            if m:
                return spotify.play_playlist_by_name(m.group(1))
            playlists = spotify.get_playlists(5)
            return ("Sus playlists: " + ", ".join(p['name'] for p in playlists[:5]) + "."
                    if playlists else "No encontré playlists.")
        # Reproducir algo
        if any(w in tl for w in ['reproduce', 'pon', 'poner', 'reproducir', 'escuchar']):
            import re as _re
            m = _re.search(r'(?:reproduce|pon|poner|reproducir|escuchar?)\s+(.+)', tl)
            query = m.group(1) if m else text
            return spotify.play(query=query)

        return None

    def _audio_action(self, text: str) -> Optional[str]:
        """Manejar comandos de grabación/transcripción de audio."""
        tl = text.lower()
        if not any(w in tl for w in ['graba audio', 'grabar audio', 'transcribe', 'monitoriza audio',
                                       'resumen de la llamada', 'transcripción', 'autoriza grabación']):
            return None

        monitor = getattr(self.brain, 'audio_monitor', None)
        if not monitor:
            return None

        if any(w in tl for w in ['autoriza', 'permiso para grabar']):
            ok = monitor.request_authorization()
            return ("Autorización concedida. Puedo grabar y transcribir audio." if ok
                    else "Autorización denegada.")

        if not monitor.is_authorized():
            return ("Para grabar audio necesito su autorización explícita. "
                    "Diga 'autoriza grabación de audio' para confirmar.")

        if any(w in tl for w in ['graba', 'grabar']):
            import re as _re
            secs = 30
            m = _re.search(r'(\d+)\s*(?:segundos|segs?)', tl)
            if m:
                secs = int(m.group(1))
            monitor.start_recording(duration=secs)
            return f"Grabando {secs} segundos. Transcribiré al finalizar."

        if 'transcribe' in tl or 'transcripción' in tl:
            recordings = monitor.get_recording_list()
            if recordings:
                t = monitor.transcribe_file(recordings[0]['path'])
                return f"Transcripción: {t}" if t else "No pude transcribir."
            return "No hay grabaciones disponibles."

        if 'resumen' in tl:
            recordings = monitor.get_recording_list()
            if recordings:
                t = monitor.transcribe_file(recordings[0]['path'])
                if t:
                    return f"Resumen: {monitor.summarize_transcription(t)}"
            return "No hay grabaciones para resumir."

        return None

    def _startup_action(self, text: str) -> Optional[str]:
        """Manejar comandos de inicio automático."""
        tl = text.lower()
        sm = getattr(self.brain, 'startup_manager', None)
        if not sm:
            return None

        startup_kws = ['inicio automático', 'autostart', 'iniciar con windows',
                       'arrancar con windows', 'ejecutar al inicio']
        if not any(k in tl for k in startup_kws):
            return None

        if any(w in tl for w in ['activa', 'habilita', 'instala', 'configura', 'pon', 'añade']):
            ok = sm.install_autostart()
            return ("JARVIS configurado para iniciarse con Windows." if ok
                    else "No pude configurar el inicio automático. Intenta ejecutar como administrador.")
        if any(w in tl for w in ['desactiva', 'elimina', 'quita', 'desinstala']):
            ok = sm.uninstall_autostart()
            return "Inicio automático desactivado." if ok else "No encontré inicio automático configurado."
        if any(w in tl for w in ['está', 'comprueba', 'verificar', 'activo']):
            enabled = sm.is_autostart_enabled()
            return ("El inicio automático está activado." if enabled
                    else "El inicio automático no está configurado. ¿Desea activarlo?")

    def load_file(self, filepath: str) -> str:
        """Carga un archivo."""
        content, ftype = self.file_proc.read(filepath)
        if content is None:
            latest = self.file_proc.find_latest_upload()
            if latest:
                content, ftype = self.file_proc.read(latest)
                filepath = latest

        if content is None:
            return (f"No encontré ningún archivo. "
                    f"Suba uno usando el botón 📎 en la interfaz, "
                    f"o indique la ruta completa.")

        self._file_path    = filepath
        self._file_content = content
        self._file_type    = ftype
        words = len(content.split())
        preview = content[:500] + ('...' if len(content) > 500 else '')

        return (f"📄 {os.path.basename(filepath)} ({ftype}, ~{words} palabras)\n\n"
                f"{preview}\n\n"
                f"Tengo el archivo cargado. Puedo: resumirlo, analizarlo, responder "
                f"preguntas, mejorarlo, corregirlo. ¿Qué necesita?")

    # ── Handlers ────────────────────────────────────────────

    def _conversational(self, text: str, intent: str, ctx: Dict) -> Optional[str]:
        hour = datetime.now().hour
        if intent == 'greeting':
            if 5 <= hour < 12:
                pool = self.knowledge.CONVERSATIONAL['greetings_morning']
            elif 20 <= hour or hour < 5:
                pool = self.knowledge.CONVERSATIONAL['greetings_night']
            else:
                pool = self.knowledge.CONVERSATIONAL['greetings']
            choices = [g for g in pool if g != self._last_greeting]
            g = random.choice(choices or pool)
            self._last_greeting = g
            return g

        if intent == 'farewell':
            return random.choice(self.knowledge.CONVERSATIONAL['farewell'])

        if intent == 'thanks':
            return random.choice(self.knowledge.CONVERSATIONAL['thanks'])

        if intent == 'identity':
            return random.choice(self.knowledge.CONVERSATIONAL['identity'])

        if intent == 'capabilities':
            return self.knowledge.CONVERSATIONAL['capabilities'][0]

        if intent == 'cancel':
            return random.choice(["Cancelado.", "De acuerdo.", "Entendido."])

        if intent == 'ai_status':
            ai = getattr(self.brain, 'ai_manager', None)
            return ai.get_status() if ai else "AI Manager no disponible."

        # Conversación libre sobre estado
        tl = text.lower()
        if any(w in tl for w in ['cómo estás', 'estás bien', 'sigues ahí', 'todo bien', 'estás ahí']):
            return self._status_natural_mark8()

        if any(w in tl for w in ['hora', 'qué hora', 'fecha', 'qué día', 'hoy']):
            now = datetime.now()
            days_es = ['lunes', 'martes', 'miércoles', 'jueves', 'viernes', 'sábado', 'domingo']
            months_es = ['enero', 'febrero', 'marzo', 'abril', 'mayo', 'junio',
                          'julio', 'agosto', 'septiembre', 'octubre', 'noviembre', 'diciembre']
            return (f"Son las {now.strftime('%H:%M')} del "
                    f"{days_es[now.weekday()]} {now.day} de {months_es[now.month-1]} de {now.year}.")

        if any(w in tl for w in ['chiste', 'cuéntame algo', 'hazme reír']):
            return random.choice([
                "¿Por qué los programadores prefieren el modo oscuro? Porque la luz atrae bugs.",
                "Un QA entra a un bar. Pide 0 cervezas. Pide -1. El bar explota.",
                "Hay 10 tipos de personas: las que entienden binario y las que no.",
                "Error 404: chiste no encontrado. Reiniciando humor...",
            ])

        # v8.0 — Consultas al cognitive loop y contexto
        if any(w in tl for w in ['qué estoy haciendo', 'qué detectas', 'qué ves',
                                   'contexto actual', 'qué app', 'qué modo']):
            cl = getattr(self.brain, 'cognitive_loop', None)
            ctx = getattr(self.brain, 'context_awareness', None)
            if cl and cl.get_current_state():
                state = cl.get_current_state()
                parts = []
                if state.active_app:
                    parts.append(f"App: {state.active_app}")
                if state.user_activity and state.user_activity != 'idle':
                    parts.append(f"Actividad: {state.user_activity}")
                if state.detected_mode != 'unknown':
                    parts.append(f"Modo: {state.detected_mode}")
                if state.active_document:
                    parts.append(f"Documento: {state.active_document}")
                return "Detecto: " + ". ".join(parts) + "." if parts else "No detecto actividad específica."
            elif ctx:
                return ctx.get_summary()
            return "Cognitive loop aún inicializando. Dame unos segundos."

        if any(w in tl for w in ['decisiones recientes', 'qué has decidido', 'acciones autónomas']):
            de = getattr(self.brain, 'decision_engine', None)
            if de:
                decisions = de.get_recent_decisions(5)
                if decisions:
                    msgs = [f"• {d['message'][:60]}" for d in decisions[-3:]]
                    return "Decisiones recientes:\n" + "\n".join(msgs)
                return "No hay decisiones autónomas recientes."
            return "Decision engine no disponible."

        if any(w in tl for w in ['percepción', 'sistema ahora', 'procesos activos']):
            pl = getattr(self.brain, 'perception_loop', None)
            if pl:
                return pl.get_system_summary()
            return "Perception loop no disponible."

        if any(w in tl for w in ['auto-mejora', 'self improvement', 'análisis de código']):
            si = getattr(self.brain, 'self_improvement', None)
            if si:
                return si.get_improvement_report()
            return "Self improvement engine no disponible."

        return None

    def _status_natural_mark8(self) -> str:
        """Estado del sistema con datos del cognitive loop de MARK 8."""
        try:
            import psutil
            cpu = psutil.cpu_percent(0.2)
            ram = psutil.virtual_memory().percent

            # Obtener contexto del cognitive loop si está disponible
            extra = ''
            if self.brain and hasattr(self.brain, 'cognitive_loop') and self.brain.cognitive_loop:
                state = self.brain.cognitive_loop.get_current_state()
                if state:
                    if state.user_activity and state.user_activity != 'idle':
                        extra = f" Detecto que estás en modo {state.user_activity}."
                    if state.detected_mode != 'unknown':
                        extra += f" Contexto: {state.detected_mode}."

            return random.choice([
                f"Cognitive loop activo. CPU {cpu:.0f}%, RAM {ram:.0f}%.{extra}",
                f"MARK 8 operativo. Sistema nominal: CPU {cpu:.0f}%, memoria {ram:.0f}%.{extra}",
                f"Todo nominal. CPU {cpu:.0f}%, RAM {ram:.0f}%.{extra}",
            ])
        except Exception:
            return "MARK 8 operativo. Sin anomalías detectadas."

    def _status_natural(self) -> str:
        try:
            import psutil
            cpu = psutil.cpu_percent(0.2)
            ram = psutil.virtual_memory().percent
            return random.choice([
                f"Operativo. CPU al {cpu:.0f}%, RAM al {ram:.0f}%. Sin anomalías.",
                f"Todo nominal. CPU {cpu:.0f}%, memoria {ram:.0f}%.",
                f"Funcionando bien. {cpu:.0f}% CPU, {ram:.0f}% RAM.",
            ])
        except Exception:
            return "Operativo. Sin anomalías detectadas."

    def _system_action(self, text: str, intent: str, ents: Dict) -> Optional[str]:
        if intent == 'system_info':
            return self.executor.get_system_info()

        if intent == 'system_screenshot':
            return self.executor.take_screenshot()

        if intent == 'system_volume':
            return self.executor.set_volume(
                ents.get('action', 'up'),
                ents.get('level')
            )

        if intent in ('open_app', 'close_app'):
            app = ents.get('app') or ents.get('query', '')
            if not app:
                # Extraer del texto
                m = re.search(r'(?:abre|lanza|inicia|ejecuta|arranca|cierra)\s+(?:el\s+|la\s+)?(.+?)(?:\s+por\s+favor)?$',
                               text, re.IGNORECASE)
                app = m.group(1).strip() if m else text.strip()
            return self.executor.open_app(app) if app else "¿Qué aplicación quiere abrir?"

        if intent == 'open_url':
            url = ents.get('url', '')
            return self.executor.open_url(url) if url else "¿Qué URL quiere abrir?"

        if intent == 'search_web':
            query = ents.get('query', text)
            return self.executor.search_web(query)

        if intent in ('media_play',):
            q = ents.get('query', '')
            if q:
                return self.executor.open_youtube(q)
            # Sin query específica → buscar música genérica
            return self.executor.open_youtube('música')

        if intent == 'media_video':
            q = ents.get('query', ents.get('description', ''))
            return self.executor.open_youtube(q) if q else self.executor.open_url('https://youtube.com')

        if intent == 'get_news':
            topic = ents.get('topic', '')
            return self.executor.search_web(f"últimas noticias {topic}".strip())

        if intent == 'get_weather':
            loc = ents.get('location', '')
            return self.executor.search_web(f"tiempo meteorológico {loc}".strip() or "tiempo hoy")

        if intent == 'mode_work':
            self.executor.open_app('code')
            self.executor.open_app('chrome')
            return "Modo Trabajo activado. VS Code y Chrome en marcha."

        if intent == 'mode_relax':
            self.executor.open_youtube('música relajante lofi chill')
            return "Modo Relax. Música ambiente en YouTube."

        if intent == 'mode_study':
            self.executor.open_youtube('música para estudiar concentración')
            return "Modo Estudio activado. Música de concentración en YouTube."

        if intent == 'memory_save':
            content = ents.get('content', text)
            return self._save_memory(content)

        if intent == 'memory_recall':
            return self._recall_memory(text)

        if intent == 'ai_math':
            return self._solve_math(text)

        if intent == 'ai_translate':
            return self._translate(ents, text)

        if intent == 'code_run':
            return self._run_script(ents.get('path', text))

        if intent == 'reminder_set':
            return self._set_reminder(ents.get('raw', text))

        return None

    def _file_action(self, text: str, intent: str, ents: Dict) -> Optional[str]:
        tl = text.lower()

        if intent in ('file_read', 'file_analyze', 'code_analyze'):
            path = ents.get('path')
            if not path:
                path = self.file_proc.find_latest_upload()
            if path:
                return self.load_file(path)
            if self._file_content:
                return self._analyze_file(text)
            return ("No hay ningún archivo cargado. Use el botón 📎 para subir uno, "
                    "o diga la ruta: 'lee C:\\mi_archivo.docx'")

        # Si hay archivo en memoria y pregunta relacionada
        if self._file_content:
            file_words = ['resume', 'analiza', 'explica', 'mejora', 'corrige',
                           'revisa', 'extrae', 'traduce', 'qué dice', 'sobre el archivo',
                           'sobre el documento', 'del archivo', 'del documento']
            if any(w in tl for w in file_words):
                return self._analyze_file(text)

        return None

    def _analyze_file(self, task: str) -> str:
        if not self._file_content:
            return "No hay ningún archivo cargado."
        ai = getattr(self.brain, 'ai_manager', None)
        if ai:
            return ai.generate_with_file(task, self._file_content, self._file_type or 'documento')
        # Sin IA: análisis básico
        w = len(self._file_content.split())
        lines = self._file_content.count('\n') + 1
        name = os.path.basename(self._file_path) if self._file_path else 'archivo'
        return (f"Análisis básico de {name}:\n"
                f"• {w} palabras, {lines} líneas\n"
                f"• Inicio: {self._file_content[:300]}...\n\n"
                f"Para análisis profundo active LM Studio (127.0.0.1:1234).")

    def _save_memory(self, content: str) -> str:
        try:
            mem = getattr(self.brain, 'memory', None)
            if mem and hasattr(mem, 'save_fact'):
                mem.save_fact('user', content)
                return f"Guardado: '{content}'"
        except Exception:
            pass
        return f"Anotado en sesión: '{content}'"

    def _recall_memory(self, query: str) -> str:
        try:
            mem = getattr(self.brain, 'memory', None)
            if mem and hasattr(mem, 'get_facts'):
                facts = mem.get_facts('user')
                if facts:
                    return "Tengo guardado:\n" + "\n".join(f"• {f}" for f in facts[:10])
        except Exception:
            pass
        return "No tengo nada guardado todavía. Dígame 'recuerda que...' y lo apunto."

    def _solve_math(self, text: str) -> str:
        expr = re.sub(r'[^\d\s\+\-\*/\.\(\)\^]', '', text).replace('^', '**')
        try:
            if expr.strip():
                result = eval(expr, {"__builtins__": {}})
                return f"= {result}"
        except Exception:
            pass
        ai = getattr(self.brain, 'ai_manager', None)
        if ai:
            return ai.generate(f"Resuelve este cálculo paso a paso: {text}", with_history=False, max_tokens=300)
        return "No pude resolver la expresión. ¿Puede reformularla?"

    def _translate(self, ents: Dict, text: str) -> str:
        langs = {'en': 'inglés', 'es': 'español', 'fr': 'francés',
                  'de': 'alemán', 'it': 'italiano', 'pt': 'portugués'}
        target = ents.get('target_lang', 'en')
        lang_name = langs.get(target, target)
        ai = getattr(self.brain, 'ai_manager', None)
        if ai:
            return ai.generate(f"Traduce al {lang_name}: {text}", with_history=False, max_tokens=400)
        return f"Necesito IA activa para traducir. Active LM Studio en 127.0.0.1:1234."

    def _run_script(self, filepath: str) -> str:
        # Buscar en workspace si no es ruta completa
        if not os.path.exists(filepath):
            workspace = os.path.join(os.path.dirname(os.path.dirname(__file__)), 'workspace')
            cand = os.path.join(workspace, os.path.basename(filepath))
            if os.path.exists(cand):
                filepath = cand
        if not os.path.exists(filepath):
            scripts = []
            workspace = os.path.join(os.path.dirname(os.path.dirname(__file__)), 'workspace')
            if os.path.exists(workspace):
                scripts = [f for f in os.listdir(workspace) if f.endswith('.py')]
            if scripts:
                return f"Scripts disponibles: {', '.join(scripts)}. ¿Cuál ejecuto?"
            return f"No encontré el script '{filepath}'."
        try:
            result = subprocess.run(['python', filepath],
                                     capture_output=True, text=True, timeout=30)
            output = result.stdout[-800:] if result.stdout else ""
            error = result.stderr[-400:] if result.stderr else ""
            if result.returncode == 0:
                return f"Script ejecutado:\n{output or '(sin output)'}"
            else:
                return f"Error en ejecución:\n{error}"
        except subprocess.TimeoutExpired:
            return "Timeout: el script tardó más de 30 segundos."
        except Exception as e:
            return f"Error ejecutando: {e}"

    def _set_reminder(self, raw: str) -> str:
        import threading
        m = re.search(r'(\d+)\s*(minuto|segundo|hora)', raw, re.IGNORECASE)
        if m:
            num = int(m.group(1))
            unit = m.group(2).lower()
            secs = num * (60 if 'minuto' in unit else 3600 if 'hora' in unit else 1)
            # Extraer mensaje
            msg_m = re.sub(r'(?:recuérdame|avísame|en\s+\d+\s+(?:minutos?|segundos?|horas?))', '', raw).strip()
            msg = msg_m or "Recordatorio"

            def fire():
                import time
                time.sleep(secs)
                logger.info(f"🔔 RECORDATORIO: {msg}")
                ai = getattr(self.brain, '_ui_callback', None)
                if ai:
                    try:
                        ai('alert', f"🔔 Recordatorio: {msg}")
                    except Exception:
                        pass

            threading.Timer(secs, fire).start()
            t_str = f"{num} {unit}{'s' if num > 1 else ''}"
            return f"Recordatorio programado en {t_str}: '{msg}'"
        return "No entendí el tiempo. Ejemplo: 'recuérdame tomar agua en 30 minutos'."

    def _ask_ai(self, text: str, nlu: Dict = None) -> str:
        ai = getattr(self.brain, 'ai_manager', None)
        if not ai:
            return self._fallback(text)
        ctx = "\n".join(
            f"{m['role']}: {m['content']}"
            for m in self._history[-4:]
        ) if self._history else ""
        # Si hay archivo cargado, incluirlo
        if self._file_content:
            file_ctx = f"\n\n[Archivo en memoria: {self._file_type}]\n{self._file_content[:2000]}"
            return ai.generate(text + file_ctx, context=ctx, with_history=True)
        return ai.generate(text, context=ctx, with_history=True)

    def _fallback(self, text: str) -> str:
        tl = text.lower()
        if '?' in text or any(w in tl for w in ['por qué', 'cómo', 'qué significa', 'cuándo', 'dónde']):
            return ("Para respuestas elaboradas necesito LM Studio activo (127.0.0.1:1234) "
                    "o internet. Puedo buscar en Google si lo prefiere. ¿Busco?")
        return random.choice([
            "Entendido. ¿Puede darme más contexto?",
            "Recibido. Dígame cómo proceder.",
            "Anotado. ¿Qué necesita exactamente?",
        ])

    def _frustration(self) -> str:
        return random.choice([
            "Entendido. Cuénteme qué está fallando.",
            "Tranquilo. ¿Qué es lo que no funciona?",
            "Anotado. ¿Por dónde empezamos a resolverlo?",
        ])

    def _push(self, user: str, bot: str):
        self._history.extend([
            {'role': 'user', 'content': user},
            {'role': 'assistant', 'content': bot}
        ])
        if len(self._history) > 24:
            self._history = self._history[-24:]


# Alias para compatibilidad
ReasoningEngine = DeepReasoner
