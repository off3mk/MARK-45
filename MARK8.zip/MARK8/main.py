#!/usr/bin/env python3
"""
MARK 8 — Fully Autonomous Cognitive System
Punto de entrada principal.

Creador: Ali (Sidi3Ali)
Sistema: MARK 8
"""

import sys
import os
import argparse
import logging
import time

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

# Crear directorios necesarios
for d in ['workspace', 'memory', 'cache', 'logs', 'skills/generated', 'models/local_models']:
    os.makedirs(d, exist_ok=True)

logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s [%(name)s] %(levelname)s: %(message)s',
    handlers=[
        logging.FileHandler('logs/mark8.log', encoding='utf-8'),
        logging.StreamHandler(sys.stdout),
    ]
)
logger = logging.getLogger('MARK8.Main')

SYSTEM_BANNER = """
╔══════════════════════════════════════════════════════════╗
║         M A R K  8  —  Autonomous Cognitive System       ║
║              Creado por Ali (Sidi3Ali)                   ║
╚══════════════════════════════════════════════════════════╝
"""


def start_gui_mode():
    """Iniciar MARK 8 con interfaz gráfica."""
    try:
        from ui.interface import JarvisInterface
        from core.brain import Mark8Brain

        brain = Mark8Brain()
        brain.initialize()

        app = JarvisInterface(brain)
        app.run()

    except ImportError as e:
        logger.error(f"Error importando módulos GUI: {e}")
        logger.info("Iniciando en modo CLI...")
        start_cli_mode()
    except Exception as e:
        logger.error(f"Error fatal en modo GUI: {e}", exc_info=True)
        sys.exit(1)


def start_cli_mode():
    """Iniciar MARK 8 en modo consola."""
    try:
        from core.brain import Mark8Brain

        brain = Mark8Brain()
        brain.initialize()

        print(SYSTEM_BANNER)
        print("Sistema activo. Escribe 'salir' para terminar.\n")

        # Saludo de inicio personalizado
        try:
            from core.startup_manager import StartupManager
            sm = brain.startup_manager or StartupManager(brain=brain)
            sm.perform_startup_greeting()
        except Exception:
            try:
                name = 'Ali'
                if brain.user_identity:
                    name = brain.user_identity.get_preferred_name()
                brain.speak(f"{_get_time_greeting()} {name}. MARK 8 operativo.")
            except Exception:
                brain.speak("MARK 8 en línea.")

        # Prompt dinámico
        def get_prompt():
            try:
                if brain.user_identity:
                    name = brain.user_identity.get_preferred_name()
                    return f"{name} → "
            except Exception:
                pass
            return "Ali → "

        while True:
            try:
                prompt = get_prompt()
                user_input = input(prompt).strip()
                if not user_input:
                    continue

                if user_input.lower() in ['salir', 'exit', 'quit', 'apagar', 'shutdown']:
                    name = 'Ali'
                    if brain.user_identity:
                        name = brain.user_identity.get_preferred_name()
                    brain.speak(f"Hasta luego, {name}. MARK 8 desconectándose.")
                    brain.shutdown()
                    break

                if user_input.lower() in ['status', 'estado']:
                    status = brain.get_status()
                    print(f"\n[STATUS MARK 8]")
                    for k, v in status.get('modules', {}).items():
                        icon = '✓' if v else '✗'
                        print(f"  {icon} {k}")
                    if brain.cognitive_loop:
                        cl = status.get('cognitive_loop', {})
                        print(f"\n[COGNITIVE LOOP]")
                        print(f"  App activa: {cl.get('current_app', '?')}")
                        print(f"  Modo: {cl.get('current_mode', '?')}")
                        print(f"  Actividad: {cl.get('activity', '?')}")
                        print(f"  CPU: {cl.get('cpu', 0):.0f}%  RAM: {cl.get('ram', 0):.0f}%")
                    print()
                    continue

                if user_input.lower() == 'contexto':
                    if brain.context_awareness:
                        ctx = brain.context_awareness.get_context()
                        if ctx:
                            print(f"\n[CONTEXTO ACTUAL]")
                            for k, v in ctx.to_dict().items():
                                if v:
                                    print(f"  {k}: {v}")
                            print()
                    continue

                if user_input.lower() == 'percepcion':
                    if brain.perception_loop:
                        print(f"\n[PERCEPCIÓN]\n  {brain.perception_loop.get_system_summary()}\n")
                    continue

                response = brain.process_command(user_input)
                if response:
                    print(f"\nMARK 8 → {response}\n")

            except KeyboardInterrupt:
                print("\n[Interrupción detectada]")
                break
            except Exception as e:
                logger.error(f"Error en CLI: {e}")

    except Exception as e:
        logger.error(f"Error fatal en CLI: {e}", exc_info=True)
        sys.exit(1)


def _get_time_greeting() -> str:
    hour = time.localtime().tm_hour
    if 5 <= hour < 12:
        return "Buenos días,"
    elif 12 <= hour < 20:
        return "Buenas tardes,"
    return "Buenas noches,"


def main():
    parser = argparse.ArgumentParser(description='MARK 8 — Fully Autonomous Cognitive System')
    parser.add_argument('--cli', action='store_true', help='Modo consola')
    parser.add_argument('--debug', action='store_true', help='Modo debug')
    args = parser.parse_args()

    if args.debug:
        logging.getLogger().setLevel(logging.DEBUG)

    logger.info("="*55)
    logger.info(f"  Iniciando MARK 8 — Ali (Sidi3Ali)")
    logger.info("="*55)

    if args.cli:
        start_cli_mode()
    else:
        start_gui_mode()


if __name__ == '__main__':
    main()
