# JARVIS v7.0
**Creado por Ali (Sidi3Ali)**

---

## Nuevas capacidades en v7.0

### Sistema de Identidad de Usuario (`core/user_identity.py`)
- Detecta automáticamente el usuario de Windows activo
- En primer inicio pregunta nombre preferido, idioma y nivel de formalidad
- **Ali (Sidi3Ali) es reconocido como creador** con acceso máximo y comportamiento especial
- Persiste perfiles en `memory/user_profiles.db`

### Saludo automático al iniciar (`core/startup_manager.py`)
- JARVIS puede configurarse para iniciarse automáticamente con Windows
- Saluda al usuario según la hora del día: "Buenos días, Ali", "Buenas noches, Ali"...
- Comandos: `"activa inicio automático"` / `"desactiva inicio automático"`

### Control total de UI (`core/ui_control.py`)
- Detectar ventanas, hacer click, escribir texto
- Flujos completos: `"abre WhatsApp y envía un mensaje a mamá"`
- Basado en pyautogui, uiautomation y win32 APIs

### Integración Spotify (`skills/spotify_skill.py`)
- Reproducir, pausar, siguiente/anterior
- Leer liked songs, playlists, artistas más escuchados
- Recomendaciones inteligentes basadas en gustos
- Comandos: `"reproduce jazz"`, `"qué suena"`, `"recomiéndame algo"`

### Monitor de Audio (`core/audio_monitor.py`)
- Captura y transcripción de audio del micrófono
- Generación de resúmenes de reuniones/llamadas
- **Solo activo con autorización explícita**: `"autoriza grabación de audio"`

### Marca de agua del creador (`core/personality.py`)
```python
CREATOR_METADATA = {
    "creator": "Ali",
    "alias": "Sidi3Ali",
    "system": "JARVIS v7.0",
    "watermark": "JARVIS v7.0 — Created by Ali (Sidi3Ali) — All rights reserved",
}
```

---

## Instalación

```batch
install.bat
```

## Inicio

```batch
start.bat
```

## Comandos nuevos en v7.0

| Comando | Acción |
|---------|--------|
| `activa inicio automático` | Registra JARVIS en el arranque de Windows |
| `desactiva inicio automático` | Elimina del arranque |
| `abre WhatsApp y envía mensaje a mamá: hola` | Automatización de WhatsApp |
| `reproduce jazz en Spotify` | Reproducción Spotify |
| `qué suena` | Canción actual en Spotify |
| `recomiéndame música` | Recomendación inteligente |
| `perfil musical` | Resumen de gustos musicales |
| `autoriza grabación de audio` | Activa el monitor de audio |
| `graba 60 segundos` | Graba audio |
| `transcribe` | Transcribe última grabación |
| `resumen de la llamada` | Resume última grabación |
| `qué ventanas están abiertas` | Lista ventanas activas |
| `cierra chrome` | Cierra una ventana |

---

## Arquitectura

```
Jarvis/
├── core/
│   ├── brain.py              ← Núcleo central (actualizado v7)
│   ├── user_identity.py      ← NUEVO — Identidad de usuario y creador
│   ├── startup_manager.py    ← NUEVO — Inicio automático con Windows
│   ├── ui_control.py         ← NUEVO — Control total de UI
│   ├── audio_monitor.py      ← NUEVO — Monitor y transcriptor de audio
│   ├── personality.py        ← ACTUALIZADO — Con watermark del creador
│   ├── cognitive_memory.py   ← ACTUALIZADO — v7.0
│   ├── autonomous.py         ← ACTUALIZADO — v7.0
│   ├── reasoning.py          ← ACTUALIZADO — Con handlers v7
│   ├── planner.py            ← ACTUALIZADO — v7.0
│   └── vision.py             ← ACTUALIZADO — v7.0
├── skills/
│   └── spotify_skill.py      ← NUEVO — Integración Spotify completa
├── memory/
│   ├── user_profiles.db      ← Perfiles de usuario
│   ├── cognitive.db          ← Memoria cognitiva
│   └── spotify_config.json   ← Credenciales Spotify
└── main.py                   ← ACTUALIZADO — Saludo personalizado
```

---

*JARVIS v7.0 — Created by Ali (Sidi3Ali)*
