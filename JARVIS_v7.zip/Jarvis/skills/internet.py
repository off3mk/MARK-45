"""
JARVIS v4.0 - Internet Skill
Búsquedas, clima, Wikipedia, noticias, URLs.
"""

import logging
import urllib.request
import urllib.parse
import urllib.error
import json
import webbrowser
import re
import html
from typing import Optional, Dict, Any

logger = logging.getLogger('JARVIS.Skills.Internet')


class InternetSkill:
    """Skill de acceso a internet y servicios web."""

    def __init__(self, brain):
        self.brain = brain
        self.timeout = 10
        self.headers = {
            'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36'
        }

    def _get(self, url: str, timeout: int = None) -> Optional[str]:
        """Realizar petición GET básica."""
        try:
            req = urllib.request.Request(url, headers=self.headers)
            with urllib.request.urlopen(req, timeout=timeout or self.timeout) as resp:
                content = resp.read()
                charset = resp.headers.get_content_charset() or 'utf-8'
                return content.decode(charset, errors='replace')
        except Exception as e:
            logger.debug(f"Error GET {url}: {e}")
            return None

    def search(self, query: str = '') -> str:
        """Buscar en DuckDuckGo y abrir resultados."""
        if not query:
            return "Especifique qué desea buscar, Señor."

        logger.info(f"Buscando: {query}")

        # Abrir búsqueda en navegador
        search_url = f"https://www.google.com/search?q={urllib.parse.quote(query)}"
        try:
            webbrowser.open(search_url)
        except Exception:
            pass

        # Intentar obtener extracto de DuckDuckGo API
        try:
            api_url = (f"https://api.duckduckgo.com/?q={urllib.parse.quote(query)}"
                       f"&format=json&no_html=1&skip_disambig=1")
            response = self._get(api_url)
            if response:
                data = json.loads(response)
                abstract = data.get('AbstractText', '').strip()
                if abstract:
                    if len(abstract) > 300:
                        abstract = abstract[:300] + "..."
                    return f"Búsqueda completada. Información encontrada:\n\n{abstract}\n\nResultados abiertos en el navegador, Señor."
        except Exception as e:
            logger.debug(f"Error DuckDuckGo API: {e}")

        return f"Búsqueda de '{query}' abierta en el navegador, Señor."

    def open_url(self, url: str = '') -> str:
        """Abrir URL en el navegador."""
        if not url:
            return "Especifique la URL, Señor."

        # Añadir protocolo si falta
        if not url.startswith(('http://', 'https://')):
            url = 'https://' + url

        try:
            webbrowser.open(url)
            return f"Abriendo '{url}' en el navegador, Señor."
        except Exception as e:
            logger.error(f"Error abriendo URL: {e}")
            return f"No pude abrir '{url}': {str(e)}, Señor."

    def weather(self, city: str = '') -> str:
        """Obtener información del clima."""
        if not city:
            return "Especifique la ciudad, Señor."

        logger.info(f"Consultando clima: {city}")

        # Usar wttr.in
        city_encoded = urllib.parse.quote(city)
        url = f"https://wttr.in/{city_encoded}?format=j1"

        response = self._get(url, timeout=8)
        if response:
            try:
                data = json.loads(response)
                current = data['current_condition'][0]

                temp_c = current.get('temp_C', 'N/A')
                feels_like = current.get('FeelsLikeC', 'N/A')
                humidity = current.get('humidity', 'N/A')
                wind_speed = current.get('windspeedKmph', 'N/A')

                # Descripción del tiempo
                desc = current.get('weatherDesc', [{}])
                weather_desc = desc[0].get('value', 'Desconocido') if desc else 'Desconocido'

                return (f"Clima en {city}:\n"
                        f"Temperatura: {temp_c}°C (sensación: {feels_like}°C)\n"
                        f"Estado: {weather_desc}\n"
                        f"Humedad: {humidity}%\n"
                        f"Viento: {wind_speed} km/h\n\n"
                        f"Información actualizada, Señor.")
            except Exception as e:
                logger.debug(f"Error parseando clima: {e}")

        # Fallback: abrir en navegador
        webbrowser.open(f"https://wttr.in/{city_encoded}")
        return f"Abriendo información del clima de {city} en el navegador, Señor."

    def wikipedia(self, topic: str = '') -> str:
        """Buscar en Wikipedia."""
        if not topic:
            return "Especifique el tema, Señor."

        logger.info(f"Buscando en Wikipedia: {topic}")

        # API de Wikipedia en español
        topic_encoded = urllib.parse.quote(topic)
        api_url = (f"https://es.wikipedia.org/api/rest_v1/page/summary/"
                   f"{topic_encoded}")

        response = self._get(api_url, timeout=8)
        if response:
            try:
                data = json.loads(response)
                extract = data.get('extract', '')
                title = data.get('title', topic)
                url = data.get('content_urls', {}).get('desktop', {}).get('page', '')

                if extract:
                    if len(extract) > 400:
                        extract = extract[:400] + "..."

                    result = f"Wikipedia - {title}:\n\n{extract}"
                    if url:
                        result += f"\n\nFuente: {url}"

                    return result + "\n\nInformación encontrada, Señor."
            except Exception as e:
                logger.debug(f"Error parseando Wikipedia: {e}")

        # Intentar búsqueda
        search_url = (f"https://es.wikipedia.org/w/index.php?"
                      f"search={topic_encoded}&action=opensearch")
        response = self._get(search_url)
        if response:
            try:
                data = json.loads(response)
                if data and len(data) > 3 and data[3]:
                    url = data[3][0]
                    webbrowser.open(url)
                    return f"Abriendo Wikipedia sobre '{topic}' en el navegador, Señor."
            except Exception:
                pass

        # Fallback
        webbrowser.open(f"https://es.wikipedia.org/wiki/{topic_encoded}")
        return f"Buscando '{topic}' en Wikipedia, Señor."

    def news(self, topic: str = 'general') -> str:
        """Obtener noticias recientes."""
        logger.info(f"Buscando noticias: {topic}")

        # Intentar con Hacker News o feeds gratuitos
        if topic == 'general' or topic == 'tecnología':
            try:
                response = self._get('https://hacker-news.firebaseio.com/v0/topstories.json')
                if response:
                    story_ids = json.loads(response)[:5]
                    stories = []

                    for story_id in story_ids:
                        story_url = f'https://hacker-news.firebaseio.com/v0/item/{story_id}.json'
                        story_response = self._get(story_url, timeout=5)
                        if story_response:
                            story = json.loads(story_response)
                            title = story.get('title', '')
                            url = story.get('url', '')
                            score = story.get('score', 0)
                            if title:
                                stories.append(f"• {title} (score: {score})")

                    if stories:
                        result = "Noticias de tecnología (Hacker News):\n\n"
                        result += "\n".join(stories)
                        return result + "\n\nNoticias actualizadas, Señor."
            except Exception as e:
                logger.debug(f"Error Hacker News: {e}")

        # Fallback: abrir Google News
        topic_encoded = urllib.parse.quote(topic)
        url = f"https://news.google.com/search?q={topic_encoded}&hl=es"
        webbrowser.open(url)
        return f"Abriendo noticias sobre '{topic}' en el navegador, Señor."

    def get_ip_info(self) -> str:
        """Obtener información de IP actual."""
        try:
            response = self._get('https://ipapi.co/json/', timeout=5)
            if response:
                data = json.loads(response)
                ip = data.get('ip', 'N/A')
                country = data.get('country_name', 'N/A')
                city = data.get('city', 'N/A')
                isp = data.get('org', 'N/A')

                return (f"Información de red:\n"
                        f"IP pública: {ip}\n"
                        f"Ubicación: {city}, {country}\n"
                        f"ISP: {isp}\n\nInformación obtenida, Señor.")
        except Exception as e:
            logger.debug(f"Error obteniendo IP: {e}")
        return "No pude obtener información de red, Señor."

    def ping(self, host: str = 'google.com') -> str:
        """Verificar conectividad con un host."""
        import subprocess
        try:
            param = '-n' if platform_is_windows() else '-c'
            result = subprocess.run(
                ['ping', param, '4', host],
                capture_output=True, text=True, timeout=10
            )
            if result.returncode == 0:
                return f"Conectividad con '{host}' verificada. Red operativa, Señor."
            return f"No hay respuesta de '{host}'. Verifique la conexión, Señor."
        except Exception as e:
            return f"Error verificando conectividad: {str(e)}, Señor."


def platform_is_windows() -> bool:
    import platform
    return platform.system() == 'Windows'
