"""
MARK 5 - Coding Skill Avanzado
- Lee documentos Word (.docx) y texto
- Aprende el estilo de escritura del usuario
- Genera código adaptado
- Modifica y mejora código existente
- Escribe "como si fuera tú"
"""

import os
import re
import json
import logging
import subprocess
import threading
import tempfile
from datetime import datetime
from typing import Optional, Dict, List, Any

logger = logging.getLogger('MARK.Coding')

WORKSPACE = os.path.join(os.path.dirname(os.path.dirname(__file__)), 'workspace')
STYLE_FILE = os.path.join(os.path.dirname(os.path.dirname(__file__)), 'memory', 'user_style.json')

# Templates de código listos
CODE_TEMPLATES = {
    'calculadora': '''"""Calculadora simple."""

def calcular(a, b, operacion):
    if operacion == '+': return a + b
    if operacion == '-': return a - b
    if operacion == '*': return a * b
    if operacion == '/': return a / b if b != 0 else "Error: división entre cero"
    return "Operación no válida"

while True:
    try:
        a = float(input("Primer número: "))
        op = input("Operación (+, -, *, /): ")
        b = float(input("Segundo número: "))
        print(f"Resultado: {calcular(a, b, op)}")
    except ValueError:
        print("Entrada inválida")
    except KeyboardInterrupt:
        print("\\nSaliendo...")
        break
''',
    'gestor_tareas': '''"""Gestor de tareas simple."""
import json, os

ARCHIVO = "tareas.json"

def cargar():
    if os.path.exists(ARCHIVO):
        with open(ARCHIVO) as f: return json.load(f)
    return []

def guardar(tareas):
    with open(ARCHIVO, 'w') as f: json.dump(tareas, f, ensure_ascii=False, indent=2)

def mostrar(tareas):
    if not tareas:
        print("Sin tareas pendientes.")
        return
    for i, t in enumerate(tareas, 1):
        estado = "✓" if t.get('hecha') else "○"
        print(f"{i}. [{estado}] {t['texto']}")

tareas = cargar()
while True:
    print("\\n1. Ver tareas  2. Añadir  3. Completar  4. Salir")
    op = input("Opción: ").strip()
    if op == '1': mostrar(tareas)
    elif op == '2':
        t = input("Nueva tarea: ").strip()
        if t: tareas.append({"texto": t, "hecha": False}); guardar(tareas)
    elif op == '3':
        mostrar(tareas)
        n = int(input("Número: ")) - 1
        if 0 <= n < len(tareas): tareas[n]['hecha'] = True; guardar(tareas)
    elif op == '4': break
''',
}


class StyleLearner:
    """Aprende y replica el estilo de escritura del usuario."""

    def __init__(self):
        self.style_data: Dict = self._load_style()

    def _load_style(self) -> Dict:
        try:
            if os.path.exists(STYLE_FILE):
                with open(STYLE_FILE) as f:
                    return json.load(f)
        except Exception:
            pass
        return {
            'samples': [],
            'avg_sentence_length': 15,
            'uses_formality': 0.5,
            'common_words': [],
            'punctuation_style': 'normal',
            'code_comments_style': 'spanish',
        }

    def _save_style(self):
        try:
            os.makedirs(os.path.dirname(STYLE_FILE), exist_ok=True)
            with open(STYLE_FILE, 'w', encoding='utf-8') as f:
                json.dump(self.style_data, f, ensure_ascii=False, indent=2)
        except Exception as e:
            logger.debug(f"Error guardando estilo: {e}")

    def learn_from_text(self, text: str, source: str = ""):
        """Analizar texto y extraer características de estilo."""
        if not text or len(text) < 50:
            return

        sentences = re.split(r'[.!?]+', text)
        sentences = [s.strip() for s in sentences if len(s.strip()) > 5]

        if not sentences:
            return

        # Longitud promedio de frase
        avg_len = sum(len(s.split()) for s in sentences) / len(sentences)

        # Nivel de formalidad (palabras formales vs informales)
        formal_words = {'respecto', 'considero', 'mediante', 'además', 'sin embargo',
                       'no obstante', 'asimismo', 'por lo tanto', 'en consecuencia'}
        informal_words = {'tío', 'bro', 'mola', 'guay', 'flipas', 'pues', 'osea', 'tipo'}
        formal_score = sum(1 for w in formal_words if w in text.lower()) / max(len(formal_words), 1)
        informal_score = sum(1 for w in informal_words if w in text.lower()) / max(len(informal_words), 1)
        formality = max(0, min(1, 0.5 + formal_score - informal_score))

        # Palabras más frecuentes (sin stopwords)
        stopwords = {'de', 'la', 'el', 'en', 'y', 'a', 'que', 'es', 'se', 'no',
                    'los', 'las', 'un', 'una', 'por', 'con', 'para', 'su', 'al'}
        words = [w.lower() for w in text.split() if len(w) > 3 and w.lower() not in stopwords]
        from collections import Counter
        common = [w for w, _ in Counter(words).most_common(20)]

        # Guardar muestra (máximo 5 muestras)
        self.style_data['samples'] = (self.style_data['samples'] + [text[:300]])[-5:]
        self.style_data['avg_sentence_length'] = round(
            (self.style_data.get('avg_sentence_length', 15) + avg_len) / 2, 1
        )
        self.style_data['uses_formality'] = round(
            (self.style_data.get('uses_formality', 0.5) + formality) / 2, 2
        )
        self.style_data['common_words'] = list(set(
            self.style_data.get('common_words', []) + common
        ))[:30]

        self._save_style()
        logger.info(f"Estilo actualizado desde: {source or 'texto directo'}")

    def get_style_prompt(self) -> str:
        """Generar instrucción de estilo para la IA."""
        if not self.style_data.get('samples'):
            return ""

        formality = self.style_data.get('uses_formality', 0.5)
        avg_len = self.style_data.get('avg_sentence_length', 15)
        samples = self.style_data.get('samples', [])

        style_desc = []
        if formality > 0.65:
            style_desc.append("escritura formal")
        elif formality < 0.35:
            style_desc.append("escritura informal y directa")
        else:
            style_desc.append("tono neutro")

        if avg_len < 10:
            style_desc.append("frases cortas y directas")
        elif avg_len > 20:
            style_desc.append("frases elaboradas")

        prompt = f"Escribe imitando este estilo ({', '.join(style_desc)}):\n"
        if samples:
            prompt += f"Muestra del usuario: \"{samples[-1][:200]}\"\n"
        prompt += "El texto debe parecer escrito por esta persona, no por una IA."
        return prompt


class DocumentReader:
    """Lee documentos Word, PDF y texto plano."""

    def read_file(self, filepath: str) -> Optional[str]:
        """Leer cualquier documento soportado."""
        if not os.path.exists(filepath):
            return None

        ext = os.path.splitext(filepath)[1].lower()

        if ext == '.docx':
            return self._read_docx(filepath)
        elif ext == '.pdf':
            return self._read_pdf(filepath)
        elif ext in ['.txt', '.md', '.py', '.js', '.html', '.css']:
            return self._read_text(filepath)
        else:
            return self._read_text(filepath)

    def _read_docx(self, path: str) -> Optional[str]:
        try:
            import docx
            doc = docx.Document(path)
            paragraphs = []
            for p in doc.paragraphs:
                if p.text.strip():
                    paragraphs.append(p.text.strip())
            # También tablas
            for table in doc.tables:
                for row in table.rows:
                    row_text = ' | '.join(cell.text.strip() for cell in row.cells if cell.text.strip())
                    if row_text:
                        paragraphs.append(row_text)
            return '\n'.join(paragraphs)
        except ImportError:
            # Intentar con python-docx2txt
            try:
                import docx2txt
                return docx2txt.process(path)
            except Exception:
                return f"[Instale python-docx para leer .docx: pip install python-docx]"
        except Exception as e:
            return f"[Error leyendo {os.path.basename(path)}: {e}]"

    def _read_pdf(self, path: str) -> Optional[str]:
        try:
            import pdfplumber
            with pdfplumber.open(path) as pdf:
                texts = []
                for page in pdf.pages:
                    t = page.extract_text()
                    if t:
                        texts.append(t)
                return '\n'.join(texts)
        except ImportError:
            try:
                import PyPDF2
                with open(path, 'rb') as f:
                    reader = PyPDF2.PdfReader(f)
                    texts = [page.extract_text() for page in reader.pages]
                return '\n'.join(t for t in texts if t)
            except Exception:
                return "[Instale pdfplumber o PyPDF2 para leer PDFs]"
        except Exception as e:
            return f"[Error leyendo PDF: {e}]"

    def _read_text(self, path: str) -> Optional[str]:
        try:
            for enc in ['utf-8', 'latin-1', 'cp1252']:
                try:
                    with open(path, encoding=enc) as f:
                        return f.read()
                except UnicodeDecodeError:
                    continue
        except Exception as e:
            return f"[Error leyendo archivo: {e}]"
        return None


class CodingSkill:
    """Skill de programación avanzado de MARK."""

    def __init__(self, brain=None):
        self.brain = brain
        self.doc_reader = DocumentReader()
        self.style_learner = StyleLearner()
        os.makedirs(WORKSPACE, exist_ok=True)
        self._pending_script: Optional[str] = None

    def execute(self, action: str, params: Dict, text: str = "") -> str:
        actions = {
            'create_script': self.create_script,
            'run_script': self.run_script,
            'confirm_run': self.confirm_run,
            'analyze_code': self.analyze_code,
            'list_scripts': self.list_scripts,
            'read_document': self.read_document,
            'analyze_document': self.analyze_document,
            'improve_document': self.improve_document,
            'learn_style': self.learn_style_from_text,
            'write_like_me': self.write_like_user,
        }
        fn = actions.get(action)
        if fn:
            return fn(params=params, text=text)
        return f"Acción de coding no reconocida: {action}"

    def create_script(self, params: Dict = None, text: str = "") -> str:
        """Generar script Python."""
        params = params or {}
        description = params.get('description', '') or text

        # Buscar template
        for key, template in CODE_TEMPLATES.items():
            if key in description.lower():
                code = template
                break
        else:
            # Generar con IA
            if self.brain and self.brain.ai_manager:
                style_ctx = self.style_learner.get_style_prompt()
                code = self.brain.ai_manager.generate_code(description, style_context=style_ctx)
                code = self._extract_code(code)
            else:
                return "Necesito IA conectada para generar código personalizado. Active LM Studio."

        if not code or len(code) < 10:
            return "No pude generar el código. Sea más específico sobre qué debe hacer."

        # Guardar
        name = re.sub(r'[^\w]', '_', description[:30].lower()).strip('_') or 'script'
        ts = datetime.now().strftime('%H%M%S')
        filename = f"{name}_{ts}.py"
        filepath = os.path.join(WORKSPACE, filename)

        with open(filepath, 'w', encoding='utf-8') as f:
            f.write(code)

        self._pending_script = filepath

        preview = code[:200] + ("..." if len(code) > 200 else "")
        return (f"Script generado: {filename}\n\n"
                f"```python\n{preview}\n```\n\n"
                f"¿Desea ejecutarlo? Diga 'sí' para confirmar o 'no' para cancelar.")

    def confirm_run(self, params: Dict = None, text: str = "") -> str:
        """Ejecutar el script pendiente de confirmación."""
        if self._pending_script and os.path.exists(self._pending_script):
            result = self._run_file(self._pending_script)
            self._pending_script = None
            return result
        return "No hay ningún script pendiente de ejecución."

    def run_script(self, params: Dict = None, text: str = "") -> str:
        """Ejecutar script por nombre."""
        params = params or {}
        name = params.get('script_name', '') or text

        # Buscar en workspace
        scripts = self._list_scripts_raw()
        match = None
        for s in scripts:
            if name.lower() in s.lower():
                match = os.path.join(WORKSPACE, s)
                break

        if not match and self._pending_script:
            match = self._pending_script

        if not match:
            return f"No encontré el script '{name}' en el workspace."

        return self._run_file(match)

    def _run_file(self, filepath: str) -> str:
        """Ejecutar un archivo Python."""
        try:
            result = subprocess.run(
                ['python', filepath],
                capture_output=True, text=True, timeout=30
            )
            output = result.stdout.strip()
            errors = result.stderr.strip()

            if result.returncode == 0:
                resp = f"Script ejecutado correctamente."
                if output:
                    resp += f"\nSalida:\n{output[:500]}"
                return resp
            else:
                return f"Error al ejecutar:\n{errors[:400]}"
        except subprocess.TimeoutExpired:
            return "El script excedió el tiempo límite de 30 segundos."
        except Exception as e:
            return f"Error ejecutando script: {e}"

    def analyze_code(self, params: Dict = None, text: str = "") -> str:
        """Analizar código en busca de problemas."""
        code = params.get('code', '') if params else text
        if not code:
            return "Proporcione el código a analizar."

        issues = []
        if 'except:' in code or 'except Exception:' in code:
            issues.append("• Captura genérica de excepciones — especifique el tipo")
        if 'eval(' in code:
            issues.append("• eval() detectado — riesgo de seguridad")
        if 'exec(' in code:
            issues.append("• exec() detectado — revisar si es necesario")
        lines = code.split('\n')
        for i, line in enumerate(lines, 1):
            if len(line) > 100:
                issues.append(f"• Línea {i} demasiado larga ({len(line)} chars)")

        if not issues:
            return "Código revisado. Sin problemas obvios detectados."
        return "Revisión del código:\n" + "\n".join(issues)

    def read_document(self, params: Dict = None, text: str = "") -> str:
        """Leer un documento y mostrar su contenido."""
        params = params or {}
        filepath = params.get('filepath') or params.get('path') or ''

        if not filepath:
            # Buscar en uploads (archivos subidos por el usuario)
            for uploads_dir in ['/mnt/user-data/uploads', 'uploads']:
                if os.path.exists(uploads_dir):
                    files = sorted([f for f in os.listdir(uploads_dir)
                                    if f.endswith(('.docx', '.doc', '.txt', '.pdf'))],
                                   key=lambda x: os.path.getmtime(os.path.join(uploads_dir, x)),
                                   reverse=True)
                    if files:
                        filepath = os.path.join(uploads_dir, files[0])
                        break

        if not filepath or not os.path.exists(filepath):
            return ("No encontré ningún documento. Opciones:\n"
                    "1. Arrastre el archivo a la carpeta 'uploads'\n"
                    "2. Diga: 'lee C:\\ruta\\al\\archivo.docx'\n"
                    "3. Comparta el documento y lo proceso.")

        content = self.doc_reader.read_file(filepath)
        if not content:
            return f"No pude leer '{os.path.basename(filepath)}'. Asegúrese de que no está protegido."

        # Aprender estilo automáticamente
        self.style_learner.learn_from_text(content, source=os.path.basename(filepath))

        word_count = len(content.split())
        preview = content[:800] + ("..." if len(content) > 800 else "")
        return (f"Documento: {os.path.basename(filepath)} ({word_count} palabras)\n\n"
                f"{preview}\n\n"
                f"Estilo de escritura analizado y guardado. "
                f"Puedo mejorarlo, corregirlo o escribir más en su estilo.")

    def analyze_document(self, params: Dict = None, text: str = "") -> str:
        """Analizar documento y dar feedback."""
        filepath = params.get('filepath', '') if params else ''
        task = params.get('task', 'analizar') if params else text

        # Leer el archivo
        content = None
        if filepath and os.path.exists(filepath):
            content = self.doc_reader.read_file(filepath)
        else:
            # Buscar el último subido
            uploads_dir = '/mnt/user-data/uploads'
            if os.path.exists(uploads_dir):
                files = sorted(os.listdir(uploads_dir))
                if files:
                    content = self.doc_reader.read_file(
                        os.path.join(uploads_dir, files[-1])
                    )

        if not content:
            return "No encontré ningún documento para analizar. Comparta el archivo primero."

        if not self.brain or not self.brain.ai_manager:
            return f"Documento leído ({len(content)} chars). Necesito LM Studio para analizarlo en profundidad."

        prompt = (f"Analiza este documento y proporciona:\n"
                  f"1. Resumen de los puntos principales\n"
                  f"2. Sugerencias de mejora\n"
                  f"3. Cualquier error o inconsistencia detectada\n\n"
                  f"Tarea específica: {task}\n\n"
                  f"DOCUMENTO:\n{content[:3000]}")

        return self.brain.ai_manager.generate(prompt, max_tokens=600)

    def improve_document(self, params: Dict = None, text: str = "") -> str:
        """Mejorar el texto de un documento manteniendo el estilo del usuario."""
        filepath = params.get('filepath', '') if params else ''
        instructions = params.get('instructions', text) if params else text

        content = None
        filename = "documento"
        if filepath and os.path.exists(filepath):
            content = self.doc_reader.read_file(filepath)
            filename = os.path.basename(filepath)
        else:
            uploads_dir = '/mnt/user-data/uploads'
            if os.path.exists(uploads_dir):
                files = sorted(os.listdir(uploads_dir))
                if files:
                    fpath = os.path.join(uploads_dir, files[-1])
                    content = self.doc_reader.read_file(fpath)
                    filename = files[-1]

        if not content:
            return "No encontré documento para mejorar. Comparta el archivo."

        # Aprender estilo del documento
        self.style_learner.learn_from_text(content, source=filename)
        style_prompt = self.style_learner.get_style_prompt()

        if not self.brain or not self.brain.ai_manager:
            return "Necesito LM Studio conectado para mejorar documentos."

        prompt = (f"Mejora este texto siguiendo estas instrucciones: {instructions or 'mejorar redacción y claridad'}\n\n"
                  f"{style_prompt}\n\n"
                  f"IMPORTANTE: El resultado debe parecer escrito por la misma persona, no por una IA.\n"
                  f"Mantén el tono, vocabulario y estructura similares al original.\n\n"
                  f"TEXTO ORIGINAL:\n{content[:2500]}\n\n"
                  f"TEXTO MEJORADO:")

        improved = self.brain.ai_manager.generate(prompt, max_tokens=800)

        # Guardar versión mejorada
        base = os.path.splitext(filename)[0]
        out_path = os.path.join(WORKSPACE, f"{base}_mejorado.txt")
        with open(out_path, 'w', encoding='utf-8') as f:
            f.write(improved)

        return (f"Documento mejorado guardado como: {base}_mejorado.txt\n\n"
                f"Previsualización:\n{improved[:600]}...")

    def learn_style_from_text(self, params: Dict = None, text: str = "") -> str:
        """Aprender estilo de escritura del usuario."""
        params = params or {}
        sample = params.get('text', '') or text
        path = params.get('path') or params.get('filepath')

        # Si hay ruta de archivo, leerlo
        if path and os.path.exists(path):
            file_content = self.doc_reader.read_file(path)
            if file_content:
                sample = file_content

        if len(sample) < 30:
            return ("Dame un texto de ejemplo para analizar tu estilo. "
                    "Puedes decir: 'este es mi estilo: [texto]' o compartir un documento.")

        self.style_learner.learn_from_text(sample, source=path or "input directo")
        formality = self.style_learner.style_data.get('uses_formality', 0.5)
        avg_len = self.style_learner.style_data.get('avg_sentence_length', 15)

        style_desc = "formal" if formality > 0.6 else "informal" if formality < 0.4 else "neutro"
        common = self.style_learner.style_data.get('common_words', [])[:5]
        vocab_hint = f", vocabulario frecuente: {', '.join(common)}" if common else ""

        return (f"Estilo analizado. Perfil: {style_desc}, "
                f"frases de ~{avg_len:.0f} palabras de media{vocab_hint}. "
                f"Cuando escriba por usted parecerá que lo redactó usted mismo.")

    def write_like_user(self, params: Dict = None, text: str = "") -> str:
        """Escribir contenido imitando el estilo del usuario."""
        topic = params.get('topic', text) if params else text
        if not topic:
            return "Indique sobre qué quiere que escriba."

        style_prompt = self.style_learner.get_style_prompt()
        if not style_prompt:
            return ("No tengo suficientes muestras de su estilo. "
                    "Use 'lee documento' o 'aprende mi estilo' primero.")

        if not self.brain or not self.brain.ai_manager:
            return "Necesito LM Studio para escribir contenido personalizado."

        prompt = (f"{style_prompt}\n\n"
                  f"Escribe sobre: {topic}\n\n"
                  f"El texto debe parecer escrito por esta persona — mismo vocabulario, "
                  f"mismo tono, misma estructura. No usar lenguaje de IA.")

        return self.brain.ai_manager.generate(prompt, max_tokens=600)

    def list_scripts(self, params: Dict = None, text: str = "") -> str:
        scripts = self._list_scripts_raw()
        if not scripts:
            return "No hay scripts en el workspace todavía."
        lines = [f"{i+1}. {s}" for i, s in enumerate(scripts)]
        return "Scripts disponibles:\n" + "\n".join(lines)

    def _list_scripts_raw(self) -> List[str]:
        try:
            return [f for f in os.listdir(WORKSPACE) if f.endswith('.py')]
        except Exception:
            return []

    def _extract_code(self, text: str) -> str:
        """Extraer código de respuesta de IA."""
        # Buscar bloque de código markdown
        blocks = re.findall(r'```(?:python)?\n(.*?)```', text, re.DOTALL)
        if blocks:
            return blocks[0].strip()
        # Si no hay bloque, tomar todo (puede ser código directo)
        lines = text.strip().split('\n')
        # Eliminar líneas de explicación al inicio/fin
        code_lines = []
        in_code = False
        for line in lines:
            if line.strip().startswith(('def ', 'class ', 'import ', 'from ', '#', 'if ', 'for ')):
                in_code = True
            if in_code:
                code_lines.append(line)
        return '\n'.join(code_lines) if code_lines else text
