"""
JARVIS v4.0 - Skill Manager
Gestor de plugins/skills con carga dinámica.
"""

import logging
import importlib
import importlib.util
import os
import sys
from typing import Optional, Dict, Any

logger = logging.getLogger('JARVIS.Skills')


class SkillManager:
    """Gestor central de skills/plugins."""

    def __init__(self, brain):
        self.brain = brain
        self._skills: Dict[str, Any] = {}
        self._skill_dir = os.path.join(os.path.dirname(os.path.dirname(__file__)), 'skills')

    def load_all_skills(self):
        """Cargar todos los skills disponibles."""
        skill_files = {
            'system': 'system',
            'internet': 'internet',
            'media': 'media',
            'coding': 'coding',
            'memory_skill': 'memory_skill',
            'browser': 'browser',
        }

        # Cargar file_skill nuevo
        try:
            from skills.file_skill import FileSkill
            self._skills['files'] = FileSkill(self.brain)
            logger.info("  ✓ Skill 'files' cargado")
        except Exception as e:
            logger.warning(f"  ✗ file_skill: {e}")

        for skill_name, module_name in skill_files.items():
            self._load_skill(skill_name, module_name)

        # Cargar skills generados dinámicamente
        self._load_generated_skills()

        loaded = list(self._skills.keys())
        logger.info(f"Skills cargados: {loaded}")

    def _load_skill(self, skill_name: str, module_name: str):
        """Cargar un skill específico."""
        try:
            module = importlib.import_module(f'skills.{module_name}')
            skill_class_name = module_name.replace('_', ' ').title().replace(' ', '') + 'Skill'

            # Buscar la clase del skill
            skill_class = getattr(module, skill_class_name, None)
            if not skill_class:
                # Intentar otros nombres comunes
                for attr_name in dir(module):
                    attr = getattr(module, attr_name)
                    if isinstance(attr, type) and attr_name.endswith('Skill'):
                        skill_class = attr
                        break

            if skill_class:
                self._skills[skill_name] = skill_class(self.brain)
                logger.info(f"  ✓ Skill '{skill_name}' cargado")
            else:
                # Intentar instanciar módulo directamente
                self._skills[skill_name] = module
                logger.info(f"  ✓ Módulo '{skill_name}' cargado")

        except ImportError as e:
            logger.warning(f"  ✗ Skill '{skill_name}' no disponible: {e}")
        except Exception as e:
            logger.warning(f"  ✗ Error cargando '{skill_name}': {e}")

    def _load_generated_skills(self):
        """Cargar skills generados automáticamente."""
        generated_dir = os.path.join(self._skill_dir, 'generated')
        if not os.path.exists(generated_dir):
            return

        for filename in os.listdir(generated_dir):
            if filename.endswith('.py') and not filename.startswith('_'):
                skill_name = filename[:-3]
                skill_path = os.path.join(generated_dir, filename)
                try:
                    spec = importlib.util.spec_from_file_location(
                        f"skills.generated.{skill_name}", skill_path
                    )
                    module = importlib.util.module_from_spec(spec)
                    spec.loader.exec_module(module)

                    # Buscar clase skill en el módulo
                    for attr_name in dir(module):
                        attr = getattr(module, attr_name)
                        if isinstance(attr, type) and attr_name.endswith('Skill'):
                            try:
                                self._skills[f"gen_{skill_name}"] = attr(self.brain)
                                logger.info(f"  ✓ Skill generado '{skill_name}' cargado")
                            except Exception:
                                self._skills[f"gen_{skill_name}"] = module
                            break

                except Exception as e:
                    logger.warning(f"Error cargando skill generado {skill_name}: {e}")

    def execute(self, skill_name: str, action: str, params: Dict, original_text: str = '') -> Optional[str]:
        """Ejecutar una acción de un skill."""
        if not skill_name:
            return None

        skill = self._skills.get(skill_name)
        if not skill:
            logger.warning(f"Skill '{skill_name}' no encontrado")
            return None

        try:
            # Buscar método de acción
            method = None
            if hasattr(skill, action):
                method = getattr(skill, action)
            elif hasattr(skill, 'execute'):
                return skill.execute(action, params, original_text)

            if method and callable(method):
                if params:
                    result = method(**params)
                else:
                    result = method()
                return result if result else None

        except TypeError as e:
            logger.debug(f"Error de parámetros en {skill_name}.{action}: {e}")
            # Intentar sin parámetros
            try:
                method = getattr(skill, action, None)
                if method:
                    return method()
            except Exception:
                pass
        except Exception as e:
            logger.error(f"Error ejecutando {skill_name}.{action}({params}): {e}")

        return None

    def get_loaded_skills(self) -> list:
        """Obtener lista de skills cargados."""
        return list(self._skills.keys())

    def register_skill(self, name: str, skill_instance):
        """Registrar skill manualmente."""
        self._skills[name] = skill_instance
        logger.info(f"Skill '{name}' registrado manualmente")

    def reload_skill(self, skill_name: str, module_name: str):
        """Recargar un skill específico."""
        if skill_name in self._skills:
            del self._skills[skill_name]
        self._load_skill(skill_name, module_name)
