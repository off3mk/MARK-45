"""
J.A.R.V.I.S MARK 6 - Motor NLU Avanzado
Entiende:
- Typos y faltas de ortografía ("ponmne musica", "abrr chorme")
- Frases incompletas ("música", "chrome", "trabajo")
- Escritura informal ("pon un temazo bro", "enga abre el explorer")
- Múltiples idiomas mezclados ("open spotify porfavor")
- Intenciones vagas ("estoy aburrido", "necesito concentrarme")
- Comandos encadenados ("abre chrome y pon música")
"""

import re
import math
import logging
from typing import Optional, Dict, List, Tuple, Any
from collections import defaultdict

logger = logging.getLogger('MARK.NLU')


# ─────────────────────────────────────────────────────────────
# CORRECTOR DE TYPOS
# ─────────────────────────────────────────────────────────────

class TypoCorrector:
    """
    Corrige errores ortográficos comunes usando distancia de edición.
    Especializado en vocabulario del sistema.
    """

    # Vocabulario del sistema que hay que reconocer aunque venga con typos
    VOCAB = {
        # Apps
        'chrome', 'firefox', 'spotify', 'youtube', 'discord', 'telegram',
        'whatsapp', 'vscode', 'notepad', 'explorer', 'steam', 'netflix',
        'twitch', 'word', 'excel', 'powerpoint', 'outlook', 'zoom', 'teams',
        'calculator', 'calculadora', 'terminal', 'powershell', 'cmd',
        # Acciones
        'abre', 'abrir', 'abrr', 'cierra', 'cerrar',
        'pon', 'poner', 'ponme', 'ponmne', 'ponne',
        'busca', 'buscar', 'busc',
        'crea', 'crear', 'genera', 'generar',
        'ejecuta', 'ejecutar', 'corre', 'correr',
        'analiza', 'analizar', 'lee', 'leer',
        'pausa', 'para', 'stop', 'play',
        'sube', 'baja', 'volumen', 'volumeen',
        'apaga', 'reinicia', 'reiniciar',
        'modo', 'mudo', 'silencio',
        # Contenido
        'música', 'musica', 'musiica', 'musiqua',
        'temazo', 'cancion', 'canción', 'playlist',
        'reggaeton', 'regueton', 'rock', 'pop', 'jazz',
        'noticias', 'notcias', 'tiempo', 'clima', 'lluvia',
        'script', 'codigo', 'código', 'programa', 'funcion',
        # Sistema
        'trabajo', 'trabjo', 'trabaho', 'trabajar',
        'relax', 'relajar', 'descanso',
        'estudio', 'estudiar', 'concentrar',
        'status', 'estado', 'sistema',
        'ram', 'cpu', 'disco', 'memoria',
    }

    # Correcciones específicas conocidas
    KNOWN_FIXES = {
        'abrr': 'abre', 'abrir': 'abre', 'abree': 'abre',
        'ponmne': 'ponme', 'ponne': 'ponme', 'pomne': 'ponme', 'ponn': 'pon',
        'musiica': 'música', 'musiqua': 'música', 'musica': 'música',
        'regueton': 'reggaeton', 'regeton': 'reggaeton',
        'chorme': 'chrome', 'crhome': 'chrome', 'chrme': 'chrome',
        'youtbe': 'youtube', 'yotube': 'youtube', 'youtueb': 'youtube',
        'spotiify': 'spotify', 'spoitfy': 'spotify', 'spotfy': 'spotify',
        'trabjo': 'trabajo', 'trabaho': 'trabajo',
        'volumeen': 'volumen', 'bolumen': 'volumen',
        'notcias': 'noticias', 'notiicass': 'noticias',
        'porfavor': 'por favor', 'xfavor': 'por favor', 'xfa': 'por favor',
        'kiero': 'quiero', 'kiero': 'quiero', 'qiero': 'quiero',
        'q': 'que', 'xq': 'porque', 'pq': 'porque', 'pk': 'porque',
        'tb': 'también', 'tmb': 'también', 'tbn': 'también',
        'pa': 'para', 'pra': 'para',
        'mas': 'más', 'si': 'sí',
        'enga': 'venga', 'venga': 'venga',
        'bro': '', 'tio': '', 'tío': '', 'macho': '', 'colega': '',
    }

    def correct(self, text: str) -> str:
        """Corregir texto manteniendo estructura."""
        words = text.split()
        corrected = []
        for word in words:
            wl = word.lower().strip('.,!?¿¡')
            if wl in self.KNOWN_FIXES:
                fixed = self.KNOWN_FIXES[wl]
                if fixed:  # No añadir si es cadena vacía (palabras a eliminar)
                    corrected.append(fixed)
            elif len(wl) >= 4 and wl not in self.VOCAB:
                closest = self._closest(wl)
                if closest:
                    corrected.append(closest)
                else:
                    corrected.append(word)
            else:
                corrected.append(word)
        return ' '.join(corrected).strip()

    def _closest(self, word: str) -> Optional[str]:
        """Encontrar palabra más cercana en vocabulario."""
        best = None
        best_dist = 2  # Solo corregir si distancia <= 2
        for vocab_word in self.VOCAB:
            if abs(len(word) - len(vocab_word)) > 3:
                continue
            dist = self._edit_distance(word, vocab_word)
            if dist < best_dist:
                best_dist = dist
                best = vocab_word
        return best

    def _edit_distance(self, s1: str, s2: str) -> int:
        """Distancia de Levenshtein optimizada."""
        if s1 == s2:
            return 0
        if len(s1) > len(s2):
            s1, s2 = s2, s1
        distances = range(len(s1) + 1)
        for i2, c2 in enumerate(s2):
            distances_ = [i2 + 1]
            for i1, c1 in enumerate(s1):
                if c1 == c2:
                    distances_.append(distances[i1])
                else:
                    distances_.append(1 + min(distances[i1], distances[i1 + 1], distances_[-1]))
            distances = distances_
        return distances[-1]


# ─────────────────────────────────────────────────────────────
# NORMALIZADOR DE TEXTO
# ─────────────────────────────────────────────────────────────

class TextNormalizer:
    """Normaliza texto informal, con emojis, abreviaciones, etc."""

    EMOJI_MAP = {
        '🎵': 'música', '🎶': 'música', '🎸': 'música', '🎤': 'música',
        '🌙': 'noche', '☀️': 'día', '⭐': '',
        '💻': 'ordenador', '🖥️': 'ordenador', '⌨️': 'teclado',
        '📁': 'archivo', '📄': 'documento', '📊': 'datos',
        '🔊': 'volumen', '🔇': 'silencio', '🔉': 'volumen',
        '⚡': 'rápido', '🔥': '',
        '✅': 'sí', '❌': 'no', '👍': 'sí', '👎': 'no',
        '🙏': 'por favor',
    }

    INFORMAL = {
        r'\btio\b': '', r'\btío\b': '', r'\bbro\b': '', r'\bcolega\b': '',
        r'\bmacho\b': '', r'\bpisha\b': '', r'\btronco\b': '',
        r'\bjaja\w*': '', r'\bjeje\w*': '', r'\bxd\b': '',
        r'\bpls\b': 'por favor', r'\bplz\b': 'por favor',
        r'\bthx\b': 'gracias', r'\bty\b': 'gracias',
        r'\bgg\b': '', r'\bwow\b': '',
        r'\bopen\b': 'abre', r'\bclose\b': 'cierra',
        r'\bplay\b': 'pon', r'\bpause\b': 'pausa',
        r'\bmute\b': 'silencio',
        r'\bshutdown\b': 'apaga', r'\brestart\b': 'reinicia',
        r'\bstatus\b': 'estado',
    }

    def normalize(self, text: str) -> str:
        # Emojis
        for emoji, word in self.EMOJI_MAP.items():
            text = text.replace(emoji, f' {word} ')

        # Informalismo y anglicismos
        for pattern, replacement in self.INFORMAL.items():
            text = re.sub(pattern, replacement, text, flags=re.IGNORECASE)

        # Limpiar espacios múltiples
        text = re.sub(r'\s+', ' ', text).strip()
        return text


# ─────────────────────────────────────────────────────────────
# DEFINICIÓN DE INTENTS
# ─────────────────────────────────────────────────────────────

INTENTS = [
    # ── SALUDOS / CONVERSACIÓN ──────────────────────────────
    {
        'name': 'greeting',
        'skill': 'conversation', 'action': 'greet',
        'patterns': [
            r'^(hola|buenas|hey|ey|buenos\s+d[ií]as|buenas\s+tardes|buenas\s+noches|qu[ée]\s+tal|qu[ée]\s+pasa)[\s!.?]*$',
            r'^(qu[ée]\s+hay|c[oó]mo\s+est[aá]s|sigue[s]?\s+ah[ií]|est[aá]s\s+ah[ií])[\s!.?]*$',
        ],
        'keywords': ['hola', 'buenas', 'hey', 'buenos días', 'buenas noches'],
        'weight': 1.0,
    },
    {
        'name': 'farewell',
        'skill': 'conversation', 'action': 'farewell',
        'patterns': [r'^(adi[oó]s|hasta\s+luego|nos\s+vemos|hasta\s+pronto|bye|chao)[\s!.?]*$'],
        'keywords': ['adiós', 'hasta luego', 'nos vemos', 'bye', 'chao'],
        'weight': 1.0,
    },
    {
        'name': 'thanks',
        'skill': 'conversation', 'action': 'thanks',
        'patterns': [r'(gracias|thanks|perfecto|genial|bien\s+hecho|excelente|crack|fenomenal)'],
        'keywords': ['gracias', 'perfecto', 'genial', 'bien hecho', 'excelente'],
        'weight': 0.9,
    },
    {
        'name': 'identity',
        'skill': 'conversation', 'action': 'who_are_you',
        'patterns': [
            r'(qui[eé]n\s+eres|qu[eé]\s+eres|c[oó]mo\s+te\s+llamas|tu\s+nombre|qu[eé]\s+es\s+mark|qu[eé]\s+es\s+jarvis)',
        ],
        'keywords': ['quién eres', 'qué eres', 'tu nombre', 'cómo te llamas'],
        'weight': 1.0,
    },

    # ── MÚSICA / MEDIA ──────────────────────────────────────
    {
        'name': 'media_play',
        'skill': 'media', 'action': 'play',
        'patterns': [
            r'(pon|ponme|reproduce|suena|escucha|quiero\s+oir|ponme\s+a|pon\s+un|ponme\s+algo)',
            r'(m[úu]sica|temazo|canci[oó]n|musica|canciones|playlist|lista)',
            r'(play|reproducir|escuchar)',
        ],
        'keywords': ['música', 'musica', 'temazo', 'canción', 'cancion', 'reproducir', 'ponme',
                     'spotify', 'reggaeton', 'rock', 'pop', 'jazz', 'electrónica', 'trap',
                     'pon algo', 'pon música', 'quiero música', 'pon un tema',
                     'quiero escuchar', 'quiero oir', 'quiero reggaeton', 'quiero rock',
                     'quiero musica', 'quiero canciones'],
        'extract': 'query',
        'weight': 0.85,
    },
    {
        'name': 'media_pause',
        'skill': 'media', 'action': 'pause',
        'patterns': [r'\b(para|pausa|detener|stop|silence|callate|quita\s+la\s+m[úu]sica)\b'],
        'keywords': ['para la música', 'pausa', 'detén', 'stop música', 'quita la música', 'silencio'],
        'weight': 0.9,
    },
    {
        'name': 'media_volume',
        'skill': 'media', 'action': 'volume',
        'patterns': [r'(sube|baja|pon|ajusta|cambia)\s+(el\s+)?(volumen|vol|sonido)'],
        'keywords': ['sube el volumen', 'baja el volumen', 'más volumen', 'menos volumen', 'volumen al'],
        'extract': 'volume_level',
        'weight': 0.9,
    },
    {
        'name': 'media_mute',
        'skill': 'media', 'action': 'mute',
        'patterns': [r'\b(mute|silenci[ao]|mutear|sin\s+sonido|modo\s+silencio)\b'],
        'keywords': ['mute', 'silencio', 'silencia', 'sin sonido'],
        'weight': 0.9,
    },

    # ── SISTEMA ─────────────────────────────────────────────
    {
        'name': 'system_info',
        'skill': 'system', 'action': 'system_info',
        'patterns': [
            r'(status|estado|informaci[oó]n)\s+(del\s+)?(sistema|pc|ordenador)',
            r'(cu[aá]nto|c[oó]mo\s+est[aá])\s+(la\s+)?(ram|cpu|disco|memoria|procesador)',
            r'\b(cpu|ram|disco|temperatura|rendimiento|recursos)\b',
        ],
        'keywords': ['status del sistema', 'estado del sistema', 'cpu', 'ram', 'cuánta ram',
                     'cómo va el pc', 'rendimiento', 'memoria', 'disco'],
        'weight': 0.85,
    },
    {
        'name': 'open_app',
        'skill': 'system', 'action': 'open_app',
        'patterns': [
            r'(abre|abrir|abrr|lanza|ejecuta|inicia|open)\s+([a-záéíóúñü\w]+)',
        ],
        'keywords': ['abre', 'abrir', 'abrr', 'lanza', 'ejecuta', 'open', 'inicia'],
        'extract': 'app_name',
        'weight': 0.9,
    },
    {
        'name': 'close_app',
        'skill': 'system', 'action': 'close_app',
        'patterns': [r'(cierra|cerrar|mata|kill|termina)\s+([a-záéíóúñü\w]+)'],
        'keywords': ['cierra', 'cerrar', 'mata', 'kill'],
        'extract': 'app_name',
        'weight': 0.9,
    },
    {
        'name': 'system_shutdown',
        'skill': 'system', 'action': 'shutdown',
        'patterns': [r'(apaga|shutdown|power\s+off)\s+(el\s+)?(pc|ordenador|equipo|sistema)'],
        'keywords': ['apaga el pc', 'apaga el ordenador', 'shutdown', 'apagar ordenador'],
        'weight': 0.95,
    },
    {
        'name': 'system_restart',
        'skill': 'system', 'action': 'restart',
        'patterns': [r'(reinicia|restart|reboot)\s*(el\s+)?(pc|ordenador|sistema)?'],
        'keywords': ['reinicia', 'restart', 'reboot', 'reiniciar'],
        'weight': 0.95,
    },

    # ── MODOS AUTOMÁTICOS ──────────────────────────────────
    {
        'name': 'mode_work',
        'skill': 'system', 'action': 'automation_mode',
        'patterns': [
            r'(modo\s+trabajo|modo\s+oficina|mode\s+work)',
            r'^(voy\s+a\s+(trabajar|programar|picar\s+c[oó]digo|currar|estudiar\s+c[oó]digo))',
            r'(prepara|configura|activa)\s+(el\s+)?(entorno\s+de\s+trabajo|modo\s+trabajo)',
            r'^(a\s+trabajar|a\s+currar|a\s+programar)[\s!.]*$',
        ],
        'keywords': ['modo trabajo', 'voy a trabajar', 'voy a programar', 'a currar', 'a trabajar',
                     'prepara el entorno', 'modo oficina', 'modo programación', 'a picar código',
                     'empezamos a trabajar', 'voy a currar'],
        'extract': 'mode_work',
        'weight': 0.95,  # Mayor peso que coding_create
    },
    {
        'name': 'mode_relax',
        'skill': 'system', 'action': 'automation_mode',
        'patterns': [
            r'(modo\s+relax|modo\s+descanso|modo\s+reposo)',
            r'(ya\s+termin[eé]|terminé\s+por\s+hoy|me\s+voy\s+a\s+relajar)',
            r'(quiero\s+relajarme|necesito\s+descansar|voy\s+a\s+descansar)',
        ],
        'keywords': ['modo relax', 'ya terminé', 'a descansar', 'modo descanso', 'relájame',
                     'terminé por hoy', 'voy a relajarme', 'necesito descansar'],
        'extract': 'mode_relax',
        'weight': 0.85,
    },
    {
        'name': 'mode_study',
        'skill': 'system', 'action': 'automation_mode',
        'patterns': [
            r'(modo\s+estudio|modo\s+concentraci[oó]n)',
            r'(voy\s+a\s+(estudiar|repasar))',
        ],
        'keywords': ['modo estudio', 'voy a estudiar', 'modo concentración', 'necesito concentrarme'],
        'extract': 'mode_study',
        'weight': 0.85,
    },

    # ── INTERNET ─────────────────────────────────────────────
    {
        'name': 'internet_search',
        'skill': 'internet', 'action': 'search',
        'patterns': [
            r'(busca|buscar|googlea|busca\s+en\s+internet|busca\s+info|qu[eé]\s+es|d[oó]nde\s+est[aá])',
            r'(search|look\s+up|encuentra)',
        ],
        'keywords': ['busca', 'googlea', 'buscar en internet', 'qué es', 'busca información sobre',
                     'dónde está', 'cómo se hace', 'busca en google'],
        'extract': 'search_query',
        'weight': 0.85,
    },
    {
        'name': 'internet_news',
        'skill': 'internet', 'action': 'news',
        'patterns': [
            r'(noticias|news|titulares|qu[eé]\s+pasa)\s*(de|del?|sobre|con|hoy)?',
        ],
        'keywords': ['noticias', 'news', 'titulares', 'qué pasa en', 'últimas noticias',
                     'noticias del barça', 'noticias del real madrid', 'noticias hoy'],
        'extract': 'news_topic',
        'weight': 0.8,
    },
    {
        'name': 'internet_weather',
        'skill': 'internet', 'action': 'weather',
        'patterns': [r'(tiempo|clima|llueve|lluvia|temperatura|hace\s+fr[ií]o|hace\s+calor)\s*(en|de)?'],
        'keywords': ['tiempo', 'clima', 'temperatura', 'llueve', 'hace calor', 'hace frío',
                     'cómo está el tiempo', 'qué tiempo hace'],
        'extract': 'location',
        'weight': 0.9,
    },

    # ── PROGRAMACIÓN ──────────────────────────────────────
    {
        'name': 'coding_create',
        'skill': 'coding', 'action': 'create_script',
        'patterns': [
            r'(crea|escribe|genera|hazme|programa|c[oó]digo\s+para|script\s+que|función\s+que)',
            r'(necesito\s+un\s+(script|programa|función|código))',
            r'(aut[o]?matiza|automatizar)',
        ],
        'keywords': ['crea un script', 'escribe código', 'genera un programa', 'hazme un script',
                     'necesito un script', 'programa que', 'función que', 'automatiza', 'código para'],
        'extract': 'code_description',
        'weight': 0.85,
    },
    {
        'name': 'coding_run',
        'skill': 'coding', 'action': 'run_script',
        'patterns': [r'(ejecuta|corre|run)\s+(el\s+)?(script|programa|c[oó]digo|archivo)'],
        'keywords': ['ejecuta el script', 'corre el programa', 'run', 'ejecutar el código'],
        'extract': 'script_name',
        'weight': 0.9,
    },
    {
        'name': 'coding_analyze',
        'skill': 'coding', 'action': 'analyze_code',
        'patterns': [r'(analiza|revisa|explica|qu[eé]\s+hace)\s+(este\s+)?(c[oó]digo|script|función)'],
        'keywords': ['analiza el código', 'revisa el script', 'qué hace este código', 'explica el código'],
        'weight': 0.85,
    },

    # ── ARCHIVOS / DOCUMENTOS ─────────────────────────────
    {
        'name': 'file_read',
        'skill': 'files', 'action': 'read',
        'patterns': [
            r'(lee|leer|abre|analiza|revisa)\s+(el\s+)?(archivo|fichero|documento|pdf|word|excel|csv)',
            r'(qu[eé]\s+dice|qu[eé]\s+contiene)\s+(el\s+)?(archivo|documento)',
        ],
        'keywords': ['lee el archivo', 'abre el documento', 'analiza el pdf', 'qué dice el word',
                     'lee el word', 'analiza el csv', 'revisa el documento', 'lee mi práctica',
                     'lee mi tarea', 'abre el fichero', 'que contiene el archivo'],
        'extract': 'file_path',
        'weight': 0.9,
    },
    {
        'name': 'file_improve',
        'skill': 'files', 'action': 'improve',
        'patterns': [
            r'(mejora|corrige|reescribe|edita)\s+(el\s+)?(documento|texto|tarea|trabajo|pr[aá]ctica)',
            r'(hazlo\s+mejor|qu[eé]\s+puedo\s+mejorar)',
        ],
        'keywords': ['mejora el documento', 'corrige mi tarea', 'reescribe el texto',
                     'ayúdame con mi práctica', 'mejora mi trabajo', 'corrige sin que se note',
                     'edita como si fuera yo', 'mejóralo'],
        'weight': 0.85,
    },
    {
        'name': 'file_upload_analyze',
        'skill': 'files', 'action': 'analyze_upload',
        'patterns': [
            r'(analiza|revisa|explica|qu[eé]\s+(es|hace|contiene))\s+(esto|este\s+archivo|lo\s+que|el\s+que)',
        ],
        'keywords': ['analiza esto', 'qué es esto', 'explica esto', 'qué hace', 'qué contiene',
                     'analiza el archivo', 'revisa esto'],
        'weight': 0.8,
    },

    # ── MEMORIA ───────────────────────────────────────────
    {
        'name': 'memory_save',
        'skill': 'memory', 'action': 'save',
        'patterns': [
            r'(recuerda|guarda|anota|memoriza)\s+(que|esto|mi|el)',
            r'(mi\s+(nombre|email|tel[eé]fono|contrase[ñn]a|direcci[oó]n)\s+es)',
        ],
        'keywords': ['recuerda que', 'guarda que', 'memoriza', 'anota', 'mi nombre es',
                     'mi email es', 'quiero que recuerdes'],
        'extract': 'memory_content',
        'weight': 0.9,
    },
    {
        'name': 'memory_recall',
        'skill': 'memory', 'action': 'recall',
        'patterns': [
            r'(cu[aá]l\s+es\s+mi|d[ií]me\s+mi|qu[eé]\s+(recuerdas|tienes\s+guardado))',
        ],
        'keywords': ['cuál es mi email', 'recuérdame', 'qué guardaste', 'qué recuerdas',
                     'dime mi teléfono'],
        'extract': 'recall_key',
        'weight': 0.9,
    },

    # ── INTENCIONES VAGAS ─────────────────────────────────
    {
        'name': 'vague_bored',
        'skill': 'vague', 'action': 'bored',
        'patterns': [r'(estoy\s+aburrido|me\s+aburro|no\s+s[eé]\s+qu[eé]\s+hacer)'],
        'keywords': ['estoy aburrido', 'me aburro', 'qué hago', 'no sé qué hacer'],
        'weight': 0.9,
    },
    {
        'name': 'vague_tired',
        'skill': 'vague', 'action': 'tired',
        'patterns': [r'(estoy\s+cansado|no\s+puedo\s+m[aá]s|estoy\s+agotado|ya\s+no\s+m[aá]s)'],
        'keywords': ['estoy cansado', 'no puedo más', 'agotado', 'ya no más'],
        'weight': 0.9,
    },
    {
        'name': 'vague_frustrated',
        'skill': 'vague', 'action': 'frustrated',
        'patterns': [r'(joder|hostia|mierda|coño|me\s+cago|no\s+funciona|est[aá]\s+roto)'],
        'keywords': ['joder', 'mierda', 'hostia', 'no funciona', 'está roto', 'coño'],
        'weight': 0.85,
    },
    {
        'name': 'vague_need_help',
        'skill': 'vague', 'action': 'help',
        'patterns': [r'(ay[uú]dame|necesito\s+ayuda|no\s+s[eé]\s+c[oó]mo|c[oó]mo\s+se\s+hace)'],
        'keywords': ['ayúdame', 'necesito ayuda', 'no sé cómo', 'cómo se hace', 'explícame'],
        'weight': 0.8,
    },
    {
        'name': 'vague_performance',
        'skill': 'vague', 'action': 'slow_pc',
        'patterns': [r'(va\s+lento|est[aá]\s+lento|est[aá]\s+colgado|va\s+mal|no\s+responde)'],
        'keywords': ['va lento', 'está lento', 'colgado', 'no responde', 'lag', 'va fatal'],
        'weight': 0.9,
    },
]


# ─────────────────────────────────────────────────────────────
# MOTOR NLU PRINCIPAL
# ─────────────────────────────────────────────────────────────

class SemanticIntentEngine:
    """
    Motor NLU avanzado.
    Combina: corrección de typos + normalización + pattern matching +
    keyword matching + TF-IDF + contexto conversacional.
    """

    def __init__(self):
        self.corrector   = TypoCorrector()
        self.normalizer  = TextNormalizer()
        self._context    = []  # Historial de intents recientes
        self._max_ctx    = 5

        logger.info(f"NLU cargado: {len(INTENTS)} intents")

    def detect_intent(self, text: str) -> Optional[Dict]:
        """
        Detectar intención con máxima tolerancia a errores.
        Retorna intent con confianza o None si no hay nada claro.
        """
        if not text or not text.strip():
            return None

        # 1. Normalizar y corregir
        normalized = self.normalizer.normalize(text)
        corrected  = self.corrector.correct(normalized)
        tl = corrected.lower().strip()
        tl_orig = text.lower().strip()

        # 2. Buscar en todos los intents
        candidates = []
        for intent_def in INTENTS:
            score, match = self._score_intent(tl, tl_orig, intent_def)
            if score > 0:
                candidates.append((score, intent_def, match))

        if not candidates:
            return None

        # 3. Ordenar por score
        candidates.sort(key=lambda x: x[0], reverse=True)
        best_score, best_intent, best_match = candidates[0]

        # 4. Umbral mínimo de confianza
        if best_score < 0.25:
            return None

        # 5. Construir resultado
        result = {
            'name': best_intent['name'],
            'skill': best_intent['skill'],
            'action': best_intent['action'],
            'confidence': min(best_score, 1.0),
            'params': self._extract_params(best_intent, tl, text, best_match),
            'original_text': text,
            'corrected_text': corrected if corrected != text else None,
            'requires_planning': best_intent.get('multi_step', False),
            'multi_step': best_intent.get('multi_step', False),
        }

        # 6. Guardar en contexto
        self._push_context(result)

        return result

    def _score_intent(self, text: str, text_orig: str,
                      intent: Dict) -> Tuple[float, Optional[re.Match]]:
        """Calcular score de coincidencia para un intent."""
        score = 0.0
        best_match = None
        w = intent.get('weight', 1.0)

        # Pattern matching (más peso)
        for pattern in intent.get('patterns', []):
            try:
                m = re.search(pattern, text, re.IGNORECASE)
                if m:
                    score = max(score, 0.85 * w)
                    best_match = m
                    break
            except re.error:
                pass

        # Keyword matching (peso medio)
        for kw in intent.get('keywords', []):
            kl = kw.lower()
            if kl in text:
                # Coincidencia exacta de frase completa — más peso
                kw_score = min(len(kl) / max(len(text), 1) * 2.5, 1.0) * w
                score = max(score, kw_score)
            elif all(word in text for word in kl.split() if len(word) > 2):
                # Todas las palabras clave presentes (orden diferente)
                score = max(score, 0.5 * w)

        # Bonus por contexto (intent relacionado con el anterior)
        if self._context:
            last = self._context[-1].get('name', '')
            if intent['name'] in self._get_related(last):
                score = min(score * 1.1, 1.0)

        return score, best_match

    def _get_related(self, intent_name: str) -> List[str]:
        """Intents relacionados para bonus de contexto."""
        relations = {
            'media_play':   ['media_pause', 'media_volume', 'media_mute'],
            'mode_work':    ['coding_create', 'open_app'],
            'file_read':    ['file_improve', 'coding_analyze'],
            'coding_create': ['coding_run', 'coding_analyze'],
        }
        return relations.get(intent_name, [])

    def _extract_params(self, intent: Dict, text: str,
                        text_orig: str, match: Optional[re.Match]) -> Dict:
        """Extraer parámetros según tipo de intent."""
        extract = intent.get('extract', '')
        params = {}

        if extract == 'query':
            params['query'] = self._extract_after_keyword(
                text, ['ponme', 'pon', 'reproduce', 'escucha', 'quiero oir'],
                default='')
            if not params['query']:
                params['query'] = self._clean_for_search(text, intent['keywords'])

        elif extract == 'app_name':
            params['app'] = self._extract_app(text)

        elif extract == 'search_query':
            params['query'] = self._extract_after_keyword(
                text, ['busca', 'googlea', 'buscar', 'qué es', 'search'],
                default=text)

        elif extract == 'news_topic':
            params['topic'] = self._extract_after_keyword(
                text, ['noticias de', 'noticias del', 'noticias sobre', 'noticias'],
                default='general')

        elif extract == 'location':
            params['location'] = self._extract_after_keyword(
                text, ['en', 'tiempo en', 'clima en', 'temperatura en'],
                default='')

        elif extract == 'volume_level':
            nums = re.findall(r'\d+', text)
            if nums:
                params['level'] = int(nums[0])
            params['direction'] = 'up' if any(w in text for w in ['sube', 'más', 'aumenta']) else \
                                  'down' if any(w in text for w in ['baja', 'menos', 'reduce']) else None

        elif extract in ('mode_work', 'mode_relax', 'mode_study'):
            params['mode'] = extract.replace('mode_', '')

        elif extract == 'file_path':
            params['path'] = self._extract_file_path(text_orig)

        elif extract == 'code_description':
            params['description'] = self._extract_after_keyword(
                text, ['crea', 'escribe', 'genera', 'hazme', 'programa', 'necesito un', 'código para'],
                default=text)

        elif extract == 'script_name':
            params['name'] = self._extract_after_keyword(
                text, ['ejecuta', 'corre', 'run'],
                default='')

        elif extract == 'memory_content':
            params['content'] = text_orig

        elif extract == 'recall_key':
            params['key'] = text_orig

        return params

    def _extract_after_keyword(self, text: str, keywords: List[str], default: str) -> str:
        """Extraer texto que viene después de una palabra clave."""
        for kw in sorted(keywords, key=len, reverse=True):
            if kw in text:
                idx = text.find(kw) + len(kw)
                rest = text[idx:].strip()
                # Limpiar partículas
                rest = re.sub(r'^(algo\s+de|un\s+poco\s+de|el|la|los|las|un|una|de|que|a)\s+', '', rest)
                if rest:
                    return rest
        return default

    def _extract_app(self, text: str) -> str:
        """Extraer nombre de app del texto."""
        # Lista de apps conocidas
        KNOWN_APPS = [
            'chrome', 'firefox', 'edge', 'brave', 'opera',
            'spotify', 'youtube', 'netflix', 'twitch', 'discord',
            'telegram', 'whatsapp', 'signal',
            'vscode', 'vs code', 'code', 'notepad', 'notepad++', 'sublime',
            'word', 'excel', 'powerpoint', 'outlook', 'teams', 'zoom',
            'steam', 'epic games', 'origin', 'battle.net',
            'explorer', 'files', 'gestor de archivos',
            'cmd', 'terminal', 'powershell', 'bash',
            'calculator', 'calculadora', 'paint', 'gimp',
            'obs', 'vlc', 'audacity',
            'task manager', 'administrador de tareas',
        ]
        for app in sorted(KNOWN_APPS, key=len, reverse=True):
            if app in text:
                return app
        # Si no hay app conocida, extraer siguiente palabra después del verbo
        m = re.search(r'(?:abre|abrir|lanza|inicia|ejecuta|open)\s+(\w+)', text)
        if m:
            return m.group(1)
        return ''

    def _extract_file_path(self, text: str) -> Optional[str]:
        """Extraer ruta de archivo si se menciona."""
        # Rutas Windows/Unix
        m = re.search(r'[A-Za-z]:\\[\w\\ .]+\.[\w]+', text)
        if m:
            return m.group(0)
        m = re.search(r'/[\w/ .]+\.[\w]+', text)
        if m:
            return m.group(0)
        # Extensiones de archivo
        m = re.search(r'[\w .\-]+\.(?:docx?|pdf|txt|csv|xlsx?|py|js|json|xml|html)', text, re.IGNORECASE)
        if m:
            return m.group(0).strip()
        return None

    def _clean_for_search(self, text: str, keywords: List[str]) -> str:
        """Limpiar texto para usarlo como query de búsqueda."""
        result = text
        stop_words = {'el', 'la', 'los', 'las', 'un', 'una', 'de', 'del', 'en', 'al', 'por', 'para'}
        for kw in keywords:
            result = result.replace(kw, '')
        words = [w for w in result.split() if w not in stop_words and len(w) > 2]
        return ' '.join(words).strip()

    def _push_context(self, intent: Dict):
        self._context.append({'name': intent['name'], 'skill': intent['skill']})
        if len(self._context) > self._max_ctx:
            self._context.pop(0)

    def detect_chain(self, text: str) -> List[str]:
        """
        Detectar si hay múltiples comandos encadenados.
        Ejemplo: "abre chrome y ponme música" → ["abre chrome", "ponme música"]
        """
        connectors = r'\s+(?:y\s+después|luego|después|y\s+también|además|y\s+luego|y)\s+'
        parts = re.split(connectors, text, flags=re.IGNORECASE)
        return [p.strip() for p in parts if p.strip() and len(p.strip()) > 2]

    def is_conversational(self, text: str) -> bool:
        """¿Es esto una pregunta conversacional / de conocimiento?"""
        tl = text.lower()
        conv_patterns = [
            r'(qu[eé]\s+(opinas?|piensas?|crees?)\s+de)',
            r'(c[oó]mo\s+se\s+(hace|usa|instala|configura))',
            r'(explica|explícame|d[eé]cuéntame)',
            r'(para\s+qu[eé]\s+sirve|ventajas|desventajas)',
            r'(qu[eé]\s+(es|son|significa))',
            r'(diferencia\s+entre|comparar)',
        ]
        return any(re.search(p, tl) for p in conv_patterns)
