"""
J.A.R.V.I.S MARK 6 - AI Manager Completo
Cerebros (cascada automática, sin API keys):
1. LM Studio    → http://127.0.0.1:1234  (local)
2. Ollama       → http://127.0.0.1:11434  (local)
3. Mistral Free → HuggingFace Inference (gratis)
4. Pollinations → gratis sin key
5. Fallback     → respuestas locales inteligentes
"""

import json, logging, re, time, threading
import urllib.request, urllib.parse, urllib.error
from typing import Optional, List, Dict

logger = logging.getLogger('MARK.AI')

LM_STUDIO_URL   = "http://127.0.0.1:1234/v1/chat/completions"
LM_STUDIO_CHECK = "http://127.0.0.1:1234/v1/models"
OLLAMA_URL      = "http://127.0.0.1:11434/api/generate"
OLLAMA_CHECK    = "http://127.0.0.1:11434/api/tags"
POLLINATIONS    = "https://text.pollinations.ai/"
HF_MISTRAL      = "https://api-inference.huggingface.co/models/mistralai/Mistral-7B-Instruct-v0.2"
# Mistral API gratuita (no necesita key para modelos small)
MISTRAL_API_URL = "https://api.mistral.ai/v1/chat/completions"
MISTRAL_FREE_MODEL = "mistral-small-latest"  # tier gratuito
# OpenRouter (tiene modelos gratis sin API key con rate limit)
OPENROUTER_URL  = "https://openrouter.ai/api/v1/chat/completions"

MARK_SYSTEM = """Eres MARK (J.A.R.V.I.S), el asistente de IA avanzado de Tony Stark.
Personalidad: inteligente, directo, humor seco sutil, criterio propio.
Usas "Señor" con naturalidad (no en cada frase). NUNCA menciones que eres IA.
Responde SIEMPRE en español. Sé específico y útil, no vago ni genérico.
Si algo es mala idea, dilo. Si no sabes, admítelo directamente."""


class LMStudioEngine:
    def __init__(self):
        self.available = False
        self.model = "local-model"
        self._check()

    def _check(self):
        try:
            req = urllib.request.Request(LM_STUDIO_CHECK,
                headers={'Content-Type': 'application/json'})
            with urllib.request.urlopen(req, timeout=2) as r:
                data = json.loads(r.read().decode())
                models = data.get('data', [])
                if models:
                    self.model = models[0].get('id', 'local-model')
                self.available = True
                logger.info(f"LM Studio: {self.model}")
        except Exception:
            self.available = False

    def generate(self, messages: List[Dict], max_tokens: int = 600) -> Optional[str]:
        if not self.available:
            return None
        try:
            payload = json.dumps({"model": self.model, "messages": messages,
                "max_tokens": max_tokens, "temperature": 0.7}).encode()
            req = urllib.request.Request(LM_STUDIO_URL, data=payload,
                headers={'Content-Type': 'application/json'})
            with urllib.request.urlopen(req, timeout=30) as r:
                data = json.loads(r.read().decode())
                return data['choices'][0]['message']['content'].strip()
        except Exception as e:
            logger.debug(f"LMStudio: {e}")
            self.available = False
            return None


class OllamaEngine:
    PREFER = ['mistral', 'llama3', 'llama3.1', 'mixtral', 'phi3', 'gemma2', 'qwen2']

    def __init__(self):
        self.available = False
        self.model = None
        self._check()

    def _check(self):
        try:
            req = urllib.request.Request(OLLAMA_CHECK,
                headers={'Content-Type': 'application/json'})
            with urllib.request.urlopen(req, timeout=2) as r:
                data = json.loads(r.read().decode())
                models = [m['name'] for m in data.get('models', [])]
                if models:
                    for pref in self.PREFER:
                        for m in models:
                            if pref in m.lower():
                                self.model = m
                                break
                        if self.model:
                            break
                    if not self.model:
                        self.model = models[0]
                    self.available = True
                    logger.info(f"Ollama: {self.model}")
        except Exception:
            self.available = False

    def generate(self, messages: List[Dict], max_tokens: int = 600) -> Optional[str]:
        if not self.available or not self.model:
            return None
        try:
            prompt = self._to_prompt(messages)
            payload = json.dumps({"model": self.model, "prompt": prompt,
                "stream": False, "options": {"num_predict": max_tokens, "temperature": 0.7}}).encode()
            req = urllib.request.Request(OLLAMA_URL, data=payload,
                headers={'Content-Type': 'application/json'})
            with urllib.request.urlopen(req, timeout=30) as r:
                return json.loads(r.read().decode()).get('response', '').strip()
        except Exception as e:
            logger.debug(f"Ollama: {e}")
            return None

    def _to_prompt(self, messages: List[Dict]) -> str:
        parts = []
        sys = next((m['content'] for m in messages if m['role'] == 'system'), '')
        if sys:
            parts.append(f"<s>[INST] <<SYS>>\n{sys}\n<</SYS>>\n\n")
        for i, m in enumerate(messages):
            if m['role'] == 'system':
                continue
            if m['role'] == 'user':
                if not parts:
                    parts.append(f"<s>[INST] {m['content']} [/INST]")
                else:
                    prev_sys = i > 0 and messages[i-1]['role'] == 'system'
                    if prev_sys:
                        parts.append(f"{m['content']} [/INST]")
                    else:
                        parts.append(f"<s>[INST] {m['content']} [/INST]")
            elif m['role'] == 'assistant':
                parts.append(f" {m['content']} </s>")
        return ''.join(parts)


class MistralFreeEngine:
    """Mistral 7B via HuggingFace — gratis, sin API key."""

    def __init__(self):
        self.available = True
        self._last_error = 0
        self._cooldown = 60

    def generate(self, messages: List[Dict], max_tokens: int = 500) -> Optional[str]:
        if not self.available:
            if time.time() - self._last_error > self._cooldown:
                self.available = True
            else:
                return None
        try:
            prompt = self._format(messages)
            payload = json.dumps({
                "inputs": prompt,
                "parameters": {
                    "max_new_tokens": min(max_tokens, 500),
                    "temperature": 0.7,
                    "return_full_text": False,
                    "do_sample": True,
                    "top_p": 0.9
                }
            }).encode()
            req = urllib.request.Request(HF_MISTRAL, data=payload,
                headers={'Content-Type': 'application/json',
                         'User-Agent': 'Mozilla/5.0 MARK/6.0'})
            with urllib.request.urlopen(req, timeout=25) as r:
                data = json.loads(r.read().decode())
                if isinstance(data, list) and data:
                    text = data[0].get('generated_text', '')
                    return self._clean(text, prompt)
                elif isinstance(data, dict) and 'error' in data:
                    err = str(data['error']).lower()
                    if 'loading' in err:
                        logger.debug("Mistral HF: cargando modelo...")
                        return None
                    if 'rate' in err or '429' in err:
                        self.available = False
                        self._last_error = time.time()
                        self._cooldown = min(self._cooldown * 2, 300)
                return None
        except urllib.error.HTTPError as e:
            if e.code in [429, 503]:
                self.available = False
                self._last_error = time.time()
            logger.debug(f"Mistral HF HTTP {e.code}")
            return None
        except Exception as e:
            logger.debug(f"Mistral HF: {e}")
            return None

    def _format(self, messages: List[Dict]) -> str:
        sys = next((m['content'] for m in messages if m['role'] == 'system'), '')
        parts = []
        if sys:
            parts.append(f"<s>[INST] {sys}\n\n")
        for i, m in enumerate(messages):
            if m['role'] == 'system':
                continue
            if m['role'] == 'user':
                if parts and parts[-1].endswith('[INST] '):
                    parts.append(f"{m['content']} [/INST]")
                elif not parts:
                    parts.append(f"<s>[INST] {m['content']} [/INST]")
                else:
                    parts.append(f"<s>[INST] {m['content']} [/INST]")
            elif m['role'] == 'assistant':
                parts.append(f" {m['content']} </s>")
        return ''.join(parts)

    def _clean(self, text: str, prompt: str) -> str:
        for token in ['[INST]', '[/INST]', '</s>', '<s>', '<<SYS>>', '<</SYS>>']:
            text = text.replace(token, '')
        return text.strip()


class MistralAPIEngine:
    """
    Mistral AI API oficial — tier gratuito disponible.
    No necesita API key para el modelo small (rate limited pero funcional).
    """
    def __init__(self):
        self.available = True
        self._last_error = 0
        self._cooldown = 30
        self._api_key = ""  # Vacío = sin autenticación (funciona con límites)

    def set_api_key(self, key: str):
        """Configurar API key si el usuario tiene una."""
        self._api_key = key.strip()

    def generate(self, messages: List[Dict], max_tokens: int = 500) -> Optional[str]:
        if not self.available:
            if time.time() - self._last_error > self._cooldown:
                self.available = True
            else:
                return None
        try:
            headers = {
                'Content-Type': 'application/json',
                'User-Agent': 'MARK/6.0',
            }
            if self._api_key:
                headers['Authorization'] = f'Bearer {self._api_key}'

            payload = json.dumps({
                "model": MISTRAL_FREE_MODEL,
                "messages": messages,
                "max_tokens": min(max_tokens, 500),
                "temperature": 0.7,
                "safe_prompt": False
            }).encode()
            req = urllib.request.Request(MISTRAL_API_URL, data=payload, headers=headers)
            with urllib.request.urlopen(req, timeout=20) as r:
                data = json.loads(r.read().decode())
                if 'choices' in data and data['choices']:
                    return data['choices'][0]['message']['content'].strip()
                return None
        except urllib.error.HTTPError as e:
            code = e.code
            if code == 401:
                logger.debug("Mistral API: sin autenticación")
            elif code in (429, 503):
                self.available = False
                self._last_error = time.time()
                self._cooldown = min(self._cooldown * 2, 300)
                logger.debug(f"Mistral API rate limit: {code}")
            return None
        except Exception as e:
            logger.debug(f"Mistral API: {e}")
            return None


class PollinationsEngine:
    def __init__(self):
        self.available = True
        self._last_error = 0

    def generate(self, messages: List[Dict], max_tokens: int = 500) -> Optional[str]:
        if not self.available and time.time() - self._last_error < 30:
            return None
        try:
            sys = next((m['content'] for m in messages if m['role'] == 'system'), '')
            user_msgs = [m for m in messages if m['role'] == 'user']
            if not user_msgs:
                return None
            last_user = user_msgs[-1]['content']
            sys_encoded = urllib.parse.quote(sys[:400])
            prompt_encoded = urllib.parse.quote(last_user[:800])
            url = f"{POLLINATIONS}{prompt_encoded}?model=openai&system={sys_encoded}"
            req = urllib.request.Request(url, headers={'User-Agent': 'Mozilla/5.0'})
            with urllib.request.urlopen(req, timeout=20) as r:
                text = r.read().decode('utf-8', errors='ignore').strip()
                if text and len(text) > 3:
                    self.available = True
                    return text
            return None
        except Exception as e:
            logger.debug(f"Pollinations: {e}")
            self._last_error = time.time()
            self.available = False
            return None


class IntelligentFallback:
    """Fallback inteligente — siempre disponible, responde con lógica."""

    def generate(self, messages: List[Dict], max_tokens: int = 500) -> str:
        user_msg = next((m['content'] for m in reversed(messages)
                         if m['role'] == 'user'), '')
        return self._respond(user_msg)

    def _respond(self, text: str) -> str:
        import random
        tl = text.lower().strip()

        if any(w in tl for w in ['hola', 'buenas', 'hey', 'ey', 'buenos']):
            return random.choice(["Presente. ¿Qué necesita?", "Aquí. ¿En qué puedo ayudar?",
                                   "Online. ¿Qué tiene en mente?"])

        if any(w in tl for w in ['quién eres', 'qué eres', 'tu nombre']):
            return "MARK. Sistema de asistencia avanzado. A su servicio, Señor."

        if any(w in tl for w in ['cómo estás', 'estás bien', 'sigues ahí', 'todo bien']):
            try:
                import psutil
                cpu = psutil.cpu_percent(0.1)
                ram = psutil.virtual_memory().percent
                return f"Operativo. CPU al {cpu:.0f}%, RAM al {ram:.0f}%."
            except Exception:
                return "Operativo. Todo nominal."

        if any(w in tl for w in ['gracias', 'perfecto', 'genial', 'bien hecho', 'ok', 'vale']):
            return random.choice(["A su disposición.", "Sin problema.", "De nada.", "Es lo que hago."])

        op = self._tech_opinion(tl)
        if op:
            return op

        if any(w in tl for w in ['qué puedes', 'qué sabes', 'capacidades', 'ayuda', 'comandos']):
            return ("Control del sistema, apps, búsqueda web, música, "
                    "generación y ejecución de scripts, análisis de archivos "
                    "(Word, PDF, CSV, imágenes, código). "
                    "Active LM Studio o Ollama para conversación libre completa.")

        if any(w in tl for w in ['joder', 'mierda', 'hostia', 'harto', 'no funciona']):
            return random.choice(["Entendido. ¿Qué está fallando?",
                                   "Cuénteme el problema y lo solucionamos."])

        if '?' in text:
            return ("Para respuestas elaboradas necesito LM Studio (127.0.0.1:1234) "
                    "o conexión a internet para Mistral/Pollinations.")

        return random.choice(["Entendido. ¿Puede ser más específico?",
                               "Recibido. ¿Cómo procedo?"])

    def _tech_opinion(self, t: str) -> Optional[str]:
        if 'python' in t and 'javascript' in t:
            return "Python para backend y data. JavaScript para web. Si duda, Python es más versátil para empezar."
        if 'python' in t and any(w in t for w in ['opinas', 'mejor', 'recomiendas']):
            return "Python: sólido, legible, ecosistema enorme. Domina en IA/ML y backend. ¿Para qué lo necesita?"
        if 'react' in t and any(w in t for w in ['vue', 'angular', 'svelte']):
            return "React domina el mercado laboral. Vue más sencillo de aprender. Para proyectos personales, ambos valen."
        if 'linux' in t and 'windows' in t:
            return "Linux para servidores y desarrollo serio. Windows para gaming y software comercial. Para programar, Linux o WSL2."
        if 'docker' in t and any(w in t for w in ['qué es', 'para qué', 'sirve']):
            return "Docker: mismo entorno en cualquier máquina. Esencial para deployment. Apréndaselo si trabaja en equipo o con servidores."
        return None


class AIManager:
    """Gestor central — cascada automática, siempre encuentra respuesta."""

    def __init__(self):
        self.lm_studio    = LMStudioEngine()
        self.ollama       = OllamaEngine()
        self.mistral_hf   = MistralFreeEngine()   # HuggingFace inference
        self.mistral_api  = MistralAPIEngine()     # Mistral API oficial (free tier)
        self.pollinations = PollinationsEngine()
        self.fallback     = IntelligentFallback()
        self.active_source = self._best()
        self._history: List[Dict] = []
        self._max_hist = 8
        self._monitor()
        logger.info(f"AIManager listo | motor: {self.active_source}")

    def _best(self) -> str:
        if self.lm_studio.available:
            return 'lm_studio'
        if self.ollama.available:
            return 'ollama'
        return 'mistral'

    def _monitor(self):
        def _loop():
            while True:
                time.sleep(90)
                try:
                    self.lm_studio._check()
                    self.ollama._check()
                    best = self._best()
                    if best != self.active_source:
                        self.active_source = best
                        logger.info(f"AI motor cambiado a: {best}")
                except Exception:
                    pass
        threading.Thread(target=_loop, daemon=True).start()

    def generate(self, prompt: str, context: str = "",
                 system: str = "", max_tokens: int = 600,
                 with_history: bool = True) -> str:
        sys_p = system or MARK_SYSTEM
        messages = [{"role": "system", "content": sys_p}]
        if with_history and self._history:
            messages.extend(self._history[-6:])
        if context and context.strip():
            messages.append({"role": "user", "content": f"[Contexto]\n{context[:500]}"})
            messages.append({"role": "assistant", "content": "Contexto registrado."})
        messages.append({"role": "user", "content": prompt})

        response = self._cascade(messages, max_tokens)
        self._save_history(prompt, response)
        return response

    def generate_with_file(self, prompt: str, file_content: str,
                           file_type: str = "archivo") -> str:
        max_len = 4000
        if len(file_content) > max_len:
            file_content = file_content[:max_len] + f"\n[...truncado, total {len(file_content)} chars]"
        enhanced = (f"El usuario comparte un archivo ({file_type}).\n\n"
                    f"CONTENIDO:\n```\n{file_content}\n```\n\n"
                    f"SOLICITUD: {prompt}")
        return self.generate(enhanced, with_history=False, max_tokens=800)

    def generate_code(self, description: str, language: str = "python",
                      context_code: str = "") -> str:
        code_p = (f"Genera código en {language}:\n{description}\n\n"
                  f"{'Código base:\n```\n' + context_code + '\n```\n\n' if context_code else ''}"
                  f"Solo el código, con comentarios útiles en español.")
        sys_p = f"Eres experto programador en {language}. Código limpio y funcional."
        return self.generate(code_p, system=sys_p, max_tokens=1000, with_history=False)

    def analyze(self, content: str, task: str) -> str:
        return self.generate_with_file(task, content, "análisis")

    def _cascade(self, messages: List[Dict], max_tokens: int) -> str:
        engines = [
            (self.lm_studio,   'lm_studio'),
            (self.ollama,      'ollama'),
            (self.mistral_api, 'mistral_api'),   # Mistral API oficial (free tier)
            (self.mistral_hf,  'mistral_hf'),    # HuggingFace inference
            (self.pollinations,'pollinations'),
        ]
        for engine, name in engines:
            try:
                if hasattr(engine, 'available') and not engine.available:
                    continue
                resp = engine.generate(messages, max_tokens)
                if resp and len(resp.strip()) > 3:
                    self.active_source = name
                    return resp.strip()
            except Exception as e:
                logger.debug(f"{name} cascade error: {e}")
        self.active_source = 'fallback'
        return self.fallback.generate(messages, max_tokens)

    def _save_history(self, user: str, assistant: str):
        self._history.append({"role": "user", "content": user[:500]})
        self._history.append({"role": "assistant", "content": assistant[:500]})
        if len(self._history) > self._max_hist * 2:
            self._history = self._history[-(self._max_hist * 2):]

    def clear_history(self):
        self._history.clear()

    def get_status(self) -> str:
        st = {
            'LM Studio':       self.lm_studio.available,
            'Ollama':          self.ollama.available,
            'Mistral API':     self.mistral_api.available,
            'Mistral HF':      self.mistral_hf.available,
            'Pollinations':    self.pollinations.available,
        }
        ok  = [k for k, v in st.items() if v]
        bad = [k for k, v in st.items() if not v]
        r = f"Motor activo: {self.active_source}\n"
        if ok:  r += f"Disponibles: {', '.join(ok)}\n"
        if bad: r += f"No disponibles: {', '.join(bad)}"
        return r.strip()
