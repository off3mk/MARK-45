"""
JARVIS v7.0 - Startup Manager
Ejecutar JARVIS automáticamente al iniciar Windows y saludar al usuario.
Creador: Ali (Sidi3Ali)
"""

import logging
import os
import sys
import winreg
import subprocess
from datetime import datetime
from pathlib import Path
from typing import Optional

logger = logging.getLogger('JARVIS.StartupManager')

JARVIS_NAME = "JARVIS_v7"
STARTUP_FOLDER = os.path.join(
    os.environ.get('APPDATA', ''),
    r'Microsoft\Windows\Start Menu\Programs\Startup'
)


class StartupManager:
    """
    Gestión de inicio automático de JARVIS con Windows.
    - Registra JARVIS en el registro o carpeta de inicio
    - Al iniciar, saluda al usuario según la hora del día
    """

    def __init__(self, brain=None):
        self.brain = brain
        self._jarvis_path = self._get_jarvis_path()

    def _get_jarvis_path(self) -> str:
        """Obtener ruta absoluta del ejecutable/script de JARVIS."""
        base = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
        main_py = os.path.join(base, 'main.py')
        return main_py

    def install_autostart(self, method: str = 'registry') -> bool:
        """
        Instalar JARVIS en el inicio automático de Windows.
        method: 'registry' o 'startup_folder'
        """
        try:
            if method == 'registry':
                return self._install_via_registry()
            else:
                return self._install_via_startup_folder()
        except Exception as e:
            logger.error(f"Error instalando autostart: {e}")
            return False

    def _install_via_registry(self) -> bool:
        """Registrar en HKCU\\SOFTWARE\\Microsoft\\Windows\\CurrentVersion\\Run"""
        try:
            python_exe = sys.executable
            script = self._jarvis_path
            command = f'"{python_exe}" "{script}" --cli'

            key = winreg.OpenKey(
                winreg.HKEY_CURRENT_USER,
                r'SOFTWARE\Microsoft\Windows\CurrentVersion\Run',
                0, winreg.KEY_SET_VALUE
            )
            winreg.SetValueEx(key, JARVIS_NAME, 0, winreg.REG_SZ, command)
            winreg.CloseKey(key)
            logger.info(f"JARVIS registrado en autostart del registro: {command}")
            return True
        except Exception as e:
            logger.error(f"Error en registro: {e}")
            return False

    def _install_via_startup_folder(self) -> bool:
        """Crear acceso directo en carpeta de inicio de Windows."""
        try:
            import winshell
            from win32com.client import Dispatch

            shortcut_path = os.path.join(STARTUP_FOLDER, f"{JARVIS_NAME}.lnk")
            shell = Dispatch('WScript.Shell')
            shortcut = shell.CreateShortCut(shortcut_path)
            shortcut.Targetpath = sys.executable
            shortcut.Arguments = f'"{self._jarvis_path}" --cli'
            shortcut.WorkingDirectory = os.path.dirname(self._jarvis_path)
            shortcut.Description = "JARVIS v7.0 - Asistente IA"
            shortcut.save()
            logger.info(f"Acceso directo creado: {shortcut_path}")
            return True
        except ImportError:
            # Crear .bat como fallback
            bat_path = os.path.join(STARTUP_FOLDER, f"{JARVIS_NAME}.bat")
            bat_content = f'@echo off\nstart "" "{sys.executable}" "{self._jarvis_path}" --cli'
            with open(bat_path, 'w') as f:
                f.write(bat_content)
            logger.info(f"Archivo .bat de inicio creado: {bat_path}")
            return True
        except Exception as e:
            logger.error(f"Error en startup folder: {e}")
            return False

    def uninstall_autostart(self) -> bool:
        """Eliminar JARVIS del inicio automático."""
        removed = False
        # Intentar eliminar del registro
        try:
            key = winreg.OpenKey(
                winreg.HKEY_CURRENT_USER,
                r'SOFTWARE\Microsoft\Windows\CurrentVersion\Run',
                0, winreg.KEY_SET_VALUE
            )
            winreg.DeleteValue(key, JARVIS_NAME)
            winreg.CloseKey(key)
            removed = True
            logger.info("JARVIS eliminado del registro de autostart.")
        except FileNotFoundError:
            pass
        except Exception as e:
            logger.debug(f"No se pudo eliminar del registro: {e}")

        # Intentar eliminar de startup folder
        for ext in ['.lnk', '.bat']:
            p = os.path.join(STARTUP_FOLDER, f"{JARVIS_NAME}{ext}")
            if os.path.exists(p):
                os.remove(p)
                removed = True
                logger.info(f"Eliminado {p}")

        return removed

    def is_autostart_enabled(self) -> bool:
        """Comprobar si JARVIS está registrado para inicio automático."""
        # Comprobar registro
        try:
            key = winreg.OpenKey(
                winreg.HKEY_CURRENT_USER,
                r'SOFTWARE\Microsoft\Windows\CurrentVersion\Run',
                0, winreg.KEY_READ
            )
            winreg.QueryValueEx(key, JARVIS_NAME)
            winreg.CloseKey(key)
            return True
        except FileNotFoundError:
            pass
        except Exception:
            pass

        # Comprobar startup folder
        for ext in ['.lnk', '.bat']:
            if os.path.exists(os.path.join(STARTUP_FOLDER, f"{JARVIS_NAME}{ext}")):
                return True

        return False

    def get_startup_greeting(self, preferred_name: str = 'Ali',
                              is_creator: bool = True) -> str:
        """
        Generar saludo de inicio según hora del día.
        Si es el creador → usar nombre propio.
        """
        hour = datetime.now().hour

        if is_creator:
            if 5 <= hour < 12:
                messages = [
                    f"Buenos días, {preferred_name}. Sistemas en línea y a su disposición.",
                    f"Mañana detectada, {preferred_name}. JARVIS operativo.",
                    f"Buenos días. Todo nominal. ¿Empezamos el día?",
                ]
            elif 12 <= hour < 20:
                messages = [
                    f"Buenas tardes, {preferred_name}. Sistema activo.",
                    f"Tardes, {preferred_name}. JARVIS a su disposición.",
                    f"Bienvenido de nuevo, {preferred_name}. Todo en orden.",
                ]
            else:
                messages = [
                    f"Buenas noches, {preferred_name}. Trabajando tarde, como siempre.",
                    f"Noche detectada, {preferred_name}. JARVIS operativo.",
                    f"Bienvenido de nuevo, {preferred_name}. El sistema está listo.",
                ]
        else:
            name = preferred_name
            if 5 <= hour < 12:
                messages = [f"Buenos días, {name}. JARVIS a su disposición."]
            elif 12 <= hour < 20:
                messages = [f"Buenas tardes, {name}. JARVIS activo."]
            else:
                messages = [f"Buenas noches, {name}. JARVIS operativo."]

        import random
        return random.choice(messages)

    def perform_startup_greeting(self):
        """
        Ejecutar saludo de inicio: detectar usuario y saludar por voz.
        Llamar desde main.py al iniciar el sistema.
        """
        try:
            from core.user_identity import get_identity
            identity = get_identity()

            voice = None
            if self.brain and self.brain.voice:
                voice = self.brain.voice

            profile = identity.load_or_create_profile(voice=voice)

            preferred_name = profile.get('preferred_name', 'Ali')
            is_creator = bool(profile.get('creator_flag', 0))

            greeting = self.get_startup_greeting(preferred_name, is_creator)

            if voice:
                voice.speak(greeting, priority=True)
            else:
                print(f"\nJARVIS > {greeting}\n")

            logger.info(f"Saludo de inicio: {greeting}")

        except Exception as e:
            logger.error(f"Error en startup greeting: {e}")
