"""
JARVIS v4.0 - System Monitor (Percepción Continua)
Daemon de monitoreo continuo del sistema.
"""

import logging
import threading
import time
import psutil
from typing import Optional, Callable, List, Dict, Any

logger = logging.getLogger('JARVIS.Perception.System')


class SystemMonitor:
    """Monitor continuo del sistema operativo."""

    def __init__(self, brain=None):
        self.brain = brain
        self._running = False
        self._thread: Optional[threading.Thread] = None
        self._callbacks: List[Callable] = []
        self._metrics_history: List[Dict] = []
        self._max_history = 60  # 5 minutos a 5s de intervalo

        self._prev_processes: set = set()

    def start(self):
        """Iniciar monitoreo."""
        self._running = True
        self._thread = threading.Thread(
            target=self._monitor_loop, daemon=True
        )
        self._thread.start()
        logger.info("System Monitor iniciado")

    def stop(self):
        """Detener monitoreo."""
        self._running = False
        if self._thread:
            self._thread.join(timeout=3)

    def _monitor_loop(self):
        """Bucle principal de monitoreo."""
        while self._running:
            try:
                metrics = self._collect_metrics()
                self._metrics_history.append(metrics)
                if len(self._metrics_history) > self._max_history:
                    self._metrics_history.pop(0)

                self._detect_process_changes()
                self._notify_metrics(metrics)

            except Exception as e:
                logger.debug(f"Error en system monitor: {e}")

            time.sleep(5)

    def _collect_metrics(self) -> Dict[str, Any]:
        """Recopilar métricas del sistema."""
        metrics = {
            'timestamp': time.time(),
            'cpu_percent': psutil.cpu_percent(),
            'memory_percent': psutil.virtual_memory().percent,
            'disk_percent': psutil.disk_usage('/').percent,
        }

        try:
            battery = psutil.sensors_battery()
            if battery:
                metrics['battery'] = {
                    'percent': battery.percent,
                    'plugged': battery.power_plugged,
                    'secs_left': battery.secsleft
                }
        except Exception:
            pass

        try:
            net = psutil.net_io_counters()
            metrics['network'] = {
                'bytes_sent': net.bytes_sent,
                'bytes_recv': net.bytes_recv
            }
        except Exception:
            pass

        return metrics

    def _detect_process_changes(self):
        """Detectar cambios en procesos del sistema."""
        try:
            current_procs = set()
            for proc in psutil.process_iter(['name', 'pid']):
                current_procs.add((proc.info['pid'], proc.info['name']))

            new_procs = current_procs - self._prev_processes
            closed_procs = self._prev_processes - current_procs

            if new_procs:
                for pid, name in new_procs:
                    logger.debug(f"Nuevo proceso: {name} (PID: {pid})")
                    self._notify_event('process_started', {'name': name, 'pid': pid})

            self._prev_processes = current_procs

        except Exception:
            pass

    def _notify_metrics(self, metrics: Dict):
        """Notificar métricas a callbacks."""
        for callback in self._callbacks:
            try:
                callback('metrics', metrics)
            except Exception:
                pass

    def _notify_event(self, event_type: str, data: Dict):
        """Notificar evento a callbacks."""
        for callback in self._callbacks:
            try:
                callback(event_type, data)
            except Exception:
                pass

    def add_callback(self, callback: Callable):
        """Añadir callback para eventos."""
        self._callbacks.append(callback)

    def get_latest_metrics(self) -> Optional[Dict]:
        """Obtener métricas más recientes."""
        if self._metrics_history:
            return self._metrics_history[-1]
        return None

    def get_metrics_average(self, window: int = 12) -> Dict:
        """Obtener promedio de métricas en ventana de tiempo."""
        if not self._metrics_history:
            return {}

        recent = self._metrics_history[-window:]
        avg = {
            'cpu_avg': sum(m.get('cpu_percent', 0) for m in recent) / len(recent),
            'memory_avg': sum(m.get('memory_percent', 0) for m in recent) / len(recent),
            'samples': len(recent)
        }
        return avg
