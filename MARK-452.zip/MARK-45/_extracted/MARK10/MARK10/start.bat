@echo off
title MARK 10 — Autonomous Cognitive System — Ali (Sidi3Ali)
color 0B
cd /d "%~dp0"
echo  Iniciando MARK 10...
python main.py %*
pause
