@echo off
title MARK 10 — Instalacion — Ali (Sidi3Ali)
color 0A
echo.
echo  ============================================================
echo   M A R K  1 0  --  Instalando dependencias
echo   Optimizado para i5-9600K + RX 5700 XT + 16GB RAM
echo   LM Studio como motor IA principal
echo   Creator: Ali (Sidi3Ali)
echo  ============================================================
echo.
echo  [1/5] Dependencias principales...
pip install psutil pyautogui pygetwindow pynput pyperclip pywin32 uiautomation
echo.
echo  [2/5] Voz (TTS/STT)...
pip install edge-tts pyttsx3 SpeechRecognition pygame
echo.
echo  [3/5] Vision y pantalla...
pip install Pillow mss
echo.
echo  [4/5] Internet y datos...
pip install requests spotipy
echo.
echo  [5/5] Extras opcionales...
pip install comtypes
echo.
echo  ============================================================
echo  OPCIONAL: Para control de volumen (pycaw):
echo    pip install pycaw
echo.
echo  OPCIONAL: Para OCR/Vision:
echo    pip install pytesseract opencv-python
echo    + Instala Tesseract: https://tesseract-ocr.github.io
echo.
echo  OPCIONAL: Para voz por microfono:
echo    pip install pipwin
echo    pipwin install pyaudio
echo.
echo  MOTOR IA: LM Studio (NO se necesita Ollama)
echo    1. Descarga: https://lmstudio.ai/download
echo    2. Carga cualquier modelo GGUF (recomendado: Mistral 7B o Llama 3.1 8B)
echo    3. En LM Studio: Server tab → Start Server (puerto 1234)
echo  ============================================================
echo.
echo  Instalacion completada. Ejecuta start.bat
pause
