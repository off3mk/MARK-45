"""
MARK 13 — Perception Loop
===========================
Monitor del sistema optimizado para:
  Ryzen 7 5800X | 32GB RAM | RTX 4060 Ti 8GB | Windows 11

Novedades respecto a MARK 12:
  • Monitoreo de VRAM de la RTX 4060 Ti via pynvml
  • Detección de temperatura de CPU/GPU
  • Métricas de red más detalladas
  • Lista de juegos actualizada para 2024/2025

Creado por Ali (Sidi3Ali) — MARK 13
"""

import logging
import os
import platform
import subprocess
import time
from datetime import datetime
from typing import Dict, List, Set

logger = logging.getLogger("MARK13.Perception")

SYSTEM = platform.system()

# ── JUEGOS CONOCIDOS ──────────────────────────────────────────────────────────
KNOWN_GAMES: Set[str] = {
    # Shooters
    "cs2.exe", "csgo.exe", "valorant.exe", "r5apex.exe",
    "cod.exe", "modernwarfare.exe", "warzone.exe", "mw2.exe",
    "bf2042.exe", "battlefieldbadcompany2.exe",
    "destiny2.exe", "halo.exe",
    # Open world / RPG
    "gta5.exe", "gtav.exe", "cyberpunk2077.exe", "rdr2.exe",
    "witcher3.exe", "eldenring.exe", "hogwartslegacy.exe",
    "starfield.exe", "baldursgate3.exe", "bg3.exe",
    "diablo4.exe", "pathofexile.exe", "poe2.exe",
    # Deportes / Racing
    "fc24.exe", "fc25.exe", "fifa24.exe", "nba2k25.exe",
    "assettocorsa.exe", "assettocorsacompetizione.exe",
    "ets2.exe", "forza.exe",
    # Indies / otros
    "minecraft.exe", "javaw.exe",
    "terraria.exe", "stardewvalley.exe",
    "hollowknight.exe", "celeste.exe",
    "lethalcompany.exe", "palworld.exe",
    # Simuladores
    "msfs.exe", "msfs2020.exe", "msfs2024.exe",
    # Launchers (cuando el juego está activo)
    "battle.net.exe", "epicgameslauncher.exe",
    "uplay.exe", "gog.exe",
}

WORK_APPS: Set[str] = {
    "code.exe", "cursor.exe", "pycharm64.exe", "webstorm64.exe",
    "devenv.exe", "notepad++.exe",
    "word.exe", "excel.exe", "powerpnt.exe",
    "outlook.exe", "teams.exe", "slack.exe",
    "obsidian.exe", "notion.exe",
    "docker desktop.exe", "wsl.exe",
}


class GPUMonitor:
    """
    Monitor de GPU — RTX 4060 Ti 8GB via NVML.
    Si pynvml no está instalado, retorna valores estimados.
    """
    def __init__(self):
        self._nvml   = None
        self._handle = None
        self._init()

    def _init(self):
        try:
            import pynvml
            pynvml.nvmlInit()
            self._nvml   = pynvml
            self._handle = pynvml.nvmlDeviceGetHandleByIndex(0)
            info = pynvml.nvmlDeviceGetName(self._handle)
            name = info.decode() if isinstance(info, bytes) else info
            logger.info(f"✓ NVML: GPU detectada — {name}")
        except ImportError:
            logger.debug("pynvml no disponible → pip install pynvml")
        except Exception as e:
            logger.debug(f"NVML init: {e}")

    def get_stats(self) -> Dict:
        if not self._nvml or not self._handle:
            return {"vram_used_mb": 0, "vram_total_mb": 8192,
                    "vram_pct": 0.0, "gpu_temp": 0, "gpu_util": 0}
        try:
            mem  = self._nvml.nvmlDeviceGetMemoryInfo(self._handle)
            temp = self._nvml.nvmlDeviceGetTemperature(
                self._handle, self._nvml.NVML_TEMPERATURE_GPU
            )
            util = self._nvml.nvmlDeviceGetUtilizationRates(self._handle)
            return {
                "vram_used_mb":  mem.used // 1024**2,
                "vram_total_mb": mem.total // 1024**2,
                "vram_pct":      (mem.used / mem.total) * 100,
                "gpu_temp":      temp,
                "gpu_util":      util.gpu,
            }
        except Exception:
            return {"vram_used_mb": 0, "vram_total_mb": 8192,
                    "vram_pct": 0.0, "gpu_temp": 0, "gpu_util": 0}

    @property
    def available(self) -> bool:
        return self._handle is not None


class SystemMonitor:
    """
    Monitor principal de MARK 13.
    Hardware objetivo: Ryzen 7 5800X | 32GB | RTX 4060 Ti 8GB | Win11
    """

    def __init__(self):
        self._ps   = None
        self._gpu  = GPUMonitor()
        self._last: Dict = {}
        self._init_psutil()

    def _init_psutil(self):
        try:
            import psutil
            self._ps = psutil
            logger.info("✓ psutil disponible")
        except ImportError:
            logger.warning("psutil no instalado → pip install psutil")

    def get_stats(self) -> Dict:
        """Recopilar métricas completas del sistema."""
        stats: Dict = {
            "cpu":          0.0,
            "ram":          0.0,
            "ram_used_gb":  0.0,
            "ram_total_gb": 32.0,
            "disk":         0.0,
            "active_app":   "",
            "active_window": "",
            "gaming_mode":  False,
            "game_name":    "",
            "is_working":   False,
            "user_idle_secs": 0,
            "gpu_vram_pct": 0.0,
            "gpu_temp":     0,
            "gpu_util":     0,
            "vram_used_mb": 0,
            "vram_total_mb": 8192,
            "timestamp":    datetime.now().isoformat(),
        }

        if not self._ps:
            return stats

        ps = self._ps
        try:
            # CPU
            stats["cpu"] = ps.cpu_percent(interval=None)

            # RAM
            mem = ps.virtual_memory()
            stats["ram"]         = mem.percent
            stats["ram_used_gb"] = round(mem.used  / 1024**3, 1)
            stats["ram_total_gb"]= round(mem.total / 1024**3, 1)

            # Disco
            try:
                d = ps.disk_usage("C:\\" if SYSTEM == "Windows" else "/")
                stats["disk"] = d.percent
            except Exception:
                pass

            # GPU (RTX 4060 Ti)
            gpu_data = self._gpu.get_stats()
            stats.update(gpu_data)

            # Procesos activos
            running: Set[str] = set()
            try:
                for p in ps.process_iter(["name"]):
                    n = (p.info.get("name") or "").lower()
                    if n and len(n) > 2:
                        running.add(n)
            except Exception:
                pass

            # Detectar gaming
            active_games = running & KNOWN_GAMES
            for pn in running:
                if any(kw in pn for kw in ["game", "unreal", "unity3d"]):
                    if pn not in {"gameplay", "gameoverlayrenderer64.exe"}:
                        active_games.add(pn)
            if active_games:
                stats["gaming_mode"] = True
                stats["game_name"]   = list(active_games)[0]

            # Detectar trabajo
            stats["is_working"] = bool(running & WORK_APPS) and not stats["gaming_mode"]

            # Ventana activa
            title = self._get_window_title()
            if title:
                stats["active_window"] = title[:100]
                stats["active_app"]    = title.split(" - ")[-1][:50]

            # Idle
            stats["user_idle_secs"] = self._get_idle_secs()

        except Exception as e:
            logger.debug(f"get_stats: {e}")

        self._last = stats
        return stats

    def _get_window_title(self) -> str:
        try:
            if SYSTEM == "Windows":
                import ctypes
                hwnd = ctypes.windll.user32.GetForegroundWindow()
                ln   = ctypes.windll.user32.GetWindowTextLengthW(hwnd)
                buf  = ctypes.create_unicode_buffer(ln + 1)
                ctypes.windll.user32.GetWindowTextW(hwnd, buf, ln + 1)
                return buf.value or ""
            elif SYSTEM == "Darwin":
                r = subprocess.run(
                    ["osascript", "-e",
                     'tell app "System Events" to get name of first process whose frontmost is true'],
                    capture_output=True, text=True, timeout=2
                )
                return r.stdout.strip()
        except Exception:
            pass
        return ""

    def _get_idle_secs(self) -> int:
        try:
            if SYSTEM == "Windows":
                import ctypes
                class LINFO(ctypes.Structure):
                    _fields_ = [("cbSize", ctypes.c_uint), ("dwTime", ctypes.c_uint)]
                lii = LINFO()
                lii.cbSize = ctypes.sizeof(LINFO)
                ctypes.windll.user32.GetLastInputInfo(ctypes.byref(lii))
                ms = ctypes.windll.kernel32.GetTickCount() - lii.dwTime
                return ms // 1000
        except Exception:
            pass
        return 0

    def get_top_processes(self, n: int = 8) -> List[Dict]:
        if not self._ps:
            return []
        try:
            procs = []
            for p in self._ps.process_iter(["name", "cpu_percent", "memory_percent"]):
                try:
                    procs.append({
                        "name": p.info["name"],
                        "cpu":  p.info["cpu_percent"] or 0,
                        "mem":  p.info["memory_percent"] or 0,
                    })
                except Exception:
                    pass
            return sorted(procs, key=lambda x: x["cpu"], reverse=True)[:n]
        except Exception:
            return []

    def get_summary_text(self) -> str:
        s = self._last or self.get_stats()
        parts = [
            f"CPU {s['cpu']:.0f}%",
            f"RAM {s['ram']:.0f}% ({s.get('ram_used_gb',0):.1f}/{s.get('ram_total_gb',32):.0f}GB)",
        ]
        if s.get("gpu_util", 0) > 0:
            parts.append(
                f"GPU {s['gpu_util']}% | VRAM {s.get('vram_used_mb',0):.0f}/{s.get('vram_total_mb',8192):.0f}MB"
            )
        if s.get("disk"):
            parts.append(f"Disco {s['disk']:.0f}%")
        if s.get("gaming_mode"):
            parts.append(f"🎮 Gaming")
        return " | ".join(parts)

    def is_gaming(self) -> bool:
        return self._last.get("gaming_mode", False)

    def is_critical(self) -> bool:
        return self._last.get("cpu", 0) > 90 or self._last.get("ram", 0) > 90
