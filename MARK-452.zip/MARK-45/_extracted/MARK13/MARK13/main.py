#!/usr/bin/env python3
"""
MARK 13 — Launcher
====================
Hardware: Ryzen 7 5800X | 32GB RAM | RTX 4060 Ti 8GB | Windows 11
Modelo:   Qwen3-8B Q5_K_M en LM Studio (CUDA)

Uso:
  python main.py          → GUI (ventana gráfica)
  python main.py --cli    → Consola interactiva
  python main.py --debug  → Logs detallados

Creado por Ali (Sidi3Ali) — MARK 13
"""

import argparse
import asyncio
import logging
import os
import sys
import threading
from datetime import datetime

# Asegurar path del proyecto
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

# Crear directorios necesarios
for d in ["workspace", "memory", "logs", "memory/audio_sessions"]:
    os.makedirs(d, exist_ok=True)


def setup_logging(debug: bool = False):
    level = logging.DEBUG if debug else logging.INFO
    fmt   = "%(asctime)s [%(name)s] %(levelname)s: %(message)s"
    handlers = [
        logging.StreamHandler(sys.stdout),
        logging.FileHandler(
            f"logs/mark13_{datetime.now().strftime('%Y%m%d')}.log",
            encoding="utf-8"
        ),
    ]
    logging.basicConfig(level=level, format=fmt, handlers=handlers)
    for quiet in ["urllib3", "httpx", "PIL", "asyncio", "comtypes"]:
        logging.getLogger(quiet).setLevel(logging.WARNING)


# ── MODO CLI ──────────────────────────────────────────────────────────────────

async def run_cli(debug: bool = False):
    from core.orchestrator import Orchestrator
    orch = Orchestrator()

    print("\n" + "╔" + "═" * 58 + "╗")
    print("║  M A R K  1 3  — Asistente Personal de Ali (Sidi3Ali)  ║")
    print("║  Ryzen 7 5800X | 32GB | RTX 4060 Ti 8GB | Win11         ║")
    print("╚" + "═" * 58 + "╝")
    print(f"  LLM activo: {getattr(orch.llm, 'active_provider', 'N/A')}")
    print(f"  Usuario: {orch._user_name}")
    print(f"  Escribe 'salir' para terminar\n")

    # Bucles de fondo (sin voice loop en CLI)
    bg = asyncio.create_task(asyncio.gather(
        orch._loop_perception(),
        orch._loop_gaming(),
        orch._loop_cognitive(),
        orch._loop_execution(),
    ))

    try:
        while orch.running:
            try:
                user_input = await asyncio.to_thread(
                    input, f"\n{orch._user_name} > "
                )
                user_input = user_input.strip()
                if not user_input:
                    continue
                if user_input.lower() in ["salir", "exit", "quit"]:
                    await orch.shutdown()
                    break

                print(f"\nMARK 13 > ", end="", flush=True)
                response = await orch.handle_command(user_input)
                print(response)

            except (KeyboardInterrupt, EOFError):
                break
    finally:
        bg.cancel()
        try: await bg
        except asyncio.CancelledError: pass

    print("\n🛑 MARK 13 apagado.")


# ── MODO GUI ──────────────────────────────────────────────────────────────────

def run_gui():
    """GUI Tkinter oscura optimizada para MARK 13."""
    try:
        import tkinter as tk
        from tkinter import scrolledtext
        from core.orchestrator import Orchestrator

        orch = Orchestrator()

        # ── Paleta de colores (tema MARK) ─────────────────────────────────────
        C = {
            "bg":      "#0d0d14",
            "bg2":     "#13131e",
            "bg3":     "#1a1a28",
            "accent":  "#00c8ff",    # Azul MARK
            "green":   "#00ff9d",    # Online indicator
            "text":    "#e0e8ff",
            "dim":     "#4a4a6a",
            "user":    "#7eb8ff",
            "mark":    "#00c8ff",
            "sys":     "#4a4a6a",
            "alert":   "#ff4466",
            "warning": "#ffaa00",
        }

        root = tk.Tk()
        root.title("MARK 13 — Ali (Sidi3Ali)")
        root.geometry("1000x700")
        root.configure(bg=C["bg"])
        root.minsize(700, 500)

        # ── Header ────────────────────────────────────────────────────────────
        header = tk.Frame(root, bg=C["bg2"], pady=8)
        header.pack(fill="x")

        tk.Label(
            header, text="M A R K  1 3",
            font=("Courier", 18, "bold"), fg=C["accent"], bg=C["bg2"]
        ).pack(side="left", padx=20)

        # Indicador de estado en tiempo real
        status_var = tk.StringVar(value="● Iniciando...")
        status_lbl = tk.Label(
            header, textvariable=status_var,
            font=("Courier", 9), fg=C["dim"], bg=C["bg2"]
        )
        status_lbl.pack(side="right", padx=20)

        # Indicador LLM
        llm_var = tk.StringVar(value=f"LLM: {getattr(orch.llm, 'active_provider', '?')}")
        tk.Label(
            header, textvariable=llm_var,
            font=("Courier", 9), fg=C["green"], bg=C["bg2"]
        ).pack(side="right", padx=10)

        # Gaming mode indicator
        gaming_var = tk.StringVar(value="")
        gaming_lbl = tk.Label(
            header, textvariable=gaming_var,
            font=("Courier", 9, "bold"), fg=C["warning"], bg=C["bg2"]
        )
        gaming_lbl.pack(side="right", padx=10)

        # ── Chat area ─────────────────────────────────────────────────────────
        chat_frame = tk.Frame(root, bg=C["bg"])
        chat_frame.pack(fill="both", expand=True, padx=12, pady=(8, 0))

        chat = scrolledtext.ScrolledText(
            chat_frame, wrap=tk.WORD, state="disabled",
            font=("Consolas", 11), bg=C["bg"], fg=C["text"],
            insertbackground=C["accent"], relief="flat",
            padx=16, pady=12, spacing1=2, spacing3=4,
        )
        chat.pack(fill="both", expand=True)

        # Tags de color
        chat.tag_config("user",    foreground=C["user"],    font=("Consolas", 11))
        chat.tag_config("mark",    foreground=C["mark"],    font=("Consolas", 11))
        chat.tag_config("sys",     foreground=C["dim"],     font=("Consolas", 9))
        chat.tag_config("alert",   foreground=C["alert"],   font=("Consolas", 11, "bold"))
        chat.tag_config("warning", foreground=C["warning"], font=("Consolas", 11))
        chat.tag_config("time",    foreground=C["dim"],     font=("Consolas", 8))

        def add_msg(text: str, role: str = "mark"):
            chat.configure(state="normal")
            ts   = datetime.now().strftime("%H:%M")
            prefixes = {
                "user":    f"\n[{ts}] {orch._user_name} › ",
                "mark":    f"\n[{ts}] MARK 13 › ",
                "sys":     f"\n[{ts}] SYS › ",
                "alert":   f"\n[{ts}] ⚠ ALERTA › ",
                "warning": f"\n[{ts}] ⚡ › ",
            }
            chat.insert(tk.END, prefixes.get(role, "\n"), role)
            chat.insert(tk.END, text)
            chat.configure(state="disabled")
            chat.see(tk.END)

        add_msg(
            f"Sistema activo. Ryzen 7 5800X | RTX 4060 Ti 8GB | Win11\n"
            f"  LLM: {getattr(orch.llm, 'active_provider', 'N/A')} | "
            f"Modelo objetivo: Qwen3-8B Q5_K_M",
            "sys"
        )

        # ── Input bar ─────────────────────────────────────────────────────────
        input_frame = tk.Frame(root, bg=C["bg2"], pady=8)
        input_frame.pack(fill="x", padx=12, pady=(4, 0))

        entry = tk.Entry(
            input_frame,
            font=("Consolas", 12),
            bg=C["bg3"], fg=C["text"],
            insertbackground=C["accent"],
            relief="flat", bd=8,
        )
        entry.pack(side="left", fill="x", expand=True, padx=(8, 6), ipady=4)

        def send(event=None):
            text = entry.get().strip()
            if not text:
                return
            entry.delete(0, tk.END)
            add_msg(text, "user")
            root.update()

            def process():
                loop = asyncio.new_event_loop()
                try:
                    resp = loop.run_until_complete(orch.handle_command(text))
                finally:
                    loop.close()
                root.after(0, lambda: add_msg(resp, "mark"))

            threading.Thread(target=process, daemon=True).start()

        entry.bind("<Return>", send)

        btn = tk.Button(
            input_frame, text="▶",
            font=("Consolas", 12, "bold"),
            bg=C["accent"], fg=C["bg"],
            relief="flat", padx=14, pady=4,
            command=send, cursor="hand2",
            activebackground=C["green"],
        )
        btn.pack(side="right", padx=(0, 8))

        # ── Stats bar ─────────────────────────────────────────────────────────
        stats_frame = tk.Frame(root, bg=C["bg"], pady=3)
        stats_frame.pack(fill="x", padx=12)

        stats_var = tk.StringVar(value="Recopilando métricas...")
        tk.Label(
            stats_frame, textvariable=stats_var,
            font=("Consolas", 8), fg=C["dim"], bg=C["bg"]
        ).pack(side="left")

        # ── UI Callback ───────────────────────────────────────────────────────
        def ui_callback(event_type: str, data=None):
            if event_type == "response" and isinstance(data, dict):
                root.after(0, lambda: add_msg(data.get("mark", ""), "mark"))
            elif event_type == "stats" and isinstance(data, dict):
                # Actualizar stats bar
                def _update():
                    if not root.winfo_exists():
                        return
                    try:
                        cpu  = data.get("cpu", 0)
                        ram  = data.get("ram", 0)
                        vram = data.get("vram_used_mb", 0)
                        vtot = data.get("vram_total_mb", 8192)
                        gm   = data.get("gaming_mode", False)
                        game = data.get("game_name", "")

                        stats_str = (
                            f"CPU {cpu:.0f}% | RAM {ram:.0f}% | "
                            f"VRAM {vram:.0f}/{vtot:.0f}MB"
                        )
                        stats_var.set(stats_str)
                        status_var.set(f"● Activo | {orch.intent.get_stats().split('|')[0].strip() if orch.intent else ''}")

                        if gm:
                            gaming_var.set(f"🎮 GAMING: {game}")
                        else:
                            gaming_var.set("")
                    except Exception:
                        pass
                root.after(0, _update)

        orch.set_ui_callback(ui_callback)

        # ── Background async loops ─────────────────────────────────────────────
        def run_background():
            if sys.platform == "win32":
                asyncio.set_event_loop_policy(asyncio.WindowsSelectorEventLoopPolicy())
            loop = asyncio.new_event_loop()
            asyncio.set_event_loop(loop)
            try:
                loop.run_until_complete(asyncio.gather(
                    orch._loop_perception(),
                    orch._loop_gaming(),
                    orch._loop_cognitive(),
                    orch._loop_vision(),
                    orch._loop_voice(),
                    orch._loop_execution(),
                ))
            except Exception:
                pass
            finally:
                loop.close()

        threading.Thread(target=run_background, daemon=True).start()

        entry.focus()
        root.protocol("WM_DELETE_WINDOW", lambda: (orch.__setattr__("running", False), root.destroy()))
        root.mainloop()

    except Exception as e:
        logging.getLogger("MARK13.GUI").error(f"GUI error: {e}", exc_info=True)
        print(f"Error en GUI: {e}\nIniciando en modo CLI...")
        if sys.platform == "win32":
            asyncio.set_event_loop_policy(asyncio.WindowsSelectorEventLoopPolicy())
        asyncio.run(run_cli())


# ── MAIN ──────────────────────────────────────────────────────────────────────

def main():
    parser = argparse.ArgumentParser(
        description="MARK 13 — Asistente Personal de Ali (Sidi3Ali)"
    )
    parser.add_argument("--cli",   action="store_true", help="Modo consola")
    parser.add_argument("--debug", action="store_true", help="Logs detallados")
    args = parser.parse_args()

    setup_logging(args.debug)
    logger = logging.getLogger("MARK13.Main")

    logger.info("=" * 60)
    logger.info("  MARK 13 — Iniciando")
    logger.info("  Ryzen 7 5800X | 32GB | RTX 4060 Ti 8GB | Win11")
    logger.info("  Creado por Ali (Sidi3Ali)")
    logger.info("=" * 60)

    if sys.platform == "win32":
        asyncio.set_event_loop_policy(asyncio.WindowsSelectorEventLoopPolicy())

    try:
        if args.cli:
            asyncio.run(run_cli(args.debug))
        else:
            run_gui()
    except KeyboardInterrupt:
        print("\n🛑 MARK 13 apagado.")
    except Exception as e:
        logger.error(f"Error fatal: {e}", exc_info=True)
        sys.exit(1)


if __name__ == "__main__":
    main()
