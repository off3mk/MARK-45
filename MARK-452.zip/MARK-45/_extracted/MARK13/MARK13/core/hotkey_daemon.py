"""
MARK 12 — Hotkey Daemon
=========================
Invocación instantánea de MARK desde cualquier aplicación.
Sin interrumpir lo que estás haciendo.

Comportamiento:
  • Ctrl+Space (configurable) → Abre/cierra la ventana de MARK
  • Ctrl+Shift+S              → Screenshot + análisis inmediato
  • Ctrl+Shift+R              → Leer texto seleccionado con voz
  • Ctrl+Shift+Q              → Analizar región (recorte interactivo)

Funciona en background — MARK siempre escuchando.
Creado por Ali (Sidi3Ali) — MARK 12
"""

import logging
import platform
import threading
from typing import Callable, Dict, Optional

logger = logging.getLogger("MARK12.Hotkey")
SYSTEM = platform.system()


class HotkeyDaemon:
    """
    Daemon de hotkeys globales.
    Permite invocar MARK desde cualquier ventana con un atajo de teclado.
    """

    DEFAULT_HOTKEYS = {
        'toggle_window':   'ctrl+space',      # Mostrar/ocultar ventana
        'screenshot':      'ctrl+shift+s',    # Captura + análisis
        'read_selection':  'ctrl+shift+r',    # Leer texto seleccionado
        'analyze_screen':  'ctrl+shift+a',    # Analizar pantalla completa
        'quick_command':   'ctrl+shift+m',    # Prompt rápido
    }

    def __init__(self, callbacks: Dict[str, Callable] = None):
        self._callbacks  = callbacks or {}
        self._running    = False
        self._thread     = None
        self._keyboard   = None
        self._hotkeys_map: Dict[str, Callable] = {}
        self._registered = []
        self._init_backend()

    def _init_backend(self):
        try:
            import keyboard
            self._keyboard = keyboard
            logger.info("✓ keyboard disponible (hotkeys globales)")
        except ImportError:
            logger.warning(
                "keyboard no disponible → pip install keyboard\n"
                "Nota: en Linux puede requerir sudo o grupo 'input'"
            )
        except Exception as e:
            logger.warning(f"keyboard init: {e}")

    def register(self, hotkey: str, callback: Callable,
                  description: str = "") -> bool:
        """Registrar un hotkey global."""
        if not self._keyboard:
            return False
        try:
            self._keyboard.add_hotkey(hotkey, callback, suppress=False)
            self._registered.append({'hotkey': hotkey, 'desc': description})
            logger.info(f"Hotkey registrado: {hotkey} → {description or 'callback'}")
            return True
        except Exception as e:
            logger.warning(f"No se pudo registrar {hotkey}: {e}")
            return False

    def setup_defaults(self, callbacks: Dict[str, Callable]):
        """Configurar todos los hotkeys por defecto."""
        self._callbacks.update(callbacks)

        for action, hotkey in self.DEFAULT_HOTKEYS.items():
            cb = self._callbacks.get(action)
            if cb:
                self.register(hotkey, cb, action)

    def start(self, block: bool = False):
        """Iniciar el daemon de hotkeys."""
        if not self._keyboard:
            logger.warning("Hotkeys no disponibles (keyboard no instalado)")
            return

        self._running = True
        logger.info(
            f"Daemon de hotkeys activo. "
            f"Registrados: {len(self._registered)}. "
            f"Hotkey principal: {self.DEFAULT_HOTKEYS['toggle_window']}"
        )

        if block:
            self._keyboard.wait()
        else:
            self._thread = threading.Thread(
                target=self._keyboard.wait,
                daemon=True
            )
            self._thread.start()

    def stop(self):
        """Detener el daemon."""
        self._running = False
        if self._keyboard:
            try:
                self._keyboard.unhook_all()
            except Exception:
                pass

    def get_registered(self) -> str:
        """Listar hotkeys registrados."""
        if not self._registered:
            return "Sin hotkeys registrados (instalar: pip install keyboard)"
        lines = ["Hotkeys activos:"]
        for h in self._registered:
            lines.append(f"  {h['hotkey']:25} → {h['desc']}")
        return '\n'.join(lines)

    @property
    def available(self) -> bool:
        return self._keyboard is not None


class OverlayToggle:
    """
    Controla la visibilidad de la ventana de MARK
    para aparecer/desaparecer sobre cualquier aplicación.
    """

    def __init__(self, window_ref=None):
        self._window   = window_ref
        self._visible  = True

    def toggle(self):
        """Alternar visibilidad de la ventana."""
        if not self._window:
            return
        try:
            if self._visible:
                self._window.iconify()
                self._visible = False
            else:
                self._window.deiconify()
                self._window.lift()
                self._window.focus_force()
                self._visible = True
        except Exception as e:
            logger.debug(f"toggle: {e}")

    def show(self):
        if self._window:
            try:
                self._window.deiconify()
                self._window.lift()
                self._window.focus_force()
                self._visible = True
            except Exception:
                pass

    def hide(self):
        if self._window:
            try:
                self._window.iconify()
                self._visible = False
            except Exception:
                pass

    def set_window(self, window):
        self._window = window
        self._visible = True
