"""
MARK 13 — Action Dispatcher
=============================
Ejecuta CUALQUIER intención devuelta por el IntentEngine.
Mapea "categoria.accion" → función real del módulo correspondiente.

No contiene lógica de interpretación — eso lo hace el IntentEngine.
Solo ejecuta: recibe un Intent, sabe a qué módulo llamar, llama.

Creado por Ali (Sidi3Ali) — MARK 13
"""

import asyncio
import logging
import os
import platform
import re
import subprocess
import webbrowser
import urllib.parse
from datetime import datetime
from typing import Any, Callable, Dict, Optional, TYPE_CHECKING

if TYPE_CHECKING:
    from core.intent_engine import Intent

logger = logging.getLogger("MARK13.Dispatcher")
SYSTEM = platform.system()


class ActionDispatcher:
    """
    Ejecuta acciones basadas en el Intent.
    Cada método corresponde a una categoría del catálogo.
    """

    def __init__(self, orchestrator):
        # Referencia al orquestador para acceder a todos los módulos
        self._orch = orchestrator

    async def dispatch(self, intent: 'Intent') -> str:
        """
        Punto de entrada principal.
        Recibe un Intent y devuelve la respuesta como string.
        """
        action = intent.action
        cat    = intent.category
        sub    = intent.subcategory
        params = intent.params

        logger.info(f"Dispatch: {action} | params={params}")

        handler = self._get_handler(cat, sub)
        if not handler:
            # Fallback: LLM conversación general
            return await self._ai_chat(intent)

        try:
            result = await handler(intent)
            return result or await self._ai_chat(intent)
        except Exception as e:
            logger.error(f"Dispatcher error [{action}]: {e}", exc_info=True)
            return f"Error ejecutando '{intent.intent}': {e}"

    def _get_handler(self, category: str, subcategory: str) -> Optional[Callable]:
        """Mapear categoría.subcategoría → handler."""
        handlers = {
            # SISTEMA
            ('system', 'status'):       self._system_status,
            ('system', 'open_app'):     self._system_open_app,
            ('system', 'close_app'):    self._system_close_app,
            ('system', 'shutdown'):     self._system_shutdown,
            ('system', 'volume'):       self._system_volume,
            ('system', 'processes'):    self._system_processes,
            ('system', 'gaming_mode'):  self._system_gaming_mode,

            # PANTALLA
            ('screen', 'analyze'):      self._screen_analyze,
            ('screen', 'screenshot'):   self._screen_screenshot,
            ('screen', 'read_text'):    self._screen_read_text,
            ('screen', 'find_click'):   self._screen_find_click,

            # CONTROL PC (Computer Use)
            ('pc', 'click'):            self._pc_click,
            ('pc', 'type'):             self._pc_type,
            ('pc', 'hotkey'):           self._pc_hotkey,
            ('pc', 'task'):             self._pc_task,
            ('pc', 'scroll'):           self._pc_scroll,

            # ARCHIVOS
            ('files', 'read'):          self._files_read,
            ('files', 'write'):         self._files_write,
            ('files', 'organize'):      self._files_organize,
            ('files', 'search'):        self._files_search,
            ('files', 'move'):          self._files_move,
            ('files', 'delete'):        self._files_delete,
            ('files', 'rename'):        self._files_rename,
            ('files', 'compress'):      self._files_compress,
            ('files', 'report'):        self._files_report,
            ('files', 'disk_info'):     self._files_disk_info,

            # WEB
            ('web', 'search'):          self._web_search,
            ('web', 'open_url'):        self._web_open_url,
            ('web', 'youtube'):         self._web_youtube,
            ('web', 'news'):            self._web_news,

            # MÚSICA
            ('music', 'play'):          self._music_play,
            ('music', 'pause'):         self._music_pause,
            ('music', 'next'):          self._music_next,
            ('music', 'previous'):      self._music_previous,
            ('music', 'volume'):        self._music_volume,
            ('music', 'info'):          self._music_info,
            ('music', 'playlist'):      self._music_playlist,
            ('music', 'shuffle'):       self._music_shuffle,

            # CÓDIGO
            ('code', 'generate'):       self._code_generate,
            ('code', 'analyze'):        self._code_analyze,
            ('code', 'fix'):            self._code_fix,
            ('code', 'run'):            self._code_run,
            ('code', 'terminal'):       self._code_terminal,

            # IA / CONVERSACIÓN
            ('ai', 'chat'):             self._ai_chat,
            ('ai', 'summarize'):        self._ai_summarize,
            ('ai', 'translate'):        self._ai_translate,
            ('ai', 'write'):            self._ai_write,
            ('ai', 'explain'):          self._ai_explain,
            ('ai', 'math'):             self._ai_math,
            ('ai', 'analyze_data'):     self._ai_analyze_data,

            # MARK (autogestión)
            ('mark', 'status'):         self._mark_status,
            ('mark', 'history'):        self._mark_history,
            ('mark', 'clear_history'):  self._mark_clear_history,
            ('mark', 'hotkeys'):        self._mark_hotkeys,
            ('mark', 'identity'):       self._mark_identity,
            ('mark', 'stop'):           self._mark_stop,
        }
        return handlers.get((category, subcategory))

    # ── SISTEMA ───────────────────────────────────────────────────────────────

    async def _system_status(self, intent: 'Intent') -> str:
        monitor = self._orch.monitor
        if not monitor:
            return "Monitor de sistema no disponible."
        stats  = await asyncio.to_thread(monitor.get_stats)
        focus  = intent.params.get('focus', '')
        ooda   = self._orch.ooda

        lines = []
        if not focus or 'cpu' in focus:
            lines.append(f"CPU: {stats.get('cpu', 0):.1f}%")
        if not focus or 'ram' in focus:
            ram_used  = stats.get('ram_used_gb', 0)
            ram_total = stats.get('ram_total_gb', 16)
            lines.append(f"RAM: {stats.get('ram', 0):.1f}% ({ram_used:.1f}/{ram_total:.0f} GB)")
        if not focus or 'disco' in focus or 'disk' in focus:
            lines.append(f"Disco: {stats.get('disk', 0):.1f}%")
        if stats.get('gaming_mode'):
            lines.append(f"🎮 Gaming: {stats.get('game_name', 'activo')}")
        if stats.get('active_window'):
            lines.append(f"Ventana: {stats['active_window'][:50]}")
        if stats.get('user_idle_secs', 0) > 60:
            lines.append(f"Idle: {stats['user_idle_secs']//60}m")

        return '\n'.join(lines) if lines else monitor.get_summary_text()

    async def _system_open_app(self, intent: 'Intent') -> str:
        app = intent.params.get('name', '') or intent.raw_input
        if not app:
            return "¿Qué aplicación quieres abrir?"
        cua = self._orch.cua
        if cua:
            ok = await cua.open_app(app)
            return f"Abriendo {app}..." if ok else f"No pude abrir '{app}'. ¿Está instalado?"
        # Fallback: subprocess
        try:
            if SYSTEM == 'Windows':
                os.startfile(app)
            else:
                subprocess.Popen([app])
            return f"Abriendo {app}..."
        except Exception as e:
            return f"Error abriendo '{app}': {e}"

    async def _system_close_app(self, intent: 'Intent') -> str:
        app = intent.params.get('name', '') or intent.raw_input
        cua = self._orch.cua
        if cua:
            ok = await asyncio.to_thread(cua.input.windows.close_window, app)
            return f"Cerrando {app}..." if ok else f"No encontré la ventana '{app}'"
        return "Computer Use no disponible para cerrar apps."

    async def _system_shutdown(self, intent: 'Intent') -> str:
        action = intent.params.get('action', 'shutdown')
        if 'reinici' in intent.raw_input.lower() or action == 'restart':
            if SYSTEM == 'Windows':
                os.system('shutdown /r /t 10')
                return "Reiniciando en 10 segundos. Para cancelar: shutdown /a"
            else:
                os.system('sudo reboot')
                return "Reiniciando..."
        return "¿Confirmas que quieres apagar el PC? Di 'sí, apaga el PC' para confirmar."

    async def _system_volume(self, intent: 'Intent') -> str:
        action = intent.params.get('action', '')
        level  = intent.params.get('level', '')
        raw    = intent.raw_input.lower()

        if SYSTEM == 'Windows':
            try:
                from core.computer_use.input_agent import InputAgent
                ia = InputAgent()
                if any(w in raw for w in ['sube', 'más', 'mas', 'subir', 'louder']):
                    ia.keyboard.hotkey('volumeup')
                    ia.keyboard.hotkey('volumeup')
                    ia.keyboard.hotkey('volumeup')
                    return "Volumen subido."
                elif any(w in raw for w in ['baja', 'menos', 'bajar', 'quieter', 'quieto']):
                    ia.keyboard.hotkey('volumedown')
                    ia.keyboard.hotkey('volumedown')
                    ia.keyboard.hotkey('volumedown')
                    return "Volumen bajado."
                elif any(w in raw for w in ['silenci', 'mute', 'calla', 'mudo']):
                    ia.keyboard.hotkey('volumemute')
                    return "Silenciado."
            except Exception:
                pass
        return "Ajuste de volumen: usa las teclas del teclado (Fn + Vol)."

    async def _system_processes(self, intent: 'Intent') -> str:
        monitor = self._orch.monitor
        if not monitor:
            return "Monitor no disponible."
        procs = await asyncio.to_thread(monitor.get_top_processes, 8)
        if not procs:
            return "No pude obtener la lista de procesos."
        lines = ["Top procesos por CPU:"]
        for p in procs:
            lines.append(f"  {p['name'][:25]:25} CPU:{p['cpu']:.1f}%  RAM:{p['mem']:.1f}%")
        return '\n'.join(lines)

    async def _system_gaming_mode(self, intent: 'Intent') -> str:
        raw = intent.raw_input.lower()
        if any(w in raw for w in ['activa', 'on', 'encien', 'pon']):
            self._orch.gaming_mode = True
            if self._orch.llm:
                await asyncio.to_thread(self._orch.llm.unload_model)
            return f"Modo Gaming activado. VRAM liberada para tu juego, {self._orch._user_name}."
        elif any(w in raw for w in ['desactiva', 'off', 'apaga', 'quita']):
            self._orch.gaming_mode = False
            return "Modo Gaming desactivado. Sistemas cognitivos al máximo."
        return f"Modo Gaming: {'🎮 ACTIVO' if self._orch.gaming_mode else '✓ Inactivo'}"

    # ── PANTALLA ──────────────────────────────────────────────────────────────

    async def _screen_analyze(self, intent: 'Intent') -> str:
        cua = self._orch.cua
        if not cua:
            return "Visión no disponible (instalar mss + pillow)."
        analysis = await cua.read_screen()
        return analysis or "No pude analizar la pantalla en este momento."

    async def _screen_screenshot(self, intent: 'Intent') -> str:
        cua = self._orch.cua
        if not cua:
            return "Captura no disponible."
        path = await cua.take_screenshot()
        return f"Captura guardada en el escritorio: {path}" if path else "Error al tomar captura."

    async def _screen_read_text(self, intent: 'Intent') -> str:
        cua = self._orch.cua
        if not cua:
            return "OCR no disponible."
        text = await asyncio.to_thread(cua.screen.get_all_text)
        if not text:
            return "No detecté texto legible en la pantalla."
        return f"Texto en pantalla:\n\n{text[:2000]}"

    async def _screen_find_click(self, intent: 'Intent') -> str:
        target = intent.params.get('text', '') or intent.raw_input
        cua = self._orch.cua
        if not cua:
            return "Computer Use no disponible."
        ok = await cua.find_and_click(target)
        return f"Click en '{target}' ✓" if ok else f"No encontré '{target}' en pantalla."

    # ── CONTROL PC ───────────────────────────────────────────────────────────

    async def _pc_click(self, intent: 'Intent') -> str:
        params = intent.params
        x = params.get('x')
        y = params.get('y')
        text_target = params.get('text', '')
        cua = self._orch.cua
        if not cua:
            return "Computer Use no disponible."
        if text_target:
            ok = await cua.find_and_click(text_target)
            return f"Click en '{text_target}' ✓" if ok else f"No encontré '{text_target}'"
        if x is not None and y is not None:
            ok = await cua.click_at(int(x), int(y))
            return f"Click en ({x},{y}) ✓" if ok else "Error haciendo click."
        return "Necesito coordenadas o texto para hacer click."

    async def _pc_type(self, intent: 'Intent') -> str:
        text = intent.params.get('text', '') or intent.raw_input
        cua  = self._orch.cua
        if not cua:
            return "Computer Use no disponible."
        ok = await cua.type_text(text)
        return f"Escrito: '{text[:50]}'" if ok else "Error escribiendo."

    async def _pc_hotkey(self, intent: 'Intent') -> str:
        keys = intent.params.get('keys', [])
        if isinstance(keys, str):
            keys = [k.strip() for k in keys.split('+')]
        if not keys:
            return "Especifica qué teclas quieres pulsar."
        cua = self._orch.cua
        if not cua:
            return "Computer Use no disponible."
        ok = await cua.press_hotkey(*keys)
        return f"Atajo {'+'.join(keys)} ejecutado." if ok else "Error ejecutando atajo."

    async def _pc_task(self, intent: 'Intent') -> str:
        """Tarea autónoma multi-paso con el Computer Use Agent."""
        goal = intent.params.get('goal', '') or intent.raw_input
        cua  = self._orch.cua
        if not cua:
            return "Computer Use Agent no disponible (instalar pyautogui + mss)."
        result = await cua.execute(goal)
        return result.get('summary', 'Tarea ejecutada.')

    async def _pc_scroll(self, intent: 'Intent') -> str:
        amount = int(intent.params.get('amount', 3))
        raw    = intent.raw_input.lower()
        if any(w in raw for w in ['abajo', 'down', 'bajar']):
            amount = -abs(amount)
        cua = self._orch.cua
        if cua:
            await asyncio.to_thread(cua.input.mouse.scroll, amount)
            return f"Scroll {'abajo' if amount < 0 else 'arriba'}."
        return "Computer Use no disponible."

    # ── ARCHIVOS ──────────────────────────────────────────────────────────────

    async def _files_read(self, intent: 'Intent') -> str:
        path = intent.params.get('path', '') or intent.params.get('file', '')
        if not path:
            # Intentar extraer ruta del texto original
            raw = intent.raw_input
            match = re.search(r'["\']([^"\']+\.[a-zA-Z0-9]+)["\']|([A-Za-z]:\\[^\s]+|/[^\s]+)', raw)
            if match:
                path = match.group(1) or match.group(2)
        if not path:
            return "¿Qué archivo quieres que lea? Dime la ruta o el nombre."
        return await asyncio.to_thread(self._orch.files.read_and_analyze, path)

    async def _files_write(self, intent: 'Intent') -> str:
        path    = intent.params.get('path', 'nuevo_archivo.txt')
        content = intent.params.get('content', '')
        if not content and self._orch.llm:
            # Generar contenido con LLM si no se especificó
            content = await asyncio.to_thread(
                self._orch.llm.generate,
                f"Genera el contenido para: {intent.raw_input}",
                False, 800
            )
        return await asyncio.to_thread(self._orch.files.write_file, path, content)

    async def _files_organize(self, intent: 'Intent') -> str:
        folder = intent.params.get('folder', 'downloads')
        method = intent.params.get('method', 'type')
        raw    = intent.raw_input.lower()

        # Resolver carpeta
        if folder == 'downloads' or any(w in raw for w in ['descargas', 'downloads']):
            folder = os.path.expanduser('~/Downloads')
            if not os.path.exists(folder):
                folder = os.path.expanduser('~/Descargas')
        elif folder == 'desktop' or 'escritorio' in raw:
            folder = os.path.expanduser('~/Desktop')
        elif not os.path.exists(folder):
            folder = os.path.expanduser(f'~/{folder}')

        dry = any(w in raw for w in ['simula', 'preview', 'qué haría', 'muéstrame'])

        if 'fecha' in raw or method == 'date':
            result = await asyncio.to_thread(
                self._orch.files.organizer.organize_by_date, folder, dry
            )
        else:
            result = await asyncio.to_thread(
                self._orch.files.organizer.organize_by_type, folder, dry
            )

        moved  = result.get('moved', [])
        errors = result.get('errors', [])
        prefix = "[Simulación] " if dry else ""
        summary = f"{prefix}Organizado {folder}:\n"
        summary += f"  {len(moved)} archivos movidos\n"
        for m in moved[:8]:
            summary += f"  • {m}\n"
        if len(moved) > 8:
            summary += f"  ... y {len(moved)-8} más\n"
        if errors:
            summary += f"  {len(errors)} errores\n"
        return summary.strip()

    async def _files_search(self, intent: 'Intent') -> str:
        query   = intent.params.get('query', '') or intent.params.get('name', '')
        ext     = intent.params.get('ext', '')
        root    = intent.params.get('root', None)
        days    = intent.params.get('days', None)
        if not query:
            query = re.sub(r'(busca|encuentra|dónde|donde|archivos?|llamados?)\s*', '',
                            intent.raw_input, flags=re.IGNORECASE).strip()
        return await asyncio.to_thread(
            self._orch.files.search_files, root, query, ext or None,
            int(days) if days else None
        )

    async def _files_move(self, intent: 'Intent') -> str:
        src = intent.params.get('src', '') or intent.params.get('source', '')
        dst = intent.params.get('dst', '') or intent.params.get('dest', '')
        if not src or not dst:
            return "Necesito origen y destino para mover el archivo."
        return await asyncio.to_thread(self._orch.files.move, src, dst)

    async def _files_delete(self, intent: 'Intent') -> str:
        path = intent.params.get('path', '') or intent.params.get('file', '')
        if not path:
            return "¿Qué archivo quieres eliminar? Dime la ruta exacta."
        # Confirmación de seguridad
        if any(d in path for d in ['/', 'C:\\', 'System', 'Windows']):
            return "No voy a eliminar eso. Parece una ruta del sistema."
        return await asyncio.to_thread(self._orch.files.delete, path)

    async def _files_rename(self, intent: 'Intent') -> str:
        folder  = intent.params.get('folder', os.path.expanduser('~/Downloads'))
        pattern = intent.params.get('pattern', '.*')
        replace = intent.params.get('replacement', '')
        dry     = 'simula' in intent.raw_input.lower()
        if not replace:
            return "Necesito saber cómo quieres renombrar los archivos. Ej: 'renombra los .jpg como foto_001, foto_002...'"
        result = await asyncio.to_thread(
            self._orch.files.organizer.bulk_rename, folder, pattern, replace, dry
        )
        renamed = result.get('renamed', [])
        return f"Renombrados {len(renamed)} archivos:\n" + '\n'.join(f"  • {r}" for r in renamed[:10])

    async def _files_compress(self, intent: 'Intent') -> str:
        source = intent.params.get('source', '') or intent.params.get('path', '')
        output = intent.params.get('output', None)
        if not source:
            return "¿Qué quieres comprimir? Dime la ruta."
        return await asyncio.to_thread(self._orch.files.compress, source, output)

    async def _files_report(self, intent: 'Intent') -> str:
        folder = intent.params.get('folder', os.path.expanduser('~/Downloads'))
        output = intent.params.get('output', None)
        rtype  = intent.params.get('type', 'expenses')
        return await asyncio.to_thread(
            self._orch.files.generate_expense_report, folder, output
        )

    async def _files_disk_info(self, intent: 'Intent') -> str:
        return await asyncio.to_thread(self._orch.files.disk_usage)

    # ── WEB ───────────────────────────────────────────────────────────────────

    async def _web_search(self, intent: 'Intent') -> str:
        query = intent.params.get('query', '') or intent.raw_input
        query = re.sub(r'^(busca|googlea|google|buscar)\s+', '', query, flags=re.IGNORECASE).strip()
        if not query:
            return "¿Qué quieres buscar?"
        url = f"https://www.google.com/search?q={urllib.parse.quote(query)}"
        webbrowser.open(url)
        return f"Buscando '{query}' en Google."

    async def _web_open_url(self, intent: 'Intent') -> str:
        url = intent.params.get('url', '')
        if not url:
            url = re.search(r'https?://\S+', intent.raw_input)
            url = url.group() if url else ''
        if not url:
            return "¿Qué URL quieres abrir?"
        if not url.startswith('http'):
            url = 'https://' + url
        webbrowser.open(url)
        return f"Abriendo {url}"

    async def _web_youtube(self, intent: 'Intent') -> str:
        query = intent.params.get('query', '')
        if not query:
            query = re.sub(r'(youtube|yt|pon|busca|ver)\s*', '', intent.raw_input,
                            flags=re.IGNORECASE).strip()
        url = f"https://www.youtube.com/results?search_query={urllib.parse.quote(query)}" \
              if query else "https://www.youtube.com"
        webbrowser.open(url)
        return f"Abriendo YouTube{f': {query}' if query else ''}."

    async def _web_news(self, intent: 'Intent') -> str:
        webbrowser.open("https://news.google.com")
        return "Abriendo Google News."

    # ── MÚSICA ───────────────────────────────────────────────────────────────

    def _get_spotify(self):
        sp_mod = self._orch._skills.get('spotify')
        if sp_mod:
            try:
                return sp_mod.get_spotify()
            except Exception:
                pass
        return None

    async def _music_play(self, intent: 'Intent') -> str:
        query = intent.params.get('query', '') or intent.params.get('song', '') or \
                intent.params.get('artist', '') or intent.params.get('playlist', '')

        sp = self._get_spotify()
        if sp:
            try:
                if query:
                    return await asyncio.to_thread(sp.execute, 'play', {'query': query}, query)
                return await asyncio.to_thread(sp.execute, 'play')
            except Exception:
                pass

        # Fallback: YouTube
        if query:
            url = f"https://www.youtube.com/results?search_query={urllib.parse.quote(query + ' música')}"
        else:
            url = "https://www.youtube.com/results?search_query=música"
        webbrowser.open(url)
        return f"Abriendo YouTube{f' para {query}' if query else ''}. (Spotify no configurado)"

    async def _music_pause(self, intent: 'Intent') -> str:
        sp = self._get_spotify()
        if sp:
            try:
                return await asyncio.to_thread(sp.execute, 'pause')
            except Exception:
                pass
        cua = self._orch.cua
        if cua:
            await cua.press_hotkey('ctrl', 'space')
        return "Pausa enviada."

    async def _music_next(self, intent: 'Intent') -> str:
        sp = self._get_spotify()
        if sp:
            try:
                return await asyncio.to_thread(sp.execute, 'next')
            except Exception:
                pass
        cua = self._orch.cua
        if cua:
            await cua.press_hotkey('ctrl', 'right')
        return "Siguiente canción."

    async def _music_previous(self, intent: 'Intent') -> str:
        sp = self._get_spotify()
        if sp:
            try:
                return await asyncio.to_thread(sp.execute, 'previous')
            except Exception:
                pass
        cua = self._orch.cua
        if cua:
            await cua.press_hotkey('ctrl', 'left')
        return "Canción anterior."

    async def _music_volume(self, intent: 'Intent') -> str:
        level = intent.params.get('level', 50)
        sp    = self._get_spotify()
        if sp:
            try:
                return await asyncio.to_thread(sp.execute, 'volume', {'level': level})
            except Exception:
                pass
        return f"Volumen ajustado a {level}% (Spotify no conectado)."

    async def _music_info(self, intent: 'Intent') -> str:
        sp = self._get_spotify()
        if sp:
            try:
                return await asyncio.to_thread(sp.execute, 'current')
            except Exception:
                pass
        return "Spotify no conectado. Configura las credenciales en memory/spotify_config.json."

    async def _music_playlist(self, intent: 'Intent') -> str:
        sp = self._get_spotify()
        if sp:
            try:
                return await asyncio.to_thread(sp.execute, 'playlists')
            except Exception:
                pass
        return "Spotify no conectado."

    async def _music_shuffle(self, intent: 'Intent') -> str:
        sp = self._get_spotify()
        if sp:
            try:
                return await asyncio.to_thread(sp.execute, 'shuffle')
            except Exception:
                pass
        return "Spotify no conectado."

    # ── CÓDIGO ────────────────────────────────────────────────────────────────

    async def _code_generate(self, intent: 'Intent') -> str:
        description = intent.params.get('description', '') or intent.raw_input
        language    = intent.params.get('language', 'python')
        if not self._orch.llm:
            return "LLM no disponible para generar código."

        code = await asyncio.to_thread(
            self._orch.llm.generate,
            f"Genera código {language} completo y funcional para:\n{description}\n\n"
            f"Solo el código limpio, sin explicaciones adicionales.",
            False, 1500, 0.3
        )

        # Limpiar markdown
        match = re.search(r'```(?:\w+)?\n(.*?)```', code, re.DOTALL)
        if match:
            code = match.group(1)

        # Validar y guardar
        from core.safety import validate_and_save_skill
        safe = re.sub(r'[^\w]', '_', description.split()[-1] or 'script')[:20]
        fp   = os.path.join('workspace', f'{safe}.py')
        ok, msg = await asyncio.to_thread(validate_and_save_skill, code, fp)

        if ok:
            preview = code[:400] + '\n...' if len(code) > 400 else code
            return f"Script guardado en `{fp}`:\n\n```{language}\n{preview}\n```"
        return f"Script generado pero error de validación: {msg}\n\nCódigo:\n{code[:600]}"

    async def _code_analyze(self, intent: 'Intent') -> str:
        path = intent.params.get('path', '')
        if path and os.path.exists(path):
            content = self._orch.files.read_file(path)
        else:
            content = intent.params.get('code', '') or intent.raw_input
        if not self._orch.llm:
            return "LLM no disponible."
        return await asyncio.to_thread(self._orch.llm.analyze_code, content)

    async def _code_fix(self, intent: 'Intent') -> str:
        code = intent.params.get('code', '') or intent.raw_input
        if not self._orch.llm:
            return "LLM no disponible."
        return await asyncio.to_thread(
            self._orch.llm.generate,
            f"Corrige este código y explica qué estaba mal:\n\n{code}",
            False, 800
        )

    async def _code_run(self, intent: 'Intent') -> str:
        path = intent.params.get('path', '') or intent.params.get('script', '')
        if not path:
            return "¿Qué script quieres ejecutar?"
        from core.safety import execute_safely
        ok, stdout, stderr = await asyncio.to_thread(execute_safely, path, 30)
        return stdout if ok else f"Error: {stderr}"

    async def _code_terminal(self, intent: 'Intent') -> str:
        cmd = intent.params.get('cmd', '') or intent.params.get('command', '')
        if not cmd:
            cmd = re.sub(r'(ejecuta|corre|run|terminal)\s*', '', intent.raw_input,
                          flags=re.IGNORECASE).strip()
        if not cmd:
            return "¿Qué comando quieres ejecutar?"

        from core.safety import validate_shell_command
        ok, reason = validate_shell_command(cmd)
        if not ok:
            return f"Comando rechazado: {reason}"

        try:
            result = subprocess.run(
                cmd, shell=True, capture_output=True, text=True, timeout=15
            )
            output = (result.stdout or result.stderr or '').strip()
            return output[:1500] if output else f"Comando ejecutado (sin salida). Código: {result.returncode}"
        except subprocess.TimeoutExpired:
            return "Timeout (15s)."
        except Exception as e:
            return f"Error: {e}"

    # ── IA / CONVERSACIÓN ─────────────────────────────────────────────────────

    async def _ai_chat(self, intent: 'Intent') -> str:
        text = intent.raw_input
        if not text:
            return f"Aquí, {self._orch._user_name}. ¿En qué puedo ayudarle?"

        # Caso especial: saludos
        if intent.params.get('type') == 'greeting':
            import random
            h = datetime.now().hour
            time_str = "buenos días" if h < 12 else "buenas tardes" if h < 20 else "buenas noches"
            return random.choice([
                f"{time_str.capitalize()}, {self._orch._user_name}. ¿Qué necesita?",
                f"Sistemas activos. ¿Qué le traiga, {self._orch._user_name}?",
                f"Aquí. ¿En qué puedo ayudarle?",
            ])

        # Hora/fecha
        if any(w in text.lower() for w in ['hora', 'fecha', 'día', 'date', 'time']):
            return datetime.now().strftime("Son las %H:%M del %d de %B de %Y.")

        if not self._orch.llm:
            return "LLM no disponible. Inicia LM Studio u Ollama."

        ooda = self._orch.ooda
        ctx  = ooda.state.context_summary() if ooda else ""
        prompt = f"[Usuario: {self._orch._user_name}. {ctx}]\n\n{text}"
        return await asyncio.to_thread(self._orch.llm.generate, prompt, True, 700)

    async def _ai_summarize(self, intent: 'Intent') -> str:
        text = intent.params.get('text', '') or intent.raw_input
        path = intent.params.get('path', '')
        if path:
            text = self._orch.files.read_file(path)
        if not self._orch.llm:
            return "LLM no disponible."
        return await asyncio.to_thread(self._orch.llm.summarize, text, 150)

    async def _ai_translate(self, intent: 'Intent') -> str:
        text   = intent.params.get('text', '') or intent.raw_input
        target = intent.params.get('to', 'español')
        if not self._orch.llm:
            return "LLM no disponible."
        return await asyncio.to_thread(
            self._orch.llm.generate,
            f"Traduce al {target}:\n\n{text}", False, 500
        )

    async def _ai_write(self, intent: 'Intent') -> str:
        if not self._orch.llm:
            return "LLM no disponible."
        return await asyncio.to_thread(
            self._orch.llm.generate,
            f"Redacta lo siguiente:\n{intent.raw_input}", True, 800
        )

    async def _ai_explain(self, intent: 'Intent') -> str:
        if not self._orch.llm:
            return "LLM no disponible."
        return await asyncio.to_thread(
            self._orch.llm.generate,
            f"Explica de forma clara y directa:\n{intent.raw_input}", True, 600
        )

    async def _ai_math(self, intent: 'Intent') -> str:
        expr = intent.params.get('expression', '') or intent.raw_input
        # Intento directo con eval (para aritmética simple)
        clean = re.sub(r'[^\d\+\-\*\/\.\(\)\s]', '', expr)
        if clean.strip():
            try:
                result = eval(clean, {"__builtins__": {}})
                return f"Resultado: {result}"
            except Exception:
                pass
        if not self._orch.llm:
            return "LLM no disponible para resolver esto."
        return await asyncio.to_thread(
            self._orch.llm.generate,
            f"Resuelve paso a paso:\n{expr}", False, 400
        )

    async def _ai_analyze_data(self, intent: 'Intent') -> str:
        if not self._orch.llm:
            return "LLM no disponible."
        return await asyncio.to_thread(
            self._orch.llm.generate,
            f"Analiza estos datos y extrae conclusiones:\n{intent.raw_input}",
            True, 700
        )

    # ── MARK (AUTOGESTIÓN) ────────────────────────────────────────────────────

    async def _mark_status(self, intent: 'Intent') -> str:
        llm_status = self._orch.llm.get_status() if self._orch.llm else "LLM: no disponible"
        cua_status = self._orch.cua.get_status() if self._orch.cua else "CUA: no disponible"
        monitor    = self._orch.monitor
        sys_info   = await asyncio.to_thread(monitor.get_summary_text) if monitor else "Monitor: N/A"
        gaming_str = "🎮 GAMING MODE ACTIVO" if self._orch.gaming_mode else "Normal"
        return (
            f"MARK 13 — Estado\n"
            f"{'─'*40}\n"
            f"{sys_info}\n"
            f"Modo: {gaming_str}\n"
            f"{llm_status.split(chr(10))[0]}\n"
            f"{cua_status}\n"
            f"Usuario: {self._orch._user_name} ({'Creador' if self._orch._is_creator else 'Estándar'})"
        )

    async def _mark_history(self, intent: 'Intent') -> str:
        hist = self._orch._chat_history[-10:]
        if not hist:
            return "Sin historial todavía."
        lines = ["Últimos mensajes:"]
        for h in hist:
            prefix = f"[{h['time']}] {'Tú' if h['role']=='user' else 'MARK'}"
            lines.append(f"{prefix}: {h['text'][:80]}")
        return '\n'.join(lines)

    async def _mark_clear_history(self, intent: 'Intent') -> str:
        if self._orch.llm:
            self._orch.llm.clear_history()
        self._orch._chat_history.clear()
        return "Historial limpiado. Empezamos de cero."

    async def _mark_hotkeys(self, intent: 'Intent') -> str:
        return self._orch.hotkey.get_registered()

    async def _mark_identity(self, intent: 'Intent') -> str:
        return (
            "Soy MARK 13, un sistema de inteligencia artificial local y autónomo.\n"
            "Creado por Ali (Sidi3Ali).\n"
            "Versión: 12.0 | Arquitectura: Async/OODA\n"
            "Puedo ver tu pantalla, controlar tu PC, gestionar archivos, "
            "generar código y razonar sobre cualquier cosa que necesites."
        )

    async def _mark_stop(self, intent: 'Intent') -> str:
        await self._orch._speak(f"Hasta luego, {self._orch._user_name}.")
        await asyncio.sleep(1)
        self._orch.running = False
        return f"Apagando MARK 13. Hasta luego, {self._orch._user_name}."
