"""
MARK 13 — Safety Engine
=========================
Valida código generado por IA antes de guardar o ejecutar.
Creado por Ali (Sidi3Ali) — MARK 13
"""

import ast
import logging
import os
import re
import subprocess
import sys
import tempfile
from typing import List, Tuple

logger = logging.getLogger("MARK13.Safety")

FORBIDDEN_ATTRS = {"rmtree", "removedirs"}
SAFE_PATHS      = {"temp", "tmp", "cache", "workspace", "logs"}
DANGEROUS_SHELL = {
    "rm -rf /", "format c:", "del /s /f c:\\",
    "rd /s /q c:\\", "mkfs", "dd if=/dev/zero",
}

DANGEROUS_PATTERNS = [
    r"rm\s+-rf\s+/",
    r"format\s+[cCdDeE]:",
    r"del\s+/[sf]",
    r"shutil\.rmtree\s*\(\s*[\"\']/",
    r"os\.remove\s*\(\s*[\"\']/",
]


def validate_syntax(code: str) -> Tuple[bool, str]:
    try:
        ast.parse(code)
        return True, ""
    except SyntaxError as e:
        return False, f"Sintaxis L{e.lineno}: {e.msg}"
    except Exception as e:
        return False, str(e)


def validate_security(code: str) -> Tuple[bool, List[str]]:
    warnings = []
    is_safe  = True

    try:
        tree = ast.parse(code)
    except SyntaxError:
        return False, ["Código con errores de sintaxis"]

    for node in ast.walk(tree):
        if isinstance(node, ast.Attribute) and node.attr in FORBIDDEN_ATTRS:
            line = ""
            try:
                lines = code.split("\n")
                if hasattr(node, "lineno") and node.lineno <= len(lines):
                    line = lines[node.lineno - 1].lower()
            except Exception:
                pass
            if not any(s in line for s in SAFE_PATHS):
                warnings.append(f"Operación destructiva: .{node.attr}()")
                is_safe = False

    for pat in DANGEROUS_PATTERNS:
        if re.search(pat, code, re.IGNORECASE | re.DOTALL):
            warnings.append(f"Patrón peligroso detectado")
            is_safe = False

    return is_safe, warnings


def validate_and_save_skill(code: str, filepath: str,
                              force: bool = False) -> Tuple[bool, str]:
    ok, err = validate_syntax(code)
    if not ok:
        return False, f"RECHAZADO (sintaxis): {err}"

    is_safe, warns = validate_security(code)
    for w in warns:
        (logger.error if not is_safe else logger.warning)(f"Safety: {w}")

    if not is_safe and not force:
        return False, f"RECHAZADO: {'; '.join(warns)}"

    try:
        os.makedirs(os.path.dirname(filepath) or ".", exist_ok=True)
        with open(filepath, "w", encoding="utf-8") as f:
            f.write(code)
        logger.info(f"✅ Guardado: {filepath}")
        return True, "OK"
    except Exception as e:
        return False, str(e)


def execute_safely(code_or_path: str, timeout: int = 30) -> Tuple[bool, str, str]:
    """Ejecutar código Python en proceso aislado con timeout."""
    # Si es un path existente, ejecutar directamente
    if os.path.exists(code_or_path):
        try:
            r = subprocess.run(
                [sys.executable, code_or_path],
                capture_output=True, text=True, timeout=timeout
            )
            return r.returncode == 0, r.stdout, r.stderr
        except subprocess.TimeoutExpired:
            return False, "", f"Timeout ({timeout}s)"
        except Exception as e:
            return False, "", str(e)

    # Si es código, validar y ejecutar en temp
    ok, err = validate_syntax(code_or_path)
    if not ok:
        return False, "", f"Sintaxis inválida: {err}"

    is_safe, warns = validate_security(code_or_path)
    if not is_safe:
        return False, "", f"Código inseguro: {'; '.join(warns)}"

    with tempfile.NamedTemporaryFile(mode="w", suffix=".py",
                                      delete=False, encoding="utf-8") as f:
        f.write(code_or_path)
        tmp = f.name
    try:
        r = subprocess.run(
            [sys.executable, tmp],
            capture_output=True, text=True, timeout=timeout
        )
        return r.returncode == 0, r.stdout, r.stderr
    except subprocess.TimeoutExpired:
        return False, "", f"Timeout ({timeout}s)"
    except Exception as e:
        return False, "", str(e)
    finally:
        try: os.unlink(tmp)
        except Exception: pass


def validate_shell_command(cmd: str) -> Tuple[bool, str]:
    cl = cmd.lower().strip()
    for d in DANGEROUS_SHELL:
        if d in cl:
            return False, f"Comando destructivo: '{d}'"
    if re.search(r"format\s+[a-z]:", cl):
        return False, "Formateo de disco prohibido"
    if re.search(r"rm\s+.*-.*r.*f.*/\s*$", cl):
        return False, "rm -rf / prohibido"
    return True, "OK"
