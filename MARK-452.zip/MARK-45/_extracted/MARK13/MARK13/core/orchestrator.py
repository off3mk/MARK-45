"""
MARK 13 — Orchestrator
========================
Cerebro central asíncrono de MARK 13.

Hardware: Ryzen 7 5800X | 32GB RAM | RTX 4060 Ti 8GB | Win11
Modelo LLM objetivo: Qwen3-8B Q5_K_M en LM Studio (CUDA)

Arquitectura:
  • asyncio puro — 6 bucles paralelos, nunca se bloquea
  • IntentEngine  — LLM clasifica cualquier frase → acción
  • Dispatcher    — ejecuta la acción sin lógica de interpretación
  • OODA Loop     — autonomía proactiva
  • Gaming Mode   — detecta juegos, libera VRAM automáticamente
  • Computer Use  — ve + controla la pantalla
  • File Manager  — acceso directo al sistema de archivos
  • Hotkeys       — invocación global con Ctrl+Space

Creado por Ali (Sidi3Ali) — MARK 13
"""

import asyncio
import logging
import os
import re
import sys
import threading
import webbrowser
import urllib.parse
from datetime import datetime
from typing import Any, Callable, Dict, List, Optional

logger = logging.getLogger("MARK13")

# ── IDENTIDAD PERMANENTE DEL SISTEMA ─────────────────────────────────────────
_IDENTITY = {
    "name":    "MARK 13",
    "creator": "Ali",
    "alias":   "Sidi3Ali",
    "version": "13.0",
    "hw":      "Ryzen 7 5800X | 32GB | RTX 4060 Ti 8GB | Win11",
}


class Orchestrator:
    """Director central de MARK 13."""

    # ── INIT ──────────────────────────────────────────────────────────────────

    def __init__(self):
        self.running     = False
        self.gaming_mode = False
        self._ui_cb: Optional[Callable] = None
        self._chat:  List[Dict] = []

        self._print_banner()

        # Módulos — orden de carga importa (LLM primero)
        self.llm     = self._init("LLM Engine",   self._load_llm)
        self._user_name  = "Señor"
        self._is_creator = False
        self._load_identity()

        self.cua     = self._init("Computer Use", self._load_cua)
        self.files   = self._init("File Manager", self._load_files)
        self.monitor = self._init("Monitor",      self._load_monitor)
        self.ooda    = self._init("OODA Loop",    self._load_ooda)
        self._voice  = self._init("Voice",        self._load_voice)
        self.hotkey  = self._init("Hotkeys",      self._load_hotkey)
        self._skills: Dict[str, Any] = {}
        self._load_skills()

        # Motor de comprensión universal
        self.intent  = self._init("IntentEngine", self._load_intent)
        self.dispatch= self._init("Dispatcher",   self._load_dispatcher)

        # Cola asyncio — se crea en start()
        self.event_queue: Optional[asyncio.Queue] = None

        self._print_ready()

    def _print_banner(self):
        logger.info("=" * 60)
        logger.info("  M A R K  1 3")
        logger.info("  Creado por Ali (Sidi3Ali)")
        logger.info(f"  HW: {_IDENTITY['hw']}")
        logger.info("=" * 60)

    def _print_ready(self):
        logger.info("-" * 60)
        logger.info(f"  Usuario:  {self._user_name} ({'Creador' if self._is_creator else 'Estándar'})")
        logger.info(f"  LLM:      {getattr(self.llm, 'active_provider', 'N/A')}")
        logger.info(f"  CUA:      {'✓' if self.cua  else '✗ (pip install pyautogui mss pillow)'}")
        logger.info(f"  VRAM mon: {'✓' if getattr(getattr(self.monitor, '_gpu', None), 'available', False) else '✗ (pip install pynvml)'}")
        logger.info(f"  Voice:    {'✓' if self._voice else '✗ (pip install edge-tts pygame)'}")
        logger.info(f"  Hotkeys:  {'✓' if getattr(self.hotkey, 'available', False) else '✗ (pip install keyboard)'}")
        logger.info("-" * 60)

    def _init(self, name: str, loader) -> Any:
        """Cargar módulo con manejo de errores."""
        try:
            result = loader()
            return result
        except Exception as e:
            logger.debug(f"{name}: {e}")
            return None

    # ── LOADERS ───────────────────────────────────────────────────────────────

    def _load_llm(self):
        from core.llm_engine import LLMEngine
        llm = LLMEngine()
        logger.info("✓ LLM Engine")
        return llm

    def _load_cua(self):
        from core.computer_use.agent import ComputerUseAgent
        cua = ComputerUseAgent(self.llm)
        logger.info("✓ Computer Use Agent")
        return cua

    def _load_files(self):
        from core.file_manager import FileManager
        fm = FileManager(self.llm)
        logger.info("✓ File Manager")
        return fm

    def _load_monitor(self):
        from perception.perception_loop import SystemMonitor
        m = SystemMonitor()
        logger.info("✓ System Monitor")
        return m

    def _load_ooda(self):
        from core.cognitive_loop import OODALoop
        o = OODALoop()
        o.state.user_name  = self._user_name
        o.state.is_creator = self._is_creator
        logger.info("✓ OODA Loop")
        return o

    def _load_voice(self):
        # Buscar VoiceSystem de JARVIS en el directorio padre
        for base in ["..", "../Jarvis", "../../Jarvis"]:
            vpath = os.path.abspath(os.path.join(os.path.dirname(__file__), base))
            if os.path.exists(os.path.join(vpath, "core", "voice.py")):
                if vpath not in sys.path:
                    sys.path.insert(0, vpath)
                from core.voice import VoiceSystem
                v = VoiceSystem()
                logger.info("✓ Voice (SSML Edge TTS)")
                return v
        # Fallback: pyttsx3 sin SSML
        import pyttsx3
        v = pyttsx3.init()
        logger.info("✓ Voice (pyttsx3 fallback)")
        return v

    def _load_hotkey(self):
        from core.hotkey_daemon import HotkeyDaemon
        hk = HotkeyDaemon()
        logger.info("✓ Hotkey Daemon")
        return hk

    def _load_intent(self):
        from core.intent_engine import IntentEngine
        ie = IntentEngine(self.llm)
        logger.info("✓ IntentEngine (comprensión universal)")
        return ie

    def _load_dispatcher(self):
        from core.dispatcher import ActionDispatcher
        d = ActionDispatcher(self)
        logger.info("✓ Dispatcher")
        return d

    def _load_identity(self):
        try:
            import getpass
            uname = getpass.getuser().lower()
            self._is_creator = any(x in uname for x in ["ali", "sidi"])
            self._user_name  = "Señor" if self._is_creator else uname.capitalize()
        except Exception:
            pass

    def _load_skills(self):
        for name, mod in {
            "system":  "skills.system",
            "media":   "skills.media",
            "browser": "skills.browser",
            "coding":  "skills.coding",
            "files":   "skills.file_skill",
            "spotify": "skills.spotify_skill",
        }.items():
            try:
                import importlib
                self._skills[name] = importlib.import_module(mod)
            except Exception:
                pass

    # ── ARRANQUE ──────────────────────────────────────────────────────────────

    async def start(self):
        """Iniciar todos los bucles asíncronos."""
        self.running     = True
        self.event_queue = asyncio.Queue()

        self._setup_hotkeys()
        await self._speak(self._greeting(), "greeting")

        logger.info("🚀 MARK 13 — Todos los sistemas activos")

        await asyncio.gather(
            self._loop_perception(),
            self._loop_gaming(),
            self._loop_cognitive(),
            self._loop_vision(),
            self._loop_voice(),
            self._loop_execution(),
        )

    def _setup_hotkeys(self):
        if not self.hotkey:
            return
        loop = asyncio.get_event_loop()
        callbacks = {
            "toggle_window": lambda: None,  # Gestionado por UI
            "screenshot":    lambda: asyncio.run_coroutine_threadsafe(
                self._hotkey_screenshot(), loop
            ),
            "analyze_screen": lambda: asyncio.run_coroutine_threadsafe(
                self._hotkey_analyze(), loop
            ),
        }
        self.hotkey.setup_defaults(callbacks)
        self.hotkey.start(block=False)

    async def _hotkey_screenshot(self):
        if self.cua and self.event_queue:
            path = await self.cua.take_screenshot()
            if path:
                await self.event_queue.put({
                    "type": "speak",
                    "text": "Captura guardada en el escritorio."
                })

    async def _hotkey_analyze(self):
        if self.cua and self.event_queue:
            analysis = await self.cua.read_screen()
            await self.event_queue.put({
                "type": "speak",
                "text": analysis[:200] if analysis else "No pude analizar la pantalla."
            })

    # ── BUCLES ────────────────────────────────────────────────────────────────

    async def _loop_perception(self):
        """Sensores HW — cada 1s. Ryzen 7 5800X lo maneja sin esfuerzo."""
        while self.running:
            try:
                if self.monitor:
                    stats = await asyncio.to_thread(self.monitor.get_stats)
                    self.gaming_mode = stats.get("gaming_mode", False)
                    if self.ooda:
                        self.ooda.observe(stats)
                    if self._ui_cb:
                        self._ui_cb("stats", stats)
            except Exception as e:
                logger.debug(f"perception: {e}")
            await asyncio.sleep(1)

    async def _loop_gaming(self):
        """Transiciones Gaming Mode — cada 5s."""
        was_gaming = False
        while self.running:
            try:
                if self.gaming_mode and not was_gaming:
                    logger.warning("🎮 GAMING MODE ON — Liberando recursos")
                    await self._speak(
                        f"Modo Gaming activado, {self._user_name}. "
                        f"VRAM liberada para tu juego.", "info"
                    )
                    if self.llm:
                        await asyncio.to_thread(self.llm.unload_model)
                    was_gaming = True

                elif not self.gaming_mode and was_gaming:
                    logger.info("✅ GAMING MODE OFF")
                    await self._speak(
                        "Modo Gaming desactivado. Sistemas cognitivos a pleno rendimiento.",
                        "info"
                    )
                    if self.llm:
                        await asyncio.to_thread(self.llm.reload_model)
                    was_gaming = False
            except Exception as e:
                logger.debug(f"gaming: {e}")
            await asyncio.sleep(5)

    async def _loop_cognitive(self):
        """OODA Loop — cada 5s (30s en gaming)."""
        while self.running:
            interval = 30 if self.gaming_mode else 5
            try:
                if self.ooda and not self.gaming_mode:
                    analysis = self.ooda.orient()
                    action   = self.ooda.decide(analysis)
                    if action and action.get("type") == "alert":
                        await self.event_queue.put({
                            "type": "speak",
                            "text": action.get("msg", ""),
                            "speech_type": "alert",
                        })
            except Exception as e:
                logger.debug(f"cognitive: {e}")
            await asyncio.sleep(interval)

    async def _loop_vision(self):
        """Análisis visual — cada 3s, apagado en gaming."""
        if not self.cua:
            return
        while self.running:
            if self.gaming_mode:
                await asyncio.sleep(10)
                continue
            try:
                analysis = await asyncio.to_thread(self.cua.screen.analyze)
                if analysis and any(
                    w in analysis.lower()
                    for w in ["error", "crítico", "fallo", "warning", "advertencia"]
                ):
                    await self.event_queue.put({
                        "type": "speak",
                        "text": f"Detección en pantalla: {analysis[:120]}",
                        "speech_type": "alert",
                    })
            except Exception as e:
                logger.debug(f"vision: {e}")
            await asyncio.sleep(3)

    async def _loop_voice(self):
        """STT — siempre activo, incluso en gaming."""
        voice = self._voice
        if not voice or not getattr(voice, "stt_enabled", False):
            return
        while self.running:
            try:
                text = await asyncio.to_thread(voice.listen, 3.0, 15.0)
                if text and len(text.strip()) > 1:
                    await self.event_queue.put({
                        "type": "voice_command",
                        "text": text.strip(),
                    })
            except Exception:
                await asyncio.sleep(0.5)

    async def _loop_execution(self):
        """Ejecutor de eventos — siempre activo."""
        while self.running:
            try:
                ev = await asyncio.wait_for(
                    self.event_queue.get(), timeout=1.0
                )
                await self._process_event(ev)
                self.event_queue.task_done()
            except asyncio.TimeoutError:
                pass
            except Exception as e:
                logger.error(f"execution: {e}")

    async def _process_event(self, ev: Dict):
        t = ev.get("type", "")
        if t == "speak":
            await self._speak(ev.get("text", ""), ev.get("speech_type", "info"))
        elif t in ("voice_command", "text_command"):
            text = ev.get("text", "")
            resp = await self.handle_command(text)
            if resp:
                await self._speak(resp)
                if self._ui_cb:
                    self._ui_cb("response", {"user": text, "mark": resp})
        elif t == "cua_task":
            if self.cua:
                result = await self.cua.execute(ev.get("goal", ""))
                await self._speak(result.get("summary", "")[:200])

    # ── COMANDO PRINCIPAL ─────────────────────────────────────────────────────

    async def handle_command(self, user_input: str) -> str:
        """
        Procesar CUALQUIER entrada del usuario.

        Flujo:
          1. Clasificar intención via LLM  (IntentEngine)
          2. Ejecutar acción correcta       (Dispatcher)

        No hay if/elif hardcodeados de comandos.
        El LLM interpreta cualquier forma de pedir algo.
        """
        if not user_input or not user_input.strip():
            return ""

        text = user_input.strip()
        logger.info(f"CMD: '{text}'")

        if self.ooda:
            self.ooda.process_user_command(text)

        self._chat.append({
            "role": "user",
            "text": text,
            "time": datetime.now().strftime("%H:%M:%S"),
        })

        # Contexto de pantalla (ligero)
        screen_ctx = ""
        if self.cua and not self.gaming_mode:
            try:
                screen_ctx = self.cua.screen.last_analysis or ""
            except Exception:
                pass

        # Contexto de conversación reciente
        conv_ctx = " | ".join(
            f"{'tú' if h['role']=='user' else 'MARK'}: {h['text'][:60]}"
            for h in self._chat[-4:]
        ) if len(self._chat) > 1 else ""

        # Clasificar + ejecutar
        if not self.intent or not self.dispatch:
            return await self._llm_fallback(text)

        intent   = await asyncio.to_thread(
            self.intent.classify, text, screen_ctx, conv_ctx
        )
        logger.info(f"Intent: {intent.action} ({intent.confidence:.0%}) — {intent.intent}")

        response = await self.dispatch.dispatch(intent)
        return self._save(response)

    async def _llm_fallback(self, text: str) -> str:
        """Fallback directo al LLM si el IntentEngine no está disponible."""
        if not self.llm:
            return "Sistema no disponible. Comprueba los logs."
        ctx    = self.ooda.state.context_summary() if self.ooda else ""
        prompt = f"[MARK 13 | {ctx} | Usuario: {self._user_name}]\n\n{text}"
        return await asyncio.to_thread(self.llm.generate, prompt, True, 700)

    # ── VOZ ───────────────────────────────────────────────────────────────────

    async def _speak(self, text: str, speech_type: str = "info"):
        if not text or not self._voice:
            return
        try:
            v = self._voice
            if hasattr(v, "speak_greeting") and speech_type == "greeting":
                await asyncio.to_thread(v.speak_greeting, text)
            elif hasattr(v, "speak_alert") and speech_type == "alert":
                await asyncio.to_thread(v.speak_alert, text)
            elif hasattr(v, "speak"):
                await asyncio.to_thread(v.speak, text)
            elif hasattr(v, "say"):
                # pyttsx3 fallback
                await asyncio.to_thread(lambda: (v.say(text), v.runAndWait()))
        except Exception as e:
            logger.debug(f"speak: {e}")

    def speak_sync(self, text: str):
        v = self._voice
        if not v:
            return
        try:
            if hasattr(v, "speak"):
                v.speak(text)
            elif hasattr(v, "say"):
                v.say(text)
                v.runAndWait()
        except Exception:
            pass

    def _greeting(self) -> str:
        h = datetime.now().hour
        g = "Buenos días" if h < 12 else "Buenas tardes" if h < 20 else "Buenas noches"
        return (
            f"{g}, {self._user_name}. "
            f"MARK 13 en línea. "
            f"Ryzen 7, RTX 4060 Ti — todos los sistemas activos."
        )

    # ── UTILIDADES PÚBLICAS ───────────────────────────────────────────────────

    def _save(self, response: str) -> str:
        self._chat.append({
            "role": "mark",
            "text": response,
            "time": datetime.now().strftime("%H:%M:%S"),
        })
        return response

    def set_ui_callback(self, cb: Callable):
        self._ui_cb = cb

    def get_stats(self) -> Dict:
        return self.monitor.get_stats() if self.monitor else {}

    def send_text_command(self, text: str) -> str:
        """Llamada síncrona desde UI (no asyncio)."""
        loop = asyncio.new_event_loop()
        try:
            return loop.run_until_complete(self.handle_command(text))
        finally:
            loop.close()

    async def shutdown(self):
        logger.info("Apagando MARK 13...")
        self.running = False
        if self.hotkey:
            self.hotkey.stop()
        if self.cua:
            self.cua.screen.close()
        logger.info("MARK 13 apagado.")
