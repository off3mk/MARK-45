"""
MARK 12 — Computer Use: Screen Agent
======================================
El agente que VE la pantalla en tiempo real y puede actuar sobre ella.

Capacidades:
  • Captura continua con mss (ultra-rápida, sin lag)
  • Análisis con LLM multimodal (LLaVA / Moondream / GPT-4V)
  • Detección de cambios para no malgastar llamadas a la IA
  • OCR para leer texto sin LLM
  • Devuelve coordenadas de elementos para que el Input Agent actúe

Hardware objetivo: i5-9600K + RX 5700 XT + 16GB RAM
Estrategia: mss captura en <5ms, numpy compara en <1ms, LLM solo si cambia >3%

Creado por Ali (Sidi3Ali) — MARK 12
"""

import base64
import logging
import os
import time
from io import BytesIO
from typing import Optional, Tuple, Dict, List, Any

logger = logging.getLogger("MARK12.ScreenAgent")


class ScreenCapture:
    """Captura de pantalla ultra-rápida con mss."""

    def __init__(self):
        self._mss     = None
        self._session = None
        self._monitor = None
        self._np      = None
        self._pil     = None
        self._init()

    def _init(self):
        try:
            import mss
            self._mss     = mss
            self._session = mss.mss()
            self._monitor = self._session.monitors[1]
            logger.info("✓ mss listo (captura ultra-rápida)")
        except ImportError:
            logger.warning("mss no disponible → pip install mss")

        try:
            import numpy as np
            self._np = np
        except ImportError:
            pass

        try:
            from PIL import Image
            self._pil = Image
        except ImportError:
            logger.warning("Pillow no disponible → pip install pillow")

    @property
    def available(self) -> bool:
        return bool(self._session and self._pil)

    def grab(self, region: Dict = None) -> Optional[Any]:
        """
        Captura rápida. region = {'left':0,'top':0,'width':1920,'height':1080}
        Retorna imagen PIL o None.
        """
        if not self._session or not self._pil:
            return None
        try:
            mon   = region or self._monitor
            frame = self._session.grab(mon)
            return self._pil.frombytes("RGB", frame.size, frame.bgra, "raw", "BGRX")
        except Exception as e:
            logger.debug(f"grab: {e}")
            return None

    def grab_region(self, x: int, y: int, w: int, h: int) -> Optional[Any]:
        return self.grab({'left': x, 'top': y, 'width': w, 'height': h})

    def to_base64(self, img, quality: int = 50) -> Optional[str]:
        """Convertir imagen PIL a base64 para enviar al LLM."""
        if not img:
            return None
        try:
            buf = BytesIO()
            img.save(buf, format="JPEG", quality=quality, optimize=True)
            return base64.b64encode(buf.getvalue()).decode()
        except Exception:
            return None

    def save(self, filepath: str = None) -> Optional[str]:
        """Guardar captura en disco."""
        img = self.grab()
        if not img:
            return None
        if not filepath:
            from datetime import datetime
            filepath = os.path.expanduser(
                f"~/Desktop/mark12_{datetime.now().strftime('%H%M%S')}.png"
            )
        try:
            img.save(filepath)
            return filepath
        except Exception:
            return None

    def get_screen_size(self) -> Tuple[int, int]:
        if self._monitor:
            return self._monitor.get('width', 1920), self._monitor.get('height', 1080)
        return 1920, 1080

    def close(self):
        if self._session:
            try:
                self._session.close()
            except Exception:
                pass


class MotionDetector:
    """
    Detección de movimiento ligera con numpy.
    Solo llama al LLM cuando la pantalla cambia significativamente.
    """

    def __init__(self, threshold: float = 3.0, scale: Tuple = (100, 100)):
        self._np        = None
        self._pil       = None
        self.threshold  = threshold
        self.scale      = scale
        self._last      = None
        self._last_diff = 0.0
        try:
            import numpy as np
            self._np = np
        except ImportError:
            pass
        try:
            from PIL import Image
            self._pil = Image
        except ImportError:
            pass

    def has_changed(self, img) -> bool:
        """True si la imagen cambió más del umbral respecto a la anterior."""
        if not self._np or not self._pil or img is None:
            return True  # Sin numpy, asumir siempre cambio
        try:
            small   = img.resize(self.scale)
            current = self._np.array(small, dtype=self._np.float32)
            if self._last is None:
                self._last = current
                return True
            diff          = float(self._np.mean(self._np.abs(current - self._last)))
            self._last    = current
            self._last_diff = diff
            return diff >= self.threshold
        except Exception:
            return True

    @property
    def last_diff(self) -> float:
        return self._last_diff

    def reset(self):
        self._last = None


class OCREngine:
    """
    Motor OCR para leer texto de la pantalla sin llamar al LLM.
    Usa Tesseract via pytesseract.
    """

    def __init__(self):
        self._ocr = None
        try:
            import pytesseract
            self._ocr = pytesseract
            logger.info("✓ Tesseract OCR disponible")
        except ImportError:
            logger.debug("pytesseract no disponible (opcional) → pip install pytesseract")

    @property
    def available(self) -> bool:
        return self._ocr is not None

    def read(self, img, lang: str = "spa+eng") -> str:
        """Extraer todo el texto de una imagen."""
        if not self._ocr or img is None:
            return ""
        try:
            return self._ocr.image_to_string(img, lang=lang, config="--oem 3 --psm 6")
        except Exception as e:
            logger.debug(f"OCR read: {e}")
            return ""

    def find_text(self, img, search: str, lang: str = "spa+eng") -> Optional[Tuple[int, int]]:
        """
        Buscar texto en imagen y devolver coordenadas del centro.
        Retorna (x, y) o None.
        """
        if not self._ocr or img is None:
            return None
        try:
            import pytesseract
            data = pytesseract.image_to_data(
                img, lang=lang, output_type=pytesseract.Output.DICT
            )
            for i, txt in enumerate(data["text"]):
                if search.lower() in str(txt).lower():
                    x = data["left"][i] + data["width"][i] // 2
                    y = data["top"][i] + data["height"][i] // 2
                    return x, y
        except Exception as e:
            logger.debug(f"OCR find: {e}")
        return None

    def get_boxes(self, img, lang: str = "spa+eng") -> List[Dict]:
        """Obtener todos los bloques de texto con sus bounding boxes."""
        if not self._ocr or img is None:
            return []
        try:
            import pytesseract
            data = pytesseract.image_to_data(
                img, lang=lang, output_type=pytesseract.Output.DICT
            )
            boxes = []
            for i, txt in enumerate(data["text"]):
                if txt.strip() and int(data.get("conf", [0])[i] or 0) > 30:
                    boxes.append({
                        "text": txt,
                        "x":    data["left"][i],
                        "y":    data["top"][i],
                        "w":    data["width"][i],
                        "h":    data["height"][i],
                        "cx":   data["left"][i] + data["width"][i] // 2,
                        "cy":   data["top"][i] + data["height"][i] // 2,
                        "conf": data["conf"][i],
                    })
            return boxes
        except Exception:
            return []


class ScreenAgent:
    """
    Agente principal de visión de MARK 12.

    Flujo:
      1. Captura pantalla con mss (<5ms)
      2. Compara con frame anterior con numpy (<1ms)
      3. Si cambió → analiza con LLM multimodal
      4. Si hay texto legible → OCR sin LLM
      5. Devuelve análisis + coordenadas de elementos
    """

    def __init__(self, llm_engine=None):
        self.llm      = llm_engine
        self.capture  = ScreenCapture()
        self.motion   = MotionDetector(threshold=3.0)
        self.ocr      = OCREngine()
        self._last_analysis     = ""
        self._last_analysis_ts  = 0.0
        self._analysis_cooldown = 4.0   # mínimo 4s entre análisis LLM
        self._active            = True

    # ── ANÁLISIS PRINCIPAL ────────────────────────────────────────────────────

    def analyze(self, force: bool = False) -> Optional[str]:
        """
        Captura + detecta cambio + analiza con LLM si es necesario.
        Llamar desde asyncio.to_thread().
        """
        if not self.capture.available:
            return None

        now = time.time()
        if not force and now - self._last_analysis_ts < self._analysis_cooldown:
            return None

        img = self.capture.grab()
        if img is None:
            return None

        if not force and not self.motion.has_changed(img):
            return None

        self._last_analysis_ts = now

        # OCR primero (gratis, sin red)
        ocr_text = self.ocr.read(img).strip() if self.ocr.available else ""

        # LLM si está disponible
        if self.llm:
            b64 = self.capture.to_base64(img, quality=50)
            if b64:
                try:
                    prompt = (
                        "Analiza esta captura de pantalla en 2-3 frases. "
                        "Indica: app activa, tarea en curso, errores visibles, "
                        "notificaciones urgentes o elementos que requieran atención."
                    )
                    result = self.llm.generate(
                        prompt, with_history=False, max_tokens=200,
                        image_base64=b64
                    )
                    self._last_analysis = result
                    return result
                except Exception as e:
                    logger.debug(f"LLM screen analysis: {e}")

        # Fallback: OCR como resumen
        if ocr_text:
            summary = ocr_text[:300].replace("\n", " ").strip()
            self._last_analysis = summary
            return f"[OCR] {summary}"

        return None

    def describe_now(self) -> str:
        """Describir la pantalla actual (forzado, con timeout 10s)."""
        result = self.analyze(force=True)
        return result or "No pude analizar la pantalla en este momento."

    # ── BÚSQUEDA DE ELEMENTOS ─────────────────────────────────────────────────

    def find_element(self, description: str) -> Optional[Tuple[int, int]]:
        """
        Buscar un elemento en pantalla por descripción textual.
        Intenta OCR primero, luego LLM si no lo encuentra.
        """
        img = self.capture.grab()
        if img is None:
            return None

        # 1. Buscar con OCR (rápido)
        coords = self.ocr.find_text(img, description)
        if coords:
            logger.info(f"Elemento '{description}' encontrado via OCR: {coords}")
            return coords

        # 2. Buscar con LLM (más potente)
        if self.llm:
            b64 = self.capture.to_base64(img, quality=60)
            if b64:
                try:
                    prompt = (
                        f"En esta captura de pantalla, busca el elemento: '{description}'. "
                        f"Si lo encuentras, responde SOLO con las coordenadas en formato: X,Y "
                        f"(siendo X píxeles desde la izquierda e Y píxeles desde arriba). "
                        f"Si no lo encuentras, responde: NO_ENCONTRADO"
                    )
                    result = self.llm.generate(
                        prompt, with_history=False, max_tokens=30,
                        image_base64=b64
                    )
                    result = result.strip()
                    if "," in result and "NO_ENCONTRADO" not in result.upper():
                        parts = result.replace(" ", "").split(",")
                        if len(parts) >= 2:
                            x, y = int(parts[0].strip()), int(parts[1].strip())
                            logger.info(f"Elemento '{description}' encontrado via LLM: ({x},{y})")
                            return x, y
                except Exception as e:
                    logger.debug(f"find_element LLM: {e}")

        return None

    def read_text_in_region(self, x: int, y: int, w: int, h: int) -> str:
        """Leer texto de una región específica de la pantalla."""
        img = self.capture.grab_region(x, y, w, h)
        if img is None:
            return ""
        return self.ocr.read(img)

    def get_all_text(self) -> str:
        """Obtener todo el texto visible en pantalla via OCR."""
        img = self.capture.grab()
        if img is None:
            return ""
        return self.ocr.read(img)

    def screenshot_to_file(self, filepath: str = None) -> Optional[str]:
        return self.capture.save(filepath)

    # ── ESTADO ────────────────────────────────────────────────────────────────

    @property
    def last_analysis(self) -> str:
        return self._last_analysis

    def get_status(self) -> str:
        parts = []
        if self.capture.available: parts.append("Captura ✓")
        else:                       parts.append("Captura ✗")
        if self.ocr.available:      parts.append("OCR ✓")
        else:                       parts.append("OCR ✗")
        if self.llm:                parts.append("LLM ✓")
        else:                       parts.append("LLM ✗")
        w, h = self.capture.get_screen_size()
        parts.append(f"Resolución {w}x{h}")
        return " | ".join(parts)

    def close(self):
        self.capture.close()
