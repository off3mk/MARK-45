"""
MARK 12 — Computer Use: Input Agent
=====================================
Control total del ratón y teclado. MARK actúa como un humano sobre el PC.
Click, escritura, atajos, drag&drop, scroll — sobre cualquier app.

Backends: pyautogui → win32api → xdotool (Linux)
Creado por Ali (Sidi3Ali) — MARK 12
"""

import logging
import platform
import time
import subprocess
from typing import List, Optional, Tuple

logger = logging.getLogger("MARK12.InputAgent")

SYSTEM = platform.system()


class MouseController:
    """Control de ratón multiplataforma."""

    def __init__(self):
        self._pag   = None
        self._win32 = False
        self._init()

    def _init(self):
        try:
            import pyautogui
            pyautogui.FAILSAFE = True
            pyautogui.PAUSE    = 0.04
            self._pag = pyautogui
            logger.info("✓ pyautogui (mouse+teclado)")
        except ImportError:
            logger.warning("pyautogui no instalado → pip install pyautogui")

        if SYSTEM == "Windows":
            try:
                import win32api
                import win32con
                self._win32 = True
            except ImportError:
                pass

    def click(self, x: int, y: int, button: str = "left", clicks: int = 1) -> bool:
        if self._pag:
            try:
                self._pag.click(x, y, button=button, clicks=clicks, interval=0.08)
                return True
            except Exception as e:
                logger.debug(f"pag.click: {e}")
        if self._win32 and button == "left":
            return self._win32_click(x, y, clicks)
        return False

    def _win32_click(self, x: int, y: int, clicks: int = 1) -> bool:
        try:
            import win32api, win32con
            win32api.SetCursorPos((x, y))
            for _ in range(clicks):
                win32api.mouse_event(win32con.MOUSEEVENTF_LEFTDOWN, 0, 0)
                time.sleep(0.04)
                win32api.mouse_event(win32con.MOUSEEVENTF_LEFTUP, 0, 0)
                time.sleep(0.05)
            return True
        except Exception as e:
            logger.debug(f"win32_click: {e}")
            return False

    def double_click(self, x: int, y: int) -> bool:
        return self.click(x, y, clicks=2)

    def right_click(self, x: int, y: int) -> bool:
        return self.click(x, y, button="right")

    def move(self, x: int, y: int, duration: float = 0.12) -> bool:
        if self._pag:
            try:
                self._pag.moveTo(x, y, duration=duration, _pause=False)
                return True
            except Exception:
                pass
        if self._win32:
            try:
                import win32api
                win32api.SetCursorPos((x, y))
                return True
            except Exception:
                pass
        return False

    def drag(self, x1: int, y1: int, x2: int, y2: int,
              duration: float = 0.4) -> bool:
        if self._pag:
            try:
                self._pag.moveTo(x1, y1, duration=0.1)
                self._pag.dragTo(x2, y2, duration=duration, button="left")
                return True
            except Exception as e:
                logger.debug(f"drag: {e}")
        return False

    def scroll(self, clicks: int, x: int = None, y: int = None) -> bool:
        if self._pag:
            try:
                if x and y:
                    self._pag.scroll(clicks, x=x, y=y)
                else:
                    self._pag.scroll(clicks)
                return True
            except Exception:
                pass
        return False

    def position(self) -> Tuple[int, int]:
        if self._pag:
            try:
                return tuple(self._pag.position())
            except Exception:
                pass
        return (0, 0)

    def screen_size(self) -> Tuple[int, int]:
        if self._pag:
            try:
                return tuple(self._pag.size())
            except Exception:
                pass
        return (1920, 1080)


class KeyboardController:
    """Control de teclado multiplataforma."""

    def __init__(self):
        self._pag = None
        self._init()

    def _init(self):
        try:
            import pyautogui
            self._pag = pyautogui
        except ImportError:
            pass

    def type(self, text: str, interval: float = 0.025) -> bool:
        """Escribir texto."""
        if not text:
            return False
        if self._pag:
            try:
                self._pag.write(text, interval=interval)
                return True
            except Exception as e:
                logger.debug(f"write: {e}")
        return self._clipboard_paste(text)

    def _clipboard_paste(self, text: str) -> bool:
        """Pegar via portapapeles (fallback para texto con caracteres especiales)."""
        try:
            if SYSTEM == "Windows":
                subprocess.run(["clip"], input=text.encode("utf-16"), check=True)
                if self._pag:
                    self._pag.hotkey("ctrl", "v")
            elif SYSTEM == "Darwin":
                subprocess.run(["pbcopy"], input=text.encode(), check=True)
                if self._pag:
                    self._pag.hotkey("command", "v")
            elif SYSTEM == "Linux":
                subprocess.run(["xclip", "-selection", "clipboard"],
                                input=text.encode(), check=True)
                if self._pag:
                    self._pag.hotkey("ctrl", "v")
            return True
        except Exception as e:
            logger.debug(f"clipboard_paste: {e}")
            return False

    def press(self, key: str) -> bool:
        if self._pag:
            try:
                self._pag.press(key)
                return True
            except Exception:
                pass
        return False

    def hotkey(self, *keys: str) -> bool:
        """Ejecutar combinación de teclas: hotkey('ctrl','c')."""
        if self._pag:
            try:
                self._pag.hotkey(*keys)
                return True
            except Exception as e:
                logger.debug(f"hotkey {keys}: {e}")
        return False

    def key_down(self, key: str) -> bool:
        if self._pag:
            try:
                self._pag.keyDown(key)
                return True
            except Exception:
                pass
        return False

    def key_up(self, key: str) -> bool:
        if self._pag:
            try:
                self._pag.keyUp(key)
                return True
            except Exception:
                pass
        return False


class WindowManager:
    """Gestión de ventanas del sistema operativo."""

    def __init__(self):
        self._win32 = False
        self._uia   = False
        if SYSTEM == "Windows":
            try:
                import win32gui, win32con
                self._win32 = True
            except ImportError:
                pass
            try:
                import uiautomation
                self._uia = True
                logger.info("✓ uiautomation disponible")
            except ImportError:
                pass

    def get_active_title(self) -> str:
        if SYSTEM == "Windows" and self._win32:
            try:
                import win32gui
                hwnd = win32gui.GetForegroundWindow()
                return win32gui.GetWindowText(hwnd)
            except Exception:
                pass
        elif SYSTEM == "Darwin":
            try:
                result = subprocess.run(
                    ["osascript", "-e",
                     'tell app "System Events" to get name of first process whose frontmost is true'],
                    capture_output=True, text=True, timeout=2
                )
                return result.stdout.strip()
            except Exception:
                pass
        return ""

    def get_all_windows(self) -> List[str]:
        titles = []
        if SYSTEM == "Windows" and self._win32:
            try:
                import win32gui
                def cb(hwnd, _):
                    if win32gui.IsWindowVisible(hwnd):
                        t = win32gui.GetWindowText(hwnd)
                        if t.strip():
                            titles.append(t)
                win32gui.EnumWindows(cb, None)
            except Exception:
                pass
        return titles

    def find_window(self, title_contains: str) -> Optional[int]:
        if SYSTEM == "Windows" and self._win32:
            try:
                import win32gui
                result = []
                def cb(hwnd, _):
                    if win32gui.IsWindowVisible(hwnd):
                        t = win32gui.GetWindowText(hwnd)
                        if title_contains.lower() in t.lower():
                            result.append(hwnd)
                win32gui.EnumWindows(cb, None)
                return result[0] if result else None
            except Exception:
                pass
        return None

    def focus_window(self, title_contains: str) -> bool:
        hwnd = self.find_window(title_contains)
        if hwnd and SYSTEM == "Windows":
            try:
                import win32gui, win32con
                win32gui.ShowWindow(hwnd, win32con.SW_RESTORE)
                win32gui.SetForegroundWindow(hwnd)
                time.sleep(0.25)
                return True
            except Exception as e:
                logger.debug(f"focus_window: {e}")
        return False

    def close_window(self, title_contains: str) -> bool:
        hwnd = self.find_window(title_contains)
        if hwnd and SYSTEM == "Windows":
            try:
                import win32gui, win32con
                win32gui.PostMessage(hwnd, win32con.WM_CLOSE, 0, 0)
                return True
            except Exception:
                pass
        return False

    def maximize_window(self, title_contains: str) -> bool:
        hwnd = self.find_window(title_contains)
        if hwnd and SYSTEM == "Windows":
            try:
                import win32gui, win32con
                win32gui.ShowWindow(hwnd, win32con.SW_MAXIMIZE)
                return True
            except Exception:
                pass
        return False

    def minimize_window(self, title_contains: str) -> bool:
        hwnd = self.find_window(title_contains)
        if hwnd and SYSTEM == "Windows":
            try:
                import win32gui, win32con
                win32gui.ShowWindow(hwnd, win32con.SW_MINIMIZE)
                return True
            except Exception:
                pass
        return False

    def find_and_click_button_uia(self, button_name: str,
                                    window_title: str = None) -> bool:
        """Usar UIAutomation para click por nombre de accesibilidad."""
        if not self._uia:
            return False
        try:
            import uiautomation as auto
            if window_title:
                win = auto.WindowControl(Name=window_title)
                btn = win.ButtonControl(Name=button_name)
            else:
                btn = auto.ButtonControl(Name=button_name)
            if btn.Exists(0):
                btn.Click()
                return True
        except Exception as e:
            logger.debug(f"uia click: {e}")
        return False


class ClipboardManager:
    """Gestión del portapapeles."""

    def get(self) -> str:
        try:
            if SYSTEM == "Windows":
                import win32clipboard
                win32clipboard.OpenClipboard()
                data = win32clipboard.GetClipboardData()
                win32clipboard.CloseClipboard()
                return str(data)
            elif SYSTEM == "Darwin":
                return subprocess.check_output(["pbpaste"]).decode().strip()
            else:
                return subprocess.check_output(
                    ["xclip", "-selection", "clipboard", "-o"]
                ).decode().strip()
        except Exception:
            return ""

    def set(self, text: str) -> bool:
        try:
            if SYSTEM == "Windows":
                subprocess.run(["clip"], input=text.encode("utf-16"), check=True)
            elif SYSTEM == "Darwin":
                subprocess.run(["pbcopy"], input=text.encode(), check=True)
            else:
                subprocess.run(
                    ["xclip", "-selection", "clipboard"],
                    input=text.encode(), check=True
                )
            return True
        except Exception:
            return False


class InputAgent:
    """
    Agente de entrada principal de MARK 12.
    Coordina mouse, teclado, ventanas y portapapeles.
    """

    def __init__(self):
        self.mouse     = MouseController()
        self.keyboard  = KeyboardController()
        self.windows   = WindowManager()
        self.clipboard = ClipboardManager()

    # ── ACCIONES DE ALTO NIVEL ────────────────────────────────────────────────

    def click_on(self, x: int, y: int) -> bool:
        return self.mouse.click(x, y)

    def type_text(self, text: str) -> bool:
        return self.keyboard.type(text)

    def hotkey(self, *keys: str) -> bool:
        return self.keyboard.hotkey(*keys)

    def press_enter(self) -> bool:
        return self.keyboard.press("enter")

    def press_escape(self) -> bool:
        return self.keyboard.press("escape")

    def press_tab(self) -> bool:
        return self.keyboard.press("tab")

    def select_all(self) -> bool:
        return self.keyboard.hotkey("ctrl", "a")

    def copy(self) -> bool:
        return self.keyboard.hotkey("ctrl", "c")

    def paste(self) -> bool:
        return self.keyboard.hotkey("ctrl", "v")

    def undo(self) -> bool:
        return self.keyboard.hotkey("ctrl", "z")

    def save(self) -> bool:
        return self.keyboard.hotkey("ctrl", "s")

    def close_app(self) -> bool:
        return self.keyboard.hotkey("alt", "f4")

    def new_tab(self) -> bool:
        return self.keyboard.hotkey("ctrl", "t")

    def close_tab(self) -> bool:
        return self.keyboard.hotkey("ctrl", "w")

    # ── INTERACCIÓN CON CAMPO DE TEXTO ────────────────────────────────────────

    def click_and_type(self, x: int, y: int, text: str,
                        clear_first: bool = True) -> bool:
        """Click en un campo y escribir texto."""
        if not self.mouse.click(x, y):
            return False
        time.sleep(0.15)
        if clear_first:
            self.keyboard.hotkey("ctrl", "a")
            time.sleep(0.05)
        return self.keyboard.type(text)

    def find_and_type(self, screen_agent, element_text: str,
                        text: str, clear_first: bool = True) -> bool:
        """Buscar elemento en pantalla por texto y escribir en él."""
        coords = screen_agent.find_element(element_text)
        if not coords:
            return False
        return self.click_and_type(coords[0], coords[1], text, clear_first)
