"""
MARK 12 — Computer Use Agent
==============================
El cerebro autónomo que combina visión + input para ejecutar
tareas complejas sobre cualquier aplicación sin integración oficial.

Capacidades:
  • Ver la pantalla en tiempo real (ScreenAgent)
  • Mover ratón, hacer click, escribir, atajos (InputAgent)
  • Ejecutar planes de N pasos generados por LLM
  • Buscar y abrir aplicaciones, archivos, URLs
  • Rellenar formularios, copiar datos entre apps
  • Operar como Claude Computer Use pero LOCAL y SIN CLOUD

Flujo de una tarea:
  1. Usuario: "busca vuelos a Madrid en Google y ponlos en el portapapeles"
  2. CUA genera plan de pasos via LLM
  3. Ejecuta cada paso: abrir Chrome, escribir URL, leer resultados, copiar
  4. Reporta resultado al usuario

Hardware: i5-9600K + RX 5700 XT + 16GB RAM
Creado por Ali (Sidi3Ali) — MARK 12
"""

import asyncio
import json
import logging
import os
import re
import subprocess
import time
import platform
from dataclasses import dataclass, field
from typing import Any, Callable, Dict, List, Optional, Tuple

from core.computer_use.screen_agent import ScreenAgent
from core.computer_use.input_agent  import InputAgent

logger = logging.getLogger("MARK12.CUA")

SYSTEM = platform.system()


# ── ESTRUCTURA DE UN PASO ─────────────────────────────────────────────────────

@dataclass
class ActionStep:
    """Un paso atómico de un plan de Computer Use."""
    type:        str                    # click, type, hotkey, open_app, wait, ...
    params:      Dict = field(default_factory=dict)
    description: str = ""
    timeout:     float = 5.0
    retry:       int   = 1


@dataclass
class TaskPlan:
    """Plan completo de una tarea autónoma."""
    goal:        str
    steps:       List[ActionStep] = field(default_factory=list)
    context:     str = ""
    max_retries: int = 2


@dataclass
class StepResult:
    """Resultado de ejecutar un ActionStep."""
    success:  bool
    message:  str
    data:     Any = None


# ── PLANIFICADOR DE TAREAS ─────────────────────────────────────────────────────

class TaskPlanner:
    """
    Usa el LLM para convertir una solicitud en lenguaje natural
    en un plan de pasos ejecutables.
    """

    # Acciones disponibles que el LLM puede usar
    AVAILABLE_ACTIONS = [
        "open_app(name)            — Abrir aplicación por nombre",
        "open_url(url)             — Abrir URL en el navegador",
        "click(x, y)               — Clic en coordenadas absolutas",
        "click_text(text)          — Clic en el elemento con ese texto",
        "double_click(x, y)        — Doble clic",
        "right_click(x, y)         — Clic derecho",
        "type(text)                — Escribir texto en el campo activo",
        "hotkey(key1, key2, ...)   — Ejecutar atajo de teclado",
        "press(key)                — Presionar tecla (enter, tab, escape, f5...)",
        "wait(seconds)             — Esperar N segundos",
        "scroll(amount)            — Scroll (positivo=arriba, negativo=abajo)",
        "read_screen()             — Leer contenido de la pantalla",
        "screenshot()              — Tomar captura",
        "copy_selection()          — Copiar selección al portapapeles",
        "get_clipboard()           — Leer el portapapeles",
        "focus_window(title)       — Enfocar ventana por título",
        "close_window(title)       — Cerrar ventana",
        "maximize_window(title)    — Maximizar ventana",
        "find_and_click(text)      — Buscar texto en pantalla y hacer clic",
        "run_command(cmd)          — Ejecutar comando en terminal",
    ]

    PLAN_PROMPT = """Eres el planificador de MARK 12. Convierte esta solicitud en un plan de pasos JSON.

Acciones disponibles:
{actions}

Solicitud: "{goal}"
Contexto de pantalla actual: {context}

Responde SOLO con un array JSON de pasos. Ejemplo:
[
  {{"action": "open_app", "params": {{"name": "Chrome"}}, "description": "Abrir Chrome"}},
  {{"action": "open_url", "params": {{"url": "https://google.com"}}, "description": "Ir a Google"}},
  {{"action": "click_text", "params": {{"text": "Buscar"}}, "description": "Hacer clic en campo de búsqueda"}},
  {{"action": "type", "params": {{"text": "vuelos Madrid"}}, "description": "Escribir búsqueda"}},
  {{"action": "press", "params": {{"key": "enter"}}, "description": "Buscar"}}
]

Solo el JSON, sin explicaciones adicionales."""

    def __init__(self, llm_engine=None):
        self.llm = llm_engine

    def plan(self, goal: str, screen_context: str = "") -> TaskPlan:
        """
        Generar plan de pasos para una tarea.
        Retorna TaskPlan con lista de ActionStep.
        """
        plan = TaskPlan(goal=goal, context=screen_context)

        if not self.llm:
            # Plan básico hardcoded si no hay LLM
            plan.steps = self._basic_plan(goal)
            return plan

        try:
            prompt = self.PLAN_PROMPT.format(
                actions="\n".join(self.AVAILABLE_ACTIONS),
                goal=goal,
                context=screen_context[:300] if screen_context else "Escritorio"
            )
            response = self.llm.generate(prompt, with_history=False, max_tokens=800)

            # Extraer JSON
            match = re.search(r'\[.*\]', response, re.DOTALL)
            if match:
                steps_data = json.loads(match.group())
                for step_dict in steps_data:
                    plan.steps.append(ActionStep(
                        type=step_dict.get('action', 'wait'),
                        params=step_dict.get('params', {}),
                        description=step_dict.get('description', ''),
                    ))
                logger.info(f"Plan generado: {len(plan.steps)} pasos para '{goal}'")
            else:
                logger.warning("LLM no devolvió JSON válido. Usando plan básico.")
                plan.steps = self._basic_plan(goal)

        except Exception as e:
            logger.error(f"TaskPlanner.plan: {e}")
            plan.steps = self._basic_plan(goal)

        return plan

    def _basic_plan(self, goal: str) -> List[ActionStep]:
        """Plan básico sin LLM para comandos simples."""
        gl = goal.lower()
        steps = []

        if 'chrome' in gl or 'navegador' in gl or 'abre chrome' in gl:
            steps.append(ActionStep('open_app', {'name': 'chrome'}, 'Abrir Chrome'))
        elif 'notepad' in gl or 'bloc' in gl:
            steps.append(ActionStep('open_app', {'name': 'notepad'}, 'Abrir Notepad'))
        elif 'calculadora' in gl or 'calc' in gl:
            steps.append(ActionStep('open_app', {'name': 'calc'}, 'Abrir Calculadora'))
        elif any(w in gl for w in ['busca', 'google']):
            query = re.sub(r'(busca|buscar|google)\s*', '', gl).strip()
            url = f"https://www.google.com/search?q={query.replace(' ', '+')}"
            steps.append(ActionStep('open_url', {'url': url}, f'Buscar: {query}'))

        if not steps:
            steps.append(ActionStep('read_screen', {}, 'Leer estado de pantalla'))

        return steps


# ── EJECUTOR DE PASOS ─────────────────────────────────────────────────────────

class StepExecutor:
    """
    Ejecuta un ActionStep usando ScreenAgent + InputAgent.
    Cada acción atómica mapeada a operaciones reales.
    """

    def __init__(self, screen: ScreenAgent, input_agent: InputAgent):
        self.screen = screen
        self.input  = input_agent

    def execute(self, step: ActionStep) -> StepResult:
        """Ejecutar un paso y retornar resultado."""
        p = step.params
        action = step.type.lower()

        logger.info(f"  → {action}: {step.description or p}")

        handlers = {
            'open_app':       self._open_app,
            'open_url':       self._open_url,
            'click':          self._click,
            'click_text':     self._click_text,
            'find_and_click': self._click_text,
            'double_click':   self._double_click,
            'right_click':    self._right_click,
            'type':           self._type,
            'hotkey':         self._hotkey,
            'press':          self._press,
            'wait':           self._wait,
            'scroll':         self._scroll,
            'read_screen':    self._read_screen,
            'screenshot':     self._screenshot,
            'copy_selection': self._copy_selection,
            'get_clipboard':  self._get_clipboard,
            'focus_window':   self._focus_window,
            'close_window':   self._close_window,
            'maximize_window': self._maximize_window,
            'run_command':    self._run_command,
            'noop':           lambda p: StepResult(True, "noop"),
        }

        handler = handlers.get(action)
        if not handler:
            return StepResult(False, f"Acción desconocida: {action}")

        try:
            result = handler(p)
            if result.success:
                time.sleep(0.2)  # Pequeña pausa entre pasos
            return result
        except Exception as e:
            logger.error(f"StepExecutor.execute [{action}]: {e}")
            return StepResult(False, str(e))

    # ── HANDLERS ──────────────────────────────────────────────────────────────

    def _open_app(self, p: Dict) -> StepResult:
        name = p.get('name', '')
        if not name:
            return StepResult(False, "Sin nombre de app")

        # Mapeo de nombres comunes
        APP_MAP = {
            'chrome':      'chrome',
            'firefox':     'firefox',
            'edge':        'msedge',
            'notepad':     'notepad',
            'notepad++':   'notepad++',
            'calc':        'calc',
            'calculadora': 'calc',
            'explorer':    'explorer',
            'word':        'winword',
            'excel':       'excel',
            'powerpoint':  'powerpnt',
            'vscode':      'code',
            'terminal':    'cmd' if SYSTEM == 'Windows' else 'terminal',
            'cmd':         'cmd',
            'powershell':  'powershell',
            'spotify':     'spotify',
            'discord':     'discord',
            'teams':       'teams',
            'outlook':     'outlook',
            'paint':       'mspaint',
            'task manager': 'taskmgr',
            'regedit':     'regedit',
        }

        exe = APP_MAP.get(name.lower(), name)

        try:
            if SYSTEM == 'Windows':
                os.startfile(exe)
            elif SYSTEM == 'Darwin':
                subprocess.Popen(['open', '-a', name])
            else:
                subprocess.Popen([exe])
            time.sleep(1.5)
            return StepResult(True, f"App '{name}' abierta")
        except Exception as e:
            # Fallback: Win+R → run
            if SYSTEM == 'Windows':
                try:
                    self.input.keyboard.hotkey('win', 'r')
                    time.sleep(0.4)
                    self.input.keyboard.type(exe)
                    time.sleep(0.1)
                    self.input.keyboard.press('enter')
                    time.sleep(1.5)
                    return StepResult(True, f"App '{name}' abierta via Run")
                except Exception as e2:
                    return StepResult(False, f"Error abriendo '{name}': {e} | {e2}")
            return StepResult(False, str(e))

    def _open_url(self, p: Dict) -> StepResult:
        url = p.get('url', '')
        if not url:
            return StepResult(False, "Sin URL")
        try:
            import webbrowser
            webbrowser.open(url)
            time.sleep(2.0)
            return StepResult(True, f"URL abierta: {url}")
        except Exception as e:
            return StepResult(False, str(e))

    def _click(self, p: Dict) -> StepResult:
        x = int(p.get('x', 0))
        y = int(p.get('y', 0))
        ok = self.input.mouse.click(x, y)
        return StepResult(ok, f"Click ({x},{y})")

    def _click_text(self, p: Dict) -> StepResult:
        text = p.get('text', '')
        if not text:
            return StepResult(False, "Sin texto para buscar")

        # Buscar con OCR primero
        coords = self.screen.find_element(text)
        if coords:
            ok = self.input.mouse.click(coords[0], coords[1])
            return StepResult(ok, f"Click en '{text}' en {coords}")
        return StepResult(False, f"Elemento '{text}' no encontrado en pantalla")

    def _double_click(self, p: Dict) -> StepResult:
        x, y = int(p.get('x', 0)), int(p.get('y', 0))
        ok = self.input.mouse.double_click(x, y)
        return StepResult(ok, f"Doble click ({x},{y})")

    def _right_click(self, p: Dict) -> StepResult:
        x, y = int(p.get('x', 0)), int(p.get('y', 0))
        ok = self.input.mouse.right_click(x, y)
        return StepResult(ok, f"Click derecho ({x},{y})")

    def _type(self, p: Dict) -> StepResult:
        text = p.get('text', '')
        ok = self.input.keyboard.type(text)
        return StepResult(ok, f"Escrito: '{text[:30]}...' " if len(text) > 30 else f"Escrito: '{text}'")

    def _hotkey(self, p: Dict) -> StepResult:
        # Acepta tanto lista como string separado por '+'
        keys = p.get('keys', [])
        if isinstance(keys, str):
            keys = [k.strip() for k in keys.split('+')]
        if not keys:
            # Intentar parámetros individuales: key1, key2, key3
            keys = [v for k, v in sorted(p.items()) if k.startswith('key')]
        if not keys:
            return StepResult(False, "Sin teclas para el hotkey")
        ok = self.input.keyboard.hotkey(*keys)
        return StepResult(ok, f"Hotkey: {'+'.join(keys)}")

    def _press(self, p: Dict) -> StepResult:
        key = p.get('key', 'enter')
        ok = self.input.keyboard.press(key)
        return StepResult(ok, f"Tecla: {key}")

    def _wait(self, p: Dict) -> StepResult:
        secs = float(p.get('seconds', 1.0))
        secs = min(secs, 15.0)  # Máximo 15 segundos
        time.sleep(secs)
        return StepResult(True, f"Esperado {secs}s")

    def _scroll(self, p: Dict) -> StepResult:
        amount = int(p.get('amount', 3))
        x = p.get('x')
        y = p.get('y')
        ok = self.input.mouse.scroll(amount, x, y)
        return StepResult(ok, f"Scroll {amount}")

    def _read_screen(self, p: Dict) -> StepResult:
        text = self.screen.get_all_text()
        if not text:
            analysis = self.screen.describe_now()
            return StepResult(True, "Pantalla analizada", analysis)
        return StepResult(True, "Texto leído", text[:500])

    def _screenshot(self, p: Dict) -> StepResult:
        filepath = p.get('filepath')
        saved = self.screen.screenshot_to_file(filepath)
        return StepResult(bool(saved), f"Captura guardada: {saved}" if saved else "Error", saved)

    def _copy_selection(self, p: Dict) -> StepResult:
        ok = self.input.keyboard.hotkey('ctrl', 'c')
        time.sleep(0.2)
        content = self.input.clipboard.get()
        return StepResult(ok, f"Copiado ({len(content)} chars)", content)

    def _get_clipboard(self, p: Dict) -> StepResult:
        content = self.input.clipboard.get()
        return StepResult(True, f"Portapapeles: {content[:100]}", content)

    def _focus_window(self, p: Dict) -> StepResult:
        title = p.get('title', '')
        ok = self.input.windows.focus_window(title)
        return StepResult(ok, f"Ventana enfocada: '{title}'")

    def _close_window(self, p: Dict) -> StepResult:
        title = p.get('title', '')
        ok = self.input.windows.close_window(title)
        return StepResult(ok, f"Ventana cerrada: '{title}'")

    def _maximize_window(self, p: Dict) -> StepResult:
        title = p.get('title', '')
        ok = self.input.windows.maximize_window(title)
        return StepResult(ok, f"Ventana maximizada: '{title}'")

    def _run_command(self, p: Dict) -> StepResult:
        cmd = p.get('cmd', '')
        if not cmd:
            return StepResult(False, "Sin comando")
        # Validación básica de seguridad
        dangerous = ['rm -rf /', 'format c:', 'del /s /f c:\\', 'rd /s /q c:\\']
        if any(d in cmd.lower() for d in dangerous):
            return StepResult(False, "Comando rechazado por seguridad")
        try:
            result = subprocess.run(
                cmd, shell=True, capture_output=True,
                text=True, timeout=15
            )
            output = (result.stdout or result.stderr or '').strip()[:300]
            return StepResult(result.returncode == 0, output, output)
        except subprocess.TimeoutExpired:
            return StepResult(False, "Timeout (15s)")
        except Exception as e:
            return StepResult(False, str(e))


# ── AGENTE PRINCIPAL ──────────────────────────────────────────────────────────

class ComputerUseAgent:
    """
    El agente autónomo principal de Computer Use en MARK 12.

    Recibe una instrucción en lenguaje natural y la ejecuta
    sobre la interfaz gráfica del PC, paso a paso.

    Uso:
        cua = ComputerUseAgent(llm=llm_engine)
        result = await cua.execute("busca el precio del dólar en Google y cópialo")
    """

    def __init__(self, llm_engine=None):
        self.screen   = ScreenAgent(llm_engine)
        self.input    = InputAgent()
        self.planner  = TaskPlanner(llm_engine)
        self.executor = StepExecutor(self.screen, self.input)
        self.llm      = llm_engine
        self._history: List[Dict] = []  # Historial de tareas ejecutadas

    # ── EJECUCIÓN PRINCIPAL ───────────────────────────────────────────────────

    async def execute(self, goal: str,
                       on_step: Callable = None) -> Dict:
        """
        Ejecutar una tarea en lenguaje natural de forma autónoma.
        on_step(step_n, total, description, success) — callback de progreso.

        Retorna dict con success, summary, steps_results, data.
        """
        logger.info(f"🤖 CUA iniciando tarea: '{goal}'")

        # 1. Leer contexto actual de pantalla
        screen_context = await asyncio.to_thread(self.screen.describe_now)
        logger.info(f"Contexto pantalla: {screen_context[:100]}")

        # 2. Generar plan
        plan = await asyncio.to_thread(self.planner.plan, goal, screen_context)

        if not plan.steps:
            return {
                'success': False,
                'summary': f"No pude generar un plan para: '{goal}'",
                'steps':   [],
                'data':    None,
            }

        logger.info(f"Plan: {len(plan.steps)} pasos")

        # 3. Ejecutar pasos
        results     = []
        collected_data = []
        success_count  = 0

        for i, step in enumerate(plan.steps):
            result = await asyncio.to_thread(self.executor.execute, step)
            results.append({
                'step':    i + 1,
                'action':  step.type,
                'desc':    step.description,
                'success': result.success,
                'message': result.message,
            })

            if result.success:
                success_count += 1
                if result.data:
                    collected_data.append(str(result.data))

            # Callback de progreso
            if on_step:
                on_step(i + 1, len(plan.steps), step.description, result.success)

            # Abortar si hay fallo crítico en los primeros pasos
            if not result.success and i < 2 and step.retry > 0:
                logger.warning(f"Paso {i+1} falló, reintentando...")
                step.retry -= 1
                await asyncio.sleep(0.8)
                result2 = await asyncio.to_thread(self.executor.execute, step)
                if result2.success:
                    results[-1]['success'] = True
                    success_count += 1

        # 4. Generar resumen
        overall_success = success_count >= len(plan.steps) * 0.7
        summary = self._generate_summary(goal, results, collected_data)

        task_record = {
            'goal':    goal,
            'success': overall_success,
            'steps':   len(plan.steps),
            'ok':      success_count,
            'summary': summary,
        }
        self._history.append(task_record)

        logger.info(
            f"Tarea {'✅ completada' if overall_success else '⚠ parcial'}: "
            f"{success_count}/{len(plan.steps)} pasos OK"
        )

        return {
            'success': overall_success,
            'summary': summary,
            'steps':   results,
            'data':    '\n'.join(collected_data) if collected_data else None,
        }

    def _generate_summary(self, goal: str, results: List[Dict],
                            data: List[str]) -> str:
        ok  = sum(1 for r in results if r['success'])
        total = len(results)
        failed = [r for r in results if not r['success']]

        summary = f"Tarea: '{goal}'\n"
        summary += f"Pasos: {ok}/{total} completados.\n"

        if data:
            summary += f"Datos obtenidos: {data[0][:200]}\n"

        if failed:
            summary += f"Pasos fallidos: {', '.join(r['desc'] or r['action'] for r in failed[:3])}"

        return summary.strip()

    # ── COMANDOS DIRECTOS (SIN PLAN) ─────────────────────────────────────────

    async def click_at(self, x: int, y: int) -> bool:
        return await asyncio.to_thread(self.input.mouse.click, x, y)

    async def type_text(self, text: str) -> bool:
        return await asyncio.to_thread(self.input.keyboard.type, text)

    async def press_hotkey(self, *keys: str) -> bool:
        return await asyncio.to_thread(self.input.keyboard.hotkey, *keys)

    async def open_app(self, name: str) -> bool:
        result = await asyncio.to_thread(
            self.executor._open_app, {'name': name}
        )
        return result.success

    async def open_url(self, url: str) -> bool:
        result = await asyncio.to_thread(
            self.executor._open_url, {'url': url}
        )
        return result.success

    async def read_screen(self) -> str:
        return await asyncio.to_thread(self.screen.describe_now)

    async def find_and_click(self, text: str) -> bool:
        coords = await asyncio.to_thread(self.screen.find_element, text)
        if coords:
            return await asyncio.to_thread(self.input.mouse.click, *coords)
        return False

    async def take_screenshot(self, filepath: str = None) -> Optional[str]:
        return await asyncio.to_thread(self.screen.screenshot_to_file, filepath)

    async def get_clipboard(self) -> str:
        return await asyncio.to_thread(self.input.clipboard.get)

    async def set_clipboard(self, text: str) -> bool:
        return await asyncio.to_thread(self.input.clipboard.set, text)

    # ── TAREAS COMPLEJAS PREDEFINIDAS ─────────────────────────────────────────

    async def search_google(self, query: str) -> str:
        """Abrir Google y buscar. Devuelve texto de resultados."""
        import urllib.parse
        url = f"https://www.google.com/search?q={urllib.parse.quote(query)}"
        await self.open_url(url)
        await asyncio.sleep(2.5)
        return await self.read_screen()

    async def open_and_type_in_app(self, app: str,
                                    text: str, save: bool = False) -> bool:
        """Abrir app, escribir texto, opcionalmente guardar."""
        ok = await self.open_app(app)
        if not ok:
            return False
        await asyncio.sleep(1.0)
        ok = await self.type_text(text)
        if save and ok:
            await self.press_hotkey('ctrl', 's')
        return ok

    async def copy_text_from_screen(self) -> str:
        """Seleccionar todo, copiar y retornar el texto de la pantalla."""
        await self.press_hotkey('ctrl', 'a')
        await asyncio.sleep(0.2)
        await self.press_hotkey('ctrl', 'c')
        await asyncio.sleep(0.2)
        return await self.get_clipboard()

    # ── ESTADO ────────────────────────────────────────────────────────────────

    def get_status(self) -> str:
        return (
            f"Computer Use Agent | "
            f"Screen: {self.screen.get_status()} | "
            f"Tareas ejecutadas: {len(self._history)}"
        )

    def get_history(self) -> List[Dict]:
        return self._history[-20:]
