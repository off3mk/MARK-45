"""
MARK 12 — File Manager
========================
Gestión directa del sistema de archivos local.
Equivalente al "Claude Cowork" — acceso, organización y procesamiento
de archivos sin que el usuario tenga que subirlos manualmente.

Capacidades:
  • Leer, escribir, mover, renombrar, eliminar archivos
  • Organizar carpetas por fecha, tipo, tamaño
  • Procesar recibos/facturas y generar reportes
  • Leer documentos: .txt, .docx, .pdf, .xlsx, .csv, .json
  • Buscar archivos por nombre, contenido, fecha
  • Comprimir/descomprimir archives
  • Renombrado masivo con patrones

Hardware: i5-9600K + 16GB RAM — sin límite de archivos
Creado por Ali (Sidi3Ali) — MARK 12
"""

import csv
import glob
import hashlib
import json
import logging
import os
import re
import shutil
import stat
import time
from datetime import datetime, timedelta
from pathlib import Path
from typing import Any, Dict, List, Optional, Tuple

logger = logging.getLogger("MARK12.FileManager")


class FileReader:
    """Lee el contenido de archivos de múltiples formatos."""

    @staticmethod
    def read(filepath: str, max_chars: int = 50_000) -> Tuple[str, str]:
        """
        Leer archivo. Retorna (contenido, error).
        max_chars limita la cantidad de texto extraído.
        """
        path = Path(filepath)
        if not path.exists():
            return "", f"Archivo no encontrado: {filepath}"

        ext = path.suffix.lower()

        try:
            # Texto plano
            if ext in {'.txt', '.md', '.py', '.js', '.ts', '.html',
                        '.css', '.json', '.yaml', '.yml', '.xml',
                        '.csv', '.log', '.ini', '.cfg', '.toml', '.sh',
                        '.bat', '.ps1', '.env', '.gitignore'}:
                with open(filepath, 'r', encoding='utf-8', errors='replace') as f:
                    return f.read()[:max_chars], ""

            # Word
            elif ext == '.docx':
                return FileReader._read_docx(filepath, max_chars)

            # PDF
            elif ext == '.pdf':
                return FileReader._read_pdf(filepath, max_chars)

            # Excel
            elif ext in {'.xlsx', '.xls'}:
                return FileReader._read_excel(filepath, max_chars)

            # CSV (ya cubierto arriba pero con procesamiento especial)
            elif ext == '.csv':
                with open(filepath, 'r', encoding='utf-8', errors='replace') as f:
                    return f.read()[:max_chars], ""

            # Imagen (solo metadatos)
            elif ext in {'.jpg', '.jpeg', '.png', '.gif', '.bmp', '.webp'}:
                size = path.stat().st_size
                return f"[Imagen: {path.name} | {size:,} bytes]", ""

            else:
                # Intentar como texto
                try:
                    with open(filepath, 'r', encoding='utf-8', errors='replace') as f:
                        return f.read()[:max_chars], ""
                except Exception:
                    size = path.stat().st_size
                    return f"[Archivo binario: {path.name} | {size:,} bytes]", ""

        except Exception as e:
            return "", str(e)

    @staticmethod
    def _read_docx(filepath: str, max_chars: int) -> Tuple[str, str]:
        try:
            from docx import Document
            doc = Document(filepath)
            text = '\n'.join(p.text for p in doc.paragraphs if p.text.strip())
            return text[:max_chars], ""
        except ImportError:
            return "", "python-docx no instalado (pip install python-docx)"
        except Exception as e:
            return "", str(e)

    @staticmethod
    def _read_pdf(filepath: str, max_chars: int) -> Tuple[str, str]:
        # Intenta pdfminer primero, luego pypdf2
        try:
            from pdfminer.high_level import extract_text
            text = extract_text(filepath)
            return (text or "")[:max_chars], ""
        except ImportError:
            pass
        try:
            import PyPDF2
            text = []
            with open(filepath, 'rb') as f:
                reader = PyPDF2.PdfReader(f)
                for page in reader.pages:
                    text.append(page.extract_text() or "")
            return '\n'.join(text)[:max_chars], ""
        except ImportError:
            return "", "PDF: instalar pdfminer.six o PyPDF2"
        except Exception as e:
            return "", str(e)

    @staticmethod
    def _read_excel(filepath: str, max_chars: int) -> Tuple[str, str]:
        try:
            import openpyxl
            wb = openpyxl.load_workbook(filepath, read_only=True, data_only=True)
            lines = []
            for sheet_name in wb.sheetnames:
                ws = wb[sheet_name]
                lines.append(f"=== Hoja: {sheet_name} ===")
                for row in ws.iter_rows(values_only=True):
                    row_str = ' | '.join(str(c or '') for c in row)
                    if row_str.strip():
                        lines.append(row_str)
                    if sum(len(l) for l in lines) > max_chars:
                        break
            wb.close()
            return '\n'.join(lines)[:max_chars], ""
        except ImportError:
            return "", "openpyxl no instalado (pip install openpyxl)"
        except Exception as e:
            return "", str(e)


class FileOrganizer:
    """Organiza carpetas automáticamente."""

    # Extensiones → categoría
    CATEGORIES = {
        'Imágenes':    {'.jpg', '.jpeg', '.png', '.gif', '.bmp', '.webp', '.svg', '.ico', '.tiff'},
        'Videos':      {'.mp4', '.avi', '.mkv', '.mov', '.wmv', '.flv', '.webm', '.m4v'},
        'Audio':       {'.mp3', '.wav', '.flac', '.aac', '.ogg', '.m4a', '.wma'},
        'Documentos':  {'.pdf', '.doc', '.docx', '.txt', '.odt', '.rtf', '.md'},
        'Hojas':       {'.xls', '.xlsx', '.csv', '.ods'},
        'Presentaciones': {'.ppt', '.pptx', '.odp'},
        'Código':      {'.py', '.js', '.ts', '.html', '.css', '.java', '.cpp', '.c',
                         '.h', '.cs', '.php', '.rb', '.go', '.rs', '.sh', '.bat'},
        'Archivos':    {'.zip', '.rar', '.7z', '.tar', '.gz', '.bz2'},
        'Ejecutables': {'.exe', '.msi', '.dmg', '.deb', '.rpm', '.apk'},
        'Datos':       {'.json', '.xml', '.yaml', '.yml', '.sql', '.db', '.sqlite'},
        'Fuentes':     {'.ttf', '.otf', '.woff', '.woff2'},
        'Torrents':    {'.torrent'},
    }

    def organize_by_type(self, folder: str,
                           dry_run: bool = False) -> Dict:
        """
        Organizar carpeta por tipo de archivo.
        dry_run=True: solo muestra qué haría sin mover nada.
        """
        folder_path = Path(folder)
        if not folder_path.exists():
            return {'error': f"Carpeta no encontrada: {folder}"}

        moved   = []
        skipped = []
        errors  = []

        for file_path in folder_path.iterdir():
            if not file_path.is_file():
                continue

            ext      = file_path.suffix.lower()
            category = self._get_category(ext)
            dest_dir = folder_path / category

            if dry_run:
                moved.append(f"{file_path.name} → {category}/")
                continue

            try:
                dest_dir.mkdir(exist_ok=True)
                dest = dest_dir / file_path.name
                # Evitar sobrescribir
                if dest.exists():
                    stem = file_path.stem
                    ts   = datetime.now().strftime('%H%M%S')
                    dest = dest_dir / f"{stem}_{ts}{ext}"
                shutil.move(str(file_path), str(dest))
                moved.append(f"{file_path.name} → {category}/")
            except Exception as e:
                errors.append(f"{file_path.name}: {e}")

        return {'moved': moved, 'skipped': skipped, 'errors': errors,
                'dry_run': dry_run}

    def organize_by_date(self, folder: str, dry_run: bool = False) -> Dict:
        """Organizar archivos en subcarpetas por fecha de modificación (YYYY/MM)."""
        folder_path = Path(folder)
        moved  = []
        errors = []

        for fp in folder_path.iterdir():
            if not fp.is_file():
                continue
            try:
                mtime    = datetime.fromtimestamp(fp.stat().st_mtime)
                dest_dir = folder_path / str(mtime.year) / f"{mtime.month:02d}"
                if not dry_run:
                    dest_dir.mkdir(parents=True, exist_ok=True)
                    dest = dest_dir / fp.name
                    if dest.exists():
                        dest = dest_dir / f"{fp.stem}_{int(time.time())}{fp.suffix}"
                    shutil.move(str(fp), str(dest))
                moved.append(f"{fp.name} → {mtime.year}/{mtime.month:02d}/")
            except Exception as e:
                errors.append(f"{fp.name}: {e}")

        return {'moved': moved, 'errors': errors, 'dry_run': dry_run}

    def bulk_rename(self, folder: str, pattern: str,
                     replacement: str, dry_run: bool = False) -> Dict:
        """
        Renombrado masivo usando regex.
        Ej: pattern='foto_(.+)', replacement='vacaciones_\\1'
        """
        folder_path = Path(folder)
        renamed = []
        errors  = []

        for fp in sorted(folder_path.iterdir()):
            if not fp.is_file():
                continue
            try:
                new_name = re.sub(pattern, replacement, fp.stem)
                new_path = fp.parent / (new_name + fp.suffix)
                if new_path == fp:
                    continue
                if not dry_run:
                    fp.rename(new_path)
                renamed.append(f"{fp.name} → {new_path.name}")
            except Exception as e:
                errors.append(f"{fp.name}: {e}")

        return {'renamed': renamed, 'errors': errors, 'dry_run': dry_run}

    def _get_category(self, ext: str) -> str:
        for category, exts in self.CATEGORIES.items():
            if ext in exts:
                return category
        return 'Otros'


class FileSearcher:
    """Búsqueda avanzada de archivos."""

    def search(self, root: str, name_pattern: str = None,
                content: str = None, ext: str = None,
                modified_after: datetime = None,
                max_results: int = 50) -> List[Dict]:
        """
        Buscar archivos con múltiples criterios.
        Retorna lista de dicts con info del archivo.
        """
        root_path = Path(root)
        results   = []

        try:
            for fp in root_path.rglob('*'):
                if not fp.is_file():
                    continue
                if len(results) >= max_results:
                    break

                # Filtro por extensión
                if ext and fp.suffix.lower() != ext.lower():
                    continue

                # Filtro por nombre
                if name_pattern:
                    if not re.search(name_pattern, fp.name, re.IGNORECASE):
                        continue

                # Filtro por fecha
                if modified_after:
                    mtime = datetime.fromtimestamp(fp.stat().st_mtime)
                    if mtime < modified_after:
                        continue

                # Filtro por contenido (solo archivos de texto)
                if content:
                    if fp.suffix.lower() in {'.txt', '.py', '.js', '.md',
                                               '.json', '.csv', '.xml'}:
                        try:
                            text = fp.read_text(encoding='utf-8', errors='replace')
                            if content.lower() not in text.lower():
                                continue
                        except Exception:
                            continue

                stat = fp.stat()
                results.append({
                    'path':     str(fp),
                    'name':     fp.name,
                    'size':     stat.st_size,
                    'size_str': self._format_size(stat.st_size),
                    'modified': datetime.fromtimestamp(stat.st_mtime).strftime('%Y-%m-%d %H:%M'),
                    'ext':      fp.suffix.lower(),
                })

        except PermissionError:
            pass
        except Exception as e:
            logger.debug(f"FileSearcher: {e}")

        return results

    def find_duplicates(self, folder: str) -> Dict[str, List[str]]:
        """Encontrar archivos duplicados por hash MD5."""
        hashes: Dict[str, List[str]] = {}
        folder_path = Path(folder)

        for fp in folder_path.rglob('*'):
            if not fp.is_file():
                continue
            try:
                h = hashlib.md5(fp.read_bytes()).hexdigest()
                if h not in hashes:
                    hashes[h] = []
                hashes[h].append(str(fp))
            except Exception:
                pass

        return {h: paths for h, paths in hashes.items() if len(paths) > 1}

    @staticmethod
    def _format_size(size: int) -> str:
        for unit in ['B', 'KB', 'MB', 'GB']:
            if size < 1024:
                return f"{size:.1f} {unit}"
            size /= 1024
        return f"{size:.1f} TB"


class ReportGenerator:
    """Genera reportes automáticos a partir de archivos locales."""

    def expenses_from_folder(self, folder: str,
                               llm_engine=None) -> Dict:
        """
        Procesar archivos de una carpeta (facturas, recibos)
        y generar reporte de gastos.
        """
        folder_path = Path(folder)
        items       = []
        total       = 0.0

        for fp in folder_path.iterdir():
            if not fp.is_file():
                continue
            ext = fp.suffix.lower()
            if ext not in {'.txt', '.pdf', '.docx', '.jpg', '.jpeg', '.png'}:
                continue

            content, err = FileReader.read(str(fp))
            if not content:
                continue

            # Extraer importes con regex
            amounts = re.findall(r'[\$€£]\s*(\d+(?:[.,]\d{2})?)', content)
            amounts += re.findall(r'(\d+(?:[.,]\d{2})?)\s*(?:€|\$|EUR|USD)', content)

            if amounts:
                for a in amounts:
                    try:
                        val = float(a.replace(',', '.'))
                        total += val
                        items.append({
                            'file':   fp.name,
                            'amount': val,
                        })
                    except ValueError:
                        pass
            elif llm_engine:
                # Usar LLM para extraer si no hay regex match
                prompt = (
                    f"Del siguiente texto de un recibo/factura, extrae "
                    f"el importe total en formato numérico simple (solo el número):\n"
                    f"{content[:500]}"
                )
                response = llm_engine.generate(prompt, with_history=False, max_tokens=50)
                try:
                    val = float(re.search(r'[\d.,]+', response).group().replace(',', '.'))
                    total += val
                    items.append({'file': fp.name, 'amount': val})
                except Exception:
                    items.append({'file': fp.name, 'amount': 0.0, 'note': 'No procesado'})

        return {
            'items':   items,
            'total':   round(total, 2),
            'count':   len(items),
            'folder':  folder,
            'date':    datetime.now().strftime('%Y-%m-%d'),
        }

    def save_report_csv(self, data: Dict, output_path: str) -> bool:
        """Guardar reporte de gastos como CSV."""
        try:
            with open(output_path, 'w', newline='', encoding='utf-8') as f:
                writer = csv.DictWriter(f, fieldnames=['file', 'amount', 'note'])
                writer.writeheader()
                writer.writerows(data.get('items', []))
                f.write(f"\nTOTAL,{data.get('total', 0)}\n")
            return True
        except Exception as e:
            logger.error(f"save_report_csv: {e}")
            return False


class FileManager:
    """
    Gestor de archivos principal de MARK 12.
    Punto de entrada unificado para todas las operaciones de archivos.
    """

    def __init__(self, llm_engine=None):
        self.reader    = FileReader()
        self.organizer = FileOrganizer()
        self.searcher  = FileSearcher()
        self.reporter  = ReportGenerator()
        self.llm       = llm_engine

    # ── LECTURA ───────────────────────────────────────────────────────────────

    def read_file(self, path: str) -> str:
        """Leer y retornar contenido de un archivo."""
        content, err = FileReader.read(path)
        if err:
            return f"Error: {err}"
        return content or "(Archivo vacío)"

    def read_and_analyze(self, path: str) -> str:
        """Leer archivo y analizarlo con LLM."""
        content, err = FileReader.read(path)
        if err:
            return f"Error leyendo {path}: {err}"
        if not content:
            return "Archivo vacío."
        if not self.llm:
            return f"Contenido de {Path(path).name}:\n\n{content[:2000]}"

        prompt = (
            f"Analiza este archivo '{Path(path).name}'.\n"
            f"Tipo: {Path(path).suffix}\n"
            f"Contenido:\n{content[:4000]}\n\n"
            f"Proporciona: 1) Resumen de qué es, 2) Puntos clave, "
            f"3) Cualquier problema o dato importante que detectes."
        )
        return self.llm.generate(prompt, with_history=False, max_tokens=600)

    # ── ESCRITURA ─────────────────────────────────────────────────────────────

    def write_file(self, path: str, content: str,
                    mode: str = 'w') -> str:
        """Crear o sobreescribir archivo."""
        try:
            Path(path).parent.mkdir(parents=True, exist_ok=True)
            with open(path, mode, encoding='utf-8') as f:
                f.write(content)
            return f"Archivo guardado: {path}"
        except Exception as e:
            return f"Error: {e}"

    def append_to_file(self, path: str, content: str) -> str:
        return self.write_file(path, content, mode='a')

    # ── OPERACIONES ───────────────────────────────────────────────────────────

    def copy(self, src: str, dst: str) -> str:
        try:
            Path(dst).parent.mkdir(parents=True, exist_ok=True)
            shutil.copy2(src, dst)
            return f"Copiado: {src} → {dst}"
        except Exception as e:
            return f"Error: {e}"

    def move(self, src: str, dst: str) -> str:
        try:
            Path(dst).parent.mkdir(parents=True, exist_ok=True)
            shutil.move(src, dst)
            return f"Movido: {src} → {dst}"
        except Exception as e:
            return f"Error: {e}"

    def delete(self, path: str, to_trash: bool = True) -> str:
        """Eliminar archivo (con papelera si es posible)."""
        try:
            p = Path(path)
            if not p.exists():
                return f"No existe: {path}"
            if p.is_dir():
                shutil.rmtree(path)
                return f"Carpeta eliminada: {path}"
            os.remove(path)
            return f"Eliminado: {path}"
        except Exception as e:
            return f"Error: {e}"

    def create_folder(self, path: str) -> str:
        try:
            Path(path).mkdir(parents=True, exist_ok=True)
            return f"Carpeta creada: {path}"
        except Exception as e:
            return f"Error: {e}"

    def list_folder(self, path: str = None, show_hidden: bool = False) -> str:
        """Listar contenido de una carpeta."""
        folder = Path(path or os.path.expanduser('~'))
        if not folder.exists():
            return f"No existe: {path}"

        items = []
        try:
            for item in sorted(folder.iterdir(),
                                 key=lambda x: (x.is_file(), x.name.lower())):
                if not show_hidden and item.name.startswith('.'):
                    continue
                if item.is_dir():
                    items.append(f"📁 {item.name}/")
                else:
                    size = FileSearcher._format_size(item.stat().st_size)
                    items.append(f"📄 {item.name} ({size})")
        except PermissionError:
            return f"Sin permisos para leer: {path}"

        header = f"📂 {folder}\n{'─' * 40}\n"
        return header + '\n'.join(items) if items else header + "(Vacío)"

    # ── ORGANIZACIÓN ──────────────────────────────────────────────────────────

    def organize_downloads(self, dry_run: bool = False) -> str:
        """Organizar la carpeta Descargas por tipo."""
        downloads = os.path.expanduser('~/Downloads')
        if not os.path.exists(downloads):
            downloads = os.path.expanduser('~/Descargas')
        if not os.path.exists(downloads):
            return "No encontré la carpeta de Descargas."

        result = self.organizer.organize_by_type(downloads, dry_run)
        moved  = result.get('moved', [])
        errors = result.get('errors', [])

        summary = f"{'[Simulación] ' if dry_run else ''}Organizar Descargas:\n"
        summary += f"  Movidos: {len(moved)}\n"
        if moved[:5]:
            for m in moved[:5]:
                summary += f"    • {m}\n"
            if len(moved) > 5:
                summary += f"    ... y {len(moved)-5} más\n"
        if errors:
            summary += f"  Errores: {len(errors)}\n"
        return summary.strip()

    # ── BÚSQUEDA ──────────────────────────────────────────────────────────────

    def search_files(self, root: str = None, query: str = "",
                      ext: str = None, days_ago: int = None) -> str:
        """Buscar archivos y devolver resumen."""
        root = root or os.path.expanduser('~')
        modified_after = None
        if days_ago:
            modified_after = datetime.now() - timedelta(days=days_ago)

        results = self.searcher.search(
            root, name_pattern=query, ext=ext,
            modified_after=modified_after, max_results=30
        )

        if not results:
            return f"Sin resultados para '{query}' en {root}"

        lines = [f"Encontrados {len(results)} archivo(s):"]
        for r in results[:15]:
            lines.append(f"  📄 {r['name']} | {r['size_str']} | {r['modified']}")
        if len(results) > 15:
            lines.append(f"  ... y {len(results)-15} más")
        return '\n'.join(lines)

    # ── REPORTES ──────────────────────────────────────────────────────────────

    def generate_expense_report(self, folder: str,
                                  output: str = None) -> str:
        """Generar reporte de gastos de una carpeta."""
        data = self.reporter.expenses_from_folder(folder, self.llm)
        if not data['items']:
            return f"No encontré importes en los archivos de {folder}"

        summary = f"Reporte de gastos — {data['date']}\n"
        summary += f"Carpeta: {folder}\n"
        summary += f"Archivos procesados: {data['count']}\n"
        summary += f"─────────────────────\n"
        for item in data['items']:
            summary += f"  {item['file']}: {item['amount']:.2f}\n"
        summary += f"─────────────────────\n"
        summary += f"TOTAL: {data['total']:.2f}\n"

        if output:
            if self.reporter.save_report_csv(data, output):
                summary += f"\nGuardado en: {output}"

        return summary

    # ── COMPRESIÓN ────────────────────────────────────────────────────────────

    def compress(self, source: str, output: str = None) -> str:
        """Comprimir archivo o carpeta en ZIP."""
        try:
            import zipfile
            source_path = Path(source)
            output = output or str(source_path.parent / f"{source_path.stem}.zip")

            with zipfile.ZipFile(output, 'w', zipfile.ZIP_DEFLATED) as zf:
                if source_path.is_dir():
                    for fp in source_path.rglob('*'):
                        zf.write(fp, fp.relative_to(source_path.parent))
                else:
                    zf.write(source_path, source_path.name)

            size = FileSearcher._format_size(Path(output).stat().st_size)
            return f"Comprimido: {output} ({size})"
        except Exception as e:
            return f"Error comprimiendo: {e}"

    def extract(self, archive: str, dest: str = None) -> str:
        """Descomprimir archivo ZIP."""
        try:
            import zipfile
            dest = dest or str(Path(archive).parent)
            with zipfile.ZipFile(archive, 'r') as zf:
                zf.extractall(dest)
            return f"Extraído en: {dest}"
        except Exception as e:
            return f"Error extrayendo: {e}"

    # ── INFO ──────────────────────────────────────────────────────────────────

    def get_file_info(self, path: str) -> str:
        """Información detallada de un archivo."""
        p = Path(path)
        if not p.exists():
            return f"No existe: {path}"
        try:
            s = p.stat()
            return (
                f"Archivo: {p.name}\n"
                f"Ruta:    {p}\n"
                f"Tipo:    {p.suffix or 'sin extensión'}\n"
                f"Tamaño:  {FileSearcher._format_size(s.st_size)}\n"
                f"Creado:  {datetime.fromtimestamp(s.st_ctime).strftime('%Y-%m-%d %H:%M')}\n"
                f"Modificado: {datetime.fromtimestamp(s.st_mtime).strftime('%Y-%m-%d %H:%M')}\n"
            )
        except Exception as e:
            return f"Error: {e}"

    def disk_usage(self, path: str = None) -> str:
        """Uso del disco."""
        path = path or os.path.expanduser('~')
        try:
            usage = shutil.disk_usage(path)
            total = FileSearcher._format_size(usage.total)
            used  = FileSearcher._format_size(usage.used)
            free  = FileSearcher._format_size(usage.free)
            pct   = (usage.used / usage.total) * 100
            return f"Disco: {used} usados / {total} total ({pct:.1f}%) | Libre: {free}"
        except Exception as e:
            return f"Error: {e}"
