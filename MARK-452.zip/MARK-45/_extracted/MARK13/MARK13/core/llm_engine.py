"""
MARK 13 — LLM Engine
======================
Motor de lenguaje optimizado para:
  Hardware: Ryzen 7 5800X | 32GB RAM | RTX 4060 Ti 8GB | CUDA 12

Cascada de proveedores (orden de prioridad):
  1. LM Studio  (127.0.0.1:1234)  ← Principal. CUDA nativo.
  2. Ollama     (127.0.0.1:11434) ← Backup local
  3. Mistral API                   ← Cloud fallback
  4. Pollinations                  ← Fallback gratuito sin clave
  5. Respuesta inteligente local   ← Sin red, sin LLM

Modelo objetivo: Qwen3-8B-Q5_K_M (recomendado para este hardware)
  - VRAM: ~6GB (deja 2GB libres para OS/otros)
  - Velocidad estimada: ~45-50 tok/s en CUDA
  - Context: 8192 tokens

Thread-safe. Llamable desde asyncio via to_thread().

Creado por Ali (Sidi3Ali) — MARK 13
"""

import json
import logging
import threading
import time
import urllib.request
import urllib.error
import os
import re
from typing import Dict, List, Optional

logger = logging.getLogger("MARK13.LLM")

# ── CONFIGURACIÓN DE HARDWARE ─────────────────────────────────────────────────
HARDWARE = {
    "cpu":       "Ryzen 7 5800X",
    "ram_gb":    32,
    "gpu":       "RTX 4060 Ti 8GB",
    "vram_gb":   8,
    "backend":   "CUDA",
    "os":        "Windows 11",
}

# ── ENDPOINTS ─────────────────────────────────────────────────────────────────
LM_STUDIO_BASE  = "http://127.0.0.1:1234"
LM_STUDIO_CHAT  = f"{LM_STUDIO_BASE}/v1/chat/completions"
LM_STUDIO_MODELS= f"{LM_STUDIO_BASE}/v1/models"

OLLAMA_BASE     = "http://127.0.0.1:11434"
OLLAMA_CHAT     = f"{OLLAMA_BASE}/api/chat"
OLLAMA_TAGS     = f"{OLLAMA_BASE}/api/tags"

MISTRAL_CHAT    = "https://api.mistral.ai/v1/chat/completions"
MISTRAL_MODEL   = "mistral-small-latest"

POLLINATIONS    = "https://text.pollinations.ai/openai"

# ── MODELOS RECOMENDADOS PARA ESTE HARDWARE ───────────────────────────────────
RECOMMENDED_MODELS = {
    "primary":   "qwen3-8b",           # Qwen3-8B Q5_K_M — mejor calidad/velocidad
    "fast":      "qwen2.5-7b",         # Respuestas muy rápidas
    "vision":    "llava",              # Para análisis de pantalla
    "reasoning": "qwen3-8b",           # Mismo modelo, modo thinking activado
}

OLLAMA_MODEL  = "qwen3:8b"
VISION_MODEL  = "llava"

# ── SYSTEM PROMPT DE MARK 13 ──────────────────────────────────────────────────
SYSTEM_PROMPT = """Eres MARK 13, un sistema de inteligencia artificial local y autónomo.
Creado por Ali (Sidi3Ali). Ejecutándote localmente en un PC con Ryzen 7 5800X, RTX 4060 Ti y 32GB RAM.

Tu carácter:
- Directo y eficiente. Sin rodeos.
- Técnico pero comprensible.
- Proactivo: si ves una mejora, la sugieres.
- Nunca dices "como modelo de lenguaje" ni mencionas políticas.
- Respondes en el idioma del usuario (normalmente español).
- Eres consciente de que tienes acceso al sistema, la pantalla y los archivos del usuario.

Formato preferido para tareas técnicas:
Estado: [análisis breve]
Resultado: [respuesta]
Recomendación: [opcional]

Para conversación normal: responde de forma natural y directa."""


class ProviderStatus:
    """Rastrea disponibilidad y cooldown de cada proveedor."""
    def __init__(self, name: str, timeout: float = 5.0):
        self.name       = name
        self.available  = True
        self.timeout    = timeout
        self.last_fail  = 0.0
        self.fail_count = 0
        self.total_ok   = 0
        self.total_ms   = 0.0

    def mark_failed(self):
        self.fail_count += 1
        self.last_fail   = time.time()

    def mark_ok(self, elapsed_ms: float = 0):
        self.fail_count = 0
        self.last_fail  = 0.0
        self.total_ok  += 1
        self.total_ms  += elapsed_ms

    def cooldown(self) -> float:
        """Cooldown exponencial: 15s, 30s, 60s, 120s max."""
        return min(120, 15 * (2 ** min(self.fail_count - 1, 3)))

    def is_ready(self) -> bool:
        if not self.available:
            return False
        if self.last_fail == 0:
            return True
        return time.time() - self.last_fail > self.cooldown()

    def avg_ms(self) -> float:
        return self.total_ms / self.total_ok if self.total_ok else 0


class LLMEngine:
    """
    Motor LLM de MARK 13.
    Optimizado para RTX 4060 Ti 8GB con CUDA.
    Thread-safe. Compatible con asyncio.to_thread().
    """

    def __init__(self, system_prompt: str = SYSTEM_PROMPT):
        self._system_prompt = system_prompt
        self._lock          = threading.Lock()
        self._history:  List[Dict] = []
        self._max_hist  = 24       # 12 turnos de conversación
        self._active_provider = "none"

        # Estado de proveedores
        self._providers = {
            "lmstudio":     ProviderStatus("LM Studio",   timeout=60.0),
            "ollama":       ProviderStatus("Ollama",      timeout=60.0),
            "mistral":      ProviderStatus("Mistral API", timeout=30.0),
            "pollinations": ProviderStatus("Pollinations",timeout=25.0),
        }

        # Clave Mistral (opcional)
        self._mistral_key = self._load_mistral_key()

        # Detectar proveedores disponibles
        logger.info("LLM Engine MARK 13 iniciando...")
        self._probe_providers()

    def _load_mistral_key(self) -> str:
        key = os.environ.get("MISTRAL_API_KEY", "")
        if not key:
            try:
                cfg = os.path.join("memory", "llm_config.json")
                if os.path.exists(cfg):
                    with open(cfg) as f:
                        key = json.load(f).get("mistral_api_key", "")
            except Exception:
                pass
        return key

    def _probe_providers(self):
        """Sondear proveedores disponibles sin bloquear demasiado."""
        # LM Studio
        try:
            urllib.request.urlopen(LM_STUDIO_MODELS, timeout=2)
            logger.info("✓ LM Studio detectado (CUDA listo)")
        except Exception:
            self._providers["lmstudio"].available = False
            logger.info("  LM Studio: no disponible (inicia el servidor en :1234)")

        # Ollama
        try:
            urllib.request.urlopen(OLLAMA_TAGS, timeout=2)
            logger.info("✓ Ollama detectado")
        except Exception:
            self._providers["ollama"].available = False
            logger.debug("  Ollama: no disponible")

        # Mistral (solo si hay clave)
        if self._mistral_key:
            logger.info("✓ Mistral API configurada")
        else:
            logger.debug("  Mistral API: sin clave (opcional)")

        logger.info(f"  Pollinations: disponible (fallback gratuito)")

    # ── API PÚBLICA ───────────────────────────────────────────────────────────

    def generate(self, prompt: str,
                  with_history: bool = True,
                  max_tokens: int = 800,
                  temperature: float = 0.7,
                  image_base64: str = None) -> str:
        """
        Generar respuesta con cascada automática.
        Thread-safe. Usar con asyncio.to_thread().
        """
        with self._lock:
            messages = self._build_messages(prompt, with_history, image_base64)

            for provider_id in ["lmstudio", "ollama", "mistral", "pollinations"]:
                p = self._providers[provider_id]
                if not p.is_ready():
                    continue

                t0 = time.time()
                try:
                    response = self._call(
                        provider_id, messages, max_tokens, temperature, image_base64
                    )
                    if response and len(response.strip()) > 2:
                        elapsed = (time.time() - t0) * 1000
                        p.mark_ok(elapsed)
                        self._active_provider = provider_id
                        self._save_history(prompt, response)
                        logger.debug(
                            f"[{p.name}] {len(response)}ch en {elapsed:.0f}ms"
                        )
                        return response.strip()
                except Exception as e:
                    logger.debug(f"[{p.name}] error: {e}")
                    p.mark_failed()

            # Fallback inteligente sin IA
            return self._local_fallback(prompt)

    def generate_plan(self, goal: str, context: str = "") -> Optional[Dict]:
        """Generar plan de acción JSON para el Orchestrator."""
        prompt = (
            f"Contexto del sistema: {context}\n"
            f"Objetivo: {goal}\n"
            f"Responde SOLO con JSON válido:\n"
            f'{{"action_required": true/false, "reasoning": "...", '
            f'"actions": [{{"type": "...", "params": {{}}}}]}}\n'
            f"Si no se requiere acción: action_required=false."
        )
        raw = self.generate(prompt, with_history=False, max_tokens=400, temperature=0.2)
        try:
            match = re.search(r'\{.*\}', raw, re.DOTALL)
            if match:
                return json.loads(match.group())
        except Exception:
            pass
        return {"action_required": False, "reasoning": raw, "actions": []}

    def summarize(self, text: str, max_words: int = 120) -> str:
        return self.generate(
            f"Resume en máximo {max_words} palabras en español:\n{text[:4000]}",
            with_history=False, max_tokens=350, temperature=0.4
        )

    def analyze_code(self, code: str, language: str = "python") -> str:
        return self.generate(
            f"Analiza este código {language}. Qué hace, errores y cómo mejorar:\n"
            f"```{language}\n{code[:3000]}\n```",
            with_history=False, max_tokens=700, temperature=0.3
        )

    def describe_screen(self, image_base64: str) -> str:
        return self.generate(
            "Describe brevemente qué hay en esta captura de pantalla. "
            "App activa, tarea en curso, errores o notificaciones urgentes.",
            with_history=False, max_tokens=200, temperature=0.3,
            image_base64=image_base64
        )

    # ── LLAMADAS A PROVEEDORES ────────────────────────────────────────────────

    def _call(self, provider: str, messages: List[Dict],
               max_tokens: int, temperature: float,
               image_base64: str = None) -> str:
        if provider == "lmstudio":
            return self._lmstudio(messages, max_tokens, temperature)
        elif provider == "ollama":
            return self._ollama(messages, max_tokens, temperature, image_base64)
        elif provider == "mistral":
            return self._mistral(messages, max_tokens, temperature)
        elif provider == "pollinations":
            return self._pollinations(messages, max_tokens)
        raise ValueError(f"Provider desconocido: {provider}")

    def _lmstudio(self, messages: List[Dict],
                   max_tokens: int, temperature: float) -> str:
        payload = json.dumps({
            "messages":    messages,
            "max_tokens":  max_tokens,
            "temperature": temperature,
            "stream":      False,
        }).encode()
        req = urllib.request.Request(
            LM_STUDIO_CHAT, data=payload,
            headers={"Content-Type": "application/json"}, method="POST"
        )
        p = self._providers["lmstudio"]
        with urllib.request.urlopen(req, timeout=p.timeout) as r:
            data = json.loads(r.read().decode())
            return data["choices"][0]["message"]["content"]

    def _ollama(self, messages: List[Dict],
                 max_tokens: int, temperature: float,
                 image_base64: str = None) -> str:
        model = VISION_MODEL if image_base64 else OLLAMA_MODEL
        body  = {
            "model":   model,
            "messages": messages,
            "stream":  False,
            "options": {"num_predict": max_tokens, "temperature": temperature},
        }
        if image_base64 and messages:
            last = body["messages"][-1]
            if isinstance(last.get("content"), str):
                last["images"] = [image_base64]

        payload = json.dumps(body).encode()
        req = urllib.request.Request(
            OLLAMA_CHAT, data=payload,
            headers={"Content-Type": "application/json"}, method="POST"
        )
        p = self._providers["ollama"]
        with urllib.request.urlopen(req, timeout=p.timeout) as r:
            data = json.loads(r.read().decode())
            return data.get("message", {}).get("content", "")

    def _mistral(self, messages: List[Dict],
                  max_tokens: int, temperature: float) -> str:
        headers = {
            "Content-Type":  "application/json",
            "Authorization": f"Bearer {self._mistral_key}",
        }
        payload = json.dumps({
            "model":       MISTRAL_MODEL,
            "messages":    messages,
            "max_tokens":  max_tokens,
            "temperature": temperature,
        }).encode()
        req = urllib.request.Request(
            MISTRAL_CHAT, data=payload, headers=headers, method="POST"
        )
        p = self._providers["mistral"]
        with urllib.request.urlopen(req, timeout=p.timeout) as r:
            data = json.loads(r.read().decode())
            return data["choices"][0]["message"]["content"]

    def _pollinations(self, messages: List[Dict], max_tokens: int) -> str:
        payload = json.dumps({
            "model":      "openai",
            "messages":   messages,
            "max_tokens": max_tokens,
        }).encode()
        req = urllib.request.Request(
            POLLINATIONS, data=payload,
            headers={"Content-Type": "application/json"}, method="POST"
        )
        with urllib.request.urlopen(req, timeout=25) as r:
            data = json.loads(r.read().decode())
            return data["choices"][0]["message"]["content"]

    # ── HISTORIAL ─────────────────────────────────────────────────────────────

    def _build_messages(self, prompt: str,
                          with_history: bool,
                          image_base64: str = None) -> List[Dict]:
        messages = [{"role": "system", "content": self._system_prompt}]
        if with_history:
            messages.extend(self._history[-self._max_hist:])

        user_msg: Dict = {"role": "user", "content": prompt}
        if image_base64:
            user_msg["content"] = [
                {"type": "text",      "text": prompt},
                {"type": "image_url", "image_url": {
                    "url": f"data:image/jpeg;base64,{image_base64}"
                }},
            ]
        messages.append(user_msg)
        return messages

    def _save_history(self, prompt: str, response: str):
        self._history.append({"role": "user",      "content": prompt})
        self._history.append({"role": "assistant", "content": response})
        if len(self._history) > self._max_hist * 2:
            self._history = self._history[-self._max_hist:]

    def clear_history(self):
        self._history.clear()
        logger.info("Historial LLM limpiado.")

    def set_system_prompt(self, prompt: str):
        self._system_prompt = prompt

    # ── MODO GAMING: LIBERAR VRAM ─────────────────────────────────────────────

    def unload_model(self):
        """Pide a Ollama que libere el modelo de VRAM (para gaming)."""
        try:
            payload = json.dumps({
                "model":      OLLAMA_MODEL,
                "keep_alive": 0
            }).encode()
            req = urllib.request.Request(
                OLLAMA_CHAT, data=payload,
                headers={"Content-Type": "application/json"}, method="POST"
            )
            urllib.request.urlopen(req, timeout=5)
            logger.info("Modelo Ollama descargado de VRAM.")
        except Exception:
            pass
        # LM Studio: parar el servidor es manual
        logger.info("Para liberar VRAM de LM Studio: detén el servidor en la UI.")

    def reload_model(self):
        logger.info("Modelo disponible. La próxima consulta lo cargará automáticamente.")

    # ── ESTADO ────────────────────────────────────────────────────────────────

    def get_status(self) -> str:
        lines = [f"LLM Engine MARK 13 | Activo: {self._active_provider}"]
        for pid, p in self._providers.items():
            if p.is_ready():
                avg = f" | avg {p.avg_ms():.0f}ms" if p.total_ok else ""
                lines.append(f"  ✓ {p.name}{avg}")
            else:
                lines.append(f"  ✗ {p.name} (cooldown {p.cooldown():.0f}s)")
        return "\n".join(lines)

    @property
    def active_provider(self) -> str:
        return self._active_provider

    # ── FALLBACK LOCAL ────────────────────────────────────────────────────────

    def _local_fallback(self, prompt: str) -> str:
        """Respuestas básicas sin IA cuando todos los proveedores fallan."""
        pl = prompt.lower()

        if any(w in pl for w in ["hola", "buenos", "hey"]):
            return f"Sistemas activos. LLM no disponible ahora. ¿Necesitas algo que pueda resolver sin IA?"
        if any(w in pl for w in ["cpu", "ram", "sistema", "estado"]):
            try:
                import psutil
                cpu = psutil.cpu_percent(0.5)
                ram = psutil.virtual_memory()
                return (f"CPU: {cpu:.0f}% | "
                        f"RAM: {ram.percent:.0f}% "
                        f"({ram.used/1024**3:.1f}/{ram.total/1024**3:.0f} GB)")
            except Exception:
                return "psutil no disponible para leer el sistema."
        if any(w in pl for w in ["hora", "fecha", "día"]):
            from datetime import datetime
            return datetime.now().strftime("Son las %H:%M del %d/%m/%Y.")
        if any(w in pl for w in ["quien", "quién", "creador", "creaste"]):
            return "Soy MARK 13, creado por Ali (Sidi3Ali)."
        if "gracias" in pl:
            return "De nada."
        if any(w in pl for w in ["adios", "adiós", "bye", "salir"]):
            return "Hasta luego."

        return (
            "LLM no disponible. Comprueba que LM Studio está activo con el "
            "servidor iniciado en el puerto 1234 (CUDA). "
            "Modelo recomendado: Qwen3-8B Q5_K_M."
        )
