"""
MARK 13 — Cognitive Loop (OODA)
=================================
Bucle cognitivo autónomo: Observe → Orient → Decide → Act

Optimizado para Ryzen 7 5800X (8C/16T) — puede correr análisis
cognitivo profundo sin impactar el rendimiento del sistema.

Con 32GB RAM se mantiene historial cognitivo largo.

Creado por Ali (Sidi3Ali) — MARK 13
"""

import logging
import time
from collections import deque
from dataclasses import dataclass, field
from datetime import datetime
from typing import Any, Dict, List, Optional

logger = logging.getLogger("MARK13.OODA")


@dataclass
class SystemState:
    """Estado cognitivo completo del sistema."""
    # Hardware
    cpu_percent:    float = 0.0
    ram_percent:    float = 0.0
    ram_used_gb:    float = 0.0
    ram_total_gb:   float = 32.0   # Hardware conocido
    disk_percent:   float = 0.0
    gpu_vram_pct:   float = 0.0    # RTX 4060 Ti 8GB

    # Contexto
    active_app:     str = ""
    active_window:  str = ""
    user_idle_secs: int = 0
    gaming_mode:    bool = False
    game_name:      str = ""
    is_working:     bool = False

    # Identidad
    user_name:      str = "Señor"
    is_creator:     bool = False

    # Historial — 32GB permite historial largo
    command_history: deque = field(default_factory=lambda: deque(maxlen=50))
    recent_alerts:   List[str] = field(default_factory=list)
    recent_actions:  List[str] = field(default_factory=list)

    last_command:   str = ""
    last_response:  str = ""
    updated_at:     str = ""

    def update_ts(self):
        self.updated_at = datetime.now().isoformat()

    def is_stressed(self) -> bool:
        return self.cpu_percent > 85 or self.ram_percent > 88

    def context_summary(self) -> str:
        parts = [
            f"CPU:{self.cpu_percent:.0f}%",
            f"RAM:{self.ram_percent:.0f}%({self.ram_used_gb:.1f}/{self.ram_total_gb:.0f}GB)",
        ]
        if self.gaming_mode:
            parts.append(f"🎮{self.game_name or 'gaming'}")
        if self.active_app:
            parts.append(f"App:{self.active_app[:20]}")
        if self.user_idle_secs > 120:
            parts.append(f"Idle:{self.user_idle_secs//60}m")
        return " | ".join(parts)


class GoalStack:
    """Pila de objetivos cognitivos (LIFO por prioridad)."""

    def __init__(self):
        self._goals: List[Dict] = []

    def push(self, goal: str, priority: int = 5, context: Dict = None):
        self._goals.append({
            "goal":     goal,
            "priority": priority,
            "context":  context or {},
            "ts":       datetime.now().isoformat(),
        })
        self._goals.sort(key=lambda x: x["priority"])

    def pop(self) -> Optional[Dict]:
        return self._goals.pop(0) if self._goals else None

    def peek(self) -> Optional[Dict]:
        return self._goals[0] if self._goals else None

    def __len__(self): return len(self._goals)
    def is_empty(self): return len(self._goals) == 0
    def clear(self): self._goals.clear()


class OODALoop:
    """
    Bucle OODA de MARK 13.
    Ryzen 7 5800X permite ciclos más frecuentes sin impacto en FPS.
    """

    RULES = [
        {
            "id":        "gaming",
            "condition": lambda s: s.gaming_mode,
            "action":    {"type": "noop", "reason": "gaming_mode"},
            "priority":  1,
            "cooldown":  60,
        },
        {
            "id":        "cpu_critical",
            "condition": lambda s: s.cpu_percent > 92 and not s.gaming_mode,
            "action":    {"type": "alert", "level": "warning",
                          "msg": "CPU al límite. Considera cerrar apps pesadas."},
            "priority":  2,
            "cooldown":  120,
        },
        {
            "id":        "ram_critical",
            "condition": lambda s: s.ram_percent > 88 and not s.gaming_mode,
            "action":    {"type": "alert", "level": "warning",
                          "msg": "RAM alta. Cerrando procesos innecesarios mejoraría el rendimiento."},
            "priority":  2,
            "cooldown":  120,
        },
        {
            "id":        "user_idle_long",
            "condition": lambda s: s.user_idle_secs > 600 and not s.gaming_mode,
            "action":    {"type": "proactive",
                          "msg": "Usuario inactivo más de 10 minutos."},
            "priority":  8,
            "cooldown":  600,
        },
    ]

    def __init__(self):
        self.state  = SystemState()
        self.goals  = GoalStack()
        self._last: Dict[str, float] = {}

    def observe(self, raw: Dict) -> SystemState:
        """OBSERVE: Actualizar estado con datos del monitor."""
        for key in ["cpu_percent", "ram_percent", "ram_used_gb",
                     "disk_percent", "active_app", "active_window",
                     "user_idle_secs", "gaming_mode", "game_name",
                     "is_working", "user_name", "is_creator"]:
            if key in raw:
                setattr(self.state, key, raw[key])
        self.state.update_ts()
        return self.state

    def orient(self) -> Dict:
        """ORIENT: Interpretar el estado observado."""
        return {
            "stressed":  self.state.is_stressed(),
            "gaming":    self.state.gaming_mode,
            "context":   self.state.context_summary(),
            "alerts":    self._get_alerts(),
            "goal":      self.goals.peek(),
        }

    def _get_alerts(self) -> List[str]:
        alerts = []
        if self.state.cpu_percent > 85:
            alerts.append(f"CPU alta: {self.state.cpu_percent:.0f}%")
        if self.state.ram_percent > 85:
            alerts.append(f"RAM alta: {self.state.ram_percent:.0f}%")
        return alerts

    def decide(self, analysis: Dict) -> Optional[Dict]:
        """DECIDE: Elegir acción según reglas con cooldown."""
        now = time.time()
        for rule in self.RULES:
            rid = rule["id"]
            if now - self._last.get(rid, 0) < rule["cooldown"]:
                continue
            try:
                if rule["condition"](self.state):
                    self._last[rid] = now
                    action = dict(rule["action"])
                    action["rule_id"] = rid
                    action["context"] = self.state.context_summary()
                    logger.debug(f"OODA decide: {rid} → {action['type']}")
                    return action
            except Exception as e:
                logger.debug(f"Regla {rid}: {e}")
        return None

    def act_result(self, action: Dict, result: Any):
        ts = datetime.now().strftime("%H:%M:%S")
        self.state.recent_actions.append(
            f"[{ts}] {action.get('type')}: {action.get('msg', '')}"
        )
        if len(self.state.recent_actions) > 30:
            self.state.recent_actions.pop(0)

    def process_user_command(self, cmd: str):
        self.state.last_command = cmd
        self.state.command_history.append({
            "cmd":  cmd,
            "time": datetime.now().strftime("%H:%M:%S"),
        })

    def add_goal(self, goal: str, priority: int = 5, ctx: Dict = None):
        self.goals.push(goal, priority, ctx)

    def get_summary(self) -> str:
        return (
            f"OODA | {self.state.context_summary()} | "
            f"Goals:{len(self.goals)} | "
            f"Último cmd: {self.state.last_command or 'ninguno'}"
        )
