@echo off
title JARVIS v7.0 — Instalación
color 0A
echo.
echo  ============================================
echo   J.A.R.V.I.S v7.0 — Instalando dependencias
echo   Creado por Ali (Sidi3Ali)
echo  ============================================
echo.

pip install --upgrade pip
pip install psutil pyautogui pygetwindow pynput
pip install edge-tts pyttsx3 SpeechRecognition
pip install spotipy
pip install uiautomation pywin32
pip install Pillow mss requests
pip install pygame

echo.
echo  [OPCIONAL] Instalar soporte avanzado:
echo   pip install opencv-python pytesseract
echo   pip install pyaudio
echo   pip install python-docx openpyxl
echo   pip install pycaw comtypes
echo.
echo  Instalacion completada. Ejecuta start.bat para iniciar JARVIS v7.0
pause
