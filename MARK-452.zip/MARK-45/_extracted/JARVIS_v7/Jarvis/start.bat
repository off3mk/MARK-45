@echo off
title JARVIS v7.0 — Ali (Sidi3Ali)
color 0B
echo.
echo  ============================================
echo   J.A.R.V.I.S v7.0 — Iniciando...
echo   Creado por Ali (Sidi3Ali)
echo  ============================================
echo.
cd /d "%~dp0"
python main.py %*
pause
