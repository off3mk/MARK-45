#!/usr/bin/env python3
"""
J.A.R.V.I.S MARK 5 - Sistema de Asistencia Avanzado
Punto de entrada principal del sistema
"""

import sys
import os
import argparse
import logging
import threading
import time

# Add project root to path
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

# Create required directories
for d in ['workspace', 'memory', 'cache', 'logs', 'skills/generated', 'models/local_models']:
    os.makedirs(d, exist_ok=True)

# Setup logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s [%(name)s] %(levelname)s: %(message)s',
    handlers=[
        logging.FileHandler('logs/jarvis.log', encoding='utf-8'),
        logging.StreamHandler(sys.stdout)
    ]
)
logger = logging.getLogger('JARVIS.Main')


def start_gui_mode():
    """Iniciar JARVIS con interfaz gráfica."""
    try:
        from ui.interface import JarvisInterface
        from core.brain import JarvisBrain

        brain = JarvisBrain()
        brain.initialize()

        app = JarvisInterface(brain)
        app.run()

    except ImportError as e:
        logger.error(f"Error importando módulos GUI: {e}")
        logger.info("Iniciando en modo CLI como fallback...")
        start_cli_mode()
    except Exception as e:
        logger.error(f"Error fatal en modo GUI: {e}")
        sys.exit(1)


def start_cli_mode():
    """Iniciar JARVIS en modo consola."""
    try:
        from core.brain import JarvisBrain

        brain = JarvisBrain()
        brain.initialize()

        print("\n" + "="*60)
        print("     J.A.R.V.I.S v7.0 — Sistema Activo")
        print("     Creado por Ali (Sidi3Ali)")
        print("="*60)
        print("Sistema iniciado. Escriba 'salir' para terminar.\n")

        # Saludo de inicio personalizado
        try:
            from core.startup_manager import StartupManager
            sm = brain.startup_manager or StartupManager(brain=brain)
            sm.perform_startup_greeting()
        except Exception:
            brain.speak("Sistema JARVIS versión 7 en línea. A sus órdenes.")

        while True:
            try:
                user_input = input("Señor > ").strip()
                if not user_input:
                    continue
                if user_input.lower() in ['salir', 'exit', 'quit', 'apagar']:
                    farewell = "Hasta luego, Ali. Sistema desconectándose."
                    if brain.user_identity:
                        name = brain.user_identity.get_preferred_name()
                        farewell = f"Hasta luego, {name}. Sistema desconectándose."
                    brain.speak(farewell)
                    break

                response = brain.process_command(user_input)
                if response:
                    print(f"\nJARVIS > {response}\n")

            except KeyboardInterrupt:
                print("\nSistema interrumpido.")
                break
            except Exception as e:
                logger.error(f"Error procesando comando: {e}")

    except Exception as e:
        logger.error(f"Error fatal en modo CLI: {e}")
        sys.exit(1)


def main():
    parser = argparse.ArgumentParser(description='J.A.R.V.I.S MARK 5 - Sistema de Asistencia Avanzado')
    parser.add_argument('--cli', action='store_true', help='Iniciar en modo consola')
    parser.add_argument('--debug', action='store_true', help='Modo debug')
    args = parser.parse_args()

    if args.debug:
        logging.getLogger().setLevel(logging.DEBUG)

    logger.info("="*50)
    logger.info("Iniciando J.A.R.V.I.S MARK 5")
    logger.info("="*50)

    if args.cli:
        start_cli_mode()
    else:
        start_gui_mode()


if __name__ == '__main__':
    main()
