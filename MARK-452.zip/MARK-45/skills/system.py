"""MARK-45 — Skill: Sistema"""
import logging
import os
import platform
import subprocess

logger = logging.getLogger("MARK45.Skills.System")


def minimize_all():
    """Minimizar todas las ventanas."""
    try:
        import pyautogui
        pyautogui.hotkey('win', 'd')
        return True
    except Exception:
        pass
    if platform.system() == 'Windows':
        try:
            import ctypes
            user32 = ctypes.windll.user32
            user32.keybd_event(0x5B, 0, 0, 0)
            user32.keybd_event(0x44, 0, 0, 0)
            user32.keybd_event(0x44, 0, 2, 0)
            user32.keybd_event(0x5B, 0, 2, 0)
            return True
        except Exception:
            pass
    return False


def get_uptime_minutes() -> float:
    try:
        import psutil
        return (psutil.time.time() - psutil.boot_time()) / 60
    except Exception:
        return 0.0
