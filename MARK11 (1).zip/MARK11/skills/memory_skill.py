"""
JARVIS v4.0 - Memory Skill
Gestión de memoria del usuario: recordar y recuperar información.
"""

import logging
import re
from typing import Optional

logger = logging.getLogger('JARVIS.Skills.Memory')


class MemorySkillSkill:
    """Skill de gestión de memoria del usuario."""

    def __init__(self, brain):
        self.brain = brain

    def _get_memory(self):
        """Obtener sistema de memoria."""
        if self.brain and self.brain.memory:
            return self.brain.memory
        return None

    def remember(self, text: str = '') -> str:
        """Guardar información en memoria."""
        if not text:
            return "No se especificó qué recordar, Señor."

        mem = self._get_memory()
        if not mem:
            return "Sistema de memoria no disponible, Señor."

        # Intentar extraer clave-valor
        key, value = self._parse_kv(text)

        if key and value:
            mem.remember(key, value, category='user_data')
            return f"Recordado: '{key}' = '{value}', Señor."
        else:
            # Guardar como dato general con texto como clave parcial
            short_key = text[:50].lower().replace(' ', '_')
            mem.remember(short_key, text, category='general')
            return f"Información guardada en memoria, Señor."

    def recall(self, key: str = '') -> str:
        """Recuperar información guardada."""
        if not key:
            return "Especifique qué desea recordar, Señor."

        mem = self._get_memory()
        if not mem:
            return "Sistema de memoria no disponible, Señor."

        # Buscar exacto primero
        value = mem.recall(key)
        if value:
            return f"'{key}': {value}, Señor."

        # Buscar con variaciones
        variations = [
            key.lower(),
            key.lower().replace(' ', '_'),
            key.lower().replace('mi ', '').replace('el ', '').replace('la ', ''),
        ]

        for var in variations:
            value = mem.recall(var)
            if value:
                return f"'{key}': {value}, Señor."

        # Búsqueda en toda la base de conocimiento
        results = mem.search_knowledge(key)
        if results:
            lines = [f"Encontré información relacionada con '{key}', Señor:"]
            for r in results[:3]:
                lines.append(f"  • {r['key']}: {r['value']}")
            return "\n".join(lines)

        return f"No encontré información sobre '{key}' en memoria, Señor."

    def forget(self, key: str = '') -> str:
        """Eliminar información de memoria (no implementado por seguridad)."""
        return f"Para proteger la integridad de datos, la eliminación requiere confirmación especial, Señor."

    def habits_summary(self) -> str:
        """Mostrar resumen de hábitos detectados."""
        if self.brain and hasattr(self.brain, 'cognitive_memory') and self.brain.cognitive_memory:
            return self.brain.cognitive_memory.get_habit_summary()
        return "Sistema de aprendizaje de hábitos no disponible, Señor."

    def list_memories(self) -> str:
        """Listar todas las memorias guardadas."""
        mem = self._get_memory()
        if not mem:
            return "Sistema de memoria no disponible, Señor."

        results = mem.search_knowledge('')
        if not results:
            return "No hay información guardada en memoria, Señor."

        lines = [f"Información almacenada ({len(results)} entradas):"]
        for r in results[:10]:
            val_preview = str(r['value'])[:50]
            lines.append(f"  • {r['key']}: {val_preview}")

        if len(results) > 10:
            lines.append(f"  ... y {len(results) - 10} entradas más.")

        return "\n".join(lines)

    def save_preference(self, key: str = '', value: str = '') -> str:
        """Guardar preferencia del usuario."""
        if not key or not value:
            return "Especifique la preferencia a guardar, Señor."

        mem = self._get_memory()
        if mem:
            mem.set_preference(key, value)
            return f"Preferencia guardada: '{key}' = '{value}', Señor."
        return "Sistema de memoria no disponible, Señor."

    def get_preference(self, key: str = '') -> str:
        """Obtener preferencia del usuario."""
        if not key:
            return "Especifique qué preferencia desea consultar, Señor."

        mem = self._get_memory()
        if mem:
            value = mem.get_preference(key)
            if value:
                return f"Preferencia '{key}': {value}, Señor."
        return f"No encontré la preferencia '{key}', Señor."

    def _parse_kv(self, text: str):
        """Intentar parsear texto como clave-valor."""
        patterns = [
            r'^mi\s+(\w+[\w\s]*?)\s+es\s+(.+)$',
            r'^el\s+(\w+[\w\s]*?)\s+es\s+(.+)$',
            r'^la\s+(\w+[\w\s]*?)\s+es\s+(.+)$',
            r'^(\w+[\w\s]*?):\s*(.+)$',
            r'^(\w+[\w\s]*?)\s+=\s*(.+)$',
        ]

        text_lower = text.lower().strip()
        for pattern in patterns:
            match = re.match(pattern, text_lower)
            if match:
                key = match.group(1).strip().replace(' ', '_')
                value = match.group(2).strip()
                return key, value

        return None, None
