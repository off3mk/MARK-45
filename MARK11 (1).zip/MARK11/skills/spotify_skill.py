"""
JARVIS v7.0 - Spotify Skill
Integración completa con Spotify API.
Creador: Ali (Sidi3Ali)
"""

import logging
import os
import json
import threading
import time
from typing import Optional, List, Dict, Any

logger = logging.getLogger('JARVIS.SpotifySkill')

# Configuración - el usuario debe proporcionar sus credenciales
SPOTIFY_CONFIG_PATH = os.path.join(
    os.path.dirname(os.path.dirname(__file__)), 'memory', 'spotify_config.json'
)


class SpotifySkill:
    """
    Skill de integración con Spotify.
    - Leer liked songs y playlists
    - Detectar gustos musicales
    - Recomendaciones inteligentes
    - Control de reproducción
    """

    def __init__(self, brain=None):
        self.brain = brain
        self._sp = None
        self._sp_ok = False
        self._config = self._load_config()
        self._init_spotify()

    def _load_config(self) -> Dict:
        """Cargar configuración de Spotify."""
        if os.path.exists(SPOTIFY_CONFIG_PATH):
            try:
                with open(SPOTIFY_CONFIG_PATH, 'r') as f:
                    return json.load(f)
            except Exception:
                pass
        return {
            'client_id': '',
            'client_secret': '',
            'redirect_uri': 'http://localhost:8888/callback',
            'scope': 'user-library-read user-read-playback-state user-modify-playback-state playlist-read-private user-top-read'
        }

    def save_config(self, client_id: str, client_secret: str):
        """Guardar credenciales de Spotify."""
        self._config['client_id'] = client_id
        self._config['client_secret'] = client_secret
        os.makedirs(os.path.dirname(SPOTIFY_CONFIG_PATH), exist_ok=True)
        with open(SPOTIFY_CONFIG_PATH, 'w') as f:
            json.dump(self._config, f, indent=2)
        self._init_spotify()

    def _init_spotify(self):
        """Inicializar cliente de Spotify."""
        if not self._config.get('client_id') or not self._config.get('client_secret'):
            logger.debug("Credenciales de Spotify no configuradas.")
            return

        try:
            import spotipy
            from spotipy.oauth2 import SpotifyOAuth

            cache_path = os.path.join(
                os.path.dirname(os.path.dirname(__file__)), 'memory', '.spotify_cache'
            )

            auth_manager = SpotifyOAuth(
                client_id=self._config['client_id'],
                client_secret=self._config['client_secret'],
                redirect_uri=self._config['redirect_uri'],
                scope=self._config['scope'],
                cache_path=cache_path,
                open_browser=True,
            )
            self._sp = spotipy.Spotify(auth_manager=auth_manager)
            # Verificar conexión
            self._sp.current_user()
            self._sp_ok = True
            logger.info("Spotify conectado.")
        except ImportError:
            logger.debug("spotipy no instalado. Instalar con: pip install spotipy")
        except Exception as e:
            logger.debug(f"Error conectando Spotify: {e}")

    def is_available(self) -> bool:
        return self._sp_ok

    def needs_setup(self) -> str:
        """Retornar instrucciones de configuración si es necesario."""
        if not self._sp_ok:
            return (
                "Para usar Spotify necesitas configurar tus credenciales API. "
                "Ve a https://developer.spotify.com/dashboard y crea una app. "
                "Luego dime: 'configura spotify con client_id: TU_ID y client_secret: TU_SECRET'"
            )
        return ""

    # ── REPRODUCCIÓN ────────────────────────────────────────────────────────

    def get_current_track(self) -> Optional[Dict]:
        """Obtener canción actual."""
        if not self._sp_ok:
            return None
        try:
            playback = self._sp.current_playback()
            if playback and playback.get('item'):
                item = playback['item']
                return {
                    'title': item['name'],
                    'artist': ', '.join(a['name'] for a in item['artists']),
                    'album': item['album']['name'],
                    'is_playing': playback.get('is_playing', False),
                    'progress_ms': playback.get('progress_ms', 0),
                    'duration_ms': item.get('duration_ms', 0),
                    'id': item['id'],
                }
        except Exception:
            pass
        return None

    def play(self, query: str = None, uri: str = None) -> str:
        """Reproducir canción/playlist por búsqueda o URI."""
        if not self._sp_ok:
            return self.needs_setup()
        try:
            if uri:
                self._sp.start_playback(uris=[uri])
                return "Reproduciendo."
            elif query:
                results = self._sp.search(q=query, limit=1, type='track')
                tracks = results.get('tracks', {}).get('items', [])
                if tracks:
                    uri = tracks[0]['uri']
                    self._sp.start_playback(uris=[uri])
                    t = tracks[0]
                    artist = t['artists'][0]['name']
                    return f"Reproduciendo '{t['name']}' de {artist}."
                return f"No encontré '{query}' en Spotify."
            else:
                self._sp.start_playback()
                return "Reproducción iniciada."
        except Exception as e:
            return f"Error: {str(e)[:100]}"

    def pause(self) -> str:
        if not self._sp_ok:
            return self.needs_setup()
        try:
            self._sp.pause_playback()
            return "Reproducción pausada."
        except Exception as e:
            return f"Error: {e}"

    def next_track(self) -> str:
        if not self._sp_ok:
            return self.needs_setup()
        try:
            self._sp.next_track()
            return "Siguiente canción."
        except Exception as e:
            return f"Error: {e}"

    def previous_track(self) -> str:
        if not self._sp_ok:
            return self.needs_setup()
        try:
            self._sp.previous_track()
            return "Canción anterior."
        except Exception as e:
            return f"Error: {e}"

    def set_volume(self, volume: int) -> str:
        """Volumen 0-100."""
        if not self._sp_ok:
            return self.needs_setup()
        try:
            vol = max(0, min(100, volume))
            self._sp.volume(vol)
            return f"Volumen de Spotify al {vol}%."
        except Exception as e:
            return f"Error: {e}"

    # ── LIBRERÍA ─────────────────────────────────────────────────────────────

    def get_liked_songs(self, limit: int = 50) -> List[Dict]:
        """Obtener canciones guardadas."""
        if not self._sp_ok:
            return []
        try:
            results = self._sp.current_user_saved_tracks(limit=limit)
            songs = []
            for item in results.get('items', []):
                track = item.get('track', {})
                if track:
                    songs.append({
                        'title': track['name'],
                        'artist': ', '.join(a['name'] for a in track['artists']),
                        'album': track['album']['name'],
                        'id': track['id'],
                        'uri': track['uri'],
                    })
            return songs
        except Exception:
            return []

    def get_playlists(self, limit: int = 20) -> List[Dict]:
        """Obtener playlists del usuario."""
        if not self._sp_ok:
            return []
        try:
            results = self._sp.current_user_playlists(limit=limit)
            playlists = []
            for p in results.get('items', []):
                playlists.append({
                    'name': p['name'],
                    'id': p['id'],
                    'uri': p['uri'],
                    'tracks': p['tracks']['total'],
                })
            return playlists
        except Exception:
            return []

    def get_top_artists(self, limit: int = 10,
                         time_range: str = 'medium_term') -> List[Dict]:
        """Artistas más escuchados (short/medium/long_term)."""
        if not self._sp_ok:
            return []
        try:
            results = self._sp.current_user_top_artists(
                limit=limit, time_range=time_range
            )
            return [
                {
                    'name': a['name'],
                    'genres': a.get('genres', []),
                    'popularity': a.get('popularity', 0),
                }
                for a in results.get('items', [])
            ]
        except Exception:
            return []

    def get_top_tracks(self, limit: int = 10,
                        time_range: str = 'medium_term') -> List[Dict]:
        """Canciones más escuchadas."""
        if not self._sp_ok:
            return []
        try:
            results = self._sp.current_user_top_tracks(
                limit=limit, time_range=time_range
            )
            return [
                {
                    'title': t['name'],
                    'artist': ', '.join(a['name'] for a in t['artists']),
                    'album': t['album']['name'],
                    'id': t['id'],
                    'uri': t['uri'],
                }
                for t in results.get('items', [])
            ]
        except Exception:
            return []

    def get_music_taste_summary(self) -> str:
        """Generar resumen de gustos musicales del usuario."""
        if not self._sp_ok:
            return self.needs_setup()

        artists = self.get_top_artists(10, 'medium_term')
        tracks = self.get_top_tracks(5, 'medium_term')

        if not artists and not tracks:
            return "No tengo suficientes datos de Spotify todavía."

        # Detectar géneros dominantes
        all_genres = []
        for a in artists:
            all_genres.extend(a.get('genres', []))

        from collections import Counter
        top_genres = [g for g, _ in Counter(all_genres).most_common(3)]
        top_artist_names = [a['name'] for a in artists[:3]]
        top_track_names = [f"'{t['title']}' de {t['artist']}" for t in tracks[:3]]

        lines = []
        if top_genres:
            lines.append(f"Géneros favoritos: {', '.join(top_genres)}.")
        if top_artist_names:
            lines.append(f"Artistas más escuchados: {', '.join(top_artist_names)}.")
        if top_track_names:
            lines.append(f"Canciones top: {', '.join(top_track_names)}.")

        return ' '.join(lines) if lines else "Perfil musical en construcción."

    def get_smart_recommendation(self) -> str:
        """Recomendación inteligente basada en gustos y contexto."""
        if not self._sp_ok:
            return self.needs_setup()

        try:
            artists = self.get_top_artists(5, 'short_term')
            if not artists:
                return "Necesito más datos de escucha para hacer recomendaciones."

            seed_artists = []
            for a in artists[:2]:
                # Buscar ID del artista
                results = self._sp.search(q=a['name'], limit=1, type='artist')
                items = results.get('artists', {}).get('items', [])
                if items:
                    seed_artists.append(items[0]['id'])

            if not seed_artists:
                return "No pude obtener recomendaciones en este momento."

            recs = self._sp.recommendations(
                seed_artists=seed_artists[:2],
                limit=5
            )
            tracks = recs.get('tracks', [])
            if not tracks:
                return "No hay recomendaciones disponibles ahora."

            t = tracks[0]
            artist = ', '.join(a['name'] for a in t['artists'])
            return (f"Basándome en sus gustos, le recomiendo '{t['name']}' de {artist}. "
                    f"¿Desea que la reproduzca?")

        except Exception as e:
            logger.debug(f"Error en recomendación: {e}")
            return "No pude generar recomendaciones en este momento."

    def play_playlist_by_name(self, name: str) -> str:
        """Reproducir playlist por nombre."""
        if not self._sp_ok:
            return self.needs_setup()

        playlists = self.get_playlists()
        name_lower = name.lower()
        for p in playlists:
            if name_lower in p['name'].lower():
                try:
                    self._sp.start_playback(context_uri=p['uri'])
                    return f"Reproduciendo playlist '{p['name']}'."
                except Exception as e:
                    return f"Error: {e}"
        return f"No encontré una playlist llamada '{name}'."
