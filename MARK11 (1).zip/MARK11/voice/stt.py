"""
MARK 10 — Speech-to-Text (STT)
Wake word detection + continuous voice input.

Creator: Ali (Sidi3Ali)
System: MARK 10
"""

import logging
import threading
import queue
import time
from typing import Optional, Callable

logger = logging.getLogger('MARK10.STT')

WAKE_WORDS = ['mark', 'oye mark', 'hey mark', 'mark diez', 'asistente']


class STTEngine:
    """
    Speech recognition with wake word detection.
    Uses SpeechRecognition library with Google (online) or Sphinx (offline).
    """

    def __init__(self, callback: Callable = None, wake_word_mode: bool = False):
        self._callback = callback
        self._wake_word_mode = wake_word_mode
        self._running = False
        self._thread: Optional[threading.Thread] = None
        self._result_queue: queue.Queue = queue.Queue()
        self._recognizer = None
        self._microphone = None
        self._sr_ok = False
        self._pa_ok = False
        self._listening_for_command = False

        self._check_deps()

    def _check_deps(self):
        try:
            import speech_recognition as sr
            self._recognizer = sr.Recognizer()
            self._recognizer.energy_threshold = 300
            self._recognizer.dynamic_energy_threshold = True
            self._recognizer.pause_threshold = 0.8
            self._sr_ok = True
        except ImportError:
            logger.warning("SpeechRecognition no disponible: pip install SpeechRecognition")

        try:
            import pyaudio
            self._pa_ok = True
        except ImportError:
            logger.warning("pyaudio no disponible. STT desactivado.")

    def start(self):
        """Start background listening."""
        if not self._sr_ok or not self._pa_ok:
            logger.warning("STT: no se puede iniciar sin SpeechRecognition + pyaudio")
            return
        self._running = True
        self._thread = threading.Thread(
            target=self._listen_loop,
            name='MARK10-STT',
            daemon=True
        )
        self._thread.start()
        logger.info("STT: escucha activa iniciada.")

    def stop(self):
        self._running = False

    def listen_once(self, timeout: float = 5.0) -> Optional[str]:
        """Listen for a single utterance. Blocking."""
        if not self._sr_ok or not self._pa_ok:
            return None
        try:
            import speech_recognition as sr
            with sr.Microphone() as source:
                self._recognizer.adjust_for_ambient_noise(source, duration=0.5)
                try:
                    audio = self._recognizer.listen(source, timeout=timeout, phrase_time_limit=10)
                    return self._transcribe(audio)
                except sr.WaitTimeoutError:
                    return None
        except Exception as e:
            logger.debug(f"listen_once error: {e}")
            return None

    def _listen_loop(self):
        """Continuous listening loop with wake word detection."""
        import speech_recognition as sr

        try:
            mic = sr.Microphone()
        except Exception as e:
            logger.warning(f"STT: no se pudo abrir micrófono: {e}")
            return

        while self._running:
            try:
                with mic as source:
                    self._recognizer.adjust_for_ambient_noise(source, duration=0.3)
                    try:
                        audio = self._recognizer.listen(
                            source,
                            timeout=3.0,
                            phrase_time_limit=8.0
                        )
                        text = self._transcribe(audio)
                        if text:
                            self._handle_input(text)
                    except sr.WaitTimeoutError:
                        pass
            except Exception as e:
                logger.debug(f"STT loop error: {e}")
                time.sleep(2)

    def _transcribe(self, audio) -> Optional[str]:
        """Transcribe audio to text."""
        import speech_recognition as sr
        try:
            # Try Google (requires internet)
            text = self._recognizer.recognize_google(audio, language='es-ES')
            return text.strip()
        except sr.UnknownValueError:
            return None
        except sr.RequestError:
            # Try Sphinx offline
            try:
                text = self._recognizer.recognize_sphinx(audio, language='es-ES')
                return text.strip()
            except Exception:
                return None
        except Exception:
            return None

    def _handle_input(self, text: str):
        """Handle recognized text — apply wake word filter if needed."""
        text_lower = text.lower()

        if self._wake_word_mode:
            # Check for wake word
            has_wake = any(w in text_lower for w in WAKE_WORDS)
            if has_wake or self._listening_for_command:
                self._listening_for_command = True
                # Strip wake word
                for w in WAKE_WORDS:
                    text = text_lower.replace(w, '').strip()
                if text:
                    self._dispatch(text)
                    self._listening_for_command = False
        else:
            self._dispatch(text)

    def _dispatch(self, text: str):
        """Send recognized text to callback or queue."""
        self._result_queue.put(text)
        if self._callback:
            try:
                self._callback(text)
            except Exception as e:
                logger.debug(f"STT callback error: {e}")

    def get_result(self, timeout: float = 0.1) -> Optional[str]:
        """Non-blocking: get next result from queue."""
        try:
            return self._result_queue.get(timeout=timeout)
        except queue.Empty:
            return None

    def is_available(self) -> bool:
        return self._sr_ok and self._pa_ok

    def get_status(self) -> dict:
        return {
            'available': self.is_available(),
            'sr_installed': self._sr_ok,
            'pyaudio_installed': self._pa_ok,
            'running': self._running,
            'wake_word_mode': self._wake_word_mode,
        }
