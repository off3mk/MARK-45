"""
MARK 10 — Text-to-Speech (TTS)
Natural Spanish voice using edge-tts with SSML pauses.
Voice: es-ES-AlvaroNeural

Creator: Ali (Sidi3Ali)
System: MARK 10
"""

import asyncio
import logging
import os
import re
import threading
import queue
import time
from typing import Optional

logger = logging.getLogger('MARK10.TTS')

VOICE       = "es-ES-AlvaroNeural"
RATE        = "-5%"
VOLUME      = "+0%"
CACHE_DIR   = os.path.join(os.path.dirname(os.path.dirname(__file__)), 'cache', 'tts')


class NaturalSpeech:
    """Convert text to natural-sounding SSML."""

    @staticmethod
    def prepare(text: str) -> str:
        """Clean and prepare text for natural TTS delivery."""
        # Normalize spaces
        text = re.sub(r'\s+', ' ', text).strip()
        # Remove markdown
        text = re.sub(r'\*\*(.+?)\*\*', r'\1', text)
        text = re.sub(r'\*(.+?)\*', r'\1', text)
        text = re.sub(r'```.*?```', '', text, flags=re.DOTALL)
        text = re.sub(r'`(.+?)`', r'\1', text)
        # Expand abbreviations
        text = text.replace('%', ' por ciento')
        text = text.replace('CPU', 'C.P.U.')
        text = text.replace('RAM', 'RAM')
        text = text.replace('GPU', 'G.P.U.')
        text = text.replace('MARK 10', 'Mark diez')
        text = text.replace('MARK10', 'Mark diez')
        # Limit length
        if len(text) > 400:
            text = text[:397] + '...'
        return text

    @staticmethod
    def to_ssml(text: str) -> str:
        """Wrap text in SSML for natural pauses."""
        clean = NaturalSpeech.prepare(text)
        # Add pauses after punctuation
        clean = clean.replace(', ', ',<break time="200ms"/> ')
        clean = clean.replace('. ', '.<break time="400ms"/> ')
        clean = clean.replace('? ', '?<break time="350ms"/> ')
        clean = clean.replace('! ', '!<break time="350ms"/> ')
        clean = clean.replace(': ', ':<break time="200ms"/> ')
        return (f'<speak version="1.0" xmlns="http://www.w3.org/2001/10/synthesis" '
                f'xml:lang="es-ES"><voice name="{VOICE}">'
                f'<prosody rate="{RATE}" volume="{VOLUME}">'
                f'{clean}</prosody></voice></speak>')


class TTSEngine:
    """
    Asynchronous TTS engine with priority queue.
    Non-blocking: speak() returns immediately.
    Priority messages interrupt current playback.
    """

    def __init__(self, enabled: bool = True):
        self.enabled = enabled
        self._queue: queue.PriorityQueue = queue.PriorityQueue()
        self._speaking = False
        self._lock = threading.Lock()
        self._thread: Optional[threading.Thread] = None
        self._running = False
        os.makedirs(CACHE_DIR, exist_ok=True)

        # Check if edge-tts available
        self._edge_ok = False
        try:
            import edge_tts
            self._edge_ok = True
        except ImportError:
            logger.warning("edge-tts no disponible. Instala: pip install edge-tts")

        # Check pyttsx3 fallback
        self._pyttsx_ok = False
        try:
            import pyttsx3
            self._pyttsx_ok = True
        except ImportError:
            pass

    def start(self):
        self._running = True
        self._thread = threading.Thread(
            target=self._worker,
            name='MARK10-TTS',
            daemon=True
        )
        self._thread.start()

    def stop(self):
        self._running = False

    def speak(self, text: str, priority: bool = False):
        """Queue text for speech. priority=True plays immediately."""
        if not self.enabled or not text or not text.strip():
            return
        # Priority 0 = high, 10 = low
        prio = 0 if priority else 10
        self._queue.put((prio, time.time(), text.strip()))

    def speak_sync(self, text: str):
        """Synchronous blocking TTS."""
        if not self.enabled or not text:
            return
        self._synthesize(text)

    def _worker(self):
        """Background worker consuming TTS queue."""
        while self._running:
            try:
                _, _, text = self._queue.get(timeout=0.5)
                with self._lock:
                    self._speaking = True
                try:
                    self._synthesize(text)
                finally:
                    with self._lock:
                        self._speaking = False
                    self._queue.task_done()
            except queue.Empty:
                pass
            except Exception as e:
                logger.debug(f"TTS worker error: {e}")

    def _synthesize(self, text: str):
        """Synthesize and play speech."""
        if self._edge_ok:
            try:
                self._synthesize_edge(text)
                return
            except Exception as e:
                logger.debug(f"edge-tts error: {e}")

        if self._pyttsx_ok:
            try:
                self._synthesize_pyttsx(text)
                return
            except Exception as e:
                logger.debug(f"pyttsx3 error: {e}")

        # Last resort: just print
        print(f"[MARK 10 — voz no disponible] {text}")

    def _synthesize_edge(self, text: str):
        """Synthesize using edge-tts via asyncio."""
        import edge_tts
        import tempfile

        ssml = NaturalSpeech.to_ssml(text)
        tmp_path = os.path.join(CACHE_DIR, f"tts_{int(time.time()*1000)}.mp3")

        async def _gen():
            communicate = edge_tts.Communicate(text=text, voice=VOICE,
                                                rate=RATE, volume=VOLUME)
            await communicate.save(tmp_path)

        try:
            loop = asyncio.new_event_loop()
            loop.run_until_complete(_gen())
            loop.close()
        except Exception:
            # Try using the event loop from current thread
            asyncio.run(_gen())

        # Play with pygame
        try:
            import pygame
            if not pygame.mixer.get_init():
                pygame.mixer.init()
            pygame.mixer.music.load(tmp_path)
            pygame.mixer.music.play()
            while pygame.mixer.music.get_busy():
                time.sleep(0.05)
        except Exception:
            # Fallback: playsound
            try:
                from playsound import playsound
                playsound(tmp_path)
            except Exception:
                pass
        finally:
            try:
                os.unlink(tmp_path)
            except Exception:
                pass

    def _synthesize_pyttsx(self, text: str):
        """Fallback TTS using pyttsx3."""
        import pyttsx3
        engine = pyttsx3.init()
        # Try to set Spanish voice
        voices = engine.getProperty('voices')
        for v in voices:
            if 'es' in v.id.lower() or 'spanish' in v.name.lower():
                engine.setProperty('voice', v.id)
                break
        engine.setProperty('rate', 160)
        engine.say(text)
        engine.runAndWait()

    def is_speaking(self) -> bool:
        with self._lock:
            return self._speaking

    def clear_queue(self):
        """Clear pending speech queue."""
        while not self._queue.empty():
            try:
                self._queue.get_nowait()
            except queue.Empty:
                break

    def get_status(self) -> dict:
        return {
            'enabled': self.enabled,
            'edge_tts': self._edge_ok,
            'pyttsx3': self._pyttsx_ok,
            'speaking': self._speaking,
            'queue_size': self._queue.qsize(),
        }


# ── Compatibility wrapper ──────────────────────────────────────────────────────
class VoiceSystem:
    """
    Compatibility shim — mirrors MARK 8/9 VoiceSystem interface.
    Wraps the new TTSEngine.
    """

    def __init__(self, config: dict = None):
        cfg = (config or {}).get('voice', {}) if config and 'voice' in config else {}
        enabled = cfg.get('enabled', True)
        self._tts = TTSEngine(enabled=enabled)
        self._tts.start()

    def speak(self, text: str, priority: bool = False):
        self._tts.speak(text, priority=priority)

    def speak_sync(self, text: str):
        self._tts.speak_sync(text)

    def is_speaking(self) -> bool:
        return self._tts.is_speaking()

    def clear_queue(self):
        self._tts.clear_queue()

    def get_status(self) -> dict:
        return self._tts.get_status()

    def stop(self):
        self._tts.stop()
