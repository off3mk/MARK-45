"""
MARK 11 — Interfaz Grafica
Reactor Arc 3D animado. Cambia de color segun actividad.
Creator: Ali (Sidi3Ali)
System: MARK 11
"""
import os, logging, threading, time, math, queue
from typing import Optional
from datetime import datetime
logger = logging.getLogger("MARK11.UI")
try:
    import tkinter as tk
    from tkinter import scrolledtext
    TK_AVAILABLE = True
except ImportError:
    TK_AVAILABLE = False

C = {
    "bg_dark":   "#080c18",
    "bg_mid":    "#0d1225",
    "bg_panel":  "#111830",
    "bg_input":  "#0b1020",
    "blue":      "#00a8ff",
    "cyan":      "#00e5ff",
    "glow":      "#1a6fff",
    "text":      "#d0e8ff",
    "text_dim":  "#5070a0",
    "text_mark": "#00e5ff",
    "text_user": "#70c0ff",
    "text_sys":  "#3590c0",
    "ok":        "#00ff88",
    "warn":      "#ffb020",
    "danger":    "#ff3050",
    "border":    "#1a3060",
}
ACTIVITY_COLORS = {
    "coding":        "#00ff88",
    "writing":       "#a0d8ff",
    "gaming":        "#ff4466",
    "watching":      "#ff8c00",
    "music":         "#cc44ff",
    "communication": "#00e5ff",
    "browsing":      "#00a8ff",
    "idle":          "#00a8ff",
    "thinking":      "#00ffcc",
    "alert":         "#ff2020",
}
SYSTEM_NAME = "MARK 11"
CREATOR     = "Ali (Sidi3Ali)"

class ArcReactor(tk.Canvas):
    """Reactor Arc 3D animado. Cambia color segun actividad."""
    def __init__(self, parent, size=188, **kw):
        super().__init__(parent, width=size, height=size,
                         bg=C["bg_dark"], highlightthickness=0, **kw)
        self._s=size; self._cx=size//2; self._cy=size//2
        self._color=C["blue"]; self._target=C["blue"]
        self._a1=0.0; self._a2=0.0; self._a3=0.0; self._p=0.0
        self._run=False

    def set_activity(self, a):
        self._target=ACTIVITY_COLORS.get(a.lower(), C["blue"])

    def start(self):
        self._run=True; self._tick()

    def stop(self):
        self._run=False

    def _lerp(self,c1,c2,t):
        def p(c): c=c.lstrip("#"); return int(c[:2],16),int(c[2:4],16),int(c[4:],16)
        r1,g1,b1=p(c1); r2,g2,b2=p(c2)
        return "#{:02x}{:02x}{:02x}".format(int(r1+(r2-r1)*t),int(g1+(g2-g1)*t),int(b1+(b2-b1)*t))

    def _dk(self,c,f):
        c=c.lstrip("#")
        return "#{:02x}{:02x}{:02x}".format(
            max(0,int(int(c[:2],16)*f)),max(0,int(int(c[2:4],16)*f)),max(0,int(int(c[4:],16)*f)))

    def _lt(self,c,f):
        c=c.lstrip("#")
        return "#{:02x}{:02x}{:02x}".format(
            min(255,int(int(c[:2],16)*(1+f))),min(255,int(int(c[2:4],16)*(1+f))),min(255,int(int(c[4:],16)*(1+f))))

    def _tick(self):
        if not self._run: return
        try: self._draw()
        except Exception: pass
        self.after(50, self._tick)

    def _ring(self,cx,cy,r,start,n,arc,col,w):
        gap=(360-n*arc)/max(n,1); step=arc+gap
        for i in range(n):
            a=start+i*step
            yf=math.sin(math.radians(a))
            ww=max(1,int(w+yf*1.5))
            sh=self._lt(col, 0.1+0.3*(1+yf)/2)
            self.create_arc(cx-r,cy-r*0.88,cx+r,cy+r*0.88,
                start=a,extent=arc,style="arc",outline=sh,width=ww)

    def _draw(self):
        self.delete("all")
        cx,cy=self._cx,self._cy; r=self._s//2-6
        self._color=self._lerp(self._color,self._target,0.07)
        col=self._color; dark=self._dk(col,0.28); glow=self._lt(col,0.45)
        self._a1+=1.8; self._a2-=3.2; self._a3+=4.5; self._p+=0.14
        for i in range(5,0,-1):
            ar=r+i*4; fade=self._dk(col,1.0-i*0.14)
            self.create_oval(cx-ar,cy-ar,cx+ar,cy+ar,fill="",outline=fade,width=1)
        self._ring(cx,cy,r-2,     self._a1,12,22,col,2)
        self._ring(cx,cy,int(r*.68),self._a2, 8,34,dark,3)
        self._ring(cx,cy,int(r*.44),self._a3, 6,44,glow,2)
        for i in range(6):
            rad=math.radians(self._a1+i*60); sl=int(r*.38)
            self.create_line(cx,cy,cx+int(sl*math.cos(rad)),cy+int(sl*math.sin(rad)),fill=dark,width=1)
        for i in range(3):
            a=math.radians(self._a1*.28+i*120); tr=int(r*.27)
            x1=cx+int(tr*math.cos(a)); y1=cy+int(tr*math.sin(a))
            x2=cx+int(tr*math.cos(a+math.radians(120))); y2=cy+int(tr*math.sin(a+math.radians(120)))
            self.create_line(x1,y1,x2,y2,fill=col,width=1)
        pv=math.sin(self._p); cr=int(r*.21+pv*3)
        self.create_oval(cx-cr,cy-cr,cx+cr,cy+cr,fill=dark,outline=col,width=2)
        ir=int(cr*.55+pv*2)
        self.create_oval(cx-ir,cy-ir,cx+ir,cy+ir,fill=glow,outline=glow)
        self.create_oval(cx-4,cy-4,cx+4,cy+4,fill="#ffffff",outline="")


class StatusPanel(tk.Frame):
    def __init__(self,parent,**kw):
        super().__init__(parent,bg=C["bg_panel"],**kw)
        self._v={}
        tk.Label(self,text="SISTEMAS",bg=C["bg_panel"],fg=C["text_dim"],
                 font=("Courier",7,"bold")).pack(anchor="w",padx=8,pady=(6,2))
        for k,lbl,fg in [
            ("ai",      "IA",        C["cyan"]),
            ("model",   "Modelo",    C["text_dim"]),
            ("cpu",     "CPU",       C["blue"]),
            ("ram",     "RAM",       C["blue"]),
            ("markram", "MARK RAM",  C["ok"]),
            ("activity","Actividad", C["ok"]),
            ("mode",    "Modo",      C["text_dim"]),
        ]:
            row=tk.Frame(self,bg=C["bg_panel"]); row.pack(fill="x",padx=8,pady=1)
            tk.Label(row,text=lbl+":",bg=C["bg_panel"],fg=C["text_dim"],
                     font=("Courier",8),width=10,anchor="w").pack(side="left")
            v=tk.Label(row,text="--",bg=C["bg_panel"],fg=fg,font=("Courier",8,"bold"),anchor="w")
            v.pack(side="left",fill="x",expand=True)
            self._v[k]=v

    def update(self,**kw):
        for k,val in kw.items():
            if k in self._v:
                try: self._v[k].config(text=str(val)[:24])
                except Exception: pass


class JarvisInterface:
    """MARK 11 — Interfaz principal con reactor 3D."""

    def __init__(self, brain=None):
        if not TK_AVAILABLE:
            raise ImportError("tkinter no disponible.")
        self.brain=brain; self._root=None; self._q=queue.Queue()
        self._thinking=False; self._running=False
        self._fpath=None; self._hist=[]; self._hidx=-1
        self._reactor=None; self._spanel=None; self._chat=None
        self._inp=None; self._ai_lbl=None; self._act_lbl=None
        self._think_lbl=None; self._time_lbl=None; self._sb_lbl=None

    def run(self):
        self._root=tk.Tk()
        self._root.title(f"{SYSTEM_NAME} -- Cognitive Operating System | {CREATOR}")
        self._root.configure(bg=C["bg_dark"])
        self._root.geometry("1120x720")
        self._root.minsize(920,600)
        self._build()
        self._running=True
        self._reactor.start()
        self._root.after(80, self._poll)
        self._root.after(1000, self._clock)
        self._root.after(2500, self._status)
        self._root.after(300, self._thinking_anim)
        self._root.after(900, self._greeting)
        self._root.protocol("WM_DELETE_WINDOW", self._close)
        self._root.mainloop()

    def _greeting(self):
        model="Qwen2.5-7B-Instruct-1M"
        lm_ok=False
        if self.brain and self.brain.ai_manager:
            lm_ok=self.brain.ai_manager.lmstudio.available
            if lm_ok: model=self.brain.ai_manager.lmstudio.model[:32]
        ai_s=("LM Studio activo  --  "+model) if lm_ok else "LM Studio INACTIVO -- modo local"
        self._post_sys(f"{SYSTEM_NAME} operativo. {ai_s}.")
        self._post_sys("Buenos dias, Ali.")

    def _build(self):
        r=self._root
        # Header
        hdr=tk.Frame(r,bg=C["bg_panel"],height=58); hdr.pack(fill="x"); hdr.pack_propagate(False)
        tk.Label(hdr,text=SYSTEM_NAME,bg=C["bg_panel"],fg=C["cyan"],
                 font=("Courier",22,"bold")).pack(side="left",padx=18,pady=10)
        tk.Label(hdr,text="-- Cognitive Operating System",bg=C["bg_panel"],
                 fg=C["text_dim"],font=("Courier",10)).pack(side="left",pady=16)
        self._ai_lbl=tk.Label(hdr,text="LM Studio: --",bg=C["bg_panel"],
                              fg=C["warn"],font=("Courier",9,"bold"))
        self._ai_lbl.pack(side="right",padx=18)
        self._time_lbl=tk.Label(hdr,text="",bg=C["bg_panel"],fg=C["text_dim"],font=("Courier",9))
        self._time_lbl.pack(side="right",padx=10)
        tk.Frame(r,bg=C["border"],height=1).pack(fill="x")
        # Main
        main=tk.Frame(r,bg=C["bg_dark"]); main.pack(fill="both",expand=True)
        # Left
        left=tk.Frame(main,bg=C["bg_dark"],width=224); left.pack(side="left",fill="y")
        left.pack_propagate(False)
        tk.Label(left,text="ARC REACTOR",bg=C["bg_dark"],fg=C["text_dim"],
                 font=("Courier",7,"bold")).pack(pady=(12,2))
        self._reactor=ArcReactor(left,size=186); self._reactor.pack(pady=4)
        self._act_lbl=tk.Label(left,text="IDLE",bg=C["bg_dark"],fg=C["blue"],
                               font=("Courier",8,"bold"))
        self._act_lbl.pack(pady=2)
        self._spanel=StatusPanel(left); self._spanel.pack(fill="x",padx=4,pady=4)
        tk.Label(left,text=CREATOR,bg=C["bg_dark"],fg=C["text_dim"],
                 font=("Courier",7)).pack(side="bottom",pady=6)
        tk.Frame(main,bg=C["border"],width=1).pack(side="left",fill="y")
        # Right
        right=tk.Frame(main,bg=C["bg_dark"]); right.pack(side="left",fill="both",expand=True)
        ch=tk.Frame(right,bg=C["bg_mid"],height=28); ch.pack(fill="x"); ch.pack_propagate(False)
        tk.Label(ch,text="INTERFAZ COGNITIVA -- "+SYSTEM_NAME,bg=C["bg_mid"],
                 fg=C["text_dim"],font=("Courier",8,"bold")).pack(side="left",padx=10,pady=6)
        self._chat=scrolledtext.ScrolledText(
            right,bg=C["bg_dark"],fg=C["text"],font=("Courier",10),
            wrap="word",state="disabled",relief="flat",selectbackground=C["glow"],
            insertbackground=C["cyan"],padx=10,pady=8,cursor="arrow")
        self._chat.pack(fill="both",expand=True,padx=8,pady=4)
        self._chat.tag_config("mark",foreground=C["text_mark"],font=("Courier",10,"bold"))
        self._chat.tag_config("user",foreground=C["text_user"])
        self._chat.tag_config("sys", foreground=C["text_sys"],font=("Courier",9))
        self._chat.tag_config("time",foreground=C["text_dim"],font=("Courier",8))
        self._chat.tag_config("warn",foreground=C["warn"])
        self._chat.tag_config("err", foreground=C["danger"])
        # Input
        inp=tk.Frame(right,bg=C["bg_mid"]); inp.pack(fill="x",padx=8,pady=(0,4))
        brd=tk.Frame(inp,bg=C["border"],padx=1,pady=1); brd.pack(fill="x")
        inn=tk.Frame(brd,bg=C["bg_input"]); inn.pack(fill="x")
        tk.Label(inn,text="Ali ->",bg=C["bg_input"],fg=C["blue"],
                 font=("Courier",10,"bold")).pack(side="left",padx=(10,4),pady=7)
        self._inp=tk.Entry(inn,bg=C["bg_input"],fg=C["text"],
                           insertbackground=C["cyan"],font=("Courier",10),relief="flat",bd=0)
        self._inp.pack(side="left",fill="x",expand=True,pady=7)
        self._inp.bind("<Return>",lambda e:self._send())
        self._inp.bind("<Up>",    lambda e:self._hu())
        self._inp.bind("<Down>",  lambda e:self._hd())
        self._inp.focus_set()
        tk.Button(inn,text="Adjunto",bg=C["bg_input"],fg=C["text_dim"],font=("Courier",8),
                  relief="flat",bd=0,padx=6,cursor="hand2",command=self._attach
                  ).pack(side="right",padx=2,pady=4)
        tk.Button(inn,text="ENVIAR",bg=C["glow"],fg="#ffffff",font=("Courier",8,"bold"),
                  relief="flat",bd=0,padx=14,cursor="hand2",command=self._send,
                  activebackground=C["cyan"],activeforeground="#000000"
                  ).pack(side="right",padx=4,pady=4)
        tk.Frame(right,bg=C["border"],height=1).pack(fill="x",padx=8)
        sb=tk.Frame(right,bg=C["bg_mid"],height=22); sb.pack(fill="x",padx=8); sb.pack_propagate(False)
        self._sb_lbl=tk.Label(sb,
            text=f"{SYSTEM_NAME} | Qwen2.5-7B-Instruct-1M | LM Studio | {CREATOR}",
            bg=C["bg_mid"],fg=C["text_dim"],font=("Courier",8),anchor="w")
        self._sb_lbl.pack(side="left",padx=8)
        self._think_lbl=tk.Label(sb,text="",bg=C["bg_mid"],fg=C["cyan"],font=("Courier",8,"bold"))
        self._think_lbl.pack(side="right",padx=8)

    def _clock(self):
        try: self._time_lbl.config(text=datetime.now().strftime("%H:%M:%S"))
        except Exception: pass
        if self._running: self._root.after(1000,self._clock)

    def _thinking_anim(self):
        try:
            if self._thinking:
                dots="."*(int(time.time()*2)%4)
                self._think_lbl.config(text="Procesando"+dots)
                self._reactor.set_activity("thinking")
            else:
                self._think_lbl.config(text="")
        except Exception: pass
        if self._running: self._root.after(300,self._thinking_anim)

    def _status(self):
        try: self._refresh()
        except Exception: pass
        if self._running: self._root.after(2500,self._status)

    def _refresh(self):
        try:
            import psutil
            cpu=psutil.cpu_percent(interval=None)
            ram=psutil.virtual_memory()
            mb=psutil.Process().memory_info().rss/1024**2
            cpu_s=f"{cpu:.0f}%"; ram_s=f"{ram.used//1024**3:.1f}/{ram.total//1024**3:.0f}GB"
            mb_s=f"{mb:.0f}MB"
        except Exception:
            cpu_s=ram_s=mb_s="?"
        ai_s="INACTIVO"; mdl="--"
        if self.brain and self.brain.ai_manager:
            s=self.brain.ai_manager.get_status()
            if s.get("lmstudio_available"):
                ai_s="LM Studio"; mdl=s.get("lmstudio_model","Qwen2.5-7B")[:22]
                self._ai_lbl.config(text="LM Studio: OK",fg=C["ok"])
            elif s.get("active_source")=="pollinations":
                ai_s="Pollinations"; self._ai_lbl.config(text="IA: Pollinations",fg=C["warn"])
            else:
                ai_s="LOCAL"; self._ai_lbl.config(text="IA: LOCAL",fg=C["danger"])
        act="idle"; mode="--"
        if self.brain and hasattr(self.brain,"context_awareness") and self.brain.context_awareness:
            try:
                ctx=self.brain.context_awareness.get_context()
                if ctx: act=ctx.user_activity or "idle"; mode=ctx.detected_mode or "--"
            except Exception: pass
        if not self._thinking:
            self._reactor.set_activity(act)
            self._act_lbl.config(text=act.upper(),fg=ACTIVITY_COLORS.get(act,C["blue"]))
        self._spanel.update(ai=ai_s,model=mdl,cpu=cpu_s,ram=ram_s,markram=mb_s,activity=act,mode=mode)

    def _poll(self):
        try:
            while True: self._write(**self._q.get_nowait())
        except queue.Empty: pass
        if self._running: self._root.after(50,self._poll)

    def _write(self,text,tag="mark",prefix=""):
        self._chat.config(state="normal")
        ts=datetime.now().strftime("%H:%M")
        self._chat.insert("end",f"[{ts}] ","time")
        if prefix: self._chat.insert("end",prefix,tag)
        self._chat.insert("end",text+"\n",tag)
        self._chat.config(state="disabled")
        self._chat.see("end")

    def _post_mark(self,t): self._q.put({"text":t,"tag":"mark","prefix":f"[{SYSTEM_NAME}] "})
    def _post_user(self,t): self._q.put({"text":t,"tag":"user","prefix":"[Ali]    "})
    def _post_sys(self,t):  self._q.put({"text":t,"tag":"sys", "prefix":"[SYS]    "})
    def _post_warn(self,t): self._q.put({"text":t,"tag":"warn","prefix":"[AVISO]  "})

    def _send(self):
        text=self._inp.get().strip()
        if not text: return
        self._inp.delete(0,"end")
        self._hist.append(text); self._hidx=-1
        if self._fpath:
            text=f"[Archivo: {os.path.basename(self._fpath)}] {text}"
            self._fpath=None
            self._sb_lbl.config(text=f"{SYSTEM_NAME} | Qwen2.5-7B | {CREATOR}",fg=C["text_dim"])
        self._post_user(text)
        threading.Thread(target=self._run_cmd,args=(text,),daemon=True,name="MARK11-Cmd").start()

    def _run_cmd(self,text):
        self._thinking=True
        try:
            resp=self.brain.process_command(text) if self.brain else "Brain no iniciado."
            self._post_mark(resp)
        except Exception as e:
            self._q.put({"text":str(e)[:120],"tag":"err","prefix":"[ERROR] "})
        finally:
            self._thinking=False

    def _hu(self):
        if not self._hist: return
        self._hidx=min(self._hidx+1,len(self._hist)-1)
        self._inp.delete(0,"end"); self._inp.insert(0,self._hist[-(self._hidx+1)])

    def _hd(self):
        if self._hidx<=0: self._hidx=-1; self._inp.delete(0,"end"); return
        self._hidx-=1; self._inp.delete(0,"end"); self._inp.insert(0,self._hist[-(self._hidx+1)])

    def _attach(self):
        try:
            from tkinter import filedialog
            p=filedialog.askopenfilename(title=f"Adjuntar -- {SYSTEM_NAME}")
            if p:
                self._fpath=p
                self._sb_lbl.config(text=f"Adjunto: {os.path.basename(p)}",fg=C["ok"])
                self._post_sys(f"Archivo adjunto: {os.path.basename(p)}")
        except Exception as e:
            self._q.put({"text":str(e),"tag":"err","prefix":"[ERROR] "})

    def ui_callback(self,event,data=None):
        if event=="decision":
            msg=(data or {}).get("message","")
            pri=(data or {}).get("priority","low")
            fn=self._post_warn if pri in ("critical","high") else self._post_sys
            fn(msg)

    def _close(self):
        self._running=False; self._reactor.stop()
        if self.brain:
            try: self.brain.shutdown()
            except Exception: pass
        self._root.destroy()
