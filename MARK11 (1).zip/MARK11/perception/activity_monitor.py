"""
MARK 10 — Activity Monitor
Detect what the user is doing in real-time.
Lightweight: uses only window title + process name.

Creator: Ali (Sidi3Ali)
System: MARK 10
"""

import logging
import time
import threading
from typing import Optional, Dict
from dataclasses import dataclass, field
from datetime import datetime

logger = logging.getLogger('MARK10.ActivityMonitor')


@dataclass
class CurrentContext:
    """Current user context — what they're doing right now."""
    timestamp: float = field(default_factory=time.time)
    active_window: str = ''
    active_app: str = ''
    active_document: str = ''
    user_activity: str = 'idle'
    detected_mode: str = 'unknown'
    activity_duration_min: float = 0.0
    time_of_day: str = ''
    is_writing: bool = False
    is_coding: bool = False
    is_browsing: bool = False
    is_watching: bool = False
    is_in_word: bool = False
    is_in_spotify: bool = False
    is_gaming: bool = False

    def describe(self) -> str:
        parts = []
        if self.active_app:
            parts.append(f"App: {self.active_app}")
        if self.user_activity not in ('idle', 'unknown'):
            parts.append(f"Actividad: {self.user_activity}")
        if self.detected_mode not in ('unknown',):
            parts.append(f"Modo: {self.detected_mode}")
        return ' | '.join(parts) if parts else 'Sin actividad detectada'


class ActivityMonitor:
    """
    Monitor user activity by tracking active window and process.
    Runs every 3 seconds. CPU overhead: negligible.
    """

    CODING_APPS    = {'code','vscode','pycharm','intellij','cursor','sublime','vim','nvim'}
    WRITING_APPS   = {'word','winword','notion','obsidian','typora','libreoffice','soffice','onenote'}
    GAMING_APPS    = {'steam','epicgames','origin','battlenet','gog'}
    COMM_APPS      = {'teams','slack','discord','zoom','telegram','whatsapp','skype'}
    WATCHING_APPS  = {'vlc','mpv','mpc-hc','potplayer','plex','davinciresovle'}
    DESIGN_APPS    = {'figma','photoshop','illustrator','gimp','blender','canva','inkscape'}
    BROWSER_APPS   = {'chrome','firefox','edge','opera','brave'}

    def __init__(self, interval: float = 3.0):
        self._interval = interval
        self._current: Optional[CurrentContext] = None
        self._prev: Optional[CurrentContext] = None
        self._lock = threading.Lock()
        self._running = False
        self._thread: Optional[threading.Thread] = None
        self._activity_start: Dict[str, float] = {}
        self._win32_ok = False
        self._win32proc_ok = False
        try:
            import win32gui; self._win32_ok = True
        except ImportError: pass
        try:
            import win32process; self._win32proc_ok = True
        except ImportError: pass

    def start(self):
        # Initial read
        self._current = self._build()
        self._running = True
        self._thread = threading.Thread(
            target=self._loop,
            name='MARK10-ActivityMonitor',
            daemon=True
        )
        self._thread.start()

    def stop(self):
        self._running = False

    def _get_active_window(self) -> str:
        if self._win32_ok:
            try:
                import win32gui
                return win32gui.GetWindowText(win32gui.GetForegroundWindow()) or ''
            except Exception: pass
        return ''

    def _get_active_app(self) -> str:
        if self._win32_ok and self._win32proc_ok:
            try:
                import win32gui, win32process, psutil
                hwnd = win32gui.GetForegroundWindow()
                _, pid = win32process.GetWindowThreadProcessId(hwnd)
                return psutil.Process(pid).name().lower().replace('.exe', '')
            except Exception: pass
        try:
            import psutil
            ignore = {'system','idle','svchost','dwm','winlogon','csrss','lsass'}
            for p in psutil.process_iter(['name','status']):
                if p.info['status'] == 'running':
                    n = p.info['name'].lower().replace('.exe','')
                    if n not in ignore and len(n) > 2:
                        return n
        except Exception: pass
        return ''

    def _classify(self, app: str, window: str) -> str:
        a = app.lower()
        w = window.lower()
        for x in self.CODING_APPS:
            if x in a: return 'coding'
        for x in self.WRITING_APPS:
            if x in a: return 'writing'
        for x in self.WATCHING_APPS:
            if x in a: return 'watching'
        for x in self.GAMING_APPS:
            if x in a: return 'gaming'
        for x in self.COMM_APPS:
            if x in a: return 'communication'
        for x in self.DESIGN_APPS:
            if x in a: return 'designing'
        if any(b in a for b in self.BROWSER_APPS):
            if any(k in w for k in ('youtube','twitch','netflix')): return 'watching'
            if any(k in w for k in ('github','stackoverflow','docs')): return 'coding'
            if any(k in w for k in ('gmail','outlook')): return 'communication'
            return 'browsing'
        return 'idle'

    def _get_time_of_day(self) -> str:
        h = datetime.now().hour
        if 5 <= h < 12: return 'morning'
        if 12 <= h < 17: return 'afternoon'
        if 17 <= h < 21: return 'evening'
        return 'night'

    def _mode_from_activity(self, activity: str) -> str:
        mapping = {
            'coding': 'work', 'writing': 'work', 'designing': 'creative',
            'browsing': 'study', 'watching': 'leisure', 'gaming': 'leisure',
            'communication': 'communication',
        }
        return mapping.get(activity, 'unknown')

    def _build(self) -> CurrentContext:
        ctx = CurrentContext()
        ctx.active_window = self._get_active_window()
        ctx.active_app = self._get_active_app()

        # Extract document name
        for sep in (' - ', ' — ', ' | '):
            if sep in ctx.active_window:
                ctx.active_document = ctx.active_window.split(sep)[0].strip()
                break

        ctx.user_activity = self._classify(ctx.active_app, ctx.active_window)
        ctx.detected_mode = self._mode_from_activity(ctx.user_activity)
        ctx.time_of_day = self._get_time_of_day()

        # Activity duration
        now = time.time()
        act = ctx.user_activity
        if act not in self._activity_start:
            self._activity_start = {act: now}
        ctx.activity_duration_min = (now - self._activity_start.get(act, now)) / 60.0

        # Boolean flags for easy access
        a = ctx.active_app.lower()
        ctx.is_coding        = ctx.user_activity == 'coding'
        ctx.is_writing       = ctx.user_activity == 'writing'
        ctx.is_browsing      = ctx.user_activity == 'browsing'
        ctx.is_watching      = ctx.user_activity == 'watching'
        ctx.is_gaming        = ctx.user_activity == 'gaming'
        ctx.is_in_word       = any(x in a for x in ('word', 'winword'))
        ctx.is_in_spotify    = 'spotify' in a

        return ctx

    def _loop(self):
        while self._running:
            try:
                ctx = self._build()
                with self._lock:
                    self._prev = self._current
                    self._current = ctx
            except Exception as e:
                logger.debug(f"ActivityMonitor error: {e}")
            time.sleep(self._interval)

    def get_context(self) -> Optional[CurrentContext]:
        with self._lock:
            return self._current

    def context_changed(self) -> bool:
        with self._lock:
            c, p = self._current, self._prev
        if not c or not p:
            return True
        return (c.active_app != p.active_app or
                c.user_activity != p.user_activity)

    def to_dict(self) -> Dict:
        ctx = self.get_context()
        if not ctx:
            return {}
        return {
            'active_window': ctx.active_window,
            'active_app': ctx.active_app,
            'active_document': ctx.active_document,
            'user_activity': ctx.user_activity,
            'detected_mode': ctx.detected_mode,
            'time_of_day': ctx.time_of_day,
            'activity_duration_minutes': round(ctx.activity_duration_min, 1),
            'is_coding': ctx.is_coding,
            'is_browsing': ctx.is_browsing,
        }
