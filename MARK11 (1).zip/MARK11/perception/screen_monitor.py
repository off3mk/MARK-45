"""
MARK 10 — Screen Monitor
Lightweight screen state tracking (no OCR by default — on-demand only).

Creator: Ali (Sidi3Ali)
System: MARK 10
"""

import logging
import os
import time
from typing import Optional, Dict, Any

logger = logging.getLogger('MARK10.ScreenMonitor')

CACHE_DIR = os.path.join(os.path.dirname(os.path.dirname(__file__)), 'cache', 'screenshots')


class ScreenMonitor:
    """
    Screen monitoring with lazy evaluation.
    Screenshots and OCR are on-demand to minimize CPU usage.
    """

    def __init__(self):
        os.makedirs(CACHE_DIR, exist_ok=True)
        self._mss_ok = False
        self._pag_ok = False
        self._ocr_ok = False
        self._cv2_ok = False
        self._check_deps()

    def _check_deps(self):
        try:
            import mss; self._mss_ok = True
        except ImportError: pass
        try:
            import pyautogui; self._pag_ok = True
        except ImportError: pass
        try:
            import pytesseract
            pytesseract.get_tesseract_version()
            self._ocr_ok = True
        except Exception: pass
        try:
            import cv2; self._cv2_ok = True
        except ImportError: pass

    def capture(self, save: bool = False) -> Optional[Any]:
        """Capture full screen. Returns PIL Image."""
        if self._mss_ok:
            try:
                import mss
                from PIL import Image
                with mss.mss() as sct:
                    shot = sct.grab(sct.monitors[1])
                    img = Image.frombytes('RGB', shot.size, shot.bgra, 'raw', 'BGRX')
                    if save:
                        path = os.path.join(CACHE_DIR, f"screen_{int(time.time())}.png")
                        img.save(path)
                    return img
            except Exception: pass
        if self._pag_ok:
            try:
                import pyautogui
                return pyautogui.screenshot()
            except Exception: pass
        return None

    def screenshot(self, path: str = None) -> Optional[str]:
        """Save screenshot to file."""
        img = self.capture()
        if not img:
            return None
        if not path:
            path = os.path.join(CACHE_DIR, f"ss_{int(time.time())}.png")
        try:
            img.save(path)
            return path
        except Exception:
            return None

    def ocr(self, image=None) -> str:
        """Extract text from screen via OCR. On-demand only."""
        if not self._ocr_ok:
            return ''
        img = image or self.capture()
        if not img:
            return ''
        try:
            import pytesseract
            if self._cv2_ok:
                import cv2, numpy as np
                from PIL import Image as PILImage
                arr = np.array(img.convert('RGB'))
                gray = cv2.cvtColor(arr, cv2.COLOR_RGB2GRAY)
                _, thresh = cv2.threshold(gray, 0, 255, cv2.THRESH_BINARY + cv2.THRESH_OTSU)
                img = PILImage.fromarray(thresh)
            return pytesseract.image_to_string(img, lang='spa+eng', config='--oem 3 --psm 6')
        except Exception as e:
            logger.debug(f"OCR error: {e}")
            return ''

    def find_text_on_screen(self, query: str) -> Optional[tuple]:
        """Find text on screen, return (x, y) center or None."""
        if not self._ocr_ok:
            return None
        img = self.capture()
        if not img:
            return None
        try:
            import pytesseract
            data = pytesseract.image_to_data(img, output_type=pytesseract.Output.DICT)
            q = query.lower()
            for i, text in enumerate(data['text']):
                if q in text.lower() and int(data['conf'][i]) > 30:
                    x = data['left'][i] + data['width'][i] // 2
                    y = data['top'][i] + data['height'][i] // 2
                    return (x, y)
        except Exception:
            pass
        return None

    def describe(self) -> str:
        """Describe current screen content."""
        text = self.ocr()
        if not text:
            return 'Sin texto detectable en pantalla.'
        lines = [l.strip() for l in text.split('\n') if l.strip()]
        return ' | '.join(lines[:5])

    def get_status(self) -> Dict:
        return {
            'mss': self._mss_ok,
            'pyautogui': self._pag_ok,
            'ocr': self._ocr_ok,
            'cv2': self._cv2_ok,
        }
