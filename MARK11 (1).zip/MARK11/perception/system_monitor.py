"""
MARK 11 — System Monitor
Monitoreo eficiente de recursos del sistema.
CPU overhead objetivo: < 0.5%

Creator: Ali (Sidi3Ali)
System: MARK 11
"""

import logging
import time
import threading
import psutil
from typing import Optional, Dict, List, Callable
from dataclasses import dataclass, field

logger = logging.getLogger('MARK11.SysMonitor')


@dataclass
class SystemSnapshot:
    timestamp:      float = field(default_factory=time.time)
    cpu_percent:    float = 0.0
    ram_percent:    float = 0.0
    ram_used_gb:    float = 0.0
    ram_total_gb:   float = 0.0
    battery_percent:Optional[float] = None
    battery_charging:bool = False
    disk_percent:   float = 0.0
    disk_free_gb:   float = 0.0
    mark_ram_mb:    float = 0.0     # RAM usada por MARK 11 en MB
    top_process:    str   = ''

    def describe(self) -> str:
        parts = [f"CPU {self.cpu_percent:.0f}%", f"RAM {self.ram_percent:.0f}%"]
        if self.battery_percent is not None:
            s = "cargando" if self.battery_charging else f"{self.battery_percent:.0f}%"
            parts.append(f"Batería {s}")
        return " | ".join(parts)


class SystemMonitor:
    """
    Monitor de sistema MARK 11.
    Acepta poll_interval o brain para compatibilidad.
    """

    def __init__(self, brain=None, poll_interval: float = 5.0):
        self.brain = brain
        self._interval = poll_interval
        self._snapshot: Optional[SystemSnapshot] = None
        self._lock = threading.Lock()
        self._running = False
        self._thread: Optional[threading.Thread] = None
        self._callbacks: List[Callable] = []
        self._history: List[SystemSnapshot] = []
        self._max_history = 60
        self._prev_net = (0, 0)
        self._prev_net_time = time.time()
        self._mark_pid = None

        # Try to get MARK's own PID for accurate memory reporting
        try:
            self._mark_pid = psutil.Process().pid
        except Exception:
            pass

        # Initial snapshot
        self._snapshot = self._collect()

    def start(self):
        self._running = True
        self._thread = threading.Thread(
            target=self._loop,
            name='MARK11-SysMonitor',
            daemon=True
        )
        self._thread.start()
        logger.info("System Monitor iniciado.")

    def stop(self):
        self._running = False

    def add_callback(self, cb: Callable):
        self._callbacks.append(cb)

    def _collect(self) -> SystemSnapshot:
        snap = SystemSnapshot()
        try:
            snap.cpu_percent = psutil.cpu_percent(interval=None)
        except Exception:
            pass
        try:
            vm = psutil.virtual_memory()
            snap.ram_percent = vm.percent
            snap.ram_used_gb = vm.used / 1024**3
            snap.ram_total_gb = vm.total / 1024**3
        except Exception:
            pass
        try:
            bat = psutil.sensors_battery()
            if bat:
                snap.battery_percent = bat.percent
                snap.battery_charging = bat.power_plugged
        except Exception:
            pass
        try:
            disk = psutil.disk_usage('/')
            snap.disk_percent = disk.percent
            snap.disk_free_gb = disk.free / 1024**3
        except Exception:
            pass
        try:
            if self._mark_pid:
                proc = psutil.Process(self._mark_pid)
                snap.mark_ram_mb = proc.memory_info().rss / 1024**2
        except Exception:
            pass
        try:
            # Top CPU process (excluding MARK itself)
            top = max(
                (p for p in psutil.process_iter(['name', 'cpu_percent'])
                 if p.pid != self._mark_pid),
                key=lambda p: p.info['cpu_percent'] or 0,
                default=None
            )
            if top:
                snap.top_process = top.info['name'].replace('.exe','').lower()
        except Exception:
            pass
        return snap

    def _loop(self):
        while self._running:
            try:
                snap = self._collect()
                with self._lock:
                    self._snapshot = snap
                    self._history.append(snap)
                    if len(self._history) > self._max_history:
                        self._history.pop(0)
                for cb in self._callbacks:
                    try:
                        cb(snap)
                    except Exception:
                        pass
            except Exception as e:
                logger.debug(f"SysMonitor loop: {e}")
            time.sleep(self._interval)

    def get_snapshot(self) -> Optional[SystemSnapshot]:
        with self._lock:
            return self._snapshot

    def get_status(self) -> Dict:
        snap = self.get_snapshot()
        if not snap:
            return {}
        return {
            'cpu':          snap.cpu_percent,
            'ram_percent':  snap.ram_percent,
            'ram_gb':       round(snap.ram_used_gb, 1),
            'ram_total_gb': round(snap.ram_total_gb, 1),
            'battery':      snap.battery_percent,
            'charging':     snap.battery_charging,
            'disk_free_gb': round(snap.disk_free_gb, 1),
            'mark_ram_mb':  round(snap.mark_ram_mb, 0),
            'top_process':  snap.top_process,
        }

    def get_cpu(self) -> float:
        s = self.get_snapshot()
        return s.cpu_percent if s else 0.0

    def get_ram_percent(self) -> float:
        s = self.get_snapshot()
        return s.ram_percent if s else 0.0

    def describe(self) -> str:
        s = self.get_snapshot()
        return s.describe() if s else "Sin datos del sistema."
