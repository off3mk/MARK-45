#!/usr/bin/env python3
"""
MARK 11 — Fully Autonomous Cognitive System
Entry point.

Creator: Ali (Sidi3Ali)
System: MARK 11
"""

import sys
import os
import argparse
import logging
import time

# Setup paths
ROOT = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, ROOT)

# Create required dirs
for d in ['memory', 'logs', 'workspace', 'cache/tts', 'cache/screenshots',
          'cache/vision', 'skills/generated']:
    os.makedirs(os.path.join(ROOT, d), exist_ok=True)

logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s [%(name)s] %(levelname)s: %(message)s',
    handlers=[
        logging.FileHandler(os.path.join(ROOT, 'logs', 'mark11.log'), encoding='utf-8'),
        logging.StreamHandler(sys.stdout),
    ]
)
logger = logging.getLogger('MARK11')

BANNER = r"""
  ╔══════════════════════════════════════════════════════════╗
  ║      M A R K  1 0  —  Autonomous Cognitive System       ║
  ║          Optimizado para i5-9600K + RX 5700 XT          ║
  ║                 Creado por Ali (Sidi3Ali)                ║
  ╚══════════════════════════════════════════════════════════╝
"""


def start_gui():
    """Start with GUI interface."""
    try:
        from ui.interface import JarvisInterface
        from core.brain import Mark11Brain
        brain = Mark11Brain()
        brain.initialize()
        app = JarvisInterface(brain)
        app.run()
    except ImportError as e:
        logger.info(f"GUI no disponible ({e}), iniciando CLI.")
        start_cli()
    except Exception as e:
        logger.error(f"Error GUI: {e}", exc_info=True)
        start_cli()


def start_cli():
    """Start command-line interface."""
    from core.brain import Mark11Brain
    brain = Mark11Brain()
    brain.initialize()

    print(BANNER)
    print("  MARK 11 activo. Escribe tu comando o:")
    print("  'status'    — Estado completo")
    print("  'contexto'  — Contexto actual")
    print("  'lm'        — Estado de LM Studio")
    print("  'salir'     — Apagar MARK 11")
    print()

    while True:
        try:
            name = brain.get_name()
            user_input = input(f"  {name} → ").strip()
            if not user_input:
                continue

            cmd = user_input.lower()

            if cmd in ('salir', 'exit', 'quit', 'apagar'):
                brain.shutdown()
                break

            if cmd == 'status':
                s = brain.get_status()
                print(f"\n  [{s['system']}] {s['watermark']}")
                print(f"  Módulos activos: {s['modules_active']}")
                if s.get('ai'):
                    ai = s['ai']
                    print(f"  AI: {ai.get('active_source','?')} | {ai.get('lmstudio_model','?')}")
                if s.get('cognitive'):
                    cog = s['cognitive']
                    print(f"  Ciclos: {cog.get('cycles','?')} | Uptime: {cog.get('uptime_minutes','?'):.0f} min")
                print()
                continue

            if cmd == 'contexto':
                ctx = brain._get_context_dict()
                if ctx:
                    print("\n  [CONTEXTO]")
                    for k, v in ctx.items():
                        if v and k not in ('is_coding','is_writing','is_browsing',
                                            'is_watching','is_gaming','is_in_word',
                                            'is_in_spotify','is_in_discord','is_in_vscode','is_in_browser'):
                            print(f"    {k}: {v}")
                    print()
                else:
                    print("  Sin contexto disponible.\n")
                continue

            if cmd == 'lm':
                if brain.ai_manager:
                    s = brain.ai_manager.get_status()
                    print(f"\n  [LM Studio]")
                    print(f"    Estado: {'Activo' if s['lmstudio_available'] else 'Inactivo'}")
                    print(f"    Modelo: {s['lmstudio_model']}")
                    print(f"    Fuente activa: {s['active_source']}")
                    print(f"    Historial: {s['history_length']} mensajes")
                    print()
                    if not s['lmstudio_available']:
                        print("  Para activar LM Studio:")
                        print("    1. Descarga: https://lmstudio.ai")
                        print("    2. Carga un modelo")
                        print("    3. Activa el servidor local en puerto 1234")
                        print()
                continue

            response = brain.process_command(user_input)
            if response:
                print(f"\n  MARK 11 → {response}\n")

        except KeyboardInterrupt:
            print("\n  [Ctrl+C — escribe 'salir' para apagar]\n")
        except Exception as e:
            logger.error(f"CLI error: {e}")


def main():
    parser = argparse.ArgumentParser(description='MARK 11 — Autonomous Cognitive System')
    parser.add_argument('--cli', action='store_true', help='Modo consola (sin GUI)')
    parser.add_argument('--debug', action='store_true', help='Debug logging')
    args = parser.parse_args()

    if args.debug:
        logging.getLogger().setLevel(logging.DEBUG)

    if args.cli:
        start_cli()
    else:
        start_gui()


if __name__ == '__main__':
    main()
