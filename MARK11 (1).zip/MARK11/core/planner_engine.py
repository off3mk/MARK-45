"""
MARK 9 — Planner Engine
Goal-based task planning with dynamic adjustment on failure.

Creator: Ali (Sidi3Ali)
System: MARK 9
"""

import logging
import time
import json
import os
from typing import Optional, Dict, List, Any, Callable
from datetime import datetime
from dataclasses import dataclass, field

logger = logging.getLogger('MARK9.Planner')

PLANS_LOG = os.path.join(
    os.path.dirname(os.path.dirname(__file__)), 'memory', 'plans.json'
)


@dataclass
class PlanStep:
    """A single executable step in a plan."""
    id: int
    action: str
    skill: str               # Which skill/module to call
    params: Dict = field(default_factory=dict)
    reversible: bool = False
    status: str = 'pending'  # pending, running, done, failed, skipped
    result: str = ''
    started_at: float = 0.0
    completed_at: float = 0.0
    retry_count: int = 0
    max_retries: int = 2

    def to_dict(self) -> Dict:
        return {
            'id': self.id,
            'action': self.action,
            'skill': self.skill,
            'params': self.params,
            'status': self.status,
            'result': self.result,
        }


@dataclass
class Plan:
    """A complete plan for achieving a goal."""
    plan_id: str
    goal: str
    steps: List[PlanStep]
    created_at: str = field(default_factory=lambda: datetime.now().isoformat())
    status: str = 'created'  # created, running, done, failed, cancelled
    current_step: int = 0
    estimated_seconds: int = 30
    fallback: str = 'Reportar al usuario'
    context: Dict = field(default_factory=dict)
    completed_steps: List[int] = field(default_factory=list)
    failed_steps: List[int] = field(default_factory=list)
    notes: str = ''

    def get_current_step(self) -> Optional[PlanStep]:
        if self.current_step < len(self.steps):
            return self.steps[self.current_step]
        return None

    def advance(self, success: bool, result: str = ''):
        step = self.get_current_step()
        if step:
            step.status = 'done' if success else 'failed'
            step.result = result
            step.completed_at = time.time()
            if success:
                self.completed_steps.append(self.current_step)
                self.current_step += 1
            else:
                self.failed_steps.append(self.current_step)
                if step.retry_count < step.max_retries:
                    step.retry_count += 1
                    step.status = 'pending'
                else:
                    self.current_step += 1

    def is_complete(self) -> bool:
        return self.current_step >= len(self.steps)

    def success_rate(self) -> float:
        total = len(self.completed_steps) + len(self.failed_steps)
        return len(self.completed_steps) / total if total > 0 else 1.0

    def to_dict(self) -> Dict:
        return {
            'plan_id': self.plan_id,
            'goal': self.goal,
            'status': self.status,
            'steps': [s.to_dict() for s in self.steps],
            'current_step': self.current_step,
            'created_at': self.created_at,
            'success_rate': self.success_rate(),
        }


class GoalParser:
    """Parse natural language goals into structured step lists."""

    # Pre-defined goal templates for common tasks
    GOAL_TEMPLATES = {
        'work_environment': {
            'steps': [
                {'action': 'Open VSCode', 'skill': 'app_launcher', 'params': {'app': 'code'}},
                {'action': 'Open browser', 'skill': 'app_launcher', 'params': {'app': 'chrome'}},
                {'action': 'Open Spotify', 'skill': 'app_launcher', 'params': {'app': 'spotify'}},
                {'action': 'Set volume 30%', 'skill': 'system', 'params': {'action': 'set_volume', 'level': 30}},
            ],
            'estimated_seconds': 20,
        },
        'prepare_presentation': {
            'steps': [
                {'action': 'Open PowerPoint', 'skill': 'app_launcher', 'params': {'app': 'powerpnt'}},
                {'action': 'Open browser for research', 'skill': 'app_launcher', 'params': {'app': 'chrome'}},
                {'action': 'Mute audio', 'skill': 'system', 'params': {'action': 'mute'}},
            ],
            'estimated_seconds': 15,
        },
        'focus_mode': {
            'steps': [
                {'action': 'Close non-essential apps', 'skill': 'system', 'params': {'action': 'close_leisure_apps'}},
                {'action': 'Set low volume', 'skill': 'system', 'params': {'action': 'set_volume', 'level': 20}},
            ],
            'estimated_seconds': 10,
        },
        'gaming_setup': {
            'steps': [
                {'action': 'Open Steam', 'skill': 'app_launcher', 'params': {'app': 'steam'}},
                {'action': 'Set volume high', 'skill': 'system', 'params': {'action': 'set_volume', 'level': 70}},
                {'action': 'Set performance mode', 'skill': 'system', 'params': {'action': 'performance_mode'}},
            ],
            'estimated_seconds': 15,
        },
        'send_message': {
            'steps': [
                {'action': 'Focus communication app', 'skill': 'ui_control', 'params': {'action': 'focus_app', 'app': '{app}'}},
                {'action': 'Send message', 'skill': 'ui_control', 'params': {'action': 'send_message', 'contact': '{contact}', 'text': '{message}'}},
            ],
            'estimated_seconds': 8,
        },
    }

    KEYWORDS_TO_TEMPLATE = {
        'entorno de trabajo': 'work_environment',
        'work environment': 'work_environment',
        'modo trabajo': 'work_environment',
        'configurar trabajo': 'work_environment',
        'preparar presentación': 'prepare_presentation',
        'prepare presentation': 'prepare_presentation',
        'modo enfoque': 'focus_mode',
        'focus mode': 'focus_mode',
        'modo juego': 'gaming_setup',
        'gaming setup': 'gaming_setup',
    }

    def parse(self, goal: str) -> Optional[Dict]:
        """Parse goal string into template or return None for LLM planning."""
        goal_lower = goal.lower().strip()

        for keyword, template_key in self.KEYWORDS_TO_TEMPLATE.items():
            if keyword in goal_lower:
                template = self.GOAL_TEMPLATES.get(template_key, {})
                return {
                    'template': template_key,
                    'steps': template.get('steps', []),
                    'estimated_seconds': template.get('estimated_seconds', 30),
                }

        return None  # Needs LLM planning

    def parse_from_llm(self, llm_output: Dict, goal: str) -> List[PlanStep]:
        """Convert LLM-generated plan to PlanStep list."""
        steps = []
        raw_steps = llm_output.get('steps', [])

        for i, raw in enumerate(raw_steps):
            step = PlanStep(
                id=i + 1,
                action=raw.get('action', f'Step {i+1}'),
                skill=raw.get('skill', 'ai'),
                params=raw.get('params', {}),
                reversible=raw.get('reversible', False),
            )
            steps.append(step)

        if not steps:
            steps = [PlanStep(
                id=1,
                action=goal,
                skill='ai',
                params={'prompt': goal},
                reversible=False,
            )]

        return steps


class StepExecutor:
    """Execute individual plan steps using the available MARK 9 systems."""

    def __init__(self, brain=None):
        self.brain = brain

    def execute(self, step: PlanStep, plan: Plan) -> bool:
        """Execute a single plan step. Returns True if successful."""
        step.status = 'running'
        step.started_at = time.time()
        logger.info(f"Executing plan step {step.id}: {step.action} ({step.skill})")

        try:
            result = self._dispatch(step, plan)
            if result is not None:
                step.result = str(result)
                return True
        except Exception as e:
            step.result = f"Error: {e}"
            logger.debug(f"Step {step.id} failed: {e}")

        return False

    def _dispatch(self, step: PlanStep, plan: Plan) -> Any:
        """Dispatch step to appropriate skill/module."""
        skill = step.skill.lower()
        params = step.params

        # App launching
        if skill in ('app_launcher', 'apps'):
            return self._launch_app(params)

        # System actions
        if skill == 'system':
            return self._system_action(params)

        # UI control
        if skill in ('ui_control', 'ui', 'ui_automation'):
            return self._ui_action(params)

        # AI / LLM
        if skill in ('ai', 'llm', 'chat'):
            return self._ai_action(params)

        # Web
        if skill in ('web', 'browser', 'internet'):
            return self._web_action(params)

        # Music
        if skill in ('spotify', 'music', 'media'):
            return self._media_action(params)

        # Memory
        if skill == 'memory':
            return self._memory_action(params)

        # Generic command
        return self._generic_action(step)

    def _launch_app(self, params: Dict) -> str:
        app = params.get('app', '')
        if not app:
            return 'Sin app especificada.'
        try:
            import subprocess
            subprocess.Popen([app], shell=True)
            time.sleep(1)
            return f"App {app} iniciada."
        except Exception as e:
            return f"Error lanzando {app}: {e}"

    def _system_action(self, params: Dict) -> str:
        action = params.get('action', '')
        if self.brain and self.brain.skill_manager:
            try:
                return self.brain.skill_manager.execute('system', action, params)
            except Exception:
                pass
        if action == 'set_volume':
            level = params.get('level', 50)
            try:
                from ctypes import cast, POINTER
                from comtypes import CLSCTX_ALL
                from pycaw.pycaw import AudioUtilities, IAudioEndpointVolume
                devices = AudioUtilities.GetSpeakers()
                interface = devices.Activate(IAudioEndpointVolume._iid_, CLSCTX_ALL, None)
                volume = cast(interface, POINTER(IAudioEndpointVolume))
                volume.SetMasterVolumeLevelScalar(level / 100.0, None)
                return f"Volumen al {level}%."
            except Exception:
                return f"Volumen: no se pudo ajustar (pycaw no disponible)."
        return f"Acción de sistema: {action}"

    def _ui_action(self, params: Dict) -> str:
        action = params.get('action', '')
        if self.brain and hasattr(self.brain, 'ui_automation') and self.brain.ui_automation:
            ua = self.brain.ui_automation
            if action == 'focus_app':
                return ua.focus_window(params.get('app', ''))
            if action == 'send_message':
                app = params.get('app', 'whatsapp')
                if 'whatsapp' in app.lower():
                    return ua.send_whatsapp(params.get('contact', ''), params.get('text', ''))
                if 'discord' in app.lower():
                    return ua.send_discord(params.get('channel', ''), params.get('text', ''))
        return f"UI action: {action}"

    def _ai_action(self, params: Dict) -> str:
        prompt = params.get('prompt', params.get('text', ''))
        if self.brain and hasattr(self.brain, 'llm_engine') and self.brain.llm_engine:
            return self.brain.llm_engine.generate_response(prompt)
        if self.brain and self.brain.ai_manager:
            return self.brain.ai_manager.ask(prompt)
        return f"AI: {prompt}"

    def _web_action(self, params: Dict) -> str:
        url = params.get('url', '')
        if url and self.brain and hasattr(self.brain, 'ui_automation') and self.brain.ui_automation:
            return self.brain.ui_automation.open_url(url)
        return f"Web: {url}"

    def _media_action(self, params: Dict) -> str:
        action = params.get('action', 'play')
        if self.brain and hasattr(self.brain, '_spotify') and self.brain._spotify:
            try:
                sp = self.brain._spotify
                if action == 'play':
                    sp.play()
                elif action == 'pause':
                    sp.pause()
                elif action == 'next':
                    sp.next_track()
                return f"Spotify: {action}"
            except Exception:
                pass
        return f"Media: {action}"

    def _memory_action(self, params: Dict) -> str:
        action = params.get('action', 'save')
        key = params.get('key', '')
        value = params.get('value', '')
        if self.brain and self.brain.memory and action == 'save':
            try:
                self.brain.memory.save_knowledge(key, value)
                return f"Guardado: {key}"
            except Exception:
                pass
        return f"Memory: {action}"

    def _generic_action(self, step: PlanStep) -> str:
        logger.info(f"Generic step execution: {step.action}")
        return f"Ejecutado: {step.action}"


class PlannerEngine:
    """
    MARK 9 — Planner Engine.
    Converts natural language goals into executable step-by-step plans.
    Dynamically adjusts based on failures. Uses LLM for complex goals.
    """

    def __init__(self, brain=None):
        self.brain = brain
        self._parser = GoalParser()
        self._executor = StepExecutor(brain=brain)
        self._active_plan: Optional[Plan] = None
        self._completed_plans: List[Dict] = []
        self._plan_counter = 0

        self._load_history()

    def _load_history(self):
        try:
            if os.path.exists(PLANS_LOG):
                with open(PLANS_LOG, 'r', encoding='utf-8') as f:
                    data = json.load(f)
                    self._completed_plans = data.get('plans', [])
        except Exception:
            pass

    def _save_plan(self, plan: Plan):
        try:
            os.makedirs(os.path.dirname(PLANS_LOG), exist_ok=True)
            self._completed_plans.append(plan.to_dict())
            with open(PLANS_LOG, 'w', encoding='utf-8') as f:
                json.dump({
                    'plans': self._completed_plans[-50:],
                    'updated': datetime.now().isoformat(),
                }, f, indent=2, ensure_ascii=False)
        except Exception:
            pass

    def create_plan(self, goal: str, context: Dict = None) -> Plan:
        """
        Create an executable plan for the given goal.
        Uses template matching first, then LLM for complex goals.
        """
        self._plan_counter += 1
        plan_id = f"plan_{self._plan_counter}_{int(time.time())}"

        # Try template matching
        template_result = self._parser.parse(goal)
        steps = []

        if template_result:
            raw_steps = template_result.get('steps', [])
            for i, raw in enumerate(raw_steps):
                # Fill template variables from context/goal
                params = self._fill_params(raw.get('params', {}), goal, context or {})
                steps.append(PlanStep(
                    id=i + 1,
                    action=raw.get('action', f'Step {i+1}'),
                    skill=raw.get('skill', 'system'),
                    params=params,
                    reversible=raw.get('reversible', False),
                ))
            estimated = template_result.get('estimated_seconds', 30)
            fallback = 'Usar método manual'
        else:
            # Use LLM for complex goals
            estimated = 30
            fallback = 'Reportar al usuario'

            if self.brain and hasattr(self.brain, 'llm_engine') and self.brain.llm_engine:
                try:
                    llm_plan = self.brain.llm_engine.generate_plan(goal, context)
                    steps = self._parser.parse_from_llm(llm_plan, goal)
                    estimated = llm_plan.get('estimated_duration_seconds', 30)
                    fallback = llm_plan.get('fallback', 'Reportar al usuario')
                except Exception as e:
                    logger.debug(f"LLM planning error: {e}")

            if not steps:
                # Simple fallback plan
                steps = [PlanStep(
                    id=1,
                    action=goal,
                    skill='ai',
                    params={'prompt': goal},
                    reversible=False,
                )]

        plan = Plan(
            plan_id=plan_id,
            goal=goal,
            steps=steps,
            estimated_seconds=estimated,
            fallback=fallback,
            context=context or {},
        )

        logger.info(f"Plan creado: '{goal}' ({len(steps)} pasos)")
        return plan

    def _fill_params(self, params: Dict, goal: str, context: Dict) -> Dict:
        """Fill template variables in params."""
        result = {}
        for k, v in params.items():
            if isinstance(v, str):
                v = v.replace('{goal}', goal)
                v = v.replace('{app}', context.get('active_app', ''))
                for ctx_k, ctx_v in context.items():
                    v = v.replace(f'{{{ctx_k}}}', str(ctx_v))
            result[k] = v
        return result

    def execute_plan(self, plan: Plan, callback: Callable = None) -> Dict:
        """
        Execute a plan step by step.
        callback(step, success, result) called after each step.
        Returns execution summary.
        """
        self._active_plan = plan
        plan.status = 'running'

        logger.info(f"Ejecutando plan: '{plan.goal}'")

        results = []
        while not plan.is_complete():
            step = plan.get_current_step()
            if not step:
                break

            success = self._executor.execute(step, plan)
            plan.advance(success, step.result)

            result_entry = {
                'step': step.id,
                'action': step.action,
                'success': success,
                'result': step.result,
            }
            results.append(result_entry)

            if callback:
                try:
                    callback(step, success, step.result)
                except Exception:
                    pass

            # Small delay between steps
            time.sleep(0.5)

        plan.status = 'done' if plan.success_rate() >= 0.5 else 'failed'

        summary = {
            'plan_id': plan.plan_id,
            'goal': plan.goal,
            'status': plan.status,
            'steps_total': len(plan.steps),
            'steps_done': len(plan.completed_steps),
            'steps_failed': len(plan.failed_steps),
            'success_rate': plan.success_rate(),
            'results': results,
        }

        self._save_plan(plan)
        self._active_plan = None

        logger.info(f"Plan completado: {plan.goal} | éxito: {plan.success_rate():.0%}")
        return summary

    def run_goal(self, goal: str, context: Dict = None,
                  speak_progress: bool = True) -> str:
        """
        High-level: create + execute plan for a goal.
        Returns natural language summary.
        """
        plan = self.create_plan(goal, context)

        total_steps = len(plan.steps)
        completed = 0

        def on_step(step, success, result):
            nonlocal completed
            if success:
                completed += 1
            if speak_progress and self.brain and self.brain.voice and total_steps > 2:
                try:
                    msg = f"Paso {step.id} de {total_steps}: {step.action}."
                    if not success:
                        msg += " Falló."
                    self.brain.voice.speak(msg, priority=False)
                except Exception:
                    pass

        summary = self.execute_plan(plan, callback=on_step)

        if summary['status'] == 'done':
            return (f"Plan '{goal}' completado: "
                    f"{summary['steps_done']}/{summary['steps_total']} pasos exitosos.")
        else:
            return (f"Plan '{goal}' falló en {summary['steps_failed']} pasos. "
                    f"Fallback: {plan.fallback}")

    def get_active_plan(self) -> Optional[Plan]:
        return self._active_plan

    def has_active_plan(self) -> bool:
        return self._active_plan is not None

    def get_history(self, n: int = 10) -> List[Dict]:
        return self._completed_plans[-n:]

    def get_status(self) -> Dict:
        return {
            'active_plan': self._active_plan.to_dict() if self._active_plan else None,
            'total_plans': self._plan_counter,
            'completed_plans': len(self._completed_plans),
        }
