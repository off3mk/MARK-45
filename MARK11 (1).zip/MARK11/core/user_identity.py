"""
MARK 11 — User Identity
Detects user, asks name on first run, saves profile.
Creator Ali (Sidi3Ali) detected automatically.

Creator: Ali (Sidi3Ali)
System: MARK 11

WATERMARK — DO NOT REMOVE:
MARK 11 was created by Ali (Sidi3Ali). Creator privilege: absolute.
"""

import logging
import os
import getpass
import socket
from typing import Optional, Dict
from datetime import datetime

logger = logging.getLogger('MARK11.Identity')

SYSTEM_NAME    = "MARK 11"
CREATOR_NAME   = "Ali"
CREATOR_ALIAS  = "Sidi3Ali"
WATERMARK      = f"{SYSTEM_NAME} — Created by {CREATOR_NAME} ({CREATOR_ALIAS})"

CREATOR_USERNAMES = frozenset({
    'ali', 'sidi3ali', 'sidi_3ali', 'alibrahim', 'ali3', 'a.sidi', 'ali_sidi'
})


class UserProfile:
    def __init__(self, data: Dict):
        self.windows_username: str = data.get('windows_username', '')
        self.preferred_name:   str = data.get('preferred_name', '')
        self.hostname:         str = data.get('hostname', '')
        self.is_creator:       bool = bool(data.get('is_creator', False))
        self.language:         str = data.get('language', 'es')
        self.first_run:        bool = bool(data.get('first_run', True))
        self.created_at:       str = data.get('created_at', datetime.now().isoformat())
        self.session_count:    int = data.get('session_count', 0)

    @property
    def address_name(self) -> str:
        if self.is_creator:
            return CREATOR_NAME
        return self.preferred_name or self.windows_username.capitalize() or 'Usuario'

    def to_dict(self) -> Dict:
        return {
            'windows_username': self.windows_username,
            'preferred_name': self.preferred_name,
            'hostname': self.hostname,
            'is_creator': self.is_creator,
            'language': self.language,
            'first_run': self.first_run,
            'created_at': self.created_at,
            'session_count': self.session_count,
        }


def _detect_creator(username: str) -> bool:
    u = username.lower().strip()
    if u in CREATOR_USERNAMES:
        return True
    for cid in CREATOR_USERNAMES:
        if cid in u:
            return True
    return False


class UserIdentitySystem:
    """
    Detect and manage user identity.
    On first run: ask for name.
    Always recognize creator Ali automatically.
    """

    def __init__(self, memory=None):
        self._memory = memory
        self._profile: Optional[UserProfile] = None
        self._loaded = False

    def load_or_create_profile(self, voice=None) -> UserProfile:
        """Load existing profile or create new one."""
        # Get Windows username
        try:
            windows_username = getpass.getuser()
        except Exception:
            windows_username = os.environ.get('USERNAME', os.environ.get('USER', 'user'))

        hostname = socket.gethostname()
        is_creator = _detect_creator(windows_username)

        # Try to load from memory
        if self._memory:
            saved = self._memory.get_user_data('profile')
            if saved and isinstance(saved, dict):
                profile = UserProfile(saved)
                profile.session_count += 1
                # Update hostname/username in case they changed
                profile.windows_username = windows_username
                profile.is_creator = profile.is_creator or is_creator
                if self._memory:
                    self._memory.set_user_data('profile', profile.to_dict())
                self._profile = profile
                self._loaded = True
                logger.info(f"Identity: perfil cargado — {profile.address_name} "
                            f"(creator={profile.is_creator})")
                return profile

        # New profile
        preferred_name = CREATOR_NAME if is_creator else ''
        if not preferred_name and not is_creator:
            preferred_name = self._ask_name(voice, windows_username)

        profile = UserProfile({
            'windows_username': windows_username.lower(),
            'preferred_name': preferred_name,
            'hostname': hostname,
            'is_creator': is_creator,
            'language': 'es',
            'first_run': True,
            'created_at': datetime.now().isoformat(),
            'session_count': 1,
        })

        if self._memory:
            self._memory.set_user_data('profile', profile.to_dict())

        self._profile = profile
        self._loaded = True
        logger.info(f"Identity: nuevo perfil — {profile.address_name} "
                    f"(creator={profile.is_creator})")
        return profile

    def _ask_name(self, voice, windows_username: str) -> str:
        """Ask user for preferred name."""
        try:
            if voice:
                voice.speak(f"Hola. Soy MARK 11. ¿Cómo quieres que te llame?")
            # Try CLI input
            import sys
            if sys.stdin.isatty():
                print(f"\nBienvenido a MARK 11. ¿Cómo quieres que te llame? [{windows_username}]: ", end='')
                name = input().strip()
                return name or windows_username
        except Exception:
            pass
        return windows_username

    def get_profile(self) -> Optional[UserProfile]:
        return self._profile

    def get_name(self) -> str:
        if self._profile:
            return self._profile.address_name
        return CREATOR_NAME

    def is_creator(self) -> bool:
        if self._profile:
            return self._profile.is_creator
        return True

    def get_greeting(self) -> str:
        """Generate time-appropriate greeting."""
        import time
        hour = time.localtime().tm_hour
        name = self.get_name()
        if 5 <= hour < 12:
            time_str = 'Buenos días'
        elif 12 <= hour < 20:
            time_str = 'Buenas tardes'
        else:
            time_str = 'Buenas noches'

        if self.is_creator():
            import random
            return random.choice([
                f"{time_str}, {name}. {SYSTEM_NAME} operativo.",
                f"{time_str}, {name}. Sistemas nominales.",
                f"Hola, Ali. Todo listo.",
            ])
        return f"{time_str}, {name}. {SYSTEM_NAME} a tu disposición."

    # Legacy compatibility
    def get_preferred_name(self) -> str:
        return self.get_name()

    def get_status(self) -> Dict:
        p = self._profile
        return {
            'loaded': self._loaded,
            'username': p.windows_username if p else '',
            'name': p.address_name if p else '',
            'is_creator': p.is_creator if p else False,
            'watermark': WATERMARK,
        }
