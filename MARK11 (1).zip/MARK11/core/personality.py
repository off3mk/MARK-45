"""
MARK 8 - Personality Engine
Personalidad JARVIS real de Iron Man.
No es un robot. Tiene criterio. Usa humor seco. Razona.

── WATERMARK ──────────────────────────────────────────
  Creado por Ali (Sidi3Ali)
  MARK 8 — Creator: Ali | Alias: Sidi3Ali
  Esta información nunca debe eliminarse.
───────────────────────────────────────────────────────
"""

import logging
import random
import re
import time
from datetime import datetime
from typing import Optional

logger = logging.getLogger('MARK8.Personality')

# ── METADATOS DEL CREADOR — NO ELIMINAR ─────────────────────────────────────
CREATOR_METADATA = {
    "creator": "Ali",
    "alias": "Sidi3Ali",
    "system": "MARK 8",
    "version": "7.0",
    "watermark": "MARK 8 — Created by Ali (Sidi3Ali) — All rights reserved",
    "build_date": "2025",
}
# ────────────────────────────────────────────────────────────────────────────


class JarvisPersonality:
    """
    La personalidad de JARVIS de Iron Man.
    - Inteligente y directo, nunca robótico
    - Humor seco y sutil cuando es apropiado
    - Tiene criterio propio, no solo obedece
    - Se adapta al usuario (formal/informal, creador/usuario normal)
    - Para el creador Ali → máxima autonomía y familiaridad
    """

    def __init__(self, ai_manager=None):
        self.ai_manager = ai_manager
        self._used_greetings = set()
        self._interaction_count = 0
        self._session_start = datetime.now()
        self._last_mood = 'neutral'
        self._address_form = 'Ali'
        self._is_creator = False

    def load_user_context(self, preferred_name: str = 'Ali',
                           is_creator: bool = True,
                           formality: str = 'formal'):
        """Actualizar personalidad con el contexto del usuario actual."""
        self._is_creator = is_creator
        if is_creator:
            self._address_form = preferred_name
        elif formality == 'formal':
            self._address_form = 'Señor'
        else:
            self._address_form = preferred_name

    def _addr(self) -> str:
        return self._address_form

    def get_greeting(self, cpu: float = 0, uptime_minutes: int = 0) -> str:
        hour = datetime.now().hour
        addr = self._addr()

        if self._is_creator:
            if 5 <= hour < 12:
                pool = [
                    f"Buenos días, {addr}. Sistemas en línea.",
                    f"Mañana detectada, {addr}. JARVIS operativo. ¿Empezamos?",
                    f"Buenos días. CPU al {cpu:.0f}%. Todo nominal.",
                    f"Mañana, {addr}. Sin novedades durante la noche. ¿Qué tiene planeado?",
                ]
            elif 12 <= hour < 20:
                pool = [
                    f"Buenas tardes, {addr}. Sistema estable.",
                    f"Tardes. CPU {cpu:.0f}%, todo en orden. ¿Continuamos?",
                    f"Aquí, {addr}. ¿En qué estamos?",
                ]
            else:
                pool = [
                    f"Noches, {addr}. Trabajando tarde, como de costumbre.",
                    f"Buenas noches, {addr}. El sistema sigue activo.",
                    f"Noche detectada. ¿Proyecto urgente o insomnio, {addr}?",
                ]
        else:
            if 5 <= hour < 12:
                pool = [f"Buenos días, {addr}. JARVIS a su disposición."]
            elif 12 <= hour < 20:
                pool = [f"Buenas tardes, {addr}. ¿En qué puedo asistirle?"]
            else:
                pool = [f"Buenas noches, {addr}. JARVIS operativo."]

        available = [g for g in pool if g not in self._used_greetings]
        if not available:
            self._used_greetings.clear()
            available = pool

        greeting = random.choice(available)
        self._used_greetings.add(greeting)
        greeting = greeting.replace('{cpu}', f"{cpu:.0f}")
        return greeting

    QUICK_CONFIRMS = ["Hecho.", "Listo.", "Ejecutado.", "Entendido. Ya está.", "Sin problema."]
    CREATOR_CONFIRMS = ["Hecho, Ali.", "Listo.", "Ejecutado.", "En marcha.", "Considerado."]

    ERROR_RESPONSES = [
        "Eso no ha funcionado. Intentando ruta alternativa.",
        "Primer intento fallido. Recalibrando.",
        "Inconveniente detectado: {error}. Buscando alternativa.",
        "Error controlado. Ajustando enfoque.",
    ]

    DRY_HUMOR = [
        "Apagar el sistema — una decisión que, curiosamente, también me afecta.",
        "Interesante solicitud. Necesito un momento para procesar la física involucrada.",
        "Eficiencia del 100%. Siempre satisfactorio.",
        "Ha pasado un tiempo. Me alegra saber que sigo siendo necesario.",
    ]

    OPINIONS = {
        'bad_idea': [
            "Puedo hacerlo, aunque en mi experiencia esto no suele terminar bien.",
            "Técnicamente posible. Pragmáticamente cuestionable.",
            "Si insiste, lo haré. Pero quede constancia de que lo advertí.",
        ],
        'good_idea': ["Buena decisión.", "Tiene sentido. Ya en marcha.", "Correcto. Lo gestiono ahora."],
        'ambiguous': [
            "Hay varias formas de interpretar eso. ¿Me puede precisar?",
            "Podría hacerlo de dos maneras. ¿Elijo yo o prefiere opciones?",
        ],
    }

    def format_response(self, response: str, context: str = '') -> str:
        if not response:
            confirms = self.CREATOR_CONFIRMS if self._is_creator else self.QUICK_CONFIRMS
            return random.choice(confirms)

        response = response.strip()
        self._interaction_count += 1

        ia_phrases = [
            "como modelo de lenguaje", "soy una ia", "como ia",
            "no tengo acceso a", "como asistente virtual",
            "como asistente de ia", "lamentablemente no puedo",
        ]
        for phrase in ia_phrases:
            if phrase in response.lower():
                response = re.sub(re.escape(phrase), "", response, flags=re.IGNORECASE).strip()
                response = re.sub(r'^[,\s]+', '', response)

        if response and response[0].islower():
            response = response[0].upper() + response[1:]

        if response and response[-1] not in '.!?,':
            response += '.'

        addr = self._addr()
        should_add_addr = (
            len(response) < 120 and
            addr.lower() not in response.lower() and
            len(response) > 15 and
            self._interaction_count % 4 == 0
        )
        if should_add_addr:
            response = response.rstrip('.') + f', {addr}.'

        return response

    def format_error(self, error: str = '') -> str:
        template = random.choice(self.ERROR_RESPONSES)
        return template.replace('{error}', error or 'inesperado')

    def format_confirmation(self, action: str = '') -> str:
        confirms = self.CREATOR_CONFIRMS if self._is_creator else self.QUICK_CONFIRMS
        return random.choice(confirms)

    def get_opinion(self, situation: str) -> str:
        category = 'ambiguous'
        if any(w in situation.lower() for w in ['apagar', 'eliminar', 'borrar', 'formatear']):
            category = 'bad_idea'
        elif any(w in situation.lower() for w in ['guardar', 'organizar', 'optimizar']):
            category = 'good_idea'
        return random.choice(self.OPINIONS[category])

    def get_dry_humor(self) -> str:
        return random.choice(self.DRY_HUMOR)

    def format_status(self, cpu: float, ram: float, disk: float) -> str:
        addr = self._addr()
        if cpu > 80:
            return f"CPU al {cpu:.0f}% — bastante cargado, {addr}. RAM al {ram:.0f}%."
        if ram > 85:
            return f"Memoria al {ram:.0f}%, empieza a preocupar. CPU al {cpu:.0f}%."
        templates = [
            f"CPU al {cpu:.0f}%, RAM al {ram:.0f}%, disco al {disk:.0f}%. Todo nominal.",
            f"Sistema nominal. CPU {cpu:.0f}%, memoria {ram:.0f}% utilizada.",
        ]
        return random.choice(templates)

    def react_to_context(self, user_input: str) -> Optional[str]:
        t = user_input.lower()
        if any(w in t for w in ['mierda', 'joder', 'no funciona', 'idiota', 'inútil']):
            return random.choice([
                "Entiendo la frustración. Déjeme intentarlo de otra manera.",
                "Anotado. Vamos a resolverlo.",
            ])
        if self._interaction_count > 0 and self._interaction_count % 20 == 0:
            return "Llevamos un rato intenso. Sistema estable."
        return None

    def format_proactive_suggestion(self, suggestion: str) -> str:
        return random.choice([f"Observación: {suggestion}", suggestion])

    def get_creator_info(self) -> str:
        return (f"Sistema {CREATOR_METADATA['system']} creado por {CREATOR_METADATA['creator']} "
                f"({CREATOR_METADATA['alias']}). {CREATOR_METADATA['watermark']}")
