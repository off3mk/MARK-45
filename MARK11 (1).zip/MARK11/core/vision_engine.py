"""
MARK 9 — Vision Engine
Full screen perception: capture, OCR, UI element detection, visual context.

Creator: Ali (Sidi3Ali)
System: MARK 9
"""

import logging
import os
import time
import threading
from typing import Optional, List, Dict, Any, Tuple
from dataclasses import dataclass, field
from datetime import datetime

logger = logging.getLogger('MARK9.Vision')


@dataclass
class VisualElement:
    """A detected UI element in the screen."""
    element_type: str       # button, text, input, image, link
    text: str
    bbox: Tuple[int, int, int, int]   # x, y, w, h
    confidence: float = 1.0
    center: Tuple[int, int] = field(default_factory=tuple)

    def __post_init__(self):
        if not self.center and self.bbox:
            x, y, w, h = self.bbox
            self.center = (x + w // 2, y + h // 2)


@dataclass
class VisualContext:
    """Structured visual context from the current screen state."""
    timestamp: str = field(default_factory=lambda: datetime.now().isoformat())
    screenshot_path: str = ''
    active_window: str = ''

    # OCR results
    full_text: str = ''
    text_blocks: List[Dict] = field(default_factory=list)

    # UI elements
    buttons: List[VisualElement] = field(default_factory=list)
    text_fields: List[VisualElement] = field(default_factory=list)
    links: List[VisualElement] = field(default_factory=list)
    all_elements: List[VisualElement] = field(default_factory=list)

    # High-level analysis
    detected_app_type: str = ''       # ide, browser, office, terminal, chat
    primary_language: str = 'es'
    has_error_messages: bool = False
    error_texts: List[str] = field(default_factory=list)
    has_notifications: bool = False

    # Image info
    width: int = 0
    height: int = 0

    def get_text_summary(self) -> str:
        """Get short text summary of what's visible."""
        if not self.full_text:
            return 'Pantalla sin texto detectable.'
        lines = [l.strip() for l in self.full_text.split('\n') if l.strip()]
        return ' | '.join(lines[:5])

    def find_text(self, query: str) -> Optional[VisualElement]:
        """Find the first element containing query text."""
        q = query.lower()
        for el in self.all_elements:
            if q in el.text.lower():
                return el
        return None

    def to_dict(self) -> Dict:
        return {
            'timestamp': self.timestamp,
            'active_window': self.active_window,
            'full_text_preview': self.full_text[:300] if self.full_text else '',
            'buttons_count': len(self.buttons),
            'text_fields_count': len(self.text_fields),
            'detected_app_type': self.detected_app_type,
            'has_error': self.has_error_messages,
            'width': self.width,
            'height': self.height,
        }


class ScreenCapture:
    """Screen capture using mss (fast) or pyautogui (fallback)."""

    def __init__(self):
        self._mss_ok = False
        self._pag_ok = False
        self._capture_dir = os.path.join(
            os.path.dirname(os.path.dirname(__file__)), 'cache', 'vision'
        )
        os.makedirs(self._capture_dir, exist_ok=True)
        self._check()

    def _check(self):
        try:
            import mss
            self._mss_ok = True
        except ImportError:
            pass
        try:
            import pyautogui
            self._pag_ok = True
        except ImportError:
            pass

    def capture_full(self, save: bool = False) -> Optional[Any]:
        """Capture full screen. Returns PIL Image or numpy array."""
        # Method 1: mss (fastest)
        if self._mss_ok:
            try:
                import mss
                from PIL import Image
                with mss.mss() as sct:
                    monitor = sct.monitors[1]  # Primary monitor
                    shot = sct.grab(monitor)
                    img = Image.frombytes('RGB', shot.size, shot.bgra, 'raw', 'BGRX')
                    if save:
                        path = os.path.join(self._capture_dir,
                                            f"screen_{int(time.time())}.png")
                        img.save(path)
                    return img
            except Exception as e:
                logger.debug(f"mss capture error: {e}")

        # Method 2: pyautogui
        if self._pag_ok:
            try:
                import pyautogui
                img = pyautogui.screenshot()
                return img
            except Exception as e:
                logger.debug(f"pyautogui capture error: {e}")

        return None

    def capture_window(self, window_title: str) -> Optional[Any]:
        """Capture a specific window by title."""
        try:
            import win32gui
            import win32ui
            import win32con
            from PIL import Image

            hwnd = None
            def find_window(h, _):
                nonlocal hwnd
                if window_title.lower() in win32gui.GetWindowText(h).lower():
                    hwnd = h
            win32gui.EnumWindows(find_window, None)

            if not hwnd:
                return self.capture_full()

            left, top, right, bottom = win32gui.GetWindowRect(hwnd)
            w, h = right - left, bottom - top
            if w <= 0 or h <= 0:
                return None

            hwndDC = win32gui.GetWindowDC(hwnd)
            mfcDC = win32ui.CreateDCFromHandle(hwndDC)
            saveDC = mfcDC.CreateCompatibleDC()
            saveBitMap = win32ui.CreateBitmap()
            saveBitMap.CreateCompatibleBitmap(mfcDC, w, h)
            saveDC.SelectObject(saveBitMap)
            saveDC.BitBlt((0, 0), (w, h), mfcDC, (0, 0), win32con.SRCCOPY)
            bmpinfo = saveBitMap.GetInfo()
            bmpstr = saveBitMap.GetBitmapBits(True)
            img = Image.frombuffer('RGB', (bmpinfo['bmWidth'], bmpinfo['bmHeight']),
                                   bmpstr, 'raw', 'BGRX', 0, 1)
            win32gui.DeleteObject(saveBitMap.GetHandle())
            saveDC.DeleteDC()
            mfcDC.DeleteDC()
            win32gui.ReleaseDC(hwnd, hwndDC)
            return img

        except Exception as e:
            logger.debug(f"Window capture error: {e}")
            return self.capture_full()

    def capture_region(self, x: int, y: int, w: int, h: int) -> Optional[Any]:
        """Capture a specific screen region."""
        if self._mss_ok:
            try:
                import mss
                from PIL import Image
                with mss.mss() as sct:
                    monitor = {'left': x, 'top': y, 'width': w, 'height': h}
                    shot = sct.grab(monitor)
                    return Image.frombytes('RGB', shot.size, shot.bgra, 'raw', 'BGRX')
            except Exception:
                pass
        full = self.capture_full()
        if full:
            try:
                return full.crop((x, y, x + w, y + h))
            except Exception:
                pass
        return None


class OCREngine:
    """OCR using pytesseract + opencv preprocessing."""

    def __init__(self):
        self._tesseract_ok = False
        self._cv2_ok = False
        self._check()

    def _check(self):
        try:
            import pytesseract
            # Test if tesseract binary is available
            pytesseract.get_tesseract_version()
            self._tesseract_ok = True
        except Exception:
            pass
        try:
            import cv2
            self._cv2_ok = True
        except ImportError:
            pass

    def extract_text(self, image, lang: str = 'spa+eng') -> str:
        """Extract all text from image."""
        if not self._tesseract_ok:
            return ''
        try:
            import pytesseract
            img = self._preprocess(image)
            config = '--oem 3 --psm 6'
            text = pytesseract.image_to_string(img, lang=lang, config=config)
            return text.strip()
        except Exception as e:
            logger.debug(f"OCR extract error: {e}")
            return ''

    def extract_text_blocks(self, image) -> List[Dict]:
        """Extract text with position/confidence data."""
        if not self._tesseract_ok:
            return []
        try:
            import pytesseract
            img = self._preprocess(image)
            data = pytesseract.image_to_data(img, output_type=pytesseract.Output.DICT,
                                              config='--oem 3 --psm 6')
            blocks = []
            n = len(data['text'])
            for i in range(n):
                conf = int(data['conf'][i])
                text = data['text'][i].strip()
                if conf > 30 and text:
                    blocks.append({
                        'text': text,
                        'confidence': conf / 100.0,
                        'bbox': (data['left'][i], data['top'][i],
                                 data['width'][i], data['height'][i]),
                        'block_num': data['block_num'][i],
                        'line_num': data['line_num'][i],
                    })
            return blocks
        except Exception as e:
            logger.debug(f"OCR blocks error: {e}")
            return []

    def find_text_location(self, image, query: str) -> Optional[Tuple[int, int, int, int]]:
        """Find bounding box of specific text in image."""
        blocks = self.extract_text_blocks(image)
        q = query.lower()
        for b in blocks:
            if q in b['text'].lower():
                return b['bbox']
        return None

    def _preprocess(self, image):
        """Preprocess image for better OCR accuracy."""
        if not self._cv2_ok:
            return image
        try:
            import cv2
            import numpy as np
            from PIL import Image as PILImage

            if isinstance(image, PILImage.Image):
                img_array = np.array(image.convert('RGB'))
            else:
                img_array = np.array(image)

            # Convert to grayscale
            gray = cv2.cvtColor(img_array, cv2.COLOR_RGB2GRAY)
            # Apply light threshold to improve OCR
            _, thresh = cv2.threshold(gray, 0, 255,
                                       cv2.THRESH_BINARY + cv2.THRESH_OTSU)
            # Scale up slightly for better recognition
            h, w = thresh.shape
            if h < 800:
                scale = 2.0
                resized = cv2.resize(thresh, (int(w * scale), int(h * scale)),
                                     interpolation=cv2.INTER_CUBIC)
                return PILImage.fromarray(resized)
            return PILImage.fromarray(thresh)
        except Exception:
            return image


class UIElementDetector:
    """Detect UI elements using CV2 template matching and heuristics."""

    def __init__(self):
        self._cv2_ok = False
        try:
            import cv2
            self._cv2_ok = True
        except ImportError:
            pass

    def detect_buttons(self, image, ocr_blocks: List[Dict]) -> List[VisualElement]:
        """Detect button-like elements using heuristics + OCR."""
        buttons = []
        button_keywords = {
            'ok', 'cancel', 'cancelar', 'aceptar', 'yes', 'no', 'sí',
            'send', 'enviar', 'submit', 'guardar', 'save', 'open', 'abrir',
            'close', 'cerrar', 'next', 'siguiente', 'back', 'atrás',
            'continue', 'continuar', 'apply', 'aplicar', 'install',
            'instalar', 'delete', 'eliminar', 'confirm', 'confirmar',
            'login', 'logout', 'search', 'buscar', 'download', 'upload',
        }

        for block in ocr_blocks:
            text = block['text'].lower().strip()
            if (text in button_keywords or
                    (len(text) < 20 and block['confidence'] > 0.7)):
                x, y, w, h = block['bbox']
                # Buttons are usually wider than tall
                if w > 0 and h > 0:
                    el = VisualElement(
                        element_type='button',
                        text=block['text'],
                        bbox=block['bbox'],
                        confidence=block['confidence'],
                    )
                    buttons.append(el)
        return buttons

    def detect_text_fields(self, image, ocr_blocks: List[Dict]) -> List[VisualElement]:
        """Detect input fields."""
        if not self._cv2_ok:
            return []
        try:
            import cv2
            import numpy as np
            from PIL import Image as PILImage

            if isinstance(image, PILImage.Image):
                img_array = np.array(image.convert('RGB'))
            else:
                img_array = np.array(image)

            gray = cv2.cvtColor(img_array, cv2.COLOR_RGB2GRAY)
            edges = cv2.Canny(gray, 50, 150)
            contours, _ = cv2.findContours(edges, cv2.RETR_EXTERNAL,
                                            cv2.CHAIN_APPROX_SIMPLE)
            fields = []
            h, w = gray.shape
            for cnt in contours:
                x, y, cw, ch = cv2.boundingRect(cnt)
                # Text field heuristic: wide and short rectangle
                if cw > 100 and 15 < ch < 60 and cw < w * 0.9:
                    aspect = cw / ch
                    if aspect > 3:
                        el = VisualElement(
                            element_type='input',
                            text='',
                            bbox=(x, y, cw, ch),
                            confidence=0.6,
                        )
                        fields.append(el)
            return fields[:10]  # Limit
        except Exception:
            return []

    def detect_error_messages(self, text: str) -> List[str]:
        """Detect error messages in OCR text."""
        error_keywords = [
            'error', 'exception', 'failed', 'failure', 'traceback',
            'cannot', 'unable', 'invalid', 'denied', 'not found',
            'fallo', 'error:', 'warning:', 'critical:', 'exception:',
            'syntaxerror', 'typeerror', 'valueerror', 'importerror',
        ]
        lines = text.split('\n')
        errors = []
        for line in lines:
            line_lower = line.lower().strip()
            if any(kw in line_lower for kw in error_keywords) and len(line.strip()) > 5:
                errors.append(line.strip()[:200])
        return errors[:5]

    def classify_app_type(self, text: str, window_title: str) -> str:
        """Classify the type of app from text/title context."""
        text_lower = text.lower()
        title_lower = window_title.lower()

        combined = text_lower + ' ' + title_lower
        if any(k in combined for k in ['def ', 'import ', 'function ', 'class ', 'return ', 'npm ']):
            return 'ide'
        if any(k in combined for k in ['http', 'www.', 'chrome', 'firefox', 'edge', 'browser']):
            return 'browser'
        if any(k in combined for k in ['inbox', 'from:', 'to:', 'subject:', 'outlook', 'gmail']):
            return 'email'
        if any(k in combined for k in ['terminal', 'powershell', 'bash', 'cmd', 'command prompt']):
            return 'terminal'
        if any(k in combined for k in ['chat', 'discord', 'teams', 'slack', 'whatsapp']):
            return 'chat'
        if any(k in combined for k in ['spotify', 'music', 'playlist', 'track']):
            return 'media'
        return 'general'


class VisionEngine:
    """
    MARK 9 — Vision Engine.
    Full screen perception: capture, OCR, UI element detection,
    visual context extraction. Runs on-demand or continuously.
    """

    def __init__(self, brain=None):
        self.brain = brain
        self._capture = ScreenCapture()
        self._ocr = OCREngine()
        self._detector = UIElementDetector()

        self._last_context: Optional[VisualContext] = None
        self._lock = threading.Lock()
        self._continuous = False
        self._thread: Optional[threading.Thread] = None

        # Report OCR availability
        if self._ocr._tesseract_ok:
            logger.info("Vision Engine: OCR disponible (pytesseract)")
        else:
            logger.info("Vision Engine: OCR no disponible (instala pytesseract + tesseract)")
        if self._capture._mss_ok:
            logger.info("Vision Engine: captura rápida (mss)")

    def capture_and_analyze(self, window_title: str = '') -> VisualContext:
        """Full vision pipeline: capture → OCR → detect elements → context."""
        ctx = VisualContext()
        ctx.active_window = window_title

        # Capture
        if window_title:
            img = self._capture.capture_window(window_title)
        else:
            img = self._capture.capture_full()

        if img is None:
            logger.debug("Vision: no se pudo capturar imagen.")
            return ctx

        try:
            ctx.width, ctx.height = img.size
        except Exception:
            pass

        # OCR
        ctx.full_text = self._ocr.extract_text(img)
        ctx.text_blocks = self._ocr.extract_text_blocks(img)

        # Element detection
        ctx.buttons = self._detector.detect_buttons(img, ctx.text_blocks)
        ctx.text_fields = self._detector.detect_text_fields(img, ctx.text_blocks)
        ctx.all_elements = ctx.buttons + ctx.text_fields

        # High-level analysis
        error_texts = self._detector.detect_error_messages(ctx.full_text)
        ctx.has_error_messages = len(error_texts) > 0
        ctx.error_texts = error_texts
        ctx.detected_app_type = self._detector.classify_app_type(
            ctx.full_text, window_title
        )

        # Notification detection
        notification_keywords = ['notification', 'notificación', 'new message',
                                  'nuevo mensaje', 'alerta', 'alert']
        ctx.has_notifications = any(k in ctx.full_text.lower()
                                     for k in notification_keywords)

        with self._lock:
            self._last_context = ctx

        return ctx

    def capture_screen_text(self) -> str:
        """Quick text extraction from current screen."""
        img = self._capture.capture_full()
        if not img:
            return ''
        return self._ocr.extract_text(img)

    def find_on_screen(self, text: str) -> Optional[Tuple[int, int]]:
        """Find text on screen and return center coordinates."""
        img = self._capture.capture_full()
        if not img:
            return None
        bbox = self._ocr.find_text_location(img, text)
        if bbox:
            x, y, w, h = bbox
            return (x + w // 2, y + h // 2)
        return None

    def screenshot_to_file(self, path: str = None) -> Optional[str]:
        """Save screenshot to file and return path."""
        img = self._capture.capture_full()
        if not img:
            return None
        if not path:
            path = os.path.join(self._capture._capture_dir,
                                f"screenshot_{int(time.time())}.png")
        try:
            img.save(path)
            return path
        except Exception as e:
            logger.debug(f"Screenshot save error: {e}")
            return None

    def start_continuous(self, interval: float = 10.0):
        """Start continuous background vision scanning."""
        self._continuous = True
        self._thread = threading.Thread(
            target=self._continuous_loop,
            args=(interval,),
            name='MARK9-Vision',
            daemon=True
        )
        self._thread.start()
        logger.info(f"Vision: monitoreo continuo activo (cada {interval}s)")

    def stop_continuous(self):
        self._continuous = False

    def _continuous_loop(self, interval: float):
        while self._continuous:
            try:
                window = ''
                if self.brain:
                    try:
                        import win32gui
                        window = win32gui.GetWindowText(win32gui.GetForegroundWindow())
                    except Exception:
                        pass
                ctx = self.capture_and_analyze(window)

                # Notify brain of errors detected
                if ctx.has_error_messages and self.brain:
                    try:
                        if self.brain._ui_callback:
                            self.brain._ui_callback('vision_error_detected', {
                                'errors': ctx.error_texts,
                                'window': window,
                            })
                    except Exception:
                        pass
            except Exception as e:
                logger.debug(f"Continuous vision error: {e}")
            time.sleep(interval)

    def get_last_context(self) -> Optional[VisualContext]:
        with self._lock:
            return self._last_context

    def describe_screen(self) -> str:
        """Natural language description of what's on screen."""
        ctx = self.capture_and_analyze()
        if not ctx.full_text and not ctx.buttons:
            return "Pantalla sin contenido detectable."

        parts = []
        if ctx.detected_app_type:
            parts.append(f"Tipo de aplicación: {ctx.detected_app_type}")
        if ctx.full_text:
            preview = ctx.full_text[:200].replace('\n', ' ')
            parts.append(f"Texto visible: {preview}")
        if ctx.buttons:
            btn_texts = [b.text for b in ctx.buttons[:5]]
            parts.append(f"Botones: {', '.join(btn_texts)}")
        if ctx.has_error_messages:
            parts.append(f"ERRORES detectados: {ctx.error_texts[0][:100]}")

        return '. '.join(parts)

    def get_status(self) -> Dict:
        return {
            'capture_mss': self._capture._mss_ok,
            'capture_pyautogui': self._capture._pag_ok,
            'ocr_available': self._ocr._tesseract_ok,
            'cv2_available': self._ocr._cv2_ok,
            'continuous': self._continuous,
            'last_scan': self._last_context.timestamp if self._last_context else None,
        }
