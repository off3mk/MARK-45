"""
MARK 11 — Brain (Central Orchestrator)
Clean, modular, optimized for i5-9600K + 16GB RAM.
Primary AI: LM Studio (http://127.0.0.1:1234)

Creator: Ali (Sidi3Ali)
System: MARK 11

WATERMARK — DO NOT REMOVE:
MARK 11 was created by Ali (Sidi3Ali). All rights reserved.
"""

import logging
import threading
import time
import queue
import json
import os
from typing import Optional, Callable, Dict, Any

logger = logging.getLogger('MARK11.Brain')

SYSTEM_NAME   = "MARK 11"
CREATOR_NAME  = "Ali"
CREATOR_ALIAS = "Sidi3Ali"
WATERMARK     = f"{SYSTEM_NAME} — Created by {CREATOR_NAME} ({CREATOR_ALIAS})"

CONFIG_PATH = os.path.join(os.path.dirname(os.path.dirname(__file__)), 'config', 'config.json')


def _load_config() -> Dict:
    try:
        with open(CONFIG_PATH, 'r', encoding='utf-8') as f:
            return json.load(f)
    except Exception:
        return {}


class Mark11Brain:
    """
    MARK 11 — Central Orchestrator.
    Modular, clean, optimized.
    """

    def __init__(self):
        self._config = _load_config()
        self.initialized = False
        self.running = False
        self._cmd_queue: queue.PriorityQueue = queue.PriorityQueue()
        self._ui_callback: Optional[Callable] = None
        self._lock = threading.Lock()

        # ── Core modules ──────────────────────────────────────────────────────
        self.ai_manager = None           # LM Studio AI (primary)
        self.memory = None               # SQLite memory
        self.voice = None                # TTS
        self.user_identity = None        # User/creator identity
        self.context_awareness = None    # Real-time context
        self.decision_engine = None      # Rule-based decisions
        self.cognitive_loop = None       # Main cognitive pipeline
        self.performance_mgr = None      # CPU/RAM management

        # ── Action modules ────────────────────────────────────────────────────
        self.sys_control = None          # System control (apps, volume)
        self.ui_control = None           # Mouse/keyboard/windows
        self.browser_control = None      # Browser automation
        self.code_executor = None        # Code execution

        # ── Perception modules ────────────────────────────────────────────────
        self.sys_monitor = None          # System resource monitor
        self.screen_monitor = None       # Screen capture + OCR

        # ── Skills (from existing system) ─────────────────────────────────────
        self.skill_manager = None

        # ── Legacy compatibility ───────────────────────────────────────────────
        # These point to MARK 11 equivalents for backward compat
        self.personality = None
        self.reasoning = None
        self.planner = None
        self.executor = None
        self.autonomous = None
        self.state = None
        self.cognitive_memory = None
        self.startup_manager = None
        self.audio_monitor = None

    # ── INITIALIZATION ────────────────────────────────────────────────────────

    def initialize(self):
        logger.info("=" * 60)
        logger.info(f"  {SYSTEM_NAME}")
        logger.info(f"  {WATERMARK}")
        logger.info("=" * 60)

        # Performance manager first (needed by everything)
        self._init_performance()

        # Memory (needed by identity + AI history)
        self._init_memory()

        # AI (primary intelligence)
        self._init_ai()

        # Voice (needed by identity greeting)
        self._init_voice()

        # Identity (needs memory + voice)
        self._init_identity()

        # Context awareness (lightweight)
        self._init_context()

        # Action modules
        self._init_actions()

        # Perception modules
        self._init_perception()

        # Skills (legacy compatibility)
        self._init_skills()

        # Legacy modules (load whatever exists)
        self._init_legacy()

        # Decision engine
        self._init_decision()

        # Cognitive loop (must be last)
        self._init_cognitive_loop()

        # Start command processor
        self.initialized = True
        self.running = True
        self._start_cmd_processor()

        # Startup greeting
        self._do_greeting()

        logger.info(f"[OK] {SYSTEM_NAME} operativo.")

    def _init_performance(self):
        try:
            from core.performance_manager import PerformanceManager
            self.performance_mgr = PerformanceManager(self._config)
            self.performance_mgr.start()
            logger.info("  [+] Performance Manager")
        except Exception as e:
            logger.warning(f"  [-] Performance: {e}")

    def _init_memory(self):
        try:
            from core.memory import MemorySystem
            db_path = self._config.get('memory', {}).get('db_path')
            if db_path:
                db_path = os.path.join(os.path.dirname(os.path.dirname(__file__)), db_path)
            self.memory = MemorySystem(db_path)
            self.memory.initialize()
            logger.info("  [+] Memory System")
        except Exception as e:
            logger.warning(f"  [-] Memory: {e}")

    def _init_ai(self):
        try:
            from core.ai_manager import AIManager
            self.ai_manager = AIManager(self._config)
            status = self.ai_manager.get_status()
            logger.info(f"  [+] AI Manager — source={status['active_source']} "
                        f"model={status['lmstudio_model']}")
        except Exception as e:
            logger.warning(f"  [-] AI Manager: {e}")

    def _init_voice(self):
        try:
            from voice.tts import VoiceSystem
            self.voice = VoiceSystem(self._config)
            logger.info("  [+] Voice (TTS)")
        except Exception:
            # Fallback: legacy voice
            try:
                from core.voice import VoiceSystem
                self.voice = VoiceSystem()
                logger.info("  [+] Voice (legacy TTS)")
            except Exception as e:
                logger.warning(f"  [-] Voice: {e}")

    def _init_identity(self):
        try:
            from core.user_identity import UserIdentitySystem
            self.user_identity = UserIdentitySystem(memory=self.memory)
            profile = self.user_identity.load_or_create_profile(voice=self.voice)
            logger.info(f"  [+] Identity — {profile.address_name} "
                        f"(creator={profile.is_creator})")
        except Exception as e:
            logger.warning(f"  [-] Identity: {e}")

    def _init_context(self):
        try:
            from core.context_awareness import ContextAwarenessSystem
            self.context_awareness = ContextAwarenessSystem(brain=self)
            self.context_awareness.start()
            logger.info("  [+] Context Awareness")
        except Exception as e:
            logger.warning(f"  [-] ContextAwareness: {e}")

    def _init_actions(self):
        try:
            from action.system_control import SystemControl
            self.sys_control = SystemControl()
            logger.info("  [+] System Control")
        except Exception as e:
            logger.warning(f"  [-] SystemControl: {e}")

        try:
            from action.ui_control import UIControl
            self.ui_control = UIControl()
            logger.info("  [+] UI Control")
        except Exception as e:
            logger.warning(f"  [-] UIControl: {e}")

        try:
            from action.browser_control import BrowserControl
            self.browser_control = BrowserControl(ui_control=self.ui_control)
            logger.info("  [+] Browser Control")
        except Exception as e:
            logger.warning(f"  [-] BrowserControl: {e}")

        try:
            from action.code_executor import CodeExecutor
            self.code_executor = CodeExecutor()
            logger.info("  [+] Code Executor")
        except Exception as e:
            logger.warning(f"  [-] CodeExecutor: {e}")

    def _init_perception(self):
        try:
            from perception.system_monitor import SystemMonitor
            self.sys_monitor = SystemMonitor(poll_interval=5.0)
            self.sys_monitor.start()
            logger.info("  [+] System Monitor")
        except Exception as e:
            logger.warning(f"  [-] SystemMonitor: {e}")

        try:
            from perception.screen_monitor import ScreenMonitor
            self.screen_monitor = ScreenMonitor()
            logger.info(f"  [+] Screen Monitor (OCR={'on' if self.screen_monitor._ocr_ok else 'off'})")
        except Exception as e:
            logger.warning(f"  [-] ScreenMonitor: {e}")

    def _init_skills(self):
        try:
            from core.skills import SkillManager
            self.skill_manager = SkillManager(self)
            self.skill_manager.load_all_skills()
            logger.info("  [+] Skill Manager")
        except Exception as e:
            logger.warning(f"  [-] Skills: {e}")

    def _init_legacy(self):
        """Load legacy modules that still exist from older versions."""
        legacy_loads = [
            ('core.personality', 'JarvisPersonality', 'personality', [self.ai_manager]),
            ('core.reasoning', 'ReasoningEngine', 'reasoning', [self]),
            ('core.planner', 'TaskPlanner', 'planner', [self]),
            ('core.executor', 'CommandExecutor', 'executor', [self]),
            ('core.autonomous', 'AutonomousEngine', 'autonomous', [self]),
            ('core.state', 'JarvisState', 'state', []),
            ('core.cognitive_memory', 'CognitiveMemory', 'cognitive_memory', []),
            ('core.startup_manager', 'StartupManager', 'startup_manager', [self]),
            ('core.audio_monitor', 'AudioMonitor', 'audio_monitor', [self]),
        ]
        for module_path, class_name, attr, args in legacy_loads:
            try:
                mod = __import__(module_path, fromlist=[class_name])
                cls = getattr(mod, class_name)
                instance = cls(*args) if args else cls()
                # Start if needed
                for method in ['start', 'initialize']:
                    if hasattr(instance, method):
                        try: getattr(instance, method)()
                        except Exception: pass
                        break
                setattr(self, attr, instance)
                logger.info(f"  [+] {class_name} (legacy)")
            except Exception:
                pass  # Legacy modules are optional

    def _init_decision(self):
        try:
            from core.decision_engine import DecisionEngine
            self.decision_engine = DecisionEngine()
            logger.info("  [+] Decision Engine")
        except Exception as e:
            logger.warning(f"  [-] DecisionEngine: {e}")

    def _init_cognitive_loop(self):
        try:
            from core.cognitive_loop import CognitiveLoop
            self.cognitive_loop = CognitiveLoop(brain=self)
            self.cognitive_loop.start()
            logger.info("  [+] Cognitive Loop")
        except Exception as e:
            logger.warning(f"  [-] CognitiveLoop: {e}")

    def _do_greeting(self):
        try:
            if self.user_identity:
                greeting = self.user_identity.get_greeting()
            else:
                import time as _t
                h = _t.localtime().tm_hour
                tod = ('Buenos días' if 5 <= h < 12
                       else 'Buenas tardes' if 12 <= h < 20 else 'Buenas noches')
                greeting = f"{tod}, Ali. {SYSTEM_NAME} operativo."
            self.speak(greeting, priority=True)
            logger.info(f"Saludo: {greeting}")
        except Exception as e:
            logger.debug(f"Greeting error: {e}")

    # ── COMMAND PROCESSING ────────────────────────────────────────────────────

    def process_command(self, user_input: str) -> str:
        if not user_input or not user_input.strip():
            return ''
        user_input = user_input.strip()
        logger.info(f"Input: '{user_input[:100]}'")

        # Save to memory
        if self.memory:
            try: self.memory.save_message('user', user_input)
            except Exception: pass

        # 1. Built-in MARK 11 commands
        response = self._handle_builtin(user_input)

        # 2. Skills
        if not response and self.skill_manager:
            try: response = self.skill_manager.process(user_input)
            except Exception: pass

        # 3. Legacy reasoning
        if not response and self.reasoning:
            try: response = self.reasoning.reason(user_input, {})
            except Exception as e:
                logger.debug(f"Reasoning error: {e}")

        # 4. AI (LM Studio primary)
        if not response or len(response.strip()) < 3:
            ctx = self._get_context_dict()
            response = self._ask_ai(user_input, ctx)

        # Save response
        if self.memory:
            try: self.memory.save_message('mark11', response)
            except Exception: pass

        # Filter legacy "Señor" from any module
        if response:
            response = response.replace("Señor", "Ali").replace("señor", "Ali")
        # Speak
        self.speak(response)
        return response

    def _handle_builtin(self, text: str) -> Optional[str]:
        """Handle MARK 11-specific built-in commands."""
        t = text.lower().strip()
        name = self.get_name()

        # ── Status ────────────────────────────────────────────────────────────
        if any(w in t for w in ['mark 10 status', 'estado completo', 'todos los sistemas']):
            return self._full_status()

        if any(w in t for w in ['estado del sistema', 'info sistema', 'recursos del sistema']):
            if self.sys_control:
                return self.sys_control.get_system_info()
            return "Monitor del sistema no disponible."

        if any(w in t for w in ['estado lm studio', 'lm studio', 'estado ia', 'modelo activo']):
            if self.ai_manager:
                s = self.ai_manager.get_status()
                return (f"LM Studio: {'activo' if s['lmstudio_available'] else 'inactivo'} | "
                        f"Modelo: {s['lmstudio_model']} | "
                        f"Fuente: {s['active_source']}")
            return "AI Manager no disponible."

        # ── Apps ──────────────────────────────────────────────────────────────
        if any(w in t for w in ['abre ', 'abrir ', 'inicia ', 'iniciar ', 'lanza ', 'lanzar ']):
            app = self._extract_after(text, ['abre', 'abrir', 'inicia', 'iniciar', 'lanza', 'lanzar'])
            if app and self.sys_control:
                return self.sys_control.open_app(app)

        if any(w in t for w in ['cierra ', 'cerrar ', 'cierre ']):
            app = self._extract_after(text, ['cierra', 'cerrar', 'cierre'])
            if app and self.sys_control:
                return self.sys_control.close_app(app)

        if any(w in t for w in ['apps activas', 'aplicaciones abiertas', 'qué apps', 'qué programas']):
            if self.sys_control:
                return self.sys_control.list_apps()

        # ── Volume ────────────────────────────────────────────────────────────
        if any(w in t for w in ['volumen', 'sube el volumen', 'baja el volumen']):
            # Parse level
            import re
            nums = re.findall(r'\d+', text)
            if nums and self.sys_control:
                return self.sys_control.set_volume(int(nums[0]))
            if 'mute' in t or 'silencia' in t or 'silenciar' in t:
                if self.sys_control:
                    return self.sys_control.mute()
            if 'activa' in t and self.sys_control:
                return self.sys_control.unmute()

        if 'silencia' in t or 'silenciar' in t or 'mute' in t:
            if self.sys_control:
                return self.sys_control.mute()

        # ── Browser ───────────────────────────────────────────────────────────
        if any(w in t for w in ['abre http', 'navega a', 've a ', 'busca en internet', 'busca ']):
            url_or_query = self._extract_after(text, ['abre', 'navega a', 've a', 'busca en internet', 'busca'])
            if url_or_query and self.browser_control:
                if url_or_query.startswith('http') or '.' in url_or_query:
                    return self.browser_control.navigate(url_or_query)
                return self.browser_control.search(url_or_query)

        # ── Screen/Vision ──────────────────────────────────────────────────────
        if any(w in t for w in ['captura pantalla', 'screenshot', 'captura de pantalla']):
            if self.screen_monitor:
                path = self.screen_monitor.screenshot()
                return f"Captura guardada: {path}" if path else "Error en captura."
            return "Monitor de pantalla no disponible."

        if any(w in t for w in ['lee pantalla', 'qué ves', 'texto en pantalla', 'ocr']):
            if self.screen_monitor:
                return self.screen_monitor.describe()
            return "OCR no disponible. Instala pytesseract."

        # ── Code ──────────────────────────────────────────────────────────────
        if any(w in t for w in ['ejecuta código', 'ejecutar código', 'run ', 'ejecuta python']):
            code = self._extract_after(text, ['ejecuta código', 'ejecutar código', 'run', 'ejecuta python'])
            if code and self.code_executor:
                result = self.code_executor.run_python(code)
                return self.code_executor.format_result(result)

        if any(w in t for w in ['cmd:', 'powershell:', 'ejecuta comando']):
            cmd = self._extract_after(text, ['cmd:', 'powershell:', 'ejecuta comando'])
            if cmd and self.code_executor:
                if 'powershell' in t:
                    result = self.code_executor.run_powershell(cmd)
                else:
                    result = self.code_executor.run_cmd(cmd)
                return self.code_executor.format_result(result)

        # ── UI Control ────────────────────────────────────────────────────────
        if any(w in t for w in ['enfocar ventana', 'activar ventana', 'foco en']):
            title = self._extract_after(text, ['enfocar ventana', 'activar ventana', 'foco en'])
            if title and self.ui_control:
                return self.ui_control.focus_window(title)

        if any(w in t for w in ['ventanas abiertas', 'listar ventanas', 'qué ventanas']):
            if self.ui_control:
                windows = self.ui_control.list_windows()
                if windows:
                    return "Ventanas: " + " | ".join(windows[:8])
                return "No se detectaron ventanas."

        if any(w in t for w in ['escribe ', 'escribir ', 'escribe esto:']):
            text_to_type = self._extract_after(text, ['escribe', 'escribir', 'escribe esto:'])
            if text_to_type and self.ui_control:
                return self.ui_control.type_text(text_to_type)

        # ── Memory ────────────────────────────────────────────────────────────
        if any(w in t for w in ['limpia historial', 'borra historial', 'limpiar memoria']):
            if self.memory:
                self.memory.clear_history()
                if self.ai_manager:
                    self.ai_manager.clear_history()
                return "Historial limpiado."

        if any(w in t for w in ['estadísticas de memoria', 'memoria stats']):
            if self.memory:
                stats = self.memory.get_stats()
                return (f"Memoria: {stats.get('messages','?')} mensajes | "
                        f"{stats.get('habits','?')} hábitos registrados")

        # ── Context ───────────────────────────────────────────────────────────
        if any(w in t for w in ['contexto actual', 'qué estoy haciendo', 'actividad actual']):
            ctx = self._get_context_dict()
            if ctx:
                app = ctx.get('active_app','?')
                activity = ctx.get('user_activity','?')
                mode = ctx.get('detected_mode','?')
                dur = ctx.get('activity_duration_minutes', 0)
                return f"App: {app} | Actividad: {activity} | Modo: {mode} | {dur:.0f} min."
            return "Sin contexto disponible."

        # ── Cognitive loop ────────────────────────────────────────────────────
        if any(w in t for w in ['ciclos cognitivos', 'cognitive loop', 'estado cognitivo']):
            if self.cognitive_loop:
                s = self.cognitive_loop.get_status()
                return (f"Cognitive Loop: {s['cycles']} ciclos | "
                        f"Uptime: {s['uptime_minutes']:.0f} min")

        # ── Decisions ─────────────────────────────────────────────────────────
        if any(w in t for w in ['decisiones recientes', 'últimas decisiones']):
            if self.decision_engine:
                decs = self.decision_engine.get_recent(5)
                if decs:
                    return "Decisiones: " + " | ".join(d['message'][:40] for d in decs[-3:])
                return "Sin decisiones recientes."

        # ── Introspección ──────────────────────────────────────────────────────
        if any(w in t for w in ['introspección', 'analízate', 'autoanalisis', 'cómo estás']):
            try:
                import psutil
                cpu = psutil.cpu_percent(0.2)
                ram = psutil.virtual_memory().percent
            except Exception:
                cpu, ram = 0, 0
            ai_source = self.ai_manager.get_source() if self.ai_manager else 'desconocido'
            return (f"MARK 11 operativo. CPU {cpu:.0f}%, RAM {ram:.0f}%. "
                    f"IA: {ai_source}. "
                    f"Ciclos: {self.cognitive_loop.get_status()['cycles'] if self.cognitive_loop else '?'}.")

        # ── Identity ──────────────────────────────────────────────────────────
        if any(w in t for w in ['quién soy', 'identidad', 'privilegio', 'quién eres']):
            if self.user_identity:
                s = self.user_identity.get_status()
                return (f"Usuario: {s['name']} | "
                        f"Creador: {'Sí' if s['is_creator'] else 'No'}")
            return f"MARK 11, creado por {CREATOR_NAME} ({CREATOR_ALIAS})."

        return None

    def _extract_after(self, text: str, keywords: list) -> str:
        """Extract text after first matching keyword."""
        t = text.lower()
        for kw in sorted(keywords, key=len, reverse=True):
            idx = t.find(kw.lower())
            if idx >= 0:
                after = text[idx + len(kw):].strip().strip(':').strip('"').strip("'").strip()
                if after:
                    return after
        return ''

    def _ask_ai(self, user_input: str, context: Dict = None) -> str:
        """Send to AI manager (LM Studio primary)."""
        if self.ai_manager:
            try:
                return self.ai_manager.ask(user_input, context)
            except Exception as e:
                logger.debug(f"AI error: {e}")
        return f"Sin respuesta disponible para: '{user_input[:60]}'"

    def _full_status(self) -> str:
        modules = {
            'AI Manager':       self.ai_manager,
            'Memory':           self.memory,
            'Voice':            self.voice,
            'Identity':         self.user_identity,
            'Context':          self.context_awareness,
            'Sys Monitor':      self.sys_monitor,
            'Screen Monitor':   self.screen_monitor,
            'Sys Control':      self.sys_control,
            'UI Control':       self.ui_control,
            'Browser Control':  self.browser_control,
            'Code Executor':    self.code_executor,
            'Decision Engine':  self.decision_engine,
            'Cognitive Loop':   self.cognitive_loop,
            'Skill Manager':    self.skill_manager,
        }
        active = [k for k, v in modules.items() if v]
        inactive = [k for k, v in modules.items() if not v]
        lines = [f"{SYSTEM_NAME} Status [{WATERMARK}]"]
        lines.append(f"Activos ({len(active)}): {', '.join(active)}")
        if inactive:
            lines.append(f"Inactivos ({len(inactive)}): {', '.join(inactive)}")
        try:
            import psutil
            lines.append(f"CPU: {psutil.cpu_percent(0.1):.0f}% | RAM: {psutil.virtual_memory().percent:.0f}%")
        except Exception: pass
        if self.ai_manager:
            s = self.ai_manager.get_status()
            lines.append(f"AI: {s['active_source']} ({s['lmstudio_model']})")
        if self.cognitive_loop:
            s = self.cognitive_loop.get_status()
            lines.append(f"Cognitive: {s['cycles']} ciclos | {s['uptime_minutes']:.0f} min")
        return '\n'.join(lines)

    # ── PUBLIC API ────────────────────────────────────────────────────────────

    def speak(self, text: str, priority: bool = False):
        if self.voice and text:
            try: self.voice.speak(text, priority=priority)
            except Exception as e: logger.debug(f"TTS: {e}")

    def get_name(self) -> str:
        if self.user_identity:
            return self.user_identity.get_name()
        return CREATOR_NAME

    def is_creator(self) -> bool:
        if self.user_identity:
            return self.user_identity.is_creator()
        return True

    def set_ui_callback(self, callback: Callable):
        self._ui_callback = callback

    def _get_context_dict(self) -> Dict:
        if self.context_awareness:
            try: return self.context_awareness.to_dict()
            except Exception: pass
        return {}

    def queue_command(self, cmd: str, priority: int = 5, callback: Callable = None):
        self._cmd_queue.put((priority, time.time(), {'cmd': cmd, 'cb': callback}))

    def _start_cmd_processor(self):
        def _proc():
            while self.running:
                try:
                    _, _, item = self._cmd_queue.get(timeout=0.2)
                    result = self.process_command(item['cmd'])
                    if item.get('cb'):
                        item['cb'](result)
                except queue.Empty: pass
                except Exception as e: logger.error(f"CmdProc: {e}")
        threading.Thread(target=_proc, daemon=True, name='MARK11-CmdProcessor').start()

    def shutdown(self):
        logger.info(f"Apagando {SYSTEM_NAME}...")
        self.running = False
        name = self.get_name()
        self.speak(f"Apagando MARK 11. Hasta luego, {name}.", priority=True)
        time.sleep(1.5)
        for attr in ['cognitive_loop', 'context_awareness', 'sys_monitor', 'voice']:
            m = getattr(self, attr, None)
            if m:
                for method in ['stop', 'close']:
                    if hasattr(m, method):
                        try: getattr(m, method)(); break
                        except Exception: pass
        if self.memory:
            try: self.memory.close()
            except Exception: pass
        logger.info(f"{SYSTEM_NAME} apagado.")

    def get_status(self) -> Dict:
        return {
            'system': SYSTEM_NAME,
            'creator': f"{CREATOR_NAME} ({CREATOR_ALIAS})",
            'watermark': WATERMARK,
            'initialized': self.initialized,
            'running': self.running,
            'ai': self.ai_manager.get_status() if self.ai_manager else {},
            'cognitive': self.cognitive_loop.get_status() if self.cognitive_loop else {},
            'context': self._get_context_dict(),
            'modules_active': sum(1 for a in [
                self.ai_manager, self.memory, self.voice, self.user_identity,
                self.context_awareness, self.decision_engine, self.cognitive_loop,
                self.sys_control, self.ui_control, self.browser_control,
                self.code_executor, self.sys_monitor, self.screen_monitor,
                self.skill_manager,
            ] if a is not None),
        }


# ── Legacy alias ──────────────────────────────────────────────────────────────
JarvisBrain = Mark11Brain

# Alias for forward compatibility
Mark10Brain = Mark11Brain
JarvisBrain = Mark11Brain
