"""
MARK 11 — Performance Manager
Monitorea el uso de MARK 11 mismo (no el RAM total del sistema).
Target MARK: < 500MB RAM, CPU < 5% en idle.

Creator: Ali (Sidi3Ali)
System: MARK 11
"""
import logging, threading, time, psutil
from typing import Dict, Optional

logger = logging.getLogger('MARK11.Performance')


class PerformanceManager:
    def __init__(self, config: Dict = None):
        cfg = (config or {}).get('performance', config or {})
        self._cpu_system_max = cfg.get('cpu_system_max', 88)  # sistema total
        self._mark_ram_max_mb = cfg.get('mark_ram_max_mb', 800)  # RAM de MARK (no sistema)
        self._running = False
        self._thread: Optional[threading.Thread] = None
        self._throttled = False
        self._lock = threading.Lock()
        self._warnings = 0
        try:
            self._mark_proc = psutil.Process()
        except Exception:
            self._mark_proc = None

    def start(self):
        self._running = True
        self._thread = threading.Thread(
            target=self._loop, name='MARK11-PerfManager', daemon=True
        )
        self._thread.start()

    def stop(self):
        self._running = False

    def _loop(self):
        while self._running:
            try:
                self._check()
            except Exception as e:
                logger.debug(f"Perf: {e}")
            time.sleep(15)

    def _check(self):
        try:
            # Check MARK's own RAM (not total system)
            mark_mb = 0
            if self._mark_proc:
                mark_mb = self._mark_proc.memory_info().rss / 1024**2
            
            # Check system CPU
            cpu = psutil.cpu_percent(interval=None)

            was = self._throttled
            # Only throttle if MARK itself is using too much, or CPU is critical
            if cpu > self._cpu_system_max or mark_mb > self._mark_ram_max_mb * 2:
                with self._lock:
                    self._throttled = True
                if not was:
                    logger.warning(f"Throttle: CPU {cpu:.0f}% | MARK RAM {mark_mb:.0f}MB")
                    self._warnings += 1
            else:
                with self._lock:
                    self._throttled = False
        except Exception:
            pass

    def is_throttled(self) -> bool:
        with self._lock:
            return self._throttled

    def get_recommended_sleep(self, base: float) -> float:
        return base * 2.0 if self.is_throttled() else base

    def get_status(self) -> Dict:
        try:
            cpu = psutil.cpu_percent(interval=None)
            ram = psutil.virtual_memory()
            mark_mb = self._mark_proc.memory_info().rss / 1024**2 if self._mark_proc else 0
            return {
                'cpu': cpu,
                'system_ram_gb': round(ram.used / 1024**3, 1),
                'mark_ram_mb': round(mark_mb, 0),
                'throttled': self._throttled,
                'warnings': self._warnings,
            }
        except Exception:
            return {'throttled': self._throttled}
