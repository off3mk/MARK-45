"""
J.A.R.V.I.S MARK 6 - NLU Engine (Natural Language Understanding)
================================================================
Motor de comprensión de lenguaje natural avanzado.

Entiende TODO: typos, abreviaturas, slang, frases vagas, combinaciones
raras, castellano de España, inglés mezclado, faltas ortográficas.

No necesita comandos exactos. Infiere intención como hacen GPT/Gemini.
"""

import re
import json
import logging
from typing import Dict, List, Optional, Tuple, Any
from difflib import SequenceMatcher

logger = logging.getLogger('MARK.NLU')


# ──────────────────────────────────────────────────────────────
# NORMALIZACIÓN DE TEXTO
# ──────────────────────────────────────────────────────────────

class TextNormalizer:
    """Normaliza texto: typos, abreviaturas, slang español."""

    # Correcciones comunes de typos / abreviaturas españolas
    CORRECTIONS = {
        # Artículos y conectores
        'q ':  'que ', 'k ':  'que ', 'x ':  'por ', 'xq': 'porque', 'xk': 'porque',
        'tb ': 'también ', 'tmb ': 'también ', 'tbn ': 'también ',
        'pq ': 'porque ', 'pk ': 'porque ',
        'mas ': 'más ', 'si ': 'sí ',  # ojo: "si" puede ser condicional
        'pa ': 'para ', 'po ': 'para ',
        'sgd': 'siguiente', 'mñ': 'mañana', 'nd': 'nada', 'msj': 'mensaje',
        'grcs': 'gracias', 'grc': 'gracias', 'gras': 'gracias',
        'ok ': 'okey ', 'oky': 'okey', 'vale ': 'okey ',
        'plis': 'por favor', 'plz': 'por favor', 'porfa': 'por favor', 'porfavor': 'por favor',
        'buen dia': 'buenos días', 'buenas noces': 'buenas noches',
        'puedo': 'puedo', 'quiero': 'quiero',
        # tech
        'pc ': 'ordenador ', 'ordi ': 'ordenador ', 'compu ': 'ordenador ',
        'app ': 'aplicación ', 'apps ': 'aplicaciones ',
        'msg ': 'mensaje ', 'info ': 'información ',
        # coding
        'cod ': 'código ', 'script ': 'script ',
        'programar': 'programar', 'picar código': 'programar',
        'picar codigo': 'programar',
    }

    # Palabras mal escritas comunes → corrección
    TYPO_MAP = {
        'musica': 'música', 'peliculas': 'películas', 'pagina': 'página',
        'informatcion': 'información', 'informacion': 'información',
        'computadora': 'ordenador', 'computador': 'ordenador',
        'anadir': 'añadir', 'ayudame': 'ayúdame', 'dime': 'dime',
        'explicame': 'explícame', 'abre': 'abre', 'pon': 'pon',
        'busca': 'busca', 'buscar': 'buscar', 'encuentra': 'encuentra',
        'muestra': 'muestra', 'mostrar': 'mostrar', 'genera': 'genera',
        'crear': 'crear', 'crea': 'crea', 'hazme': 'hazme', 'haz': 'haz',
        'escribir': 'escribir', 'escribe': 'escribe', 'escrivir': 'escribir',
        'necesito': 'necesito', 'necesita': 'necesita', 'quiero': 'quiero',
        'quero': 'quiero', 'kiero': 'quiero', 'quier': 'quiero',
        'puedes': 'puedes', 'puede': 'puede',
        'abrir': 'abrir', 'cerrar': 'cerrar', 'cierra': 'cierra',
        'apagar': 'apagar', 'apaga': 'apaga', 'encender': 'encender',
        'bajar': 'bajar', 'subir': 'subir', 'silencio': 'silencio',
    }

    def normalize(self, text: str) -> str:
        """Normaliza texto para procesamiento."""
        t = text.strip()

        # Minúsculas para análisis
        tl = t.lower()

        # Aplicar correcciones de abreviaturas (con espacio para evitar false positives)
        for abbr, full in self.CORRECTIONS.items():
            tl = tl.replace(abbr, full)

        # Corregir typos conocidos
        words = tl.split()
        corrected = []
        for w in words:
            clean_w = re.sub(r'[^a-záéíóúüñ]', '', w)
            if clean_w in self.TYPO_MAP:
                corrected.append(self.TYPO_MAP[clean_w])
            else:
                corrected.append(w)
        tl = ' '.join(corrected)

        # Limpiar espacios múltiples
        tl = re.sub(r'\s+', ' ', tl).strip()
        return tl

    def similarity(self, a: str, b: str) -> float:
        """Similitud entre dos strings (0-1)."""
        return SequenceMatcher(None, a.lower(), b.lower()).ratio()


# ──────────────────────────────────────────────────────────────
# CLASIFICADOR DE INTENCIONES
# ──────────────────────────────────────────────────────────────

class IntentClassifier:
    """
    Clasifica la intención del usuario en categorías de acción.
    Usa patrones + similitud semántica aproximada.
    """

    # Intenciones y sus señales lingüísticas
    # Formato: 'intent': ([keywords], [patterns_regex], confidence_base)
    INTENTS = {
        # ── SISTEMA ──
        'system_info': (
            ['cpu', 'ram', 'memoria', 'disco', 'temperatura', 'hardware',
             'status', 'estado', 'rendimiento', 'cuánto ocupa', 'cuanta ram',
             'velocidad', 'núcleos', 'procesador', 'batería', 'bateria',
             'cuánta memoria', 'info del sistema', 'información del sistema'],
            [r'c[oó]mo\s+est[aá]\s+(el\s+)?(sistema|pc|ordenador)',
             r'(muestra|dime|dame)\s+(el\s+)?(estado|info|información)',
             r'(cuánto|cuanta|cuantos)\s+(ram|memoria|disco|cpu)',
             r'estat(us|ísticas)\s+(del\s+)?(sistema|pc)'],
            0.7
        ),
        'system_kill': (
            ['mata', 'cierra proceso', 'termina proceso', 'kill', 'fuerza cierre',
             'libera memoria', 'limpia memoria', 'cierra todo'],
            [r'(mata|cierra|termina|elimina)\s+(el\s+)?(proceso|programa)',
             r'(libera|limpia)\s+(la\s+)?memoria'],
            0.75
        ),
        'system_volume': (
            ['volumen', 'sube el volumen', 'baja el volumen', 'silencio', 'mute',
             'más alto', 'más bajo', 'quieto', 'más fuerte', 'más flojo',
             'sube', 'baja', 'alto', 'bajo'],
            [r'(pon|sube|baja|ajusta)\s+(el\s+)?volumen',
             r'volumen\s+al\s+\d+',
             r'(m[aá]s\s+)?(alto|bajo|silencio|mute|fuerte|flojo)'],
            0.6
        ),
        'system_restart': (
            ['reinicia', 'reiniciar', 'restart', 'reinicio'],
            [r'(re)?inicia\s+(el\s+)?(pc|sistema|ordenador|windows)'],
            0.8
        ),
        'system_shutdown': (
            ['apaga', 'apagar', 'shutdown', 'apagado'],
            [r'(apaga|cierra)\s+(el\s+)?(pc|ordenador|sistema|windows)'],
            0.85
        ),
        'system_screenshot': (
            ['captura', 'screenshot', 'pantalla', 'foto de pantalla', 'captura de pantalla'],
            [r'(toma|haz|saca)\s+(una\s+)?(captura|foto|screenshot)',
             r'screenshot'],
            0.8
        ),
        'system_clipboard': (
            ['portapapeles', 'clipboard', 'lo que copié', 'lo que hay copiado'],
            [r'(qu[eé]\s+hay|muestra|lee)\s+(en\s+)?(el\s+)?portapapeles'],
            0.7
        ),

        # ── APPS ──
        'open_app': (
            ['abre', 'abrir', 'lanza', 'lanzar', 'inicia', 'iniciar', 'ejecuta',
             'ejecutar', 'start', 'open', 'arranca'],
            [r'(abre|abrí|lanza|inicia|ejecuta|arranca)\s+\w+',
             r'(quiero|necesito)\s+(abrir|usar|ejecutar)\s+\w+'],
            0.65
        ),
        'close_app': (
            ['cierra', 'cerrar', 'cierre', 'mata', 'termina'],
            [r'(cierra|cierre|mata|termina)\s+\w+\s*(por favor)?$'],
            0.65
        ),

        # ── MEDIOS ──
        'media_play': (
            ['pon', 'poner', 'reproduce', 'reproducir', 'play', 'música', 'canción',
             'song', 'musica', 'spotify', 'youtube', 'escuchar', 'oír', 'oye',
             'suena', 'toca', 'toca algo', 'pon algo'],
            [r'(pon|reproduce|toca|suena)\s+.{1,60}',
             r'(quiero\s+escuchar|escucha[rm]e|ponme)\s+.{1,60}',
             r'(m[uú]sica|canci[oó]n)\s+(de|del?)\s+\w+'],
            0.7
        ),
        'media_pause': (
            ['pausa', 'pausar', 'pause', 'detén', 'detener', 'stop', 'para la música',
             'para eso', 'para'],
            [r'(pausa|para|detén|deja|stop)\s*(la\s+m[uú]sica|eso|ya)?$'],
            0.65
        ),
        'media_next': (
            ['siguiente', 'next', 'otra', 'skip', 'salta', 'cambia'],
            [r'(siguiente|next|otra|skip)\s*(canci[oó]n|cancion|pista)?'],
            0.7
        ),
        'media_video': (
            ['vídeo', 'video', 'serie', 'película', 'pelicula', 've', 'ver',
             'netflix', 'youtube video'],
            [r'(pon|abre|ver)\s+(una?\s+)?(pel[ií]cula|serie|v[ií]deo)',
             r'(quiero\s+ver|ponme)\s+.{1,60}'],
            0.65
        ),

        # ── WEB / BÚSQUEDA ──
        'search_web': (
            ['busca', 'buscar', 'googlea', 'google', 'busca en internet',
             'busca en google', 'busca en youtube', 'qué es', 'quién es',
             'cuándo fue', 'encuentra', 'investiga', 'mira en internet'],
            [r'(busca|googlea|encuentra|investiga)\s+.{1,100}',
             r'(qu[eé]|qui[eé]n|c[oó]mo|cu[aá]ndo|d[oó]nde)\s+(es|son|fue|fué|funciona)',
             r'(busca|mira|echa un vistazo)\s+(en\s+)?(internet|google|la web)'],
            0.6
        ),
        'open_url': (
            ['abre', 'entra en', 've a', 'navega a', 'visita'],
            [r'(abre|entra en|ve a|navega a|visita)\s+(https?://|www\.|\w+\.com)',
             r'https?://\S+',
             r'www\.\S+'],
            0.8
        ),
        'get_news': (
            ['noticias', 'últimas noticias', 'qué ha pasado', 'novedades',
             'actualidad', 'headlines', 'noticias del', 'news'],
            [r'(noticias|actualidad|novedades|headlines)(\s+de|\s+del?)?',
             r'qu[eé]\s+(ha\s+pasado|hay\s+de\s+nuevo)',
             r'(últimas|recientes)\s+noticias'],
            0.7
        ),
        'get_weather': (
            ['tiempo', 'clima', 'temperatura', 'llueve', 'lloverá', 'sol', 'nublado',
             'weather', 'meteorología', 'va a llover', 'hace calor', 'hace frío'],
            [r'(qu[eé]\s+tiempo|c[oó]mo\s+est[aá]\s+el\s+tiempo)',
             r'(tiempo|clima|temperatura)\s+(en|de|para)\s+\w+',
             r'(va\s+a\s+llover|har[aá]\s+(calor|fr[ií]o))'],
            0.7
        ),

        # ── PROGRAMACIÓN / CÓDIGO ──
        'code_generate': (
            ['crea', 'crear', 'genera', 'generar', 'escribe', 'escribir',
             'hazme', 'haz', 'necesito', 'quiero', 'script', 'código',
             'código para', 'programa', 'función', 'clase', 'algoritmo',
             'bot', 'automatiza', 'automatizar'],
            [r'(crea|genera|escribe|hazme|programa)\s+(un[ao]?\s+)?(script|código|función|clase|programa|bot)',
             r'(c[oó]digo|script)\s+(para|que|de)\s+.{5,}',
             r'(automatiza|haz\s+que)\s+.{5,}',
             r'(necesito|quiero)\s+un[ao]?\s+(script|programa|código|función)'],
            0.65
        ),
        'code_analyze': (
            ['analiza', 'analizar', 'revisa', 'revisar', 'explica este código',
             'qué hace', 'qué hace este', 'explica', 'mejora este código',
             'bugs', 'errores en el código', 'qué falla'],
            [r'(analiza|revisa|explica|mejora)\s+(este|el|mi)\s+(c[oó]digo|script|archivo|fichero)',
             r'(qu[eé]\s+(hace|falla|mal)\s+(este|el))',
             r'(busca|encuentra)\s+(bugs|errores|fallos)\s+(en|del?)'],
            0.7
        ),
        'code_run': (
            ['ejecuta', 'ejecutar', 'corre', 'run', 'lanza el script'],
            [r'(ejecuta|corre|run|lanza)\s+(el\s+)?(script|c[oó]digo|archivo|programa)',
             r'(ejecuta|corre)\s+\w+\.py'],
            0.75
        ),

        # ── ARCHIVOS ──
        'file_read': (
            ['lee', 'leer', 'abre', 'muestra', 'qué dice', 'contenido de',
             'lee el archivo', 'lee el documento', 'lee el word', 'lee el pdf',
             'analiza el archivo', 'analiza el documento', 'lee esto'],
            [r'(lee|muestra|abre)\s+(el\s+)?(archivo|documento|fichero|word|pdf|excel)',
             r'(qu[eé]\s+dice|contenido)\s+(del?|en)\s+(archivo|documento)',
             r'(analiza|procesa)\s+(el\s+)?(archivo|documento)',
             r'lee\s+esto'],
            0.7
        ),
        'file_edit': (
            ['edita', 'modifica', 'cambia', 'añade', 'agrega', 'escribe en',
             'guarda', 'sobreescribe', 'actualiza el archivo'],
            [r'(edita|modifica|cambia|actualiza)\s+(el\s+)?(archivo|documento|fichero)',
             r'(a[ñn]ade|agrega|escribe)\s+(en|al?)\s+(archivo|documento)'],
            0.7
        ),
        'file_analyze': (
            ['analiza', 'resume', 'extrae', 'saca info', 'dame un resumen',
             'qué información tiene', 'revisa el documento', 'practica', 'tarea'],
            [r'(analiza|resume|extrae\s+info)\s+(del?|en\s+el)\s+(archivo|documento|pdf)',
             r'(dame\s+un\s+resumen|resumir)\s+(de\s+)?(este|el|mi)',
             r'(revisa|analiza)\s+(mi\s+)?(práctica|tarea|trabajo|documento)'],
            0.65
        ),

        # ── CONVERSACIÓN / IA ──
        'ai_chat': (
            ['qué es', 'explícame', 'cuéntame', 'dime', 'cómo funciona',
             'por qué', 'cuál es la diferencia', 'compara', 'ventajas',
             'desventajas', 'opinas', 'piensas', 'crees', 'recomiendas',
             'ayúdame a entender', 'no entiendo', 'explicación'],
            [r'(qu[eé]|cu[aá]l|c[oó]mo)\s+(es|son|funciona|sirve)\s+.{3,}',
             r'(expl[ií]came|cu[eé]ntame|dime)\s+.{3,}',
             r'(por\s+qu[eé]|cu[aá]ndo|d[oó]nde)\s+.{3,}',
             r'(opinas|piensas|crees|recomiendas)\s+(sobre|de|en)\s+.{3,}',
             r'(diferencia\s+entre|comparar|ventajas\s+de)',
             r'(ayúdame|ayudame)\s+(a\s+)?(entender|aprender)',
             r'(no\s+entiendo|explícame)\s+.{3,}'],
            0.55
        ),
        'ai_write': (
            ['escríbeme', 'redacta', 'redactar', 'escribe', 'escribe un', 'escribe una',
             'carta', 'email', 'correo', 'ensayo', 'resumen', 'texto',
             'artículo', 'blog', 'post', 'descripción', 'bio'],
            [r'(escr[ií]beme|redacta|escribe)\s+(un[ao]?\s+)?(correo|email|carta|texto|ensayo|resumen)',
             r'(necesito|quiero)\s+(un[ao]?\s+)?(texto|escrito|redacción|correo)',
             r'(escribe|redacta)\s+(sobre|acerca\s+de|para)\s+.{3,}'],
            0.65
        ),
        'ai_translate': (
            ['traduce', 'traducir', 'translate', 'en inglés', 'al inglés', 'al español',
             'al francés', 'cómo se dice'],
            [r'(traduce|translate|tradúceme)\s+.{3,}',
             r'c[oó]mo\s+se\s+dice\s+.{3,}\s+en\s+\w+',
             r'(en|al?)\s+(ingl[eé]s|espa[nñ]ol|franc[eé]s|alem[aá]n|italiano)\s+.{3,}'],
            0.8
        ),
        'ai_math': (
            ['calcula', 'calcular', 'cuánto es', 'cuánto da', 'resultado de',
             'matemáticas', 'porcentaje', 'integral', 'derivada', 'ecuación'],
            [r'(cu[aá]nto\s+(es|da|son)|resultado\s+de)\s+.{1,50}',
             r'(calcula|calcular)\s+.{1,50}',
             r'[\d\s\+\-\*/\^]+[\d]'],
            0.8
        ),

        # ── MEMO/RECUERDA ──
        'memory_save': (
            ['recuerda', 'guarda', 'anota', 'apunta', 'memoriza', 'no olvides',
             'tengo que', 'debo', 'mi email es', 'mi contraseña', 'mi número'],
            [r'(recuerda|guarda|anota|apunta|memoriza)\s+(que\s+)?.{5,}',
             r'(mi\s+\w+\s+es)\s+.{3,}',
             r'(no\s+olvides|ten\s+en\s+cuenta)\s+que\s+.{5,}'],
            0.7
        ),
        'memory_recall': (
            ['recuérdame', 'qué recuerdas', 'qué guardaste', 'cuál es mi',
             'dime lo que', 'busca en tu memoria', 'tienes guardado'],
            [r'(recu[eé]rdame|qu[eé]\s+recuerdas|qu[eé]\s+guardaste)',
             r'(cu[aá]l\s+es\s+mi|dame\s+mi)\s+\w+',
             r'tienes\s+guardado\s+(algo\s+sobre|mi)'],
            0.7
        ),

        # ── MODO / AMBIENTE ──
        'mode_work': (
            ['modo trabajo', 'modo trabajo', 'a trabajar', 'voy a trabajar',
             'voy a programar', 'empezar a trabajar', 'entorno trabajo',
             'setup trabajo', 'prepara para trabajar'],
            [r'(modo|entorno)\s+(trabajo|laboral|oficina)',
             r'(voy\s+a|empiezo\s+a)\s+(trabajar|programar|currar)',
             r'(prepara|configura)\s+(el\s+)?(entorno|setup)\s+(para\s+)?(trabajar|programar)'],
            0.75
        ),
        'mode_relax': (
            ['modo relax', 'modo descanso', 'ya terminé', 'termino', 'descanso',
             'relajarse', 'tiempo libre', 'modo ocio'],
            [r'(modo|entorno)\s+(relax|descanso|ocio)',
             r'(ya\s+)?(terminé|acab[eé])\s+(por\s+hoy|el\s+trabajo)?$',
             r'(me\s+voy\s+a\s+)?(descansar|relajar|dormir)'],
            0.7
        ),
        'mode_study': (
            ['modo estudio', 'voy a estudiar', 'estudiar', 'modo concentración', 'focus'],
            [r'(modo|entorno)\s+(estudio|concentraci[oó]n|focus)',
             r'(voy\s+a|necesito)\s+estudiar'],
            0.75
        ),

        # ── AGENDA / RECORDATORIOS ──
        'reminder_set': (
            ['recuérdame', 'avísame', 'alarma', 'recordatorio', 'en X minutos',
             'en una hora', 'mañana a las', 'pon una alarma'],
            [r'(recu[eé]rdame|av[ií]same|pon\s+un\s+recordatorio)\s+.{3,}',
             r'(alarma|recordatorio)\s+(a\s+las|en\s+\d+)\s+.{3,}',
             r'en\s+\d+\s+(minutos?|horas?|d[ií]as?)'],
            0.8
        ),

        # ── SALUDOS / CONVERSACIÓN ──
        'greeting': (
            ['hola', 'buenas', 'hey', 'ey', 'buenos días', 'buenas tardes',
             'buenas noches', 'qué tal', 'cómo estás', 'cómo te encuentras',
             'sigues ahí', 'estás ahí', 'qué pasa', 'qué hay'],
            [r'^(hola|buenas|hey|ey|oi)[\s!.]*$',
             r'^(buenos\s+d[ií]as|buenas\s+(tardes|noches))[\s!.]*$',
             r'^(qu[eé]\s+tal|c[oó]mo\s+est[aá]s?|qu[eé]\s+(pasa|hay))[\s?!.]*$'],
            0.9
        ),
        'farewell': (
            ['adiós', 'hasta luego', 'chao', 'bye', 'hasta pronto', 'hasta mañana',
             'nos vemos', 'cierra', 'apágate'],
            [r'^(adi[oó]s|hasta\s+(luego|pronto|ma[nñ]ana)|bye|chao|nos\s+vemos)[\s!.]*$'],
            0.85
        ),
        'identity': (
            ['quién eres', 'qué eres', 'cómo te llamas', 'tu nombre', 'eres jarvis',
             'eres mark', 'qué eres tú', 'eres una ia'],
            [r'(qui[eé]n|qu[eé])\s+eres(\s+t[uú])?[\s?!.]*$',
             r'c[oó]mo\s+(te\s+llamas|se\s+llama)\s*(t[uú])?[\s?!.]*$'],
            0.85
        ),
        'capabilities': (
            ['qué puedes', 'qué sabes', 'qué haces', 'capacidades', 'comandos',
             'para qué sirves', 'qué puedo pedirte', 'cómo te uso', 'ayuda'],
            [r'(qu[eé]\s+(puedes|sabes|haces)|capacidades|comandos)',
             r'(para\s+qu[eé]\s+sirves|c[oó]mo\s+te\s+uso)',
             r'^ayuda[\s?!.]*$'],
            0.8
        ),
        'thanks': (
            ['gracias', 'gracias mark', 'muchas gracias', 'perfecto', 'genial',
             'bien hecho', 'excelente', 'crack'],
            [r'^(gracias|muchas\s+gracias|perfect[oa]|genial|bien\s+hecho)[\s!.]*$'],
            0.85
        ),
        'cancel': (
            ['cancela', 'olvídalo', 'para', 'stop', 'no hagas nada', 'déjalo',
             'cancela eso', 'olvida', 'no importa'],
            [r'^(cancela|olv[ií]dalo|para|stop|no\s+(hagas|importa))[\s!.]*$'],
            0.8
        ),
        'ai_status': (
            ['cómo está la ia', 'qué motor', 'motor activo', 'ia conectada',
             'ollama', 'lm studio', 'estado ia'],
            [r'(estado|status)\s+(de\s+la\s+)?(ia|ai|inteligencia)',
             r'(qu[eé]\s+motor|motor\s+activo)',
             r'(ollama|lm\s*studio|mistral)\s+(disponible|activo|conectado)'],
            0.8
        ),
    }

    def __init__(self):
        self.normalizer = TextNormalizer()

    def classify(self, text: str) -> Tuple[str, float, Dict]:
        """
        Clasifica texto → (intent, confidence, metadata).
        Devuelve el mejor match con metadata útil.
        """
        normalized = self.normalizer.normalize(text)
        tl = normalized.lower()

        best_intent = 'ai_chat'  # default: pregunta libre a la IA
        best_conf = 0.0
        best_meta = {}

        for intent, (keywords, patterns, base_conf) in self.INTENTS.items():
            conf = self._score(tl, text, keywords, patterns, base_conf)
            if conf > best_conf:
                best_conf = conf
                best_intent = intent
                best_meta = self._extract_meta(intent, tl, text)

        # Si nada supera 0.3, tratar como pregunta libre
        if best_conf < 0.3:
            best_intent = 'ai_chat'
            best_conf = 0.5
            best_meta = {}

        logger.debug(f"NLU: '{text}' → '{best_intent}' [{best_conf:.2f}]")
        return best_intent, best_conf, best_meta

    def _score(self, tl: str, original: str, keywords: List, patterns: List, base: float) -> float:
        score = 0.0

        # 1. Coincidencia de keywords
        keyword_hits = sum(1 for kw in keywords if kw in tl)
        if keyword_hits > 0:
            score += base * (0.5 + 0.1 * min(keyword_hits, 5))

        # 2. Coincidencia de patrones regex
        for pat in patterns:
            if re.search(pat, tl, re.IGNORECASE):
                score = max(score, base * 1.1)
                break

        # 3. Bonus por keyword exacto al principio
        first_word = tl.split()[0] if tl.split() else ''
        if any(kw.split()[0] == first_word for kw in keywords if kw.split()):
            score += 0.05

        return min(score, 1.0)

    def _extract_meta(self, intent: str, tl: str, original: str) -> Dict:
        """Extrae metadatos útiles según el intent."""
        meta = {}

        if intent == 'open_app':
            # Qué app abrir
            m = re.search(r'(?:abre|lanza|inicia|ejecuta|arranca)\s+(.+?)(?:\s+por favor)?$', tl)
            if m:
                meta['app'] = m.group(1).strip()

        elif intent == 'media_play':
            # Qué reproducir
            for pat in [r'(?:pon|reproduce|toca|suena|escucha[rm]e|ponme)\s+(.+)',
                        r'(?:m[uú]sica|canci[oó]n)\s+de\s+(.+)']:
                m = re.search(pat, tl)
                if m:
                    meta['query'] = m.group(1).strip()
                    break

        elif intent == 'search_web':
            for pat in [r'(?:busca|googlea|encuentra)\s+(.+)',
                        r'(?:qu[eé]|qui[eé]n|c[oó]mo|cu[aá]ndo)\s+(?:es|son|fue)\s+(.+)']:
                m = re.search(pat, tl)
                if m:
                    meta['query'] = m.group(1).strip()
                    break
            if not meta.get('query'):
                meta['query'] = original.strip()

        elif intent == 'get_news':
            m = re.search(r'noticias\s+(?:de|del?)\s+(.+)', tl)
            if m:
                meta['topic'] = m.group(1).strip()

        elif intent == 'get_weather':
            m = re.search(r'(?:tiempo|clima|temperatura)\s+(?:en|de)\s+(.+)', tl)
            if m:
                meta['location'] = m.group(1).strip()

        elif intent in ('code_generate', 'ai_write'):
            meta['description'] = original.strip()

        elif intent == 'memory_save':
            m = re.search(r'(?:recuerda|guarda|anota|apunta|memoriza)\s+(?:que\s+)?(.+)', tl)
            if m:
                meta['content'] = m.group(1).strip()
            else:
                meta['content'] = original.strip()

        elif intent == 'reminder_set':
            meta['raw'] = original.strip()

        elif intent in ('file_read', 'file_analyze', 'code_analyze'):
            # Intentar extraer ruta de archivo
            path_m = re.search(r'[\w/\\:\- ]+\.(?:docx?|txt|pdf|py|js|csv|xlsx?|json|xml)',
                                original, re.IGNORECASE)
            if path_m:
                meta['path'] = path_m.group(0).strip()

        elif intent == 'system_volume':
            # Nivel de volumen si lo mencionan
            m = re.search(r'(?:volumen|audio)\s+(?:al|a)\s+(\d+)', tl)
            if m:
                meta['level'] = int(m.group(1))
            elif any(w in tl for w in ['sube', 'más fuerte', 'más alto', 'subir']):
                meta['action'] = 'up'
            elif any(w in tl for w in ['baja', 'más bajo', 'más flojo', 'bajar']):
                meta['action'] = 'down'
            elif any(w in tl for w in ['silencio', 'mute', 'muto', 'quieto']):
                meta['action'] = 'mute'

        elif intent == 'ai_translate':
            lang_map = {'inglés': 'en', 'ingl': 'en', 'español': 'es', 'espanol': 'es',
                        'francés': 'fr', 'frances': 'fr', 'alemán': 'de', 'aleman': 'de',
                        'italiano': 'it', 'portugués': 'pt', 'portugues': 'pt'}
            for word, code in lang_map.items():
                if word in tl:
                    meta['target_lang'] = code
                    break
            meta['text_to_translate'] = original.strip()

        return meta


# ──────────────────────────────────────────────────────────────
# ANALIZADOR DE CONTEXTO
# ──────────────────────────────────────────────────────────────

class ContextAnalyzer:
    """Analiza el contexto emocional y estructura de la solicitud."""

    FRUSTRATION = {
        'joder', 'mierda', 'hostia', 'coño', 'me cago', 'ostia', 'puñeta',
        'no funciona', 'está roto', 'harto', 'qué asco', 'una mierda', 'fatal',
        'imbécil', 'idiota', 'inútil', 'no sirve', 'qué mierda', 'bug', 'falla',
        'petado', 'me va a matar', 'imposible', 'no hay manera'
    }

    URGENCY = {
        'urgente', 'ahora mismo', 'rápido', 'ya', 'inmediatamente',
        'enseguida', 'cuanto antes', 'lo antes posible', 'asap', 'emergency'
    }

    UNCERTAINTY = {
        'no sé', 'no se', 'quizás', 'tal vez', 'a lo mejor', 'puede que',
        'no estoy seguro', 'creo que', 'me parece', 'quizá'
    }

    def analyze(self, text: str, history: List[Dict] = None) -> Dict:
        tl = text.lower()
        words = set(tl.split())

        is_frustrated = bool(self.FRUSTRATION & words) or any(f in tl for f in self.FRUSTRATION)
        is_urgent = bool(self.URGENCY & words) or any(u in tl for u in self.URGENCY)
        is_uncertain = bool(self.UNCERTAINTY & words) or any(u in tl for u in self.UNCERTAINTY)
        is_question = bool(re.search(r'[?]|^(qu[eé]|c[oó]mo|cu[aá]ndo|d[oó]nde|por\s+qu[eé]|cu[aá]l|qui[eé]n)', tl))
        is_command = bool(re.search(r'^(abre|cierra|pon|quita|activa|desactiva|crea|genera|busca|ejecuta|sube|baja)', tl))
        is_vague = len(text.split()) <= 4 and not is_question
        is_chained = bool(re.search(r'\s+(y\s+(luego|después|también)|luego|después)\s+', tl))

        # Detectar si es continuación de conversación
        is_continuation = False
        if history:
            last_bot = next((m['content'] for m in reversed(history) if m['role'] == 'assistant'), '')
            if '?' in last_bot:
                is_continuation = True

        return {
            'is_frustrated': is_frustrated,
            'is_urgent': is_urgent,
            'is_uncertain': is_uncertain,
            'is_question': is_question,
            'is_command': is_command,
            'is_vague': is_vague,
            'is_chained': is_chained,
            'is_continuation': is_continuation,
            'emotional_tone': 'frustrated' if is_frustrated else 'curious' if is_question else 'neutral',
            'word_count': len(text.split()),
        }


# ──────────────────────────────────────────────────────────────
# EXTRACTOR DE ENTIDADES
# ──────────────────────────────────────────────────────────────

class EntityExtractor:
    """Extrae entidades clave del texto: apps, archivos, URLs, etc."""

    KNOWN_APPS = {
        # Navegadores
        'chrome': 'chrome', 'chromium': 'chromium', 'firefox': 'firefox',
        'edge': 'msedge', 'safari': 'safari', 'opera': 'opera', 'brave': 'brave',
        # Editores
        'vscode': 'code', 'vs code': 'code', 'visual studio code': 'code',
        'notepad': 'notepad', 'notepad++': 'notepad++', 'sublime': 'subl',
        'vim': 'vim', 'nano': 'nano', 'pycharm': 'pycharm', 'intellij': 'idea',
        # Terminal
        'terminal': 'cmd', 'cmd': 'cmd', 'powershell': 'powershell',
        'git bash': 'bash', 'consola': 'cmd',
        # Medios
        'spotify': 'spotify', 'vlc': 'vlc', 'youtube music': 'youtube-music',
        'itunes': 'itunes', 'winamp': 'winamp',
        # Office
        'word': 'winword', 'excel': 'excel', 'powerpoint': 'powerpnt',
        'outlook': 'outlook', 'teams': 'teams',
        # Otros
        'steam': 'steam', 'discord': 'discord', 'telegram': 'telegram',
        'whatsapp': 'whatsapp', 'slack': 'slack', 'notion': 'notion',
        'obsidian': 'obsidian', 'figma': 'figma', 'zoom': 'zoom',
        'skype': 'skype', 'calc': 'calc', 'calculadora': 'calc',
        'explorador': 'explorer', 'explorer': 'explorer',
        'paint': 'mspaint', 'gimp': 'gimp', 'photoshop': 'photoshop',
    }

    def extract_app(self, text: str) -> Optional[str]:
        """Extrae nombre de aplicación del texto."""
        tl = text.lower()
        # Buscar apps conocidas
        for name, exe in sorted(self.KNOWN_APPS.items(), key=lambda x: len(x[0]), reverse=True):
            if name in tl:
                return name
        # Fallback: extraer última palabra que parece app
        m = re.search(r'(?:abre|lanza|inicia|ejecuta)\s+(?:el\s+|la\s+|los\s+|las\s+)?(.+?)(?:\s+por\s+favor)?$',
                      tl)
        if m:
            return m.group(1).strip()
        return None

    def extract_file_path(self, text: str) -> Optional[str]:
        """Extrae ruta de archivo del texto."""
        # Rutas absolutas Windows
        m = re.search(r'[A-Za-z]:\\[\w\\ \.]+', text)
        if m:
            return m.group(0)
        # Rutas absolutas Unix
        m = re.search(r'/[\w/ \.]+\.\w+', text)
        if m:
            return m.group(0)
        # Nombre de archivo con extensión
        m = re.search(r'[\w\- ]+\.(?:docx?|pdf|txt|py|js|csv|xlsx?|json|xml|png|jpg|jpeg)',
                      text, re.IGNORECASE)
        if m:
            return m.group(0).strip()
        return None

    def extract_url(self, text: str) -> Optional[str]:
        """Extrae URL del texto."""
        m = re.search(r'https?://\S+|www\.\S+', text)
        return m.group(0) if m else None

    def extract_query(self, text: str) -> str:
        """Extrae la query de búsqueda limpia."""
        # Quitar prefijos de comando
        tl = text.lower()
        for prefix in ['busca ', 'googlea ', 'busca en google ', 'busca en internet ',
                        'busca en youtube ', 'encuentra ', 'investiga ']:
            if tl.startswith(prefix):
                return text[len(prefix):].strip()
        return text.strip()

    def extract_number(self, text: str) -> Optional[float]:
        """Extrae número del texto."""
        m = re.search(r'\d+(?:\.\d+)?', text)
        return float(m.group(0)) if m else None


# ──────────────────────────────────────────────────────────────
# MOTOR NLU PRINCIPAL
# ──────────────────────────────────────────────────────────────

class NLUEngine:
    """
    Motor principal de comprensión de lenguaje natural.
    Combina normalización + clasificación + contexto + entidades.
    """

    def __init__(self):
        self.normalizer  = TextNormalizer()
        self.classifier  = IntentClassifier()
        self.ctx_analyzer = ContextAnalyzer()
        self.entity_ext  = EntityExtractor()
        self._history: List[Dict] = []

    def understand(self, text: str) -> Dict:
        """
        Comprensión completa de un texto.
        Devuelve dict con todo lo necesario para actuar.
        """
        if not text or not text.strip():
            return self._empty()

        # Normalizar
        normalized = self.normalizer.normalize(text)

        # Clasificar intención
        intent, confidence, meta = self.classifier.classify(normalized)

        # Analizar contexto
        ctx = self.ctx_analyzer.analyze(text, self._history)

        # Extraer entidades adicionales
        entities = self._extract_entities(text, intent)
        entities.update(meta)

        # Ajustar confianza por contexto
        if ctx['is_continuation'] and intent == 'ai_chat':
            confidence = max(confidence, 0.7)

        result = {
            'original':    text,
            'normalized':  normalized,
            'intent':      intent,
            'confidence':  confidence,
            'entities':    entities,
            'context':     ctx,
            'is_question': ctx['is_question'],
            'is_command':  ctx['is_command'],
            'emotional_tone': ctx['emotional_tone'],
            'needs_ai':    intent in ('ai_chat', 'ai_write', 'ai_translate', 'ai_math'),
            'needs_local': intent in ('system_info', 'system_volume', 'system_kill',
                                       'open_app', 'close_app', 'media_play', 'media_pause',
                                       'media_next', 'mode_work', 'mode_relax', 'mode_study'),
        }

        # Guardar en historial para contexto
        self._history.append({'role': 'user', 'content': text, 'intent': intent})
        if len(self._history) > 20:
            self._history = self._history[-20:]

        return result

    def _extract_entities(self, text: str, intent: str) -> Dict:
        entities = {}
        if intent in ('open_app', 'close_app'):
            app = self.entity_ext.extract_app(text)
            if app:
                entities['app'] = app
        if intent in ('file_read', 'file_edit', 'file_analyze', 'code_analyze', 'code_run'):
            path = self.entity_ext.extract_file_path(text)
            if path:
                entities['path'] = path
        if intent == 'open_url':
            url = self.entity_ext.extract_url(text)
            if url:
                entities['url'] = url
        if intent in ('search_web', 'get_news'):
            entities['query'] = self.entity_ext.extract_query(text)
        return entities

    def add_bot_response(self, response: str):
        """Registrar respuesta del bot para contexto."""
        self._history.append({'role': 'assistant', 'content': response})

    def clear_history(self):
        self._history.clear()

    def _empty(self) -> Dict:
        return {
            'original': '', 'normalized': '', 'intent': 'ai_chat',
            'confidence': 0.5, 'entities': {}, 'context': {},
            'is_question': False, 'is_command': False,
            'emotional_tone': 'neutral', 'needs_ai': True, 'needs_local': False,
        }


# Instancia global
_nlu = None

def get_nlu() -> NLUEngine:
    global _nlu
    if _nlu is None:
        _nlu = NLUEngine()
    return _nlu
