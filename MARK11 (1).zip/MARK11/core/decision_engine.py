"""
MARK 11 — Decision Engine
Rule-based autonomous decisions with cooldowns.
No LLM calls — runs on lightweight rules only.

Creator: Ali (Sidi3Ali)
System: MARK 11
"""

import logging
import time
from typing import Optional, Dict, List
from dataclasses import dataclass

logger = logging.getLogger('MARK11.Decision')


@dataclass
class Decision:
    type: str          # alert, suggest, info, action
    message: str
    priority: str      # critical, high, medium, low
    auto: bool = False
    cooldown_key: str = ''
    data: Dict = None


class DecisionEngine:
    """
    Autonomous decision engine using pure rules.
    Fast, low CPU, no LLM required.
    """

    def __init__(self):
        self._cooldowns: Dict[str, float] = {}
        self._history: List[Dict] = []
        self._paused = False

    def pause(self):
        self._paused = True

    def resume(self):
        self._paused = False

    def _can_fire(self, key: str, cooldown: float) -> bool:
        now = time.time()
        if now - self._cooldowns.get(key, 0) >= cooldown:
            self._cooldowns[key] = now
            return True
        return False

    def evaluate(self, ctx: Dict, sys: Dict) -> Optional[Decision]:
        """
        Evaluate context and system state.
        Returns single most important decision or None.
        """
        if self._paused:
            return None

        cpu = sys.get('cpu', 0)
        ram = sys.get('ram_percent', 0)
        battery = sys.get('battery')
        charging = sys.get('charging', True)
        activity = ctx.get('user_activity', 'idle')
        duration = ctx.get('activity_duration_minutes', 0)

        # Priority order: critical → high → medium → low

        # 1. Critical battery
        if battery and not charging and battery < 8:
            if self._can_fire('bat_critical', 120):
                return Decision('alert', f"Batería al {battery:.0f}%. ¡Conecta el cargador ya!", 'critical')

        # 2. Critical RAM
        if ram > 92:
            if self._can_fire('ram_critical', 180):
                return Decision('alert', f"Memoria al {ram:.0f}%. Riesgo de bloqueo.", 'critical')

        # 3. High CPU
        if cpu > 88:
            if self._can_fire('cpu_high', 300):
                return Decision('alert', f"CPU al {cpu:.0f}%. Sistema bajo carga pesada.", 'high')

        # 4. Low battery
        if battery and not charging and battery < 20:
            if self._can_fire('bat_low', 600):
                return Decision('alert', f"Batería al {battery:.0f}%. Conecta el cargador.", 'high')

        # 5. RAM warning
        if ram > 80:
            if self._can_fire('ram_high', 300):
                return Decision('info', f"Memoria al {ram:.0f}%. Considera cerrar apps.", 'medium')

        # 6. Long work session
        if activity in ('coding', 'writing') and duration > 90:
            if self._can_fire(f'break_{activity}', 5400):
                return Decision('suggest', f"Llevas {duration:.0f} minutos programando. Descansa un momento.", 'low')

        # 7. Mode switch to work
        if ctx.get('changed') and activity in ('coding', 'writing'):
            if self._can_fire('work_mode', 3600):
                app = ctx.get('active_app', '')
                return Decision('info', f"Modo trabajo en {app}. Listo.", 'low')

        # 8. Leisure without music
        if activity in ('watching', 'gaming') and not ctx.get('is_in_spotify'):
            if self._can_fire('leisure_music', 7200):
                return Decision('suggest', "¿Pongo música?", 'low')

        return None

    def record(self, decision: Decision):
        """Log a decision that was acted upon."""
        self._history.append({
            'time': time.time(),
            'type': decision.type,
            'message': decision.message,
            'priority': decision.priority,
        })
        if len(self._history) > 50:
            self._history = self._history[-50:]

    def get_recent(self, n: int = 5) -> List[Dict]:
        return self._history[-n:]
