"""
JARVIS v7.0 - Audio Monitor
Captura audio del sistema, transcribe y genera resúmenes.
Solo con consentimiento explícito del usuario.
Creador: Ali (Sidi3Ali)
"""

import logging
import threading
import os
import time
import wave
import json
import tempfile
from datetime import datetime
from typing import Optional, Callable, List, Dict

logger = logging.getLogger('JARVIS.AudioMonitor')

RECORDINGS_DIR = os.path.join(os.path.dirname(os.path.dirname(__file__)), 'memory', 'recordings')


class AudioMonitor:
    """
    Monitor de audio del sistema.
    - Captura audio del micrófono o del sistema (loopback)
    - Transcribe a texto
    - Genera resúmenes con IA
    IMPORTANTE: Solo activo con autorización explícita del usuario.
    """

    def __init__(self, brain=None):
        self.brain = brain
        self._authorized = False  # SIEMPRE False por defecto
        self._recording = False
        self._thread: Optional[threading.Thread] = None
        self._frames: List[bytes] = []
        self._sr_ok = False
        self._pyaudio_ok = False
        self._init_libs()
        os.makedirs(RECORDINGS_DIR, exist_ok=True)

    def _init_libs(self):
        try:
            import speech_recognition as sr
            self._sr_ok = True
        except ImportError:
            logger.debug("speech_recognition no disponible")
        try:
            import pyaudio
            self._pyaudio_ok = True
        except ImportError:
            logger.debug("pyaudio no disponible")

    def request_authorization(self) -> bool:
        """
        Solicitar autorización explícita del usuario para monitorizar audio.
        Retorna True si el usuario confirma.
        """
        msg = ("¿Autoriza a JARVIS a capturar y transcribir el audio de esta sesión? "
               "El audio nunca se enviará a servidores externos. "
               "Responda 'sí' para autorizar o 'no' para cancelar.")

        if self.brain and self.brain.voice:
            self.brain.voice.speak(msg, priority=True)

        print(f"\n[SEGURIDAD] {msg}")
        try:
            response = input("Respuesta > ").strip().lower()
            authorized = any(w in response for w in ['si', 'sí', 'yes', 'autorizo', 'confirmo'])
            self._authorized = authorized
            if authorized:
                logger.info("AudioMonitor: autorización concedida por el usuario.")
            else:
                logger.info("AudioMonitor: autorización denegada por el usuario.")
            return authorized
        except Exception:
            self._authorized = False
            return False

    def is_authorized(self) -> bool:
        return self._authorized

    def revoke_authorization(self):
        """Revocar autorización y detener cualquier grabación activa."""
        self._authorized = False
        if self._recording:
            self.stop_recording()
        logger.info("AudioMonitor: autorización revocada.")

    def start_recording(self, source: str = 'microphone',
                         duration: Optional[float] = None,
                         on_complete: Optional[Callable] = None) -> bool:
        """
        Iniciar grabación de audio.
        source: 'microphone' o 'system' (loopback)
        duration: segundos a grabar (None = hasta stop_recording)
        on_complete: callback cuando termine
        """
        if not self._authorized:
            logger.warning("AudioMonitor: grabación bloqueada — sin autorización.")
            return False
        if not self._pyaudio_ok:
            logger.warning("AudioMonitor: PyAudio no disponible.")
            return False
        if self._recording:
            logger.warning("AudioMonitor: ya hay una grabación activa.")
            return False

        self._recording = True
        self._frames = []

        def _record():
            try:
                import pyaudio
                pa = pyaudio.PyAudio()
                CHUNK = 1024
                FORMAT = pyaudio.paInt16
                CHANNELS = 1
                RATE = 16000

                stream = pa.open(
                    format=FORMAT,
                    channels=CHANNELS,
                    rate=RATE,
                    input=True,
                    frames_per_buffer=CHUNK
                )

                logger.info(f"Grabando audio ({source})...")
                start = time.time()
                while self._recording:
                    if duration and (time.time() - start) >= duration:
                        break
                    data = stream.read(CHUNK, exception_on_overflow=False)
                    self._frames.append(data)

                stream.stop_stream()
                stream.close()
                pa.terminate()
                self._recording = False

                # Guardar WAV
                audio_path = self._save_audio(RATE, CHANNELS, FORMAT)
                logger.info(f"Audio guardado: {audio_path}")

                if on_complete and audio_path:
                    on_complete(audio_path)

            except Exception as e:
                logger.error(f"Error en grabación: {e}")
                self._recording = False

        self._thread = threading.Thread(target=_record, daemon=True)
        self._thread.start()
        return True

    def stop_recording(self) -> Optional[str]:
        """Detener grabación y guardar archivo."""
        self._recording = False
        if self._thread:
            self._thread.join(timeout=3)
        if self._frames:
            return self._save_audio(16000, 1, None)
        return None

    def _save_audio(self, rate: int, channels: int, fmt,
                     filename: str = None) -> Optional[str]:
        """Guardar audio grabado en archivo WAV."""
        try:
            import pyaudio
            if filename is None:
                timestamp = datetime.now().strftime('%Y%m%d_%H%M%S')
                filename = os.path.join(RECORDINGS_DIR, f"recording_{timestamp}.wav")

            wf = wave.open(filename, 'wb')
            wf.setnchannels(channels)
            wf.setsampwidth(2)  # paInt16
            wf.setframerate(rate)
            wf.writeframes(b''.join(self._frames))
            wf.close()
            return filename
        except Exception as e:
            logger.error(f"Error guardando audio: {e}")
            return None

    def transcribe_file(self, audio_path: str, language: str = 'es-ES') -> str:
        """Transcribir archivo de audio a texto."""
        if not self._authorized:
            return ""
        if not self._sr_ok:
            return "[STT no disponible]"
        if not os.path.exists(audio_path):
            return ""

        try:
            import speech_recognition as sr
            recognizer = sr.Recognizer()
            with sr.AudioFile(audio_path) as source:
                audio = recognizer.record(source)

            # Intentar Google primero
            try:
                text = recognizer.recognize_google(audio, language=language)
                logger.info(f"Transcripción completada: {len(text)} chars")
                return text
            except sr.UnknownValueError:
                return "[Audio ininteligible]"
            except Exception:
                # Fallback a Sphinx
                try:
                    return recognizer.recognize_sphinx(audio, language=language)
                except Exception:
                    return "[Error de transcripción]"

        except Exception as e:
            logger.error(f"Error transcribiendo: {e}")
            return ""

    def record_and_transcribe(self, duration: float = 30.0,
                               language: str = 'es-ES') -> str:
        """
        Grabar audio por duration segundos y transcribir.
        Requiere autorización previa.
        """
        if not self._authorized:
            return ""

        result_container = {'text': '', 'path': ''}

        def on_done(path):
            result_container['path'] = path
            result_container['text'] = self.transcribe_file(path, language)

        self.start_recording(duration=duration, on_complete=on_done)
        # Esperar a que termine
        timeout = duration + 5
        start = time.time()
        while self._recording and (time.time() - start) < timeout:
            time.sleep(0.5)

        return result_container.get('text', '')

    def summarize_transcription(self, transcription: str) -> str:
        """
        Generar resumen de transcripción con IA.
        """
        if not transcription:
            return ""

        if self.brain and self.brain.ai_manager:
            try:
                prompt = (f"Eres JARVIS. Resume esta transcripción de audio de forma concisa y clara:\n\n"
                          f"{transcription}\n\nResumen:")
                return self.brain.ai_manager.ask(prompt)
            except Exception:
                pass

        # Resumen básico sin IA
        words = transcription.split()
        if len(words) <= 50:
            return transcription
        return ' '.join(words[:50]) + '... [transcripción resumida]'

    def get_recording_list(self) -> List[Dict]:
        """Listar grabaciones disponibles."""
        recordings = []
        try:
            for f in os.listdir(RECORDINGS_DIR):
                if f.endswith('.wav'):
                    path = os.path.join(RECORDINGS_DIR, f)
                    size = os.path.getsize(path)
                    mtime = datetime.fromtimestamp(os.path.getmtime(path))
                    recordings.append({
                        'filename': f,
                        'path': path,
                        'size_kb': size // 1024,
                        'date': mtime.isoformat(),
                    })
        except Exception:
            pass
        return sorted(recordings, key=lambda x: x['date'], reverse=True)
