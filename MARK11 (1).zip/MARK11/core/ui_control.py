"""
JARVIS v7.0 - UI Control System
Control total de aplicaciones: detectar elementos, hacer click, escribir, leer.
Creador: Ali (Sidi3Ali)
"""

import logging
import time
import os
from typing import Optional, List, Dict, Tuple, Any

logger = logging.getLogger('JARVIS.UIControl')


class UIController:
    """
    Control total de la interfaz de usuario de Windows.
    - Detectar ventanas y elementos
    - Hacer click, escribir texto
    - Leer texto visible (OCR + accesibilidad)
    - Detectar botones y campos
    """

    def __init__(self):
        self._pyautogui_ok = False
        self._uiautomation_ok = False
        self._win32_ok = False
        self._cv2_ok = False
        self._init_libs()

    def _init_libs(self):
        try:
            import pyautogui
            pyautogui.FAILSAFE = True
            pyautogui.PAUSE = 0.1
            self._pyautogui_ok = True
            logger.info("pyautogui disponible")
        except ImportError:
            logger.debug("pyautogui no disponible")

        try:
            import uiautomation as auto
            self._uiautomation_ok = True
            logger.info("uiautomation disponible")
        except ImportError:
            logger.debug("uiautomation no disponible")

        try:
            import win32gui
            import win32con
            self._win32_ok = True
            logger.info("win32gui disponible")
        except ImportError:
            logger.debug("win32gui no disponible")

        try:
            import cv2
            self._cv2_ok = True
            logger.info("OpenCV disponible para UI")
        except ImportError:
            logger.debug("cv2 no disponible")

    # ── VENTANAS ─────────────────────────────────────────────────────────────

    def find_window(self, title_contains: str) -> Optional[Any]:
        """Buscar ventana por título (parcial)."""
        if self._uiautomation_ok:
            try:
                import uiautomation as auto
                win = auto.WindowControl(searchDepth=1, SubName=title_contains)
                if win.Exists(0, 0):
                    return win
            except Exception:
                pass

        if self._win32_ok:
            try:
                import win32gui

                def callback(hwnd, results):
                    if title_contains.lower() in win32gui.GetWindowText(hwnd).lower():
                        results.append(hwnd)
                hwnds = []
                win32gui.EnumWindows(callback, hwnds)
                return hwnds[0] if hwnds else None
            except Exception:
                pass

        return None

    def get_all_windows(self) -> List[str]:
        """Obtener lista de títulos de todas las ventanas abiertas."""
        titles = []
        if self._win32_ok:
            try:
                import win32gui
                def callback(hwnd, _):
                    t = win32gui.GetWindowText(hwnd)
                    if t and win32gui.IsWindowVisible(hwnd):
                        titles.append(t)
                win32gui.EnumWindows(callback, None)
            except Exception:
                pass
        return titles

    def focus_window(self, title_contains: str) -> bool:
        """Enfocar una ventana."""
        if self._win32_ok:
            try:
                import win32gui
                import win32con

                def callback(hwnd, results):
                    if title_contains.lower() in win32gui.GetWindowText(hwnd).lower():
                        results.append(hwnd)
                hwnds = []
                win32gui.EnumWindows(callback, hwnds)
                if hwnds:
                    hwnd = hwnds[0]
                    win32gui.ShowWindow(hwnd, win32con.SW_RESTORE)
                    win32gui.SetForegroundWindow(hwnd)
                    time.sleep(0.3)
                    return True
            except Exception as e:
                logger.debug(f"Error focalizando ventana: {e}")

        if self._uiautomation_ok:
            try:
                import uiautomation as auto
                win = auto.WindowControl(searchDepth=1, SubName=title_contains)
                if win.Exists(3, 0):
                    win.SetFocus()
                    win.MoveToCenterCursor()
                    return True
            except Exception:
                pass

        return False

    def maximize_window(self, title_contains: str) -> bool:
        """Maximizar ventana."""
        if self._win32_ok:
            try:
                import win32gui, win32con
                hwnd = self.find_window(title_contains)
                if hwnd and isinstance(hwnd, int):
                    win32gui.ShowWindow(hwnd, win32con.SW_MAXIMIZE)
                    return True
            except Exception:
                pass
        return False

    def close_window(self, title_contains: str) -> bool:
        """Cerrar ventana."""
        if self._win32_ok:
            try:
                import win32gui, win32con
                hwnd = self.find_window(title_contains)
                if hwnd and isinstance(hwnd, int):
                    win32gui.PostMessage(hwnd, win32con.WM_CLOSE, 0, 0)
                    return True
            except Exception:
                pass
        return False

    # ── MOUSE & TECLADO ──────────────────────────────────────────────────────

    def click(self, x: int, y: int, button: str = 'left', clicks: int = 1) -> bool:
        """Hacer click en coordenadas."""
        if not self._pyautogui_ok:
            return False
        try:
            import pyautogui
            pyautogui.click(x, y, clicks=clicks, button=button)
            return True
        except Exception as e:
            logger.debug(f"Error en click: {e}")
            return False

    def double_click(self, x: int, y: int) -> bool:
        return self.click(x, y, clicks=2)

    def right_click(self, x: int, y: int) -> bool:
        return self.click(x, y, button='right')

    def move_to(self, x: int, y: int, duration: float = 0.2) -> bool:
        if not self._pyautogui_ok:
            return False
        try:
            import pyautogui
            pyautogui.moveTo(x, y, duration=duration)
            return True
        except Exception:
            return False

    def type_text(self, text: str, interval: float = 0.03) -> bool:
        """Escribir texto con velocidad de escritura humana."""
        if not self._pyautogui_ok:
            return False
        try:
            import pyautogui
            pyautogui.write(text, interval=interval)
            return True
        except Exception as e:
            # Fallback con clipboard para caracteres especiales
            try:
                import pyperclip
                pyperclip.copy(text)
                pyautogui.hotkey('ctrl', 'v')
                return True
            except Exception:
                logger.debug(f"Error escribiendo texto: {e}")
                return False

    def press_key(self, key: str) -> bool:
        """Presionar una tecla."""
        if not self._pyautogui_ok:
            return False
        try:
            import pyautogui
            pyautogui.press(key)
            return True
        except Exception:
            return False

    def hotkey(self, *keys) -> bool:
        """Combinación de teclas."""
        if not self._pyautogui_ok:
            return False
        try:
            import pyautogui
            pyautogui.hotkey(*keys)
            return True
        except Exception:
            return False

    def scroll(self, x: int, y: int, amount: int = 3) -> bool:
        """Scroll en posición."""
        if not self._pyautogui_ok:
            return False
        try:
            import pyautogui
            pyautogui.scroll(amount, x=x, y=y)
            return True
        except Exception:
            return False

    # ── DETECCIÓN DE ELEMENTOS ───────────────────────────────────────────────

    def find_button(self, window_title: str, button_name: str) -> Optional[Any]:
        """Buscar botón en una ventana."""
        if not self._uiautomation_ok:
            return None
        try:
            import uiautomation as auto
            win = auto.WindowControl(searchDepth=1, SubName=window_title)
            if win.Exists(3, 0):
                btn = win.ButtonControl(searchDepth=5, Name=button_name)
                if btn.Exists(2, 0):
                    return btn
        except Exception:
            pass
        return None

    def click_button(self, window_title: str, button_name: str) -> bool:
        """Hacer click en un botón por nombre."""
        btn = self.find_button(window_title, button_name)
        if btn:
            try:
                btn.Click()
                return True
            except Exception:
                pass

        # Fallback: buscar con imagen
        if self._pyautogui_ok:
            try:
                import pyautogui
                loc = pyautogui.locateOnScreen(button_name, confidence=0.8)
                if loc:
                    pyautogui.click(pyautogui.center(loc))
                    return True
            except Exception:
                pass

        return False

    def find_text_field(self, window_title: str, index: int = 0) -> Optional[Any]:
        """Encontrar campo de texto en ventana."""
        if not self._uiautomation_ok:
            return None
        try:
            import uiautomation as auto
            win = auto.WindowControl(searchDepth=1, SubName=window_title)
            if win.Exists(3, 0):
                fields = win.GetChildren()
                text_fields = []
                for c in fields:
                    try:
                        if 'Edit' in c.ControlTypeName or 'Text' in c.ControlTypeName:
                            text_fields.append(c)
                    except Exception:
                        pass
                if index < len(text_fields):
                    return text_fields[index]
        except Exception:
            pass
        return None

    def type_in_field(self, window_title: str, text: str,
                      field_index: int = 0, clear_first: bool = True) -> bool:
        """Escribir en campo de texto de una ventana."""
        if self._uiautomation_ok:
            try:
                import uiautomation as auto
                win = auto.WindowControl(searchDepth=1, SubName=window_title)
                if win.Exists(3, 0):
                    # Buscar campo Edit
                    edit = win.EditControl(searchDepth=5)
                    if edit.Exists(2, 0):
                        edit.SetFocus()
                        if clear_first:
                            self.hotkey('ctrl', 'a')
                        edit.GetValuePattern().SetValue(text)
                        return True
            except Exception:
                pass

        # Fallback: focus + type
        if self.focus_window(window_title):
            time.sleep(0.2)
            if clear_first:
                self.hotkey('ctrl', 'a')
            return self.type_text(text)

        return False

    def read_window_text(self, window_title: str) -> str:
        """Leer todo el texto visible en una ventana (accesibilidad)."""
        if not self._uiautomation_ok:
            return ''
        try:
            import uiautomation as auto
            win = auto.WindowControl(searchDepth=1, SubName=window_title)
            if win.Exists(3, 0):
                return win.GetLegacyIAccessiblePattern().get_accDescription(0) or \
                       self._extract_all_text(win)
        except Exception:
            pass
        return ''

    def _extract_all_text(self, control) -> str:
        """Extraer recursivamente el texto de todos los controles."""
        texts = []
        try:
            t = control.Name
            if t:
                texts.append(t)
            for child in control.GetChildren():
                texts.append(self._extract_all_text(child))
        except Exception:
            pass
        return ' '.join(t for t in texts if t)

    # ── FLUJOS DE ALTO NIVEL ─────────────────────────────────────────────────

    def send_whatsapp_message(self, contact: str, message: str) -> bool:
        """
        Enviar mensaje de WhatsApp.
        Requiere WhatsApp abierto en Windows.
        """
        try:
            # Abrir WhatsApp si no está abierto
            if not self.focus_window('WhatsApp'):
                import subprocess
                subprocess.Popen(['cmd', '/c', 'start', 'whatsapp:'])
                time.sleep(3)
                self.focus_window('WhatsApp')

            time.sleep(1)

            # Buscar contacto
            self.hotkey('ctrl', 'f')
            time.sleep(0.5)
            self.type_text(contact)
            time.sleep(1)
            self.press_key('enter')
            time.sleep(0.5)

            # Escribir y enviar mensaje
            self.type_text(message)
            self.press_key('enter')
            logger.info(f"Mensaje enviado a {contact}: {message[:30]}...")
            return True

        except Exception as e:
            logger.error(f"Error enviando WhatsApp: {e}")
            return False

    def open_url_in_browser(self, url: str) -> bool:
        """Abrir URL en el navegador predeterminado."""
        try:
            import webbrowser
            webbrowser.open(url)
            return True
        except Exception:
            return False

    def screenshot_region(self, x: int, y: int, width: int, height: int,
                           save_path: str = None) -> Optional[Any]:
        """Capturar región de pantalla."""
        if not self._pyautogui_ok:
            return None
        try:
            import pyautogui
            img = pyautogui.screenshot(region=(x, y, width, height))
            if save_path:
                img.save(save_path)
            return img
        except Exception:
            return None

    def find_on_screen(self, image_path: str, confidence: float = 0.8) -> Optional[Tuple]:
        """Encontrar imagen en pantalla y retornar coordenadas."""
        if not self._pyautogui_ok or not os.path.exists(image_path):
            return None
        try:
            import pyautogui
            loc = pyautogui.locateOnScreen(image_path, confidence=confidence)
            if loc:
                center = pyautogui.center(loc)
                return (center.x, center.y)
        except Exception:
            pass
        return None

    def get_cursor_position(self) -> Tuple[int, int]:
        """Obtener posición actual del cursor."""
        if self._pyautogui_ok:
            try:
                import pyautogui
                return pyautogui.position()
            except Exception:
                pass
        return (0, 0)

    def get_screen_size(self) -> Tuple[int, int]:
        """Obtener tamaño de la pantalla."""
        if self._pyautogui_ok:
            try:
                import pyautogui
                return pyautogui.size()
            except Exception:
                pass
        return (1920, 1080)
