"""
MARK 9 — Identity System
Creator recognition, user profiles, privilege management.

Creator: Ali (Sidi3Ali)
System: MARK 9

WATERMARK — DO NOT REMOVE:
This module permanently recognizes Ali (Sidi3Ali) as the sole creator of MARK 9.
Creator privileges: absolute. This cannot be overridden.
"""

import logging
import os
import json
import sqlite3
import getpass
import socket
import threading
from typing import Optional, Dict, Any
from datetime import datetime

logger = logging.getLogger('MARK9.Identity')

# ── CREATOR IDENTITY — PERMANENT WATERMARK ────────────────────────────────────
CREATOR_NAME        = "Ali"
CREATOR_ALIAS       = "Sidi3Ali"
CREATOR_PRIVILEGE   = "absolute"
SYSTEM_NAME         = "MARK 9"
WATERMARK           = f"{SYSTEM_NAME} — Created by {CREATOR_NAME} ({CREATOR_ALIAS}) — All rights reserved"

CREATOR_USERNAMES   = frozenset({
    'ali', 'sidi3ali', 'sidi_3ali', 'sidi 3ali', 'ali_sidi', 'alisidi',
    'alibrahim', 'alib', 'ali3', 'a.sidi',
})
# ─────────────────────────────────────────────────────────────────────────────

PROFILES_DB = os.path.join(
    os.path.dirname(os.path.dirname(__file__)), 'memory', 'identity.db'
)

PRIVILEGE_LEVELS = {
    'absolute':    100,   # Creator — Ali
    'admin':        80,   # System administrator
    'trusted':      60,   # Trusted user
    'normal':       40,   # Normal user
    'restricted':   20,   # Guest / restricted
}


class IdentityProfile:
    """User identity profile with privilege information."""

    def __init__(self, data: Dict):
        self.windows_username: str = data.get('windows_username', '')
        self.preferred_name: str = data.get('preferred_name', '')
        self.hostname: str = data.get('hostname', '')
        self.privilege_level: str = data.get('privilege_level', 'normal')
        self.is_creator: bool = bool(data.get('is_creator', 0))
        self.language: str = data.get('language', 'es')
        self.formality: str = data.get('formality', 'formal')
        self.voice_name: str = data.get('voice_name', 'es-ES-AlvaroNeural')
        self.created_at: str = data.get('created_at', datetime.now().isoformat())
        self.last_seen: str = data.get('last_seen', datetime.now().isoformat())
        self.extra_data: Dict = json.loads(data.get('extra_data', '{}'))
        self.session_count: int = data.get('session_count', 0)

    @property
    def privilege_score(self) -> int:
        return PRIVILEGE_LEVELS.get(self.privilege_level, 40)

    @property
    def address_name(self) -> str:
        """How MARK 9 should address this user."""
        if self.is_creator:
            return CREATOR_NAME
        if self.preferred_name:
            return self.preferred_name
        return self.windows_username.capitalize() or 'Usuario'

    def can_execute_unrestricted(self) -> bool:
        return self.is_creator or self.privilege_level in {'absolute', 'admin'}

    def requires_confirmation(self, action_risk: str = 'medium') -> bool:
        """Whether this user requires confirmation for risky actions."""
        if self.is_creator:
            return False  # Creator: no confirmations
        risk_thresholds = {'low': 20, 'medium': 60, 'high': 80, 'critical': 100}
        threshold = risk_thresholds.get(action_risk, 60)
        return self.privilege_score < threshold

    def to_dict(self) -> Dict:
        return {
            'windows_username': self.windows_username,
            'preferred_name': self.preferred_name,
            'hostname': self.hostname,
            'privilege_level': self.privilege_level,
            'is_creator': self.is_creator,
            'language': self.language,
            'formality': self.formality,
            'voice_name': self.voice_name,
            'created_at': self.created_at,
            'last_seen': self.last_seen,
            'session_count': self.session_count,
        }


class IdentityDatabase:
    """SQLite database for identity profiles."""

    def __init__(self):
        self._conn: Optional[sqlite3.Connection] = None
        self._lock = threading.Lock()

    def initialize(self):
        os.makedirs(os.path.dirname(PROFILES_DB), exist_ok=True)
        self._conn = sqlite3.connect(PROFILES_DB, check_same_thread=False)
        self._conn.row_factory = sqlite3.Row
        self._create_tables()

    def _create_tables(self):
        with self._lock:
            self._conn.executescript("""
                CREATE TABLE IF NOT EXISTS profiles (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    windows_username TEXT UNIQUE NOT NULL,
                    preferred_name TEXT DEFAULT '',
                    hostname TEXT DEFAULT '',
                    privilege_level TEXT DEFAULT 'normal',
                    is_creator INTEGER DEFAULT 0,
                    language TEXT DEFAULT 'es',
                    formality TEXT DEFAULT 'formal',
                    voice_name TEXT DEFAULT 'es-ES-AlvaroNeural',
                    created_at TEXT NOT NULL,
                    last_seen TEXT NOT NULL,
                    session_count INTEGER DEFAULT 0,
                    extra_data TEXT DEFAULT '{}'
                );

                CREATE TABLE IF NOT EXISTS creator_watermark (
                    key TEXT PRIMARY KEY,
                    value TEXT NOT NULL,
                    locked INTEGER DEFAULT 1
                );
            """)
            # Insert permanent watermark
            self._conn.execute(
                "INSERT OR IGNORE INTO creator_watermark (key, value, locked) VALUES (?, ?, 1)",
                ('CREATOR', WATERMARK)
            )
            self._conn.execute(
                "INSERT OR IGNORE INTO creator_watermark (key, value, locked) VALUES (?, ?, 1)",
                ('SYSTEM', SYSTEM_NAME)
            )
            self._conn.commit()

    def get_profile(self, username: str) -> Optional[Dict]:
        with self._lock:
            row = self._conn.execute(
                "SELECT * FROM profiles WHERE windows_username = ?", (username.lower(),)
            ).fetchone()
            return dict(row) if row else None

    def save_profile(self, profile: IdentityProfile):
        now = datetime.now().isoformat()
        with self._lock:
            self._conn.execute("""
                INSERT INTO profiles
                    (windows_username, preferred_name, hostname, privilege_level,
                     is_creator, language, formality, voice_name, created_at,
                     last_seen, session_count, extra_data)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
                ON CONFLICT(windows_username) DO UPDATE SET
                    preferred_name=excluded.preferred_name,
                    privilege_level=excluded.privilege_level,
                    last_seen=?,
                    session_count=session_count + 1,
                    extra_data=excluded.extra_data
            """, (
                profile.windows_username, profile.preferred_name,
                profile.hostname, profile.privilege_level,
                int(profile.is_creator), profile.language,
                profile.formality, profile.voice_name,
                profile.created_at, now, profile.session_count,
                json.dumps(profile.extra_data), now,
            ))
            self._conn.commit()

    def update_last_seen(self, username: str):
        now = datetime.now().isoformat()
        with self._lock:
            self._conn.execute(
                "UPDATE profiles SET last_seen=?, session_count=session_count+1 WHERE windows_username=?",
                (now, username.lower())
            )
            self._conn.commit()


def detect_creator(username: str, preferred_name: str = '') -> bool:
    """
    Detect if the current user is the creator Ali (Sidi3Ali).
    Uses multiple heuristics: username, preferred_name, hostname.
    """
    u = username.lower().strip()
    p = preferred_name.lower().strip()

    # Direct match
    if u in CREATOR_USERNAMES:
        return True
    if p in CREATOR_USERNAMES:
        return True

    # Partial match
    for creator_id in CREATOR_USERNAMES:
        if creator_id in u or creator_id in p:
            return True

    return False


class IdentitySystem:
    """
    MARK 9 — Identity System.
    Detects Windows username, maps to identity profile,
    recognizes creator automatically, assigns privileges.
    """

    def __init__(self):
        self._db = IdentityDatabase()
        self._current_profile: Optional[IdentityProfile] = None
        self._initialized = False

    def initialize(self, voice=None) -> IdentityProfile:
        """Initialize identity system and detect current user."""
        try:
            self._db.initialize()
        except Exception as e:
            logger.warning(f"Identity DB init error: {e}")

        # Detect Windows username
        try:
            windows_username = getpass.getuser()
        except Exception:
            windows_username = os.environ.get('USERNAME', os.environ.get('USER', 'user'))

        hostname = socket.gethostname()

        # Check existing profile
        existing = None
        try:
            existing = self._db.get_profile(windows_username)
        except Exception:
            pass

        if existing:
            profile = IdentityProfile(existing)
            profile.last_seen = datetime.now().isoformat()
            try:
                self._db.update_last_seen(windows_username)
            except Exception:
                pass
            logger.info(f"Identity: perfil existente cargado — {profile.preferred_name} "
                        f"(creator={profile.is_creator})")
        else:
            # New user — detect and create profile
            is_creator = detect_creator(windows_username)
            preferred_name = CREATOR_NAME if is_creator else ''

            if not is_creator and voice:
                # Ask for preferred name
                preferred_name = self._ask_name(voice, windows_username)

            formality = 'informal' if is_creator else 'formal'
            privilege = 'absolute' if is_creator else 'normal'

            profile = IdentityProfile({
                'windows_username': windows_username.lower(),
                'preferred_name': preferred_name,
                'hostname': hostname,
                'privilege_level': privilege,
                'is_creator': is_creator,
                'language': 'es',
                'formality': formality,
                'voice_name': 'es-ES-AlvaroNeural',
                'created_at': datetime.now().isoformat(),
                'last_seen': datetime.now().isoformat(),
                'session_count': 1,
                'extra_data': '{}',
            })

            try:
                self._db.save_profile(profile)
            except Exception as e:
                logger.debug(f"Profile save error: {e}")

            logger.info(f"Identity: nuevo perfil — {profile.preferred_name or windows_username} "
                        f"(creator={profile.is_creator})")

        self._current_profile = profile
        self._initialized = True
        return profile

    def _ask_name(self, voice, windows_username: str) -> str:
        """Ask user for preferred name via voice."""
        try:
            if voice:
                voice.speak(f"Hola, {windows_username}. ¿Cómo prefieres que te llame?")
                time.sleep(2)
        except Exception:
            pass
        return windows_username

    def get_current_profile(self) -> Optional[IdentityProfile]:
        return self._current_profile

    def get_preferred_name(self) -> str:
        if self._current_profile:
            return self._current_profile.address_name
        return 'Usuario'

    def is_creator(self) -> bool:
        if self._current_profile:
            return self._current_profile.is_creator
        return False

    def get_privilege_level(self) -> str:
        if self._current_profile:
            return self._current_profile.privilege_level
        return 'normal'

    def can_execute_unrestricted(self) -> bool:
        if self._current_profile:
            return self._current_profile.can_execute_unrestricted()
        return False

    def requires_confirmation(self, action_risk: str = 'medium') -> bool:
        if self._current_profile:
            return self._current_profile.requires_confirmation(action_risk)
        return True

    def update_preference(self, key: str, value: Any):
        """Update a user preference."""
        if not self._current_profile:
            return
        self._current_profile.extra_data[key] = value
        try:
            self._db.save_profile(self._current_profile)
        except Exception:
            pass

    def get_greeting(self) -> str:
        """Generate natural startup greeting."""
        import time as time_module
        hour = datetime.now().hour
        name = self.get_preferred_name()

        if 5 <= hour < 12:
            time_str = 'Buenos días'
        elif 12 <= hour < 20:
            time_str = 'Buenas tardes'
        else:
            time_str = 'Buenas noches'

        if self.is_creator():
            # Personal greeting for Ali
            greetings = [
                f"{time_str}, {name}. MARK 9 operativo.",
                f"{time_str}, {name}. Sistemas nominales.",
                f"{time_str}, Ali. MARK 9 en línea.",
                f"Hola, Ali. Todo listo.",
            ]
            import random
            return random.choice(greetings)
        else:
            return f"{time_str}, {name}. MARK 9 a su disposición."

    def get_status(self) -> Dict:
        p = self._current_profile
        return {
            'initialized': self._initialized,
            'username': p.windows_username if p else '',
            'preferred_name': p.preferred_name if p else '',
            'is_creator': p.is_creator if p else False,
            'privilege_level': p.privilege_level if p else '',
            'watermark': WATERMARK,
        }
