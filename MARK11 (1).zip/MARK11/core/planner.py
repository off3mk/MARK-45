"""
JARVIS v7.0 - Task Planner
Planificación y ejecución de tareas multi-paso.
Creador: Ali (Sidi3Ali)
"""

import logging
import time
from typing import Optional, List, Dict, Any

logger = logging.getLogger('JARVIS.Planner')


class TaskStep:
    """Paso individual en un plan de tareas."""

    def __init__(self, skill: str, action: str, params: Dict, description: str):
        self.skill = skill
        self.action = action
        self.params = params
        self.description = description
        self.status = 'pending'  # pending, running, done, failed
        self.result: Optional[str] = None


class TaskPlan:
    """Plan de ejecución de tareas."""

    def __init__(self, name: str, description: str):
        self.name = name
        self.description = description
        self.steps: List[TaskStep] = []
        self.status = 'pending'

    def add_step(self, skill: str, action: str, params: Dict, description: str):
        self.steps.append(TaskStep(skill, action, params, description))

    def __repr__(self):
        return f"TaskPlan({self.name}, {len(self.steps)} pasos)"


class TaskPlanner:
    """Planificador de tareas multi-paso."""

    # Templates predefinidos
    TEMPLATES = {
        'trabajo': {
            'name': 'Modo Trabajo',
            'description': 'Preparar entorno de trabajo',
            'steps': [
                {'skill': 'system', 'action': 'open_app', 'params': {'app': 'chrome'}, 'desc': 'Abrir navegador'},
                {'skill': 'system', 'action': 'open_app', 'params': {'app': 'vscode'}, 'desc': 'Abrir VSCode'},
                {'skill': 'media', 'action': 'volume', 'params': {'level': 30}, 'desc': 'Volumen al 30%'},
            ]
        },
        'relajacion': {
            'name': 'Modo Relajación',
            'description': 'Entorno de descanso',
            'steps': [
                {'skill': 'media', 'action': 'volume', 'params': {'level': 50}, 'desc': 'Volumen al 50%'},
                {'skill': 'media', 'action': 'play', 'params': {'query': 'música relajante'}, 'desc': 'Música relajante'},
            ]
        },
        'estudio': {
            'name': 'Modo Estudio',
            'description': 'Entorno de estudio concentrado',
            'steps': [
                {'skill': 'system', 'action': 'open_app', 'params': {'app': 'chrome'}, 'desc': 'Abrir navegador'},
                {'skill': 'media', 'action': 'volume', 'params': {'level': 20}, 'desc': 'Volumen bajo'},
                {'skill': 'media', 'action': 'play', 'params': {'query': 'música estudio concentración'}, 'desc': 'Música de estudio'},
            ]
        },
        'investigacion': {
            'name': 'Investigación Web',
            'description': 'Abrir herramientas de investigación',
            'steps': [
                {'skill': 'system', 'action': 'open_app', 'params': {'app': 'chrome'}, 'desc': 'Abrir navegador'},
                {'skill': 'internet', 'action': 'search', 'params': {'query': '{topic}'}, 'desc': 'Buscar información'},
            ]
        }
    }

    def __init__(self, brain):
        self.brain = brain
        self._active_plan: Optional[TaskPlan] = None

    def create_plan(self, user_input: str, intent: Optional[Dict] = None) -> Optional[TaskPlan]:
        """Crear plan de ejecución para la solicitud."""
        text_lower = user_input.lower()

        # Buscar template matching
        for key, template in self.TEMPLATES.items():
            if key in text_lower or any(alias in text_lower for alias in self._get_aliases(key)):
                plan = self._build_from_template(template, user_input)
                logger.info(f"Plan creado desde template: {plan.name}")
                return plan

        # Intentar generar plan dinámico
        return self._generate_dynamic_plan(user_input, intent)

    def _get_aliases(self, template_key: str) -> List[str]:
        """Obtener aliases para un template."""
        aliases = {
            'trabajo': ['work', 'trabajar', 'oficina'],
            'relajacion': ['relax', 'descanso', 'descansar'],
            'estudio': ['study', 'estudiar', 'aprender'],
            'investigacion': ['investigar', 'research', 'buscar información'],
        }
        return aliases.get(template_key, [])

    def _build_from_template(self, template: Dict, user_input: str) -> TaskPlan:
        """Construir plan desde un template."""
        plan = TaskPlan(template['name'], template['description'])
        for step in template['steps']:
            # Reemplazar placeholders
            params = dict(step['params'])
            for k, v in params.items():
                if isinstance(v, str) and '{' in v:
                    params[k] = user_input  # Usar input del usuario

            plan.add_step(step['skill'], step['action'], params, step['desc'])
        return plan

    def _generate_dynamic_plan(self, user_input: str, intent: Optional[Dict]) -> Optional[TaskPlan]:
        """Generar plan dinámico basado en la solicitud."""
        text_lower = user_input.lower()

        # Detectar pasos múltiples con "y", "luego", "después"
        connectors = [' y ', ' luego ', ' después ', ' también ', ' además ']
        has_multiple = any(c in text_lower for c in connectors)

        if not has_multiple:
            return None

        plan = TaskPlan('Plan Personalizado', user_input)

        # Dividir por conectores y procesar cada parte
        parts = text_lower
        for connector in connectors:
            parts = parts.replace(connector, '|')

        sub_tasks = [p.strip() for p in parts.split('|') if p.strip()]

        for sub_task in sub_tasks:
            # Detectar qué hacer en cada sub-tarea
            if any(w in sub_task for w in ['abre', 'inicia', 'lanza']):
                app_name = sub_task.split()[-1]
                plan.add_step('system', 'open_app', {'app': app_name}, f'Abrir {app_name}')
            elif any(w in sub_task for w in ['busca', 'googlea']):
                query = ' '.join(sub_task.split()[1:])
                plan.add_step('internet', 'search', {'query': query}, f'Buscar: {query}')
            elif any(w in sub_task for w in ['pon', 'reproduce', 'música']):
                plan.add_step('media', 'play', {'query': sub_task}, f'Reproducir música')

        if plan.steps:
            logger.info(f"Plan dinámico creado con {len(plan.steps)} pasos")
            return plan

        return None

    def execute_plan(self, plan: TaskPlan) -> str:
        """Ejecutar un plan de tareas."""
        self._active_plan = plan
        plan.status = 'running'

        results = []
        logger.info(f"Ejecutando plan: {plan.name}")

        results.append(f"Iniciando '{plan.name}', Señor. Ejecutando {len(plan.steps)} pasos:")

        for i, step in enumerate(plan.steps, 1):
            try:
                step.status = 'running'
                logger.debug(f"Paso {i}/{len(plan.steps)}: {step.description}")

                if self.brain.skill_manager:
                    result = self.brain.skill_manager.execute(
                        step.skill, step.action, step.params, step.description
                    )
                    step.result = result
                    step.status = 'done'
                    results.append(f"  ✓ {step.description}")
                else:
                    step.status = 'failed'
                    results.append(f"  ✗ {step.description} (skill no disponible)")

                time.sleep(0.5)  # Pequeña pausa entre pasos

            except Exception as e:
                step.status = 'failed'
                step.result = str(e)
                results.append(f"  ✗ {step.description}: {str(e)}")
                logger.error(f"Error en paso {i}: {e}")

        completed = sum(1 for s in plan.steps if s.status == 'done')
        plan.status = 'completed'
        results.append(f"\nPlan completado: {completed}/{len(plan.steps)} pasos exitosos, Señor.")

        return "\n".join(results)
