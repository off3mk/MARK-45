"""
MARK 8 — Self Improvement Engine
Análisis de rendimiento, detección de mejoras y generación de nuevas capacidades.

Creador: Ali (Sidi3Ali)
Sistema: MARK 8
"""

import logging
import os
import json
import time
import threading
from typing import Dict, List, Optional, Any
from datetime import datetime

logger = logging.getLogger('MARK8.SelfImprovement')

IMPROVEMENT_LOG = os.path.join(
    os.path.dirname(os.path.dirname(__file__)), 'memory', 'improvements.json'
)
GENERATED_SKILLS_DIR = os.path.join(
    os.path.dirname(os.path.dirname(__file__)), 'skills', 'generated'
)


class PerformanceAnalyzer:
    """Analizar el rendimiento del sistema para detectar cuellos de botella."""

    def analyze_command_history(self, memory_system) -> Dict:
        """Analizar historial de comandos para detectar patrones."""
        report = {
            'total_commands': 0,
            'failed_commands': 0,
            'slow_commands': [],
            'most_frequent': [],
            'errors_detected': [],
        }

        if not memory_system:
            return report

        try:
            history = memory_system.get_history(limit=100) if hasattr(memory_system, 'get_history') else []
            if not history:
                return report

            from collections import Counter
            commands = [h.get('content', '') for h in history if h.get('role') == 'user']
            report['total_commands'] = len(commands)
            if commands:
                freq = Counter(commands)
                report['most_frequent'] = [
                    {'command': cmd, 'count': cnt}
                    for cmd, cnt in freq.most_common(5)
                ]
        except Exception as e:
            logger.debug(f"Error en performance analysis: {e}")

        return report

    def analyze_code_quality(self, filepath: str) -> Dict:
        """Analizar calidad básica de un archivo Python."""
        report = {'file': filepath, 'issues': [], 'suggestions': []}
        if not os.path.exists(filepath):
            return report

        try:
            with open(filepath, 'r', encoding='utf-8', errors='replace') as f:
                code = f.read()

            lines = code.split('\n')
            report['lines'] = len(lines)

            # Detectar funciones sin docstring
            import ast
            try:
                tree = ast.parse(code)
                for node in ast.walk(tree):
                    if isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef)):
                        if not (node.body and isinstance(node.body[0], ast.Expr)
                                and isinstance(node.body[0].value, ast.Constant)):
                            report['issues'].append(
                                f"Función '{node.name}' sin docstring (línea {node.lineno})"
                            )
            except SyntaxError as e:
                report['issues'].append(f"Error de sintaxis: {e}")

            # Detectar funciones muy largas
            for i, line in enumerate(lines):
                if line.strip().startswith('def ') and i + 50 < len(lines):
                    # Contar líneas de la función
                    func_lines = 0
                    for j in range(i + 1, min(i + 200, len(lines))):
                        if lines[j].strip() and not lines[j][0].isspace() and j != i:
                            break
                        func_lines += 1
                    if func_lines > 80:
                        fname = line.strip().replace('def ', '').split('(')[0]
                        report['suggestions'].append(
                            f"Función '{fname}' puede ser muy larga ({func_lines} líneas). Considera dividirla."
                        )

        except Exception as e:
            report['issues'].append(f"Error analizando: {e}")

        return report


class SkillGenerator:
    """Generar nuevos skills automáticamente basados en patrones de uso."""

    SKILL_TEMPLATE = '''"""
MARK 8 — Auto-generated Skill: {skill_name}
Generado automáticamente por el Self Improvement Engine.
Fecha: {date}
Creador del sistema: Ali (Sidi3Ali)
"""

import logging
from typing import Optional, Dict, Any

logger = logging.getLogger('MARK8.Skill.{skill_name}')


class {class_name}:
    """Skill autogenerado: {description}"""

    def __init__(self, brain=None):
        self.brain = brain
        self.enabled = True

    def execute(self, params: Dict = None) -> str:
        """Ejecutar la acción del skill."""
        params = params or {{}}
        logger.info(f"Ejecutando {skill_name} con {{params}}")
        # TODO: Implementar lógica específica
        return "{skill_name} ejecutado."

    def get_info(self) -> Dict:
        return {{
            'name': '{skill_name}',
            'description': '{description}',
            'auto_generated': True,
        }}
'''

    def generate_skill(self, skill_name: str, description: str,
                        base_code: str = '') -> Optional[str]:
        """Generar un nuevo archivo de skill."""
        os.makedirs(GENERATED_SKILLS_DIR, exist_ok=True)

        class_name = ''.join(word.capitalize() for word in skill_name.replace('-', '_').split('_'))
        class_name += 'Skill'

        content = self.SKILL_TEMPLATE.format(
            skill_name=skill_name,
            class_name=class_name,
            description=description,
            date=datetime.now().strftime('%Y-%m-%d'),
        )

        if base_code:
            content += f"\n\n# Código adicional:\n{base_code}\n"

        filepath = os.path.join(GENERATED_SKILLS_DIR, f"{skill_name}.py")
        try:
            with open(filepath, 'w', encoding='utf-8') as f:
                f.write(content)
            logger.info(f"Skill generado: {filepath}")
            return filepath
        except Exception as e:
            logger.error(f"Error generando skill: {e}")
            return None


class SelfImprovementEngine:
    """
    MARK 8 — Motor de Auto-mejora.
    Analiza el rendimiento del sistema, detecta patrones de fallo,
    genera nuevos skills y sugiere mejoras al creador.
    """

    def __init__(self, brain=None):
        self.brain = brain
        self._analyzer = PerformanceAnalyzer()
        self._generator = SkillGenerator()
        self._improvements: List[Dict] = []
        self._lock = threading.Lock()
        self._last_analysis: float = 0.0
        self._analysis_interval = 3600  # Análisis cada hora

        os.makedirs(GENERATED_SKILLS_DIR, exist_ok=True)
        self._load_log()

    def _load_log(self):
        """Cargar historial de mejoras previas."""
        try:
            if os.path.exists(IMPROVEMENT_LOG):
                with open(IMPROVEMENT_LOG, 'r', encoding='utf-8') as f:
                    data = json.load(f)
                    self._improvements = data.get('improvements', [])
        except Exception:
            pass

    def _save_log(self):
        """Guardar historial de mejoras."""
        try:
            os.makedirs(os.path.dirname(IMPROVEMENT_LOG), exist_ok=True)
            with open(IMPROVEMENT_LOG, 'w', encoding='utf-8') as f:
                json.dump({
                    'improvements': self._improvements[-50:],
                    'last_updated': datetime.now().isoformat(),
                }, f, indent=2, ensure_ascii=False)
        except Exception:
            pass

    def run_analysis(self) -> Dict:
        """Ejecutar análisis completo del sistema."""
        report = {
            'timestamp': datetime.now().isoformat(),
            'system': 'MARK 8',
            'issues': [],
            'suggestions': [],
            'generated_skills': [],
        }

        # Analizar módulos del core
        core_dir = os.path.dirname(__file__)
        core_files = [f for f in os.listdir(core_dir) if f.endswith('.py')]

        total_issues = 0
        for fname in core_files[:5]:  # Analizar hasta 5 archivos
            fpath = os.path.join(core_dir, fname)
            analysis = self._analyzer.analyze_code_quality(fpath)
            if analysis.get('issues'):
                total_issues += len(analysis['issues'])
            if analysis.get('suggestions'):
                report['suggestions'].extend(analysis['suggestions'][:2])

        report['issues'].append(f"Análisis de código: {total_issues} issues detectados en {len(core_files)} módulos.")

        # Analizar historial de comandos
        if self.brain and self.brain.memory:
            perf = self._analyzer.analyze_command_history(self.brain.memory)
            if perf.get('most_frequent'):
                top_cmd = perf['most_frequent'][0]
                report['suggestions'].append(
                    f"Comando más frecuente: '{top_cmd['command'][:30]}' ({top_cmd['count']}x). "
                    f"Considera crear un atajo."
                )

        # Registrar
        improvement = {
            'timestamp': report['timestamp'],
            'issues_found': total_issues,
            'suggestions_count': len(report['suggestions']),
        }
        with self._lock:
            self._improvements.append(improvement)
        self._save_log()
        self._last_analysis = time.time()

        return report

    def suggest_new_skill(self, usage_pattern: str) -> Optional[str]:
        """
        Basándose en un patrón de uso, sugerir y generar un nuevo skill.
        Retorna el nombre del skill generado.
        """
        # Mapear patrones a skills potenciales
        patterns = {
            'calendario': ('calendar_skill', 'Gestión de calendario y eventos'),
            'email': ('email_skill', 'Gestión de email'),
            'traducir': ('translation_skill', 'Traducción de texto'),
            'clima': ('weather_skill', 'Información del tiempo'),
            'notas': ('notes_skill', 'Gestión de notas rápidas'),
            'timer': ('timer_skill', 'Temporizador y alarmas'),
            'calculadora': ('calculator_skill', 'Cálculos avanzados'),
            'clipboard': ('clipboard_skill', 'Gestión del portapapeles'),
        }

        pattern_lower = usage_pattern.lower()
        for keyword, (skill_name, description) in patterns.items():
            if keyword in pattern_lower:
                # Verificar si ya existe
                existing = os.path.join(GENERATED_SKILLS_DIR, f"{skill_name}.py")
                if not os.path.exists(existing):
                    filepath = self._generator.generate_skill(skill_name, description)
                    if filepath:
                        return skill_name
                else:
                    return skill_name

        return None

    def generate_custom_skill(self, skill_name: str, description: str,
                               code_hint: str = '') -> Optional[str]:
        """Generar un skill personalizado por solicitud del creador."""
        return self._generator.generate_skill(skill_name, description, code_hint)

    def get_improvement_report(self) -> str:
        """Generar informe de auto-mejora en lenguaje natural."""
        with self._lock:
            recent = self._improvements[-5:] if self._improvements else []

        if not recent:
            return "No se ha ejecutado ningún análisis de auto-mejora todavía."

        last = recent[-1]
        lines = [
            f"Último análisis: {last['timestamp'][:16]}",
            f"Issues detectados: {last.get('issues_found', 0)}",
            f"Sugerencias: {last.get('suggestions_count', 0)}",
        ]

        # Skills generados
        try:
            generated = [
                f for f in os.listdir(GENERATED_SKILLS_DIR)
                if f.endswith('.py') and f != '__init__.py'
            ]
            if generated:
                lines.append(f"Skills autogenerados: {len(generated)}")
        except Exception:
            pass

        return '\n'.join(lines)

    def schedule_periodic_analysis(self):
        """Ejecutar análisis periódico en background."""
        def _run():
            while True:
                try:
                    now = time.time()
                    if now - self._last_analysis >= self._analysis_interval:
                        report = self.run_analysis()
                        # Notificar al creador si hay sugerencias importantes
                        if (report.get('suggestions') and
                                self.brain and self.brain.voice):
                            msg = f"Auto-mejora: {len(report['suggestions'])} sugerencias disponibles."
                            # Solo notificar en horario razonable
                            hour = datetime.now().hour
                            if 9 <= hour <= 21:
                                try:
                                    self.brain.voice.speak(msg, priority=False)
                                except Exception:
                                    pass
                except Exception as e:
                    logger.debug(f"Error en periodic analysis: {e}")
                time.sleep(3600)

        t = threading.Thread(target=_run, name='MARK8-SelfImprovement', daemon=True)
        t.start()

    def get_status(self) -> Dict:
        with self._lock:
            analyses = len(self._improvements)

        generated_count = 0
        try:
            generated_count = len([
                f for f in os.listdir(GENERATED_SKILLS_DIR)
                if f.endswith('.py') and f != '__init__.py'
            ])
        except Exception:
            pass

        return {
            'analyses_run': analyses,
            'generated_skills': generated_count,
            'last_analysis': self._improvements[-1]['timestamp'] if self._improvements else 'nunca',
        }
