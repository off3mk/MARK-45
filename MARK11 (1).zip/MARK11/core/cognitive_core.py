"""
MARK 9 — Cognitive Core
True cognitive pipeline: Perception → Context Fusion → Reasoning →
Planning → Decision → Execution → Memory → Self-Improvement.

This is the central cognitive engine of MARK 9.

Creator: Ali (Sidi3Ali)
System: MARK 9
"""

import logging
import threading
import time
import queue
from typing import Optional, Dict, Any, List, Callable
from datetime import datetime
from dataclasses import dataclass, field

logger = logging.getLogger('MARK9.CognitiveCore')

# ── Pipeline timing ───────────────────────────────────────────────────────────
PERCEPTION_INTERVAL  = 2.0    # Fast: window, app, resources
FUSION_INTERVAL      = 5.0    # Context fusion + opportunity detection
REASONING_INTERVAL   = 30.0   # Deep reasoning (LLM-powered)
IMPROVEMENT_INTERVAL = 3600   # Self-improvement cycle


@dataclass
class CognitiveCycle:
    """State produced by one full cognitive cycle."""
    cycle_id: int = 0
    timestamp: str = field(default_factory=lambda: datetime.now().isoformat())

    # Perception
    active_window: str = ''
    active_app: str = ''
    active_document: str = ''
    user_activity: str = 'idle'
    detected_mode: str = 'unknown'
    cpu: float = 0.0
    ram: float = 0.0
    battery: Optional[float] = None
    media_playing: bool = False

    # Context fusion
    fused_context: Dict = field(default_factory=dict)
    context_changed: bool = False
    context_summary: str = ''

    # Reasoning
    reasoning_triggered: bool = False
    reasoning_output: str = ''

    # Planning
    active_plan: Optional[Dict] = None
    plan_step: int = 0

    # Decision
    decision: Optional[str] = None
    decision_action: Optional[Dict] = None
    confidence: float = 0.0

    # Execution
    execution_result: Optional[str] = None
    execution_success: bool = True

    # Memory
    memory_saved: bool = False


class PerceptionModule:
    """Phase 1: Perceive the system environment."""

    def __init__(self):
        self._win32_ok = False
        self._win32proc_ok = False
        try:
            import win32gui
            self._win32_ok = True
        except ImportError:
            pass
        try:
            import win32process
            self._win32proc_ok = True
        except ImportError:
            pass

    def perceive(self) -> Dict:
        """Collect full system perception snapshot."""
        result = {
            'active_window': '',
            'active_app': '',
            'active_document': '',
            'user_activity': 'idle',
            'media_playing': False,
            'media_app': '',
            'cpu': 0.0,
            'ram': 0.0,
            'battery': None,
            'battery_charging': False,
        }

        # Window + App
        if self._win32_ok:
            try:
                import win32gui
                hwnd = win32gui.GetForegroundWindow()
                result['active_window'] = win32gui.GetWindowText(hwnd) or ''
            except Exception:
                pass

        if self._win32_ok and self._win32proc_ok:
            try:
                import win32gui, win32process, psutil
                hwnd = win32gui.GetForegroundWindow()
                _, pid = win32process.GetWindowThreadProcessId(hwnd)
                result['active_app'] = psutil.Process(pid).name().lower().replace('.exe', '')
            except Exception:
                result['active_app'] = self._get_app_fallback()
        else:
            result['active_app'] = self._get_app_fallback()

        # Document from window title
        win = result['active_window']
        for sep in [' - ', ' — ', ' | ']:
            if sep in win:
                result['active_document'] = win.split(sep)[0].strip()
                break

        # Activity classification
        result['user_activity'] = self._classify_activity(result['active_app'], win)

        # System resources
        try:
            import psutil
            result['cpu'] = psutil.cpu_percent(interval=None)
            result['ram'] = psutil.virtual_memory().percent
            bat = psutil.sensors_battery()
            if bat:
                result['battery'] = bat.percent
                result['battery_charging'] = bat.power_plugged
        except Exception:
            pass

        # Media
        result['media_playing'], result['media_app'] = self._detect_media()

        return result

    def _get_app_fallback(self) -> str:
        try:
            import psutil
            ignore = {'system', 'idle', 'svchost', 'dwm', 'winlogon', 'csrss'}
            for p in psutil.process_iter(['name', 'status']):
                if p.info['status'] == 'running':
                    n = p.info['name'].lower().replace('.exe', '')
                    if n not in ignore and len(n) > 2:
                        return n
        except Exception:
            pass
        return ''

    def _classify_activity(self, app: str, window: str) -> str:
        a = app.lower()
        w = window.lower()
        cats = {
            'coding':        {'code', 'vscode', 'pycharm', 'intellij', 'cursor', 'sublime', 'vim'},
            'writing':       {'word', 'winword', 'notion', 'obsidian', 'typora', 'libreoffice'},
            'designing':     {'figma', 'photoshop', 'illustrator', 'gimp', 'blender', 'canva'},
            'gaming':        {'steam', 'epicgames', 'origin', 'battlenet'},
            'communication': {'teams', 'slack', 'discord', 'zoom', 'telegram', 'whatsapp'},
            'watching':      {'vlc', 'mpv', 'mpc-hc', 'potplayer', 'plex'},
        }
        for activity, apps in cats.items():
            if any(x in a for x in apps):
                return activity
        if any(b in a for b in ['chrome', 'firefox', 'edge', 'opera', 'brave']):
            if any(k in w for k in ['youtube', 'twitch', 'netflix']):
                return 'watching'
            if any(k in w for k in ['github', 'stackoverflow', 'docs']):
                return 'coding'
            return 'browsing'
        return 'idle'

    def _detect_media(self):
        try:
            import psutil
            media = {'spotify', 'vlc', 'mpv', 'foobar2000', 'musicbee', 'itunes', 'mpc-hc'}
            for p in psutil.process_iter(['name']):
                n = p.info['name'].lower().replace('.exe', '')
                if n in media:
                    return True, n
        except Exception:
            pass
        return False, ''


class ContextFusionModule:
    """Phase 2: Fuse perception with history and memory."""

    def __init__(self):
        self._prev_context: Dict = {}
        self._context_history: List[Dict] = []
        self._activity_times: Dict[str, float] = {}

    def fuse(self, raw_perception: Dict, memory_facts: Dict = None) -> Dict:
        """Merge perception + history + memory into rich context."""
        ctx = dict(raw_perception)

        # Activity duration
        activity = ctx.get('user_activity', 'idle')
        now = time.time()
        if activity not in self._activity_times:
            self._activity_times = {activity: now}
        ctx['activity_duration_minutes'] = (now - self._activity_times.get(activity, now)) / 60.0

        # Mode detection
        mode_map = {
            'coding': 'work', 'writing': 'work', 'designing': 'creative',
            'browsing': 'study', 'watching': 'leisure', 'gaming': 'leisure',
            'communication': 'communication', 'idle': 'unknown',
        }
        ctx['detected_mode'] = mode_map.get(activity, 'unknown')

        # Time context
        hour = datetime.now().hour
        ctx['hour'] = hour
        ctx['time_of_day'] = ('morning' if 5 <= hour < 12 else
                               'afternoon' if 12 <= hour < 17 else
                               'evening' if 17 <= hour < 21 else 'night')
        ctx['weekday'] = datetime.now().weekday()

        # Merge memory facts
        if memory_facts:
            ctx['memory'] = memory_facts

        # Detect context change
        changed = self._detect_change(ctx)
        ctx['context_changed'] = changed

        # Update history
        self._prev_context = ctx.copy()
        self._context_history.append(ctx)
        if len(self._context_history) > 100:
            self._context_history = self._context_history[-100:]

        return ctx

    def _detect_change(self, ctx: Dict) -> bool:
        if not self._prev_context:
            return True
        significant = ['active_app', 'user_activity', 'detected_mode']
        return any(ctx.get(k) != self._prev_context.get(k) for k in significant)

    def get_history(self, n: int = 10) -> List[Dict]:
        return self._context_history[-n:]

    def get_dominant_mode(self, window: int = 20) -> str:
        from collections import Counter
        history = self._context_history[-window:]
        modes = [c.get('detected_mode', 'unknown') for c in history
                 if c.get('detected_mode') != 'unknown']
        if not modes:
            return 'unknown'
        return Counter(modes).most_common(1)[0][0]


class ReasoningModule:
    """Phase 3: LLM-powered reasoning about context."""

    def __init__(self, llm_engine=None):
        self.llm = llm_engine
        self._last_reasoning: float = 0.0
        self._reasoning_cooldown = 120.0  # Min 2 min between LLM reasoning calls
        self._cache: Dict[str, str] = {}

    def should_reason(self, ctx: Dict) -> bool:
        """Determine if deep reasoning is needed."""
        now = time.time()
        if now - self._last_reasoning < self._reasoning_cooldown:
            return False

        # Trigger on significant events
        triggers = [
            ctx.get('cpu', 0) > 85,
            ctx.get('context_changed', False) and ctx.get('detected_mode') != 'unknown',
            ctx.get('activity_duration_minutes', 0) > 90,
            ctx.get('ram', 0) > 88,
        ]
        return any(triggers)

    def reason(self, ctx: Dict) -> str:
        """Deep reasoning using LLM about current context."""
        if not self.llm:
            return ''

        self._last_reasoning = time.time()
        try:
            return self.llm.analyze_context(ctx, "¿Qué necesita el usuario ahora? ¿Hay alguna oportunidad de asistencia?")
        except Exception as e:
            logger.debug(f"Reasoning error: {e}")
            return ''


class PlanningModule:
    """Phase 4: Convert goals into executable steps."""

    def __init__(self, llm_engine=None):
        self.llm = llm_engine
        self._active_plan: Optional[Dict] = None
        self._plan_step = 0
        self._completed_plans: List[Dict] = []

    def create_plan(self, goal: str, ctx: Dict = None) -> Dict:
        """Generate an executable plan for a goal."""
        if self.llm:
            try:
                plan = self.llm.generate_plan(goal, ctx)
                self._active_plan = plan
                self._plan_step = 0
                logger.info(f"Plan creado: {goal} ({len(plan.get('steps', []))} pasos)")
                return plan
            except Exception as e:
                logger.debug(f"Planning LLM error: {e}")

        # Fallback: simple direct plan
        return {
            'goal': goal,
            'steps': [{'id': 1, 'action': goal, 'skill': 'ai', 'params': {}, 'reversible': False}],
            'estimated_duration_seconds': 5,
            'fallback': 'Reportar al usuario',
        }

    def get_next_step(self) -> Optional[Dict]:
        if not self._active_plan:
            return None
        steps = self._active_plan.get('steps', [])
        if self._plan_step < len(steps):
            return steps[self._plan_step]
        return None

    def advance_step(self, success: bool = True):
        if success:
            self._plan_step += 1
        else:
            # Plan failed — try fallback
            logger.warning(f"Paso de plan falló (paso {self._plan_step})")
            self._active_plan = None
            self._plan_step = 0

    def complete_plan(self):
        if self._active_plan:
            self._completed_plans.append({
                'plan': self._active_plan,
                'completed_at': datetime.now().isoformat(),
            })
        self._active_plan = None
        self._plan_step = 0

    def has_active_plan(self) -> bool:
        return self._active_plan is not None

    def get_active_plan(self) -> Optional[Dict]:
        return self._active_plan


class DecisionModule:
    """Phase 5: Decide what to do based on fused context and reasoning."""

    def __init__(self):
        self._cooldowns: Dict[str, float] = {}
        self._decision_history: List[Dict] = []

    def decide(self, ctx: Dict, reasoning: str = '') -> Optional[Dict]:
        """Make an autonomous decision based on context."""
        now = time.time()
        decision = None

        # Rule-based decisions (fast path, no LLM needed)
        decision = (
            self._check_resource_alerts(ctx, now) or
            self._check_work_patterns(ctx, now) or
            self._check_mode_transitions(ctx, now) or
            self._check_battery(ctx, now)
        )

        # LLM-informed suggestion (if reasoning provided)
        if not decision and reasoning and len(reasoning) > 20:
            key = f"llm_suggest_{ctx.get('detected_mode')}"
            if now - self._cooldowns.get(key, 0) > 3600:
                self._cooldowns[key] = now
                decision = {
                    'type': 'llm_suggest',
                    'message': reasoning[:200],
                    'priority': 'low',
                    'auto': False,
                }

        if decision:
            self._decision_history.append({
                'decision': decision,
                'context': {k: ctx.get(k) for k in ['active_app', 'user_activity', 'detected_mode']},
                'time': now,
            })

        return decision

    def _check_resource_alerts(self, ctx: Dict, now: float) -> Optional[Dict]:
        cpu = ctx.get('cpu', 0)
        ram = ctx.get('ram', 0)

        if cpu > 90 and now - self._cooldowns.get('cpu90', 0) > 180:
            self._cooldowns['cpu90'] = now
            return {'type': 'alert', 'priority': 'high', 'auto': False,
                    'message': f"CPU al {cpu:.0f}%. ¿Analizo procesos?"}

        if cpu > 80 and now - self._cooldowns.get('cpu80', 0) > 300:
            self._cooldowns['cpu80'] = now
            return {'type': 'alert', 'priority': 'medium', 'auto': False,
                    'message': f"CPU al {cpu:.0f}%. Sistema bajo carga."}

        if ram > 92 and now - self._cooldowns.get('ram92', 0) > 180:
            self._cooldowns['ram92'] = now
            return {'type': 'alert', 'priority': 'high', 'auto': False,
                    'message': f"Memoria al {ram:.0f}%. Riesgo de lentitud."}

        return None

    def _check_work_patterns(self, ctx: Dict, now: float) -> Optional[Dict]:
        duration = ctx.get('activity_duration_minutes', 0)
        activity = ctx.get('user_activity', '')

        if activity in {'coding', 'writing'} and duration > 90:
            key = f"break_{activity}"
            if now - self._cooldowns.get(key, 0) > 5400:
                self._cooldowns[key] = now
                return {'type': 'suggest', 'priority': 'low', 'auto': False,
                        'message': f"Llevas {duration:.0f} minutos en modo {activity}. Considera un descanso, Ali."}
        return None

    def _check_mode_transitions(self, ctx: Dict, now: float) -> Optional[Dict]:
        if not ctx.get('context_changed'):
            return None
        mode = ctx.get('detected_mode', 'unknown')
        if mode == 'unknown':
            return None

        key = f"mode_switch_{mode}"
        if now - self._cooldowns.get(key, 0) < 3600:
            return None
        self._cooldowns[key] = now

        if mode == 'work':
            return {'type': 'info', 'priority': 'low', 'auto': False,
                    'message': f"Modo trabajo detectado en {ctx.get('active_app', '')}. Listo para asistir."}
        if mode == 'leisure' and not ctx.get('media_playing'):
            return {'type': 'suggest', 'priority': 'low', 'auto': False,
                    'message': "Modo ocio detectado. ¿Pongo música?"}
        return None

    def _check_battery(self, ctx: Dict, now: float) -> Optional[Dict]:
        bat = ctx.get('battery')
        charging = ctx.get('battery_charging', True)
        if bat is None or charging:
            return None
        if bat < 10 and now - self._cooldowns.get('bat10', 0) > 300:
            self._cooldowns['bat10'] = now
            return {'type': 'alert', 'priority': 'critical', 'auto': False,
                    'message': f"Batería al {bat:.0f}%. Conecta el cargador AHORA."}
        if bat < 20 and now - self._cooldowns.get('bat20', 0) > 600:
            self._cooldowns['bat20'] = now
            return {'type': 'alert', 'priority': 'high', 'auto': False,
                    'message': f"Batería al {bat:.0f}%. Conecta el cargador."}
        return None

    def get_history(self, n: int = 10) -> List[Dict]:
        return self._decision_history[-n:]


class MemoryUpdateModule:
    """Phase 7: Save cognitive cycle to persistent memory."""

    def save(self, cycle: CognitiveCycle, brain) -> bool:
        if not brain:
            return False
        try:
            if brain.cognitive_memory:
                brain.cognitive_memory.log_action(
                    action=cycle.user_activity,
                    skill='cognitive_core',
                    params={
                        'app': cycle.active_app,
                        'mode': cycle.detected_mode,
                        'doc': cycle.active_document[:80] if cycle.active_document else '',
                    },
                    context=cycle.detected_mode,
                )
                return True
        except Exception as e:
            logger.debug(f"Memory save error: {e}")
        return False


class CognitiveCore:
    """
    MARK 9 — Cognitive Core.
    True cognitive pipeline running continuously in background.
    Each cycle: Perception → Context Fusion → Reasoning → Planning →
                Decision → Execution → Memory → Self-Improvement
    """

    def __init__(self, brain=None):
        self.brain = brain
        self._running = False
        self._paused = False
        self._thread: Optional[threading.Thread] = None
        self._cycle_count = 0
        self._session_start = time.time()
        self._current_cycle: Optional[CognitiveCycle] = None
        self._lock = threading.Lock()

        # Pipeline modules
        self._perception = PerceptionModule()
        self._fusion = ContextFusionModule()
        self._reasoning = ReasoningModule()
        self._planning = PlanningModule()
        self._decision = DecisionModule()
        self._memory_mod = MemoryUpdateModule()

        # External callbacks
        self._state_callbacks: List[Callable] = []
        self._notification_callbacks: List[Callable] = []

        # Timing
        self._last_deep_reasoning = 0.0
        self._last_improvement = 0.0

    def set_llm(self, llm_engine):
        """Inject LLM engine after initialization."""
        self._reasoning.llm = llm_engine
        self._planning.llm = llm_engine

    def start(self):
        """Start the cognitive pipeline in background."""
        self._running = True
        self._thread = threading.Thread(
            target=self._pipeline,
            name='MARK9-CognitiveCore',
            daemon=True
        )
        self._thread.start()
        logger.info("MARK 9 Cognitive Core pipeline started.")

    def stop(self):
        self._running = False
        if self._thread:
            self._thread.join(timeout=5)
        logger.info("MARK 9 Cognitive Core stopped.")

    def pause(self):
        self._paused = True

    def resume(self):
        self._paused = False

    def _pipeline(self):
        """Main cognitive pipeline loop."""
        last_fusion = 0.0
        last_deep = 0.0

        while self._running:
            if self._paused:
                time.sleep(1)
                continue

            cycle_start = time.time()
            cycle = CognitiveCycle(cycle_id=self._cycle_count)
            self._cycle_count += 1

            try:
                # ── Phase 1: Perception ──────────────────────────────────────
                raw = self._perception.perceive()
                cycle.active_window = raw.get('active_window', '')
                cycle.active_app = raw.get('active_app', '')
                cycle.active_document = raw.get('active_document', '')
                cycle.user_activity = raw.get('user_activity', 'idle')
                cycle.cpu = raw.get('cpu', 0.0)
                cycle.ram = raw.get('ram', 0.0)
                cycle.battery = raw.get('battery')
                cycle.media_playing = raw.get('media_playing', False)

                now = time.time()

                # ── Phase 2: Context Fusion (every 5s) ───────────────────────
                if now - last_fusion >= FUSION_INTERVAL:
                    last_fusion = now
                    memory_facts = self._get_memory_facts()
                    ctx = self._fusion.fuse(raw, memory_facts)
                    cycle.fused_context = ctx
                    cycle.context_changed = ctx.get('context_changed', False)
                    cycle.detected_mode = ctx.get('detected_mode', 'unknown')
                    cycle.context_summary = f"{cycle.active_app} | {cycle.user_activity}"

                    # ── Phase 3: Reasoning (LLM, throttled) ─────────────────
                    if (self._reasoning.should_reason(ctx) and
                            now - last_deep >= REASONING_INTERVAL):
                        last_deep = now
                        cycle.reasoning_triggered = True
                        cycle.reasoning_output = self._reasoning.reason(ctx)

                    # ── Phase 4: Planning ────────────────────────────────────
                    # Only create plans when explicitly requested (via create_plan)

                    # ── Phase 5: Decision ────────────────────────────────────
                    decision = self._decision.decide(ctx, cycle.reasoning_output)
                    if decision:
                        cycle.decision = decision.get('type')
                        cycle.decision_action = decision
                        cycle.confidence = 0.85

                    # ── Phase 6: Execution ───────────────────────────────────
                    if decision:
                        self._execute_decision(decision, cycle)

                    # ── Phase 7: Memory ──────────────────────────────────────
                    cycle.memory_saved = self._memory_mod.save(cycle, self.brain)

                # Update current cycle
                with self._lock:
                    self._current_cycle = cycle

                # Notify external callbacks
                for cb in self._state_callbacks:
                    try:
                        cb(cycle)
                    except Exception:
                        pass

                # ── Phase 8: Self-Improvement (hourly) ───────────────────────
                if now - self._last_improvement >= IMPROVEMENT_INTERVAL:
                    self._last_improvement = now
                    self._run_self_improvement()

            except Exception as e:
                logger.debug(f"Cognitive pipeline error: {e}")

            elapsed = time.time() - cycle_start
            sleep_time = max(0.1, PERCEPTION_INTERVAL - elapsed)
            time.sleep(sleep_time)

    def _get_memory_facts(self) -> Dict:
        """Retrieve relevant facts from persistent memory."""
        facts = {}
        try:
            if self.brain and self.brain.cognitive_memory:
                predictions = self.brain.cognitive_memory.get_predictions_for_now()
                if predictions:
                    facts['predicted_actions'] = predictions
        except Exception:
            pass
        return facts

    def _execute_decision(self, decision: Dict, cycle: CognitiveCycle):
        """Execute an autonomous decision (notification / action)."""
        msg = decision.get('message', '')
        dtype = decision.get('type', 'info')
        priority = decision.get('priority', 'low')
        auto = decision.get('auto', False)

        logger.info(f"[COGNITIVE DECISION] {dtype.upper()}: {msg}")

        if self.brain:
            # Voice notification
            if self.brain.voice and msg:
                speak_priority = priority in {'high', 'critical'}
                try:
                    self.brain.voice.speak(msg, priority=speak_priority)
                except Exception:
                    pass

            # UI callback
            if self.brain._ui_callback and msg:
                try:
                    self.brain._ui_callback('cognitive_decision', {
                        'type': dtype,
                        'priority': priority,
                        'message': msg,
                        'cycle_id': cycle.cycle_id,
                        'auto': auto,
                    })
                except Exception:
                    pass

        cycle.execution_result = msg
        cycle.execution_success = True

        # Notify external callbacks
        for cb in self._notification_callbacks:
            try:
                cb(decision, cycle)
            except Exception:
                pass

    def _run_self_improvement(self):
        """Trigger self-improvement analysis in background."""
        if self.brain and hasattr(self.brain, 'self_improvement') and self.brain.self_improvement:
            def _run():
                try:
                    report = self.brain.self_improvement.run_analysis()
                    logger.info(f"Self-improvement: {report.get('issues', [])[:1]}")
                except Exception:
                    pass
            threading.Thread(target=_run, daemon=True, name='MARK9-SelfImprove').start()

    # ── Public API ────────────────────────────────────────────────────────────

    def create_plan(self, goal: str) -> Dict:
        """Create and activate a plan for a goal."""
        ctx = self.get_current_context()
        plan = self._planning.create_plan(goal, ctx)
        return plan

    def get_current_cycle(self) -> Optional[CognitiveCycle]:
        with self._lock:
            return self._current_cycle

    def get_current_context(self) -> Dict:
        with self._lock:
            c = self._current_cycle
        if c and c.fused_context:
            return c.fused_context
        if c:
            return {
                'active_app': c.active_app,
                'user_activity': c.user_activity,
                'detected_mode': c.detected_mode,
                'cpu': c.cpu,
                'ram': c.ram,
            }
        return {}

    def add_state_callback(self, cb: Callable):
        self._state_callbacks.append(cb)

    def add_notification_callback(self, cb: Callable):
        self._notification_callbacks.append(cb)

    def get_status(self) -> Dict:
        c = self.get_current_cycle()
        return {
            'running': self._running,
            'paused': self._paused,
            'cycles': self._cycle_count,
            'session_minutes': (time.time() - self._session_start) / 60.0,
            'current_app': c.active_app if c else '',
            'current_mode': c.detected_mode if c else '',
            'activity': c.user_activity if c else '',
            'cpu': c.cpu if c else 0.0,
            'ram': c.ram if c else 0.0,
            'active_plan': self._planning.has_active_plan(),
            'recent_decisions': len(self._decision.get_history()),
        }
