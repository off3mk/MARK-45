"""
MARK 11 — Memory System
SQLite persistence: conversations, preferences, habits, user profile.
LRU cache for fast access. Auto-load on startup.

Creator: Ali (Sidi3Ali)
System: MARK 11
"""

import sqlite3
import json
import logging
import os
import threading
import time
from typing import Optional, List, Dict, Any
from datetime import datetime
from collections import OrderedDict

logger = logging.getLogger('MARK11.Memory')

DB_PATH = os.path.join(os.path.dirname(os.path.dirname(__file__)), 'memory', 'mark11.db')


class LRUCache:
    def __init__(self, size: int = 100):
        self._cache = OrderedDict()
        self._size = size
        self._lock = threading.Lock()

    def get(self, key: str) -> Optional[Any]:
        with self._lock:
            if key not in self._cache:
                return None
            self._cache.move_to_end(key)
            return self._cache[key]

    def put(self, key: str, value: Any):
        with self._lock:
            if key in self._cache:
                self._cache.move_to_end(key)
            self._cache[key] = value
            if len(self._cache) > self._size:
                self._cache.popitem(last=False)

    def clear(self):
        with self._lock:
            self._cache.clear()


class MemorySystem:
    """
    MARK 11 persistent memory.
    Tables: conversations, preferences, habits, knowledge, events.
    """

    def __init__(self, db_path: str = None):
        self._db_path = db_path or DB_PATH
        self._conn: Optional[sqlite3.Connection] = None
        self._lock = threading.Lock()
        self._cache = LRUCache(100)
        self._initialized = False

    def initialize(self):
        os.makedirs(os.path.dirname(self._db_path), exist_ok=True)
        self._conn = sqlite3.connect(self._db_path, check_same_thread=False)
        self._conn.row_factory = sqlite3.Row
        self._conn.execute("PRAGMA journal_mode=WAL")
        self._conn.execute("PRAGMA synchronous=NORMAL")
        self._create_tables()
        self._initialized = True
        logger.info(f"Memory: {self._db_path}")

    def _create_tables(self):
        with self._lock:
            self._conn.executescript("""
                CREATE TABLE IF NOT EXISTS conversations (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    timestamp TEXT NOT NULL,
                    role TEXT NOT NULL,
                    content TEXT NOT NULL,
                    session_id TEXT DEFAULT 'default'
                );

                CREATE TABLE IF NOT EXISTS preferences (
                    key TEXT PRIMARY KEY,
                    value TEXT NOT NULL,
                    updated_at TEXT NOT NULL
                );

                CREATE TABLE IF NOT EXISTS habits (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    action TEXT NOT NULL,
                    frequency INTEGER DEFAULT 1,
                    last_seen TEXT,
                    hour_of_day INTEGER DEFAULT -1
                );

                CREATE TABLE IF NOT EXISTS knowledge (
                    key TEXT PRIMARY KEY,
                    value TEXT NOT NULL,
                    category TEXT DEFAULT 'general',
                    updated_at TEXT NOT NULL
                );

                CREATE TABLE IF NOT EXISTS events (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    timestamp TEXT NOT NULL,
                    event_type TEXT NOT NULL,
                    data TEXT,
                    app TEXT DEFAULT ''
                );

                CREATE TABLE IF NOT EXISTS user_profile (
                    key TEXT PRIMARY KEY,
                    value TEXT NOT NULL,
                    updated_at TEXT NOT NULL
                );
            """)
            self._conn.commit()

    # ── Conversations ─────────────────────────────────────────────────────────
    def save_message(self, role: str, content: str, session_id: str = 'default'):
        if not self._initialized:
            return
        now = datetime.now().isoformat()
        with self._lock:
            self._conn.execute(
                "INSERT INTO conversations (timestamp, role, content, session_id) VALUES (?,?,?,?)",
                (now, role, content[:2000], session_id)
            )
            self._conn.commit()

    def get_history(self, n: int = 20, session_id: str = 'default') -> List[Dict]:
        if not self._initialized:
            return []
        with self._lock:
            rows = self._conn.execute(
                "SELECT role, content, timestamp FROM conversations "
                "WHERE session_id=? ORDER BY id DESC LIMIT ?",
                (session_id, n)
            ).fetchall()
        return [{'role': r['role'], 'content': r['content'],
                 'timestamp': r['timestamp']} for r in reversed(rows)]

    def get_recent_messages(self, n: int = 10) -> List[Dict]:
        """Get last N messages as [role, content] dicts for LLM context."""
        history = self.get_history(n)
        return [{'role': h['role'], 'content': h['content']} for h in history]

    def clear_history(self, session_id: str = 'default'):
        with self._lock:
            self._conn.execute("DELETE FROM conversations WHERE session_id=?", (session_id,))
            self._conn.commit()

    # ── Preferences ───────────────────────────────────────────────────────────
    def set_preference(self, key: str, value: Any):
        if not self._initialized:
            return
        now = datetime.now().isoformat()
        val = json.dumps(value) if not isinstance(value, str) else value
        with self._lock:
            self._conn.execute(
                "INSERT OR REPLACE INTO preferences (key, value, updated_at) VALUES (?,?,?)",
                (key, val, now)
            )
            self._conn.commit()
        self._cache.put(f"pref_{key}", value)

    def get_preference(self, key: str, default: Any = None) -> Any:
        cached = self._cache.get(f"pref_{key}")
        if cached is not None:
            return cached
        if not self._initialized:
            return default
        with self._lock:
            row = self._conn.execute(
                "SELECT value FROM preferences WHERE key=?", (key,)
            ).fetchone()
        if not row:
            return default
        try:
            val = json.loads(row['value'])
        except Exception:
            val = row['value']
        self._cache.put(f"pref_{key}", val)
        return val

    # ── User profile ──────────────────────────────────────────────────────────
    def set_user_data(self, key: str, value: Any):
        self.set_preference(f"_user_{key}", value)
        # Also in user_profile table
        if not self._initialized:
            return
        now = datetime.now().isoformat()
        val = json.dumps(value) if not isinstance(value, str) else value
        with self._lock:
            self._conn.execute(
                "INSERT OR REPLACE INTO user_profile (key, value, updated_at) VALUES (?,?,?)",
                (key, val, now)
            )
            self._conn.commit()

    def get_user_data(self, key: str, default: Any = None) -> Any:
        return self.get_preference(f"_user_{key}", default)

    # ── Knowledge ─────────────────────────────────────────────────────────────
    def save_knowledge(self, key: str, value: Any, category: str = 'general'):
        if not self._initialized:
            return
        now = datetime.now().isoformat()
        val = json.dumps(value) if not isinstance(value, str) else value
        with self._lock:
            self._conn.execute(
                "INSERT OR REPLACE INTO knowledge (key, value, category, updated_at) VALUES (?,?,?,?)",
                (key, val, category, now)
            )
            self._conn.commit()

    def get_knowledge(self, key: str) -> Optional[Any]:
        if not self._initialized:
            return None
        with self._lock:
            row = self._conn.execute("SELECT value FROM knowledge WHERE key=?", (key,)).fetchone()
        if not row:
            return None
        try:
            return json.loads(row['value'])
        except Exception:
            return row['value']

    # ── Habits ────────────────────────────────────────────────────────────────
    def record_habit(self, action: str):
        if not self._initialized:
            return
        now = datetime.now().isoformat()
        hour = datetime.now().hour
        with self._lock:
            existing = self._conn.execute(
                "SELECT id, frequency FROM habits WHERE action=?", (action,)
            ).fetchone()
            if existing:
                self._conn.execute(
                    "UPDATE habits SET frequency=frequency+1, last_seen=?, hour_of_day=? WHERE id=?",
                    (now, hour, existing['id'])
                )
            else:
                self._conn.execute(
                    "INSERT INTO habits (action, frequency, last_seen, hour_of_day) VALUES (?,1,?,?)",
                    (action, now, hour)
                )
            self._conn.commit()

    def get_frequent_habits(self, n: int = 5) -> List[Dict]:
        if not self._initialized:
            return []
        with self._lock:
            rows = self._conn.execute(
                "SELECT action, frequency, last_seen FROM habits ORDER BY frequency DESC LIMIT ?",
                (n,)
            ).fetchall()
        return [dict(r) for r in rows]

    # ── Events ────────────────────────────────────────────────────────────────
    def log_event(self, event_type: str, data: Any = None, app: str = ''):
        if not self._initialized:
            return
        now = datetime.now().isoformat()
        with self._lock:
            self._conn.execute(
                "INSERT INTO events (timestamp, event_type, data, app) VALUES (?,?,?,?)",
                (now, event_type, json.dumps(data) if data else '', app)
            )
            self._conn.commit()

    # ── Utility ───────────────────────────────────────────────────────────────
    def close(self):
        if self._conn:
            try:
                self._conn.close()
            except Exception:
                pass

    def get_stats(self) -> Dict:
        if not self._initialized:
            return {}
        with self._lock:
            msg_count = self._conn.execute("SELECT COUNT(*) FROM conversations").fetchone()[0]
            pref_count = self._conn.execute("SELECT COUNT(*) FROM preferences").fetchone()[0]
            habit_count = self._conn.execute("SELECT COUNT(*) FROM habits").fetchone()[0]
        return {
            'messages': msg_count,
            'preferences': pref_count,
            'habits': habit_count,
            'db_path': self._db_path,
        }
