"""
MARK 11 — Cognitive Loop
Main autonomous loop: Perception → Analysis → Decision → Action → Memory.
Interval: 2.5 seconds. CPU target: < 5% idle.

Creator: Ali (Sidi3Ali)
System: MARK 11
"""

import logging
import threading
import time
from typing import Optional, Dict

logger = logging.getLogger('MARK11.CognitiveLoop')

LOOP_INTERVAL   = 2.5    # Fast loop: perception + decision
SLOW_INTERVAL   = 15.0   # Slow loop: deeper analysis


class CognitiveLoop:
    """
    MARK 11 main cognitive pipeline.
    Runs in background thread. Never blocks UI.
    Uses existing perception + decision modules.
    """

    def __init__(self, brain=None):
        self._brain = brain
        self._running = False
        self._paused = False
        self._thread: Optional[threading.Thread] = None
        self._slow_thread: Optional[threading.Thread] = None
        self._cycle_count = 0
        self._session_start = time.time()
        self._last_decision_time = 0.0

    def start(self):
        self._running = True
        # Fast loop
        self._thread = threading.Thread(
            target=self._fast_loop,
            name='MARK11-CognitiveLoop',
            daemon=True
        )
        self._thread.start()
        # Slow loop
        self._slow_thread = threading.Thread(
            target=self._slow_loop,
            name='MARK11-SlowLoop',
            daemon=True
        )
        self._slow_thread.start()
        logger.info("Cognitive Loop: iniciado.")

    def stop(self):
        self._running = False

    def pause(self):
        self._paused = True

    def resume(self):
        self._paused = False

    def _fast_loop(self):
        """Fast cycle: perception + decision (2.5s)."""
        while self._running:
            if not self._paused:
                try:
                    self._run_cycle()
                except Exception as e:
                    logger.debug(f"Fast loop error: {e}")
            time.sleep(LOOP_INTERVAL)

    def _slow_loop(self):
        """Slow cycle: deeper analysis (15s)."""
        time.sleep(10)  # Start delayed
        while self._running:
            if not self._paused:
                try:
                    self._run_slow_cycle()
                except Exception as e:
                    logger.debug(f"Slow loop error: {e}")
            time.sleep(SLOW_INTERVAL)

    def _run_cycle(self):
        """Execute one fast cognitive cycle."""
        self._cycle_count += 1
        b = self._brain
        if not b:
            return

        # ── Perception ────────────────────────────────────────────────────────
        ctx: Dict = {}
        sys_state: Dict = {}

        if hasattr(b, 'context_awareness') and b.context_awareness:
            try:
                c = b.context_awareness.get_context()
                if c:
                    ctx = c.to_dict()
            except Exception: pass

        if hasattr(b, 'sys_monitor') and b.sys_monitor:
            try:
                sys_state = b.sys_monitor.get_status()
            except Exception: pass
        else:
            try:
                import psutil
                sys_state = {
                    'cpu': psutil.cpu_percent(interval=None),
                    'ram_percent': psutil.virtual_memory().percent,
                }
                bat = psutil.sensors_battery()
                if bat:
                    sys_state['battery'] = bat.percent
                    sys_state['charging'] = bat.power_plugged
            except Exception: pass

        # ── Decision ──────────────────────────────────────────────────────────
        if hasattr(b, 'decision_engine') and b.decision_engine:
            try:
                decision = b.decision_engine.evaluate(ctx, sys_state)
                if decision:
                    b.decision_engine.record(decision)
                    self._execute_decision(decision)
            except Exception: pass

    def _execute_decision(self, decision):
        """Execute a decision: notify via voice/UI."""
        b = self._brain
        msg = decision.message
        logger.info(f"[DECISION] {decision.priority.upper()}: {msg}")

        if b and hasattr(b, 'voice') and b.voice and msg:
            try:
                is_priority = decision.priority in ('critical', 'high')
                b.voice.speak(msg, priority=is_priority)
            except Exception: pass

        if b and b._ui_callback:
            try:
                b._ui_callback('decision', {
                    'type': decision.type,
                    'priority': decision.priority,
                    'message': msg,
                })
            except Exception: pass

    def _run_slow_cycle(self):
        """Deeper analysis every 15 seconds."""
        b = self._brain
        if not b:
            return
        # Log activity to memory
        if (hasattr(b, 'context_awareness') and b.context_awareness and
                hasattr(b, 'memory') and b.memory):
            try:
                ctx = b.context_awareness.get_context()
                if ctx and ctx.user_activity != 'idle':
                    b.memory.record_habit(ctx.user_activity)
                    b.memory.log_event('activity', ctx.user_activity, ctx.active_app)
            except Exception: pass

    def get_status(self) -> Dict:
        uptime = (time.time() - self._session_start) / 60.0
        return {
            'running': self._running,
            'paused': self._paused,
            'cycles': self._cycle_count,
            'uptime_minutes': round(uptime, 1),
        }
