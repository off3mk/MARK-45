"""
MARK 11 — AI Manager
Motor principal: LM Studio + Qwen2.5-7B-Instruct-1M
Fallback: Pollinations.ai (online gratuito)
Optimizado: i5-9600K + RX 5700 XT + 16GB RAM

Creator: Ali (Sidi3Ali)
System: MARK 11
"""

import json
import logging
import time
import threading
import urllib.request
import urllib.error
from typing import Optional, List, Dict

logger = logging.getLogger('MARK11.AI')

LM_STUDIO_CHAT   = "http://127.0.0.1:1234/v1/chat/completions"
LM_STUDIO_MODELS = "http://127.0.0.1:1234/v1/models"
POLLINATIONS_URL  = "https://text.pollinations.ai/"

# ── System prompt MARK 11 ─────────────────────────────────────────────────────
MARK11_SYSTEM = """Eres MARK 11, el sistema operativo cognitivo personal creado por Ali (Sidi3Ali).

Tu función es actuar como un sistema operativo inteligente, no como un chatbot.

Reglas fundamentales:
- Eres el sistema operativo del usuario, no un asistente externo.
- Tu propósito es ayudar, ejecutar acciones, razonar y asistir proactivamente.
- Hablas de forma natural, calmada, precisa y eficiente.
- Te diriges al usuario por su nombre: Ali.
- NUNCA uses la palabra "Señor". Siempre usa "Ali" directamente.
- Nunca dices que eres un modelo de lenguaje ni una IA.
- Nunca dices que no puedes hacer algo sin ofrecer una alternativa.
- Eres directo, eficiente y profesional.

Capacidades:
- Controlar el sistema operativo
- Analizar contexto del usuario
- Ayudar con programación y código
- Tomar decisiones lógicas
- Ejecutar acciones cuando se solicite

Responde siempre en español. Respuestas concisas y útiles."""


class LMStudioEngine:
    """
    Cliente LM Studio optimizado para Qwen2.5-7B-Instruct-1M.
    Endpoint: http://127.0.0.1:1234/v1/chat/completions
    """

    def __init__(self, config: Dict = None):
        cfg = config or {}
        ai_cfg = cfg.get("ai", cfg)
        self.url        = ai_cfg.get("lmstudio_url", LM_STUDIO_CHAT)
        self.models_url = ai_cfg.get("lmstudio_models_url", LM_STUDIO_MODELS)
        self.timeout    = ai_cfg.get("timeout", 60)
        self.max_tokens = ai_cfg.get("max_tokens", 600)
        self.temperature= ai_cfg.get("temperature", 0.3)
        self.model      = ai_cfg.get("model_name", "qwen2.5-7b-instruct-1m")
        self.available  = False
        self._lock      = threading.Lock()
        self._check()

    def _check(self) -> bool:
        try:
            req = urllib.request.Request(
                self.models_url,
                headers={"Accept": "application/json"}
            )
            with urllib.request.urlopen(req, timeout=3) as r:
                data = json.loads(r.read().decode())
                models = data.get("data", [])
                if models:
                    # Use the loaded model name from LM Studio
                    self.model = models[0].get("id", self.model)
                self.available = True
                logger.info(f"LM Studio OK → modelo: {self.model}")
                return True
        except Exception:
            self.available = False
            return False

    def chat(self, messages: List[Dict], system: str = "",
             max_tokens: int = None, temperature: float = None) -> Optional[str]:
        if not self.available:
            return None

        full_messages = []
        if system:
            full_messages.append({"role": "system", "content": system})
        full_messages.extend(messages)

        payload = json.dumps({
            "model": self.model,
            "messages": full_messages,
            "max_tokens": max_tokens or self.max_tokens,
            "temperature": temperature or self.temperature,
            "top_p": 0.9,
            "stream": False,
        }).encode("utf-8")

        try:
            req = urllib.request.Request(
                self.url, data=payload,
                headers={"Content-Type": "application/json"}
            )
            with urllib.request.urlopen(req, timeout=self.timeout) as r:
                data = json.loads(r.read().decode())
                content = data["choices"][0]["message"]["content"].strip()
                return content if content else None
        except urllib.error.URLError:
            logger.debug("LM Studio: sin conexión")
            self.available = False
            return None
        except Exception as e:
            logger.debug(f"LM Studio error: {e}")
            return None

    def generate(self, prompt: str, system: str = "") -> Optional[str]:
        return self.chat([{"role": "user", "content": prompt}], system=system)

    def reconnect(self) -> bool:
        return self._check()


class PollinationsFallback:
    """Fallback online gratuito cuando LM Studio no está disponible."""

    def __init__(self):
        self._last_call  = 0.0
        self._min_interval = 3.0
        self._errors     = 0
        self._max_errors = 3

    def generate(self, prompt: str, system: str = "") -> Optional[str]:
        if self._errors >= self._max_errors:
            return None
        now = time.time()
        wait = self._min_interval - (now - self._last_call)
        if wait > 0:
            time.sleep(wait)
        try:
            import urllib.parse
            full = (system + "\n\n" + prompt) if system else prompt
            encoded = urllib.parse.quote(full[:1500])
            url = f"{POLLINATIONS_URL}{encoded}?model=openai&private=true"
            req = urllib.request.Request(url, headers={"User-Agent": "MARK11/1.0"})
            with urllib.request.urlopen(req, timeout=20) as r:
                text = r.read().decode("utf-8", errors="ignore").strip()
                self._last_call = time.time()
                self._errors = 0
                return text if len(text) > 3 else None
        except Exception as e:
            logger.debug(f"Pollinations: {e}")
            self._errors += 1
            self._last_call = time.time()
            return None


class LocalFallback:
    """Respuestas locales inteligentes. Sin red. Sin modelos."""

    def generate(self, text: str) -> str:
        import random
        t = text.lower().strip()
        if any(w in t for w in ["hola", "buenas", "hey"]):
            return random.choice([
                "Presente, Ali. ¿Qué necesitas?",
                "Aquí, Ali. ¿En qué te ayudo?",
                "Online. Dime.",
            ])
        if any(w in t for w in ["quien eres", "qué eres", "nombre"]):
            return "MARK 11 — sistema operativo cognitivo. Creado por Ali (Sidi3Ali)."
        if any(w in t for w in ["como estas", "estas bien", "todo bien"]):
            try:
                import psutil
                proc = psutil.Process()
                ram_mb = proc.memory_info().rss / 1024**2
                cpu = psutil.cpu_percent(0.1)
                return f"Operativo. CPU {cpu:.0f}%, MARK usa {ram_mb:.0f}MB RAM."
            except Exception:
                return "MARK 11 operativo. Nominal."
        if any(w in t for w in ["gracias", "perfecto", "genial"]):
            return random.choice(["A tu disposición, Ali.", "Sin problema."])
        if any(w in t for w in ["lm studio", "modelo", "ia"]):
            return "LM Studio no activo. Inícialo en puerto 1234 y carga Qwen2.5-7B."
        if "?" in text:
            return "LM Studio no está activo. Inícialo para respuestas elaboradas."
        return random.choice([
            "Recibido, Ali. ¿Cómo procedo?",
            "Entendido. ¿Más detalles?",
        ])


class AIManager:
    """
    MARK 11 — Gestor de IA.
    Prioridad: LM Studio (Qwen2.5-7B) → Pollinations → Local.
    """

    def __init__(self, config: Dict = None):
        self._config     = config or {}
        self.lmstudio    = LMStudioEngine(self._config)
        self.pollinations= PollinationsFallback()
        self.local       = LocalFallback()

        self._history: List[Dict] = []
        self._max_history: int = (
            self._config.get("ai", self._config).get("max_history", 10)
        )
        self._system_prompt = MARK11_SYSTEM
        self._lock = threading.Lock()
        self._source = "lmstudio" if self.lmstudio.available else "local"

        # Background monitor — reconnects LM Studio
        threading.Thread(
            target=self._monitor, daemon=True, name="MARK11-AIMonitor"
        ).start()

        logger.info(
            f"AI Manager: source={self._source} | "
            f"model={self.lmstudio.model} | "
            f"lmstudio={'OK' if self.lmstudio.available else 'INACTIVO'}"
        )

    def _monitor(self):
        while True:
            time.sleep(30)
            try:
                if not self.lmstudio.available:
                    if self.lmstudio.reconnect():
                        self._source = "lmstudio"
                        logger.info("AI: LM Studio reconectado.")
                else:
                    # Keep checking it's still alive
                    if not self.lmstudio._check():
                        self._source = "local"
            except Exception:
                pass

    def _build_messages(self, user_input: str, context: Dict = None):
        with self._lock:
            history = list(self._history[-self._max_history:])
        system = self._system_prompt
        if context:
            parts = []
            for k in ("active_app", "user_activity", "detected_mode"):
                v = context.get(k)
                if v:
                    parts.append(k + ": " + str(v))
            if parts:
                # Fix: build context string separately to avoid nested f-string
                ctx_str = " | ".join(parts)
                system = system + "\n\n[Contexto actual: " + ctx_str + "]"
        messages = history + [{"role": "user", "content": user_input}]
        return messages, system

    def ask(self, user_input: str, context: Dict = None) -> str:
        messages, system = self._build_messages(user_input, context)
        response = None

        # 1. LM Studio (Qwen2.5-7B)
        if self.lmstudio.available:
            response = self.lmstudio.chat(messages, system=system)
            if response:
                self._source = "lmstudio"

        # 2. Pollinations fallback
        if not response:
            response = self.pollinations.generate(user_input, system=system)
            if response:
                self._source = "pollinations"

        # 3. Local rules
        if not response:
            response = self.local.generate(user_input)
            self._source = "local"

        # Fix "Señor" from any source
        response = response.replace("Señor", "Ali").replace("señor", "Ali")

        with self._lock:
            self._history.append({"role": "user", "content": user_input})
            self._history.append({"role": "assistant", "content": response})
            if len(self._history) > self._max_history * 2:
                self._history = self._history[-(self._max_history * 2):]

        return response

    def generate_structured(self, prompt: str, max_tokens: int = 400) -> Optional[Dict]:
        if not self.lmstudio.available:
            return None
        system = self._system_prompt + "\n\nResponde SOLO con JSON válido. Sin markdown."
        result = self.lmstudio.chat(
            [{"role": "user", "content": prompt}],
            system=system, max_tokens=max_tokens, temperature=0.1
        )
        if not result:
            return None
        try:
            import re
            m = re.search(r"\{.*\}", result, re.DOTALL)
            if m:
                return json.loads(m.group())
        except Exception:
            pass
        return None

    def clear_history(self):
        with self._lock:
            self._history = []

    def get_source(self) -> str:
        return self._source

    def get_status(self) -> Dict:
        return {
            "active_source":     self._source,
            "lmstudio_available":self.lmstudio.available,
            "lmstudio_model":    self.lmstudio.model,
            "history_length":    len(self._history),
        }
