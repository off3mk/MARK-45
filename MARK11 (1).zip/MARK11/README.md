# MARK 11 — Cognitive Operating System
**Creator: Ali (Sidi3Ali)**
*Motor IA: LM Studio + Qwen2.5-7B-Instruct-1M*
*Hardware: i5-9600K | 16GB RAM | RX 5700 XT 8GB VRAM*

---

## Motor IA: LM Studio + Qwen2.5-7B

**Configuración LM Studio:**
```
Modelo:          Qwen2.5-7B-Instruct-1M-GGUF (Q4_K_M)
Temperature:     0.3
Top-P:           0.9
Context Length:  8192
GPU Layers:      20-35 (RX 5700 XT)
Endpoint:        http://127.0.0.1:1234/v1/chat/completions
```

**Setup:**
1. Descarga LM Studio: https://lmstudio.ai/download
2. Busca: `Qwen2.5-7B-Instruct-1M-GGUF`
3. Descarga cuantización `Q4_K_M`
4. **Server tab → Start Server** (puerto 1234)

**Cascada IA:** LM Studio → Pollinations.ai → Respuestas locales

---

## Inicio

```batch
install.bat      # Primera vez
start.bat        # Inicio normal (GUI + CLI fallback)
start_cli.bat    # Solo consola
```

---

## Arquitectura

```
MARK 11
├── main.py                 Entrada
├── core/
│   ├── brain.py            Orquestador central (Mark11Brain)
│   ├── ai_manager.py       LM Studio + Qwen2.5-7B (FIJO)
│   ├── memory.py           SQLite (mark11.db)
│   ├── user_identity.py    Detección creador Ali
│   ├── context_awareness.py  App/actividad en tiempo real
│   ├── decision_engine.py  Reglas autónomas
│   ├── cognitive_loop.py   Pipeline principal 2.5s
│   └── performance_manager.py  CPU/RAM de MARK
├── perception/
│   ├── system_monitor.py   CPU/RAM/batería
│   ├── activity_monitor.py Actividad usuario
│   └── screen_monitor.py   OCR bajo demanda
├── action/
│   ├── system_control.py   Apps, volumen
│   ├── ui_control.py       Click, teclado, ventanas
│   ├── browser_control.py  Navegador
│   └── code_executor.py    Python/PowerShell/CMD
├── voice/
│   ├── tts.py              edge-tts español
│   └── stt.py              Reconocimiento de voz
├── ui/
│   └── interface.py        GUI + Reactor Arc 3D
├── skills/                 Habilidades expandibles
├── config/config.json      Configuración central
└── memory/mark11.db        Base de datos SQLite
```

---

## Reactor Arc 3D — Colores por actividad

| Actividad    | Color       |
|--------------|-------------|
| idle         | Azul        |
| coding       | Verde       |
| writing      | Azul claro  |
| gaming       | Rojo        |
| watching     | Naranja     |
| music        | Violeta     |
| browsing     | Azul        |
| thinking     | Cian verde  |
| alert        | Rojo vivo   |

---

## Comandos principales

```
"abre chrome"               → Abre Chrome
"cierra spotify"            → Cierra Spotify  
"volumen 60"                → Volumen al 60%
"estado del sistema"        → CPU/RAM/disco
"navega a github.com"       → Abre URL
"captura pantalla"          → Screenshot
"ejecuta código print(42)"  → Python
"mark 11 status"            → Estado completo
"estado lm studio"          → Estado IA
"contexto actual"           → App/actividad actual
"cómo estás"                → Autodiagnóstico
"limpia historial"          → Borrar conversación
```

---

*MARK 11 — Created by Ali (Sidi3Ali). Todos los derechos reservados.*
