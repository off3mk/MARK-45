"""
MARK 10 — Code Executor
Run Python code, PowerShell, and CMD commands safely.

Creator: Ali (Sidi3Ali)
System: MARK 10
"""

import logging
import subprocess
import sys
import io
import os
import time
import tempfile
from typing import Dict

logger = logging.getLogger('MARK10.CodeExecutor')

WORKSPACE_DIR = os.path.join(os.path.dirname(os.path.dirname(__file__)), 'workspace')


class CodeExecutor:
    """Safe code execution with output capture and timeout."""

    def __init__(self):
        os.makedirs(WORKSPACE_DIR, exist_ok=True)

    def run_python(self, code: str, timeout: int = 15) -> Dict:
        """Execute Python code and capture output."""
        # Save to temp file for clean execution
        tmp = tempfile.NamedTemporaryFile(
            mode='w', suffix='.py', dir=WORKSPACE_DIR,
            delete=False, encoding='utf-8'
        )
        try:
            tmp.write(code)
            tmp.close()
            result = subprocess.run(
                [sys.executable, tmp.name],
                capture_output=True,
                text=True,
                timeout=timeout,
                cwd=WORKSPACE_DIR,
            )
            return {
                'success': result.returncode == 0,
                'stdout': result.stdout.strip()[:2000],
                'stderr': result.stderr.strip()[:500],
                'returncode': result.returncode,
            }
        except subprocess.TimeoutExpired:
            return {'success': False, 'stdout': '', 'stderr': f'Timeout: {timeout}s', 'returncode': -1}
        except Exception as e:
            return {'success': False, 'stdout': '', 'stderr': str(e), 'returncode': -1}
        finally:
            try:
                os.unlink(tmp.name)
            except Exception:
                pass

    def run_powershell(self, command: str, timeout: int = 20) -> Dict:
        """Execute PowerShell command."""
        try:
            result = subprocess.run(
                ['powershell', '-NoProfile', '-NonInteractive',
                 '-ExecutionPolicy', 'Bypass', '-Command', command],
                capture_output=True,
                text=True,
                timeout=timeout,
                encoding='utf-8',
                errors='ignore',
            )
            return {
                'success': result.returncode == 0,
                'stdout': result.stdout.strip()[:2000],
                'stderr': result.stderr.strip()[:500],
                'returncode': result.returncode,
            }
        except subprocess.TimeoutExpired:
            return {'success': False, 'stdout': '', 'stderr': 'Timeout', 'returncode': -1}
        except Exception as e:
            return {'success': False, 'stdout': '', 'stderr': str(e), 'returncode': -1}

    def run_cmd(self, command: str, timeout: int = 15) -> Dict:
        """Execute CMD command."""
        try:
            result = subprocess.run(
                command,
                shell=True,
                capture_output=True,
                text=True,
                timeout=timeout,
                encoding='utf-8',
                errors='ignore',
            )
            return {
                'success': result.returncode == 0,
                'stdout': result.stdout.strip()[:2000],
                'stderr': result.stderr.strip()[:500],
                'returncode': result.returncode,
            }
        except subprocess.TimeoutExpired:
            return {'success': False, 'stdout': '', 'stderr': 'Timeout', 'returncode': -1}
        except Exception as e:
            return {'success': False, 'stdout': '', 'stderr': str(e), 'returncode': -1}

    def format_result(self, result: Dict) -> str:
        """Format execution result as readable string."""
        if result['success']:
            out = result.get('stdout', '').strip()
            return out if out else "Ejecutado sin salida."
        else:
            err = result.get('stderr', '').strip() or result.get('stdout', '').strip()
            return f"Error (código {result.get('returncode','?')}): {err[:200]}"

    def save_script(self, code: str, filename: str) -> str:
        """Save script to workspace directory."""
        path = os.path.join(WORKSPACE_DIR, filename)
        try:
            with open(path, 'w', encoding='utf-8') as f:
                f.write(code)
            return f"Script guardado: {path}"
        except Exception as e:
            return f"Error guardando: {e}"
